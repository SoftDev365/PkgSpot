/*
 * Copyright 2015 Google Inc. All Rights Reserved.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.pkgspot.utils;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.pkgspot.R;
import com.pkgspot.activity.MainActivity;

import java.util.Map;


public class MyFcmListenerService extends FirebaseMessagingService {

    private static final String TAG = "MyFcmListenerService";
    private PrefStore prefStore;

    public static void displayMessage(Context context, Bundle extras) {
        Intent intent = new Intent(Const.DISPLAY_MESSAGE_ACTION);
        intent.putExtras(extras);
        context.sendBroadcast(intent);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        prefStore = new PrefStore(this);
        Map data = remoteMessage.getData();
        Log.e("bundle Data", "" + data);

        String from = remoteMessage.getFrom();
        Log.d(TAG, "From: " + from);
        Bundle bundle = new Bundle();
        bundle.putString("action", data.get("action").toString());
        bundle.putString("controller", data.get("controller").toString());
        bundle.putString("message", data.get("message").toString());
        if (data.containsKey("id")) {
            bundle.putInt("id", Integer.parseInt(data.get("id").toString()));
        }

        bundle.putBoolean("isPush", true);
        if (inForeground()) {
            displayMessage(this, bundle);
        } else {
            displayMessage(this, bundle);
            generateNotification(this, bundle);
        }
    }


    private boolean inForeground() {
        return prefStore.getBoolean(Const.FORGROUND);
    }


    public void generateNotification(Context context, Bundle extra) {
        String notificationMessage = extra.getString("message");
        int id = extra.getInt("id");

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context);
        mBuilder.setSmallIcon(R.drawable.ic_stat_name)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_stat_name));
        mBuilder.setContentTitle(this.getResources().getString(R.string.app_name))
                .setContentText(notificationMessage)
                .setAutoCancel(true);


        Uri NotiSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        mBuilder.setSound(NotiSound);
        long[] vibrate = {0, 100, 200, 300};
        mBuilder.setVibrate(vibrate);

        Intent resultIntent = new Intent(context, MainActivity.class);

        resultIntent.putExtras(extra);
        PendingIntent resultPendingIntent = PendingIntent.getActivity(this, id, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);

        NotificationManager mNotificationManager = (NotificationManager) context
                .getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(id, mBuilder.build());
    }
}
