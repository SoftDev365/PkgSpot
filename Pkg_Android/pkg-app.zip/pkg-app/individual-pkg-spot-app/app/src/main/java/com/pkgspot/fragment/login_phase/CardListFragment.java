package com.pkgspot.fragment.login_phase;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.pkgspot.R;
import com.pkgspot.adapter.CardListAdapter;
import com.pkgspot.data.CardData;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by TOXSL\chirag.tyagi on 18/9/17.
 */

public class CardListFragment extends BaseFragment {
    public EditText cardNumET, cvvET;
    public Spinner monthSP, yearSP;
    public AlertDialog dialogg;
    private View view;
    private RecyclerView listRV;
    private CardListAdapter listAdapter;
    private ArrayList<CardData> cardDatas = new ArrayList<>();
    private String customer_id, user_id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
        if (profileData.customer_id != null) {
            customer_id = profileData.customer_id;
            user_id = store.getString(Const.USER_ID);

        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_card_list, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        listRV = (RecyclerView) view.findViewById(R.id.listRV);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity().getBaseContext());
        listRV.setLayoutManager(linearLayoutManager);

        getCardList();


    }

    private void getCardList() {
        syncManager.sendToServer(Const.CARD_LIST + "/" + customer_id + "/" + user_id, null, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            cardDatas.clear();
            if (jsonObject.getString("url").equals(Const.CARD_LIST + "/" + customer_id + "/" + user_id)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        CardData cardData = new CardData();
                        cardData.cardId = object.getString("id");
                        cardData.last4 = object.getString("last4");
                        cardData.exp_month = object.getString("exp_month");
                        cardData.exp_year = object.getString("exp_year");
                        cardDatas.add(cardData);
                    }
                    setAdapter();

                } else {
                    if (listAdapter != null) {
                        listAdapter.notifyDataSetChanged();
                    }
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }


    private void setAdapter() {
        if (listAdapter == null) {
            listAdapter = new CardListAdapter(baseActivity, cardDatas, this);
            listRV.setAdapter(listAdapter);
        } else {
            listAdapter.notifyDataSetChanged();
        }
    }


    public void showCard(String last4) {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        View view = View.inflate(baseActivity, R.layout.dialog_card_add, null);
        builder.setView(view);
        cardNumET = (EditText) view.findViewById(R.id.cardNumET);
        monthSP = (Spinner) view.findViewById(R.id.monthSP);
        yearSP = (Spinner) view.findViewById(R.id.yearSP);
        cvvET = (EditText) view.findViewById(R.id.cvvET);

        cardNumET.setText(baseActivity.getString(R.string.last_four_unit, last4));
        Button okBT = (Button) view.findViewById(R.id.okBT);
        ImageView crossIV = (ImageView) view.findViewById(R.id.crossIV);

        ArrayList<Integer> years = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < 15; i++) {
            years.add(calendar.get(Calendar.YEAR));
            calendar.add(Calendar.YEAR, 1);
        }
        ArrayAdapter adapterYears = new ArrayAdapter(baseActivity, android.R.layout.simple_spinner_item, years);
        adapterYears.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSP.setAdapter(adapterYears);


        okBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cardNumET.getText().toString().trim().isEmpty()) {
                    baseActivity.showToastOne("Please enter card details");
                } else if (cvvET.getText().toString().isEmpty()) {
                    baseActivity.showToastOne("Please enter cvv number");
                } else {
                    hitPaymentApi();
                }
            }
        });

        dialogg = builder.create();
        crossIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogg.dismiss();
            }
        });
        dialogg.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialogg.setCancelable(false);
        dialogg.show();
    }

    private void hitPaymentApi() {
        baseActivity.showToastOne("Success");

    }

}
