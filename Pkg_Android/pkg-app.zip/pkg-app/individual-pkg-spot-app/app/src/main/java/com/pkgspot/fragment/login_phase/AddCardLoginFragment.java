package com.pkgspot.fragment.login_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.pkgspot.R;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.stripe.android.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by TOXSL\chirag.tyagi on 18/9/17.
 */

public class AddCardLoginFragment extends BaseFragment {
    private View view;
    private EditText nameET, cardET, dateET, cvvET;
    private Spinner monthSP, yearSP;
    private String userId, customer_id;
    private ArrayList<Integer> years;
    private ArrayList<Integer> months;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
        userId = store.getString(Const.USER_ID);
        if (profileData.customer_id != null) {
            customer_id = profileData.customer_id;
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_add_card_login, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        nameET = (EditText) view.findViewById(R.id.nameET);
        cardET = (EditText) view.findViewById(R.id.cardET);
        dateET = (EditText) view.findViewById(R.id.dateET);
        cvvET = (EditText) view.findViewById(R.id.cvvET);

        monthSP = (Spinner) view.findViewById(R.id.monthSP);
        yearSP = (Spinner) view.findViewById(R.id.yearSP);


        years = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < 15; i++) {
            years.add(calendar.get(Calendar.YEAR));
            calendar.add(Calendar.YEAR, 1);
        }


        ArrayAdapter adapterYears = new ArrayAdapter(baseActivity, android.R.layout.simple_spinner_item, years);
        adapterYears.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSP.setAdapter(adapterYears);


        months = new ArrayList<>();
        for (int i = 1; i < 13; i++) {
            months.add(i);
        }
        ArrayAdapter adapterMonths = new ArrayAdapter(baseActivity, android.R.layout.simple_spinner_item, months);
        adapterMonths.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        monthSP.setAdapter(adapterMonths);

        Button addBT = (Button) view.findViewById(R.id.addBT);
        addBT.setOnClickListener(this);

        getCardInfo();

    }

    private void getCardInfo() {
        syncManager.sendToServer(Const.CARD_LIST + "/" + customer_id + "/" + userId, null, this);
    }


    private boolean isValidate() {
        if (cardET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_card_number));
            return false;
        } else if (cardET.getText().toString().length() != 16) {
            showToast(getString(R.string.enter_valid_16_digit_number));
            return false;
        } else if (cvvET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_cvv_number));
            return false;
        } else {
            return true;
        }

    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.addBT:
                if (isValidate()) {
                    hitAddCardApi();
                }
                break;
        }
    }

    private void hitAddCardApi() {
        int year = (int) yearSP.getSelectedItem();
        Card card = new Card(cardET.getText().toString()
                , monthSP.getSelectedItemPosition() + 1
                , year
                , cvvET.getText().toString());

        boolean validation = card.validateCard();
        if (validation) {
            log("Card Validated");
            baseActivity.startProgressDialog();
            new Stripe().createToken(card, Const.PUBLISHABLE_KEY_TEST,
                    new TokenCallback() {
                        public void onSuccess(Token token) {
                            log("In success");
                            saveCardOnServer(token.getId());
                            baseActivity.stopProgressDialog();
                        }

                        public void onError(Exception error) {
                            log("In Error : " + error.getMessage());
                            log("In Error : " + error.getLocalizedMessage());
                            log("In Error : " + error.getCause());
                            log("In Error : " + error);
                            showToast(error.getLocalizedMessage());
                            baseActivity.stopProgressDialog();
                        }
                    });
        } else if (!card.validateNumber()) {
            showToast(baseActivity.getString(R.string.invalid_card_number));
            baseActivity.stopProgressDialog();
        } else if (!card.validateExpiryDate()) {
            showToast(baseActivity.getString(R.string.invalid_expiration_date));
            baseActivity.stopProgressDialog();
        } else if (!card.validateCVC()) {
            showToast(baseActivity.getString(R.string.invalid_cvc_code));
            baseActivity.stopProgressDialog();
        } else {
            showToast(baseActivity.getString(R.string.invalid_card_details));
            baseActivity.stopProgressDialog();
        }
    }

    private void saveCardOnServer(String id) {
        RequestParams params = new RequestParams();
        params.put("customer_id", customer_id);
        params.put("number", id);
        syncManager.sendToServer(Const.UPDATE_CARD + "/" + userId, params, this);

    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.UPDATE_CARD + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("Card Updated successfully");
                    baseActivity.getSupportFragmentManager().popBackStack();
                } else {
                    JSONObject error = jsonObject.getJSONObject("error");
                    baseActivity.showToastOne(error.getString("message"));
                }
            } else if (jsonObject.getString("url").equals(Const.CARD_LIST + "/" + customer_id + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        cardET.setText(baseActivity.getString(R.string.last_four_unit, object.getString("last4")));

                        yearSP.setSelection(years.indexOf(object.getInt("exp_year")));
                        monthSP.setSelection(months.indexOf(object.getInt("exp_month")));

                    }


                } else {

                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }


}
