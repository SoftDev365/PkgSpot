package com.pkgspot.utils;

public class Const {

    //        public static final String SERVER_REMOTE_URL = "http://192.168.2.26:3040/";         //Local
    public static final String SERVER_REMOTE_URL = "http://34.230.87.240/";           //Live
    public static final String DISPLAY_MESSAGE_ACTION = "com.packagename.DISPLAY_MESSAGE";
    public static final int PLAY_SERVICES_RESOLUTION_REQUEST = 1234;
    /**
     * ******************************* App buy or Purchase Key *************************************
     */
    public static final String IN_APP_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiwmkXRr/Ui6Onc3hZl8gvxe2D9DIyAELLBMryE2+iz1X6ToPAl2D+Lypytja+xc5u1s5yyfX5PzsruerkUfwm6nMjXwX2v64+syV3QjC1yQ3HuMCL4IJgu+jSymj8PQ+tBK9i8ehWm4NvYZ8KG6uCXnR2xqWQKgJEm0E96aMl7jwb7BvAvfn62/Frqlxw9n3V1f11CbgbQUbY8rOjpZvTZ+LF+Ly5NdFAM+H8BafdF7WQ0N3mmQfqmEBLamiqS/+5F5nGjSYrn2cjjBCbfDlQMxUS0fSjACQm+Ri6r5Qzi+cYyYt9Zn/i/U6Aimj/9qyoDwTV3TTMm2tv7lVn7VLnQIDAQAB";
    public static final int GALLERY_REQ = 1;
    public static final int CAMERA_REQ = 2;
    public static final int STATUS_OK = 200;
    public static final int STATUS_NOK = 1000;

    public static final int GOOGLE_PLACE = 5;

    public static final int TYPE_PAGE_HELP = 1;
    public static final int TYPE_TERMS_CUSTOMER = 2;
    public static final int TYPE_POLICY_CUSTOMER = 3;


    public static final int TYPE_LOCATION_SIGN_UP = 1;
    public static final int TYPE_MY_LOCATION = 2;
    public static final int TYPE_FIND_LOCATION = 3;


    public static final int POS_MY_LOCATION = 0;
    public static final int POS_FIND_LOCATION = 1;


    public static final String TIME_DURATION_WEEKLY = "0";
    public static final String TIME_DURATION_DAILY = "1";


    public static final String PUBLISHABLE_KEY_TEST = "pk_test_yxQ3QEFMkJK1xLAAIJb33mK3";

    public static final String STORE_USER_PROFILE_DATA = "userProfileData";
    public static final String ROW_ID = "news_id";
    public static final String USER_ID = "user_id";
    public static final String TITLE = "title";
    public static final String DEVICE_TOKEN = "device_token";
    public static final String FORGROUND = "forground_notification";

    public static final String STEP_1_SIGN_UP = "/api/user/customer";
    public static final String STEP_2_SIGN_UP = "/api/user/customer-step2";
    public static final String STEP_3_SIGN_UP = "/api/user/customer-step3";
    public static final String SIGN_UP_LOCATION = "/api/user/plocation";
    public static final String SIGN_UP_FINAL = "/api/user/signup-complete";
    public static final String ADD_CARD = "/api/user/add-card";
    public static final String FORGOT_PASSWORD = "/api/user/forgot-password";
    public static final String VERIFY_EMAIL = "/api/user/confirm-otp";


    public static final String CHANGE_PASSWORD = "/api/user/change-password";
    public static final String USER_PROFILE = "/api/user/profile";
    public static final String USER_INFO = "/api/user/info";
    public static final String HELP_PAGE = "/api/user/help-page";
    public static final String TERMS_PAGE = "/api/partner/terms";
    public static final String PACKAGE_INDEX = "/api/package/index";


    public static final String LOGIN = "/api/user/login";
    public static final String LOGOUT = "/api/user/logout";
    public static final String USER_CHECK = "/api/user/check";
    public static final String UPDATE_EMAIL = "/api/user/upadte-email";
    public static final String UPDATE_NAME = "/api/user/customer-update";
    public static final String ADD_CARD_LOGIN = "/api/user/card-detail";
    public static final String CARD_LIST = "/api/user/get-card-detail";
    public static final String UPDATE_CARD = "/api/user/update-card";
    public static final String ZIP_CODE_LIST = "/api/user/partner-zipcode";
    public static final String CITY_LIST = "/api/user/city";
    public static final String USER_CHANGE_NUMBER = "/api/user/change-number";


    public static final String MY_LOCATION = "/api/user/my-location";
    public static final String ADD_LOCATION = "/api/user/location";


    public static final String CARD_INFO = "/api/user/amount-detail";


    public static final String CODE_INFO = "/api/package/message-detail";

    public static final String PACKAGE_FILTER = "/api/package/filter";

    public static final String DOWNLOAD_PDF = "http://34.230.87.240/api/package/download/";


}