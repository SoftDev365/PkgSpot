package com.pkgspot.fragment.user_home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.MainActivity;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.fragment.login_phase.AddCardLoginFragment;
import com.pkgspot.fragment.login_phase.CardListFragment;
import com.pkgspot.fragment.sign_up_phase.AddPhoneFragment;
import com.pkgspot.utils.Const;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\riya.mahajan on 29/8/17.
 */

public class MyAccountFrag extends BaseFragment {
    private View view;
    private TextView addCardTV, nameTV, accountTV, acoountnoTV;
    private EditText changepwdET, phoneET, emailET, name1ET;
    private String userId;
    private ImageView editIV, editEmailIV, emailtcIV, editTcIV;
    private boolean isemail;
    private LinearLayout payInfoLL;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userId = store.getString(Const.USER_ID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_my_account, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
        getProfileInfo();
    }

    private void getProfileInfo() {
        if (userId != null) {
            syncManager.sendToServer(Const.USER_PROFILE + "/" + userId, null, this);
        } else {
            showToast("User Id not found");
        }
    }

    private void init() {
        addCardTV = (TextView) view.findViewById(R.id.addCardTV);
        nameTV = (TextView) view.findViewById(R.id.nameTV);
        accountTV = (TextView) view.findViewById(R.id.accountTV);
        acoountnoTV = (TextView) view.findViewById(R.id.acoountnoTV);
        payInfoLL = (LinearLayout) view.findViewById(R.id.payInfoLL);

        name1ET = (EditText) view.findViewById(R.id.name1ET);
        changepwdET = (EditText) view.findViewById(R.id.changepwdET);
        phoneET = (EditText) view.findViewById(R.id.phoneET);
        emailET = (EditText) view.findViewById(R.id.emailET);

        editIV = (ImageView) view.findViewById(R.id.editIV);
        editEmailIV = (ImageView) view.findViewById(R.id.editEmailIV);
        emailtcIV = (ImageView) view.findViewById(R.id.emailtcIV);
        editTcIV = (ImageView) view.findViewById(R.id.editTcIV);

        addCardTV.setOnClickListener(this);
        changepwdET.setOnClickListener(this);
        editIV.setOnClickListener(this);
        editEmailIV.setOnClickListener(this);
        emailtcIV.setOnClickListener(this);
        editTcIV.setOnClickListener(this);
        phoneET.setOnClickListener(this);
        payInfoLL.setOnClickListener(this);

        emailET.setEnabled(false);
        name1ET.setEnabled(false);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.changepwdET:
                Fragment fragment = new ChangePasswordFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, fragment)
                        .addToBackStack(null)
                        .commit();

                break;

            case R.id.addCardTV:
                baseActivity.getSupportFragmentManager()
                        .beginTransaction().
                        replace(R.id.container, new AddCardLoginFragment())
                        .addToBackStack(null)
                        .commit();
                break;

            case R.id.editIV:
                goToUpdateNameFragment();
                break;

            case R.id.editEmailIV:
                gotToUpdateEmailFragment();
                break;

            case R.id.emailtcIV:
                gotToUpdateEmailFragment();
                break;

            case R.id.editTcIV:
                goToUpdateNameFragment();
                break;

            case R.id.payInfoLL:
                gotoCardListFragment();
                break;

            case R.id.phoneET:
                gotoAddPhoneFragment();
                break;

        }
    }

    private void goToUpdateNameFragment() {
        Fragment fragment = new UpdateNameFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void gotToUpdateEmailFragment() {
        Fragment fragment = new UpdateEmailFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void gotoAddPhoneFragment() {
        Fragment fragment = new AddPhoneFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean("is_login", true);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void gotoCardListFragment() {
        Fragment fragment1 = new CardListFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment1)
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.USER_PROFILE + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        nameTV.setText(object.getString("full_name"));
                        name1ET.setText(object.getString("full_name"));

                        accountTV.setText(baseActivity.getString(R.string.account_unit, object.getString("unique_id")));
                        acoountnoTV.setText(object.getString("unique_id"));

                        emailET.setText(object.getString("email"));

                        phoneET.setText("+" + object.getString("contact_no"));

                        UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                        baseActivity.saveUserProfileDataInPrefStore(profileData);

                    }

                } else {
                    showToast(jsonObject.optString("error"));
                }
            } else if (jsonObject.getString("url").equals(Const.UPDATE_EMAIL + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    emailET.setEnabled(false);
                    emailtcIV.setVisibility(View.GONE);
                    editEmailIV.setVisibility(View.VISIBLE);
                    baseActivity.showToastOne("Email Changes Success");
                    if (jsonObject.has("data")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject object = data.getJSONObject(i);
                            UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                            baseActivity.saveUserProfileDataInPrefStore(profileData);
                        }
                    }
                } else {
                    elseErrorMsg(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.UPDATE_NAME + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    name1ET.setEnabled(false);
                    editTcIV.setVisibility(View.GONE);
                    editIV.setVisibility(View.VISIBLE);
                    baseActivity.showToastOne(getString(R.string.name_changes_success));
                    if (jsonObject.has("data")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject object = data.getJSONObject(i);
                            UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                            baseActivity.saveUserProfileDataInPrefStore(profileData);
                        }
                        ((MainActivity) baseActivity).updateDrawer();
                        UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
                        nameTV.setText(profileData.full_name);
                    }
                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
