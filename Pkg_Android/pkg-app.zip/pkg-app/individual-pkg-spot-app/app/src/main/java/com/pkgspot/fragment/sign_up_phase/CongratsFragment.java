package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class CongratsFragment extends BaseFragment {
    private View view;
    private TextView billnoTV, nameTV, addressTV, billno1TV, cityTV, zipTV, stateTV;
    private String user_id;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_id");
            hitInfoApi();
        }
    }

    private void hitInfoApi() {
        syncManager.sendToServer(Const.USER_INFO + "/" + user_id, null, this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_congratulations, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        billnoTV = (TextView) view.findViewById(R.id.billnoTV);
        nameTV = (TextView) view.findViewById(R.id.nameTV);
        addressTV = (TextView) view.findViewById(R.id.addressTV);
        billno1TV = (TextView) view.findViewById(R.id.billno1TV);
        cityTV = (TextView) view.findViewById(R.id.cityTV);
        zipTV = (TextView) view.findViewById(R.id.zipTV);
        stateTV = (TextView) view.findViewById(R.id.stateTV);

        nextBT.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                RequestParams params = new RequestParams();
                params.put("device_token", baseActivity.getUniqueDeviceId());
                syncManager.sendToServer(Const.SIGN_UP_FINAL + "/" + user_id, params, this);
                break;
        }
    }

    private void gotoThankuFragment() {
        Fragment fragment = new ThankYouFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.SIGN_UP_FINAL + "/" + user_id)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    gotoThankuFragment();
                } else {
                    showToast(jsonObject.optString("error"));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            if (jsonObject.getString("url").equals(Const.USER_INFO + "/" + user_id)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    billnoTV.setText(baseActivity.getString(R.string.pkg_unit, data.getString("userUniqueId")));

                    nameTV.setText(data.getString("userName"));
                    JSONArray location = data.getJSONArray("location");
                    if (location.length() == 0) {
                        addressTV.setText(baseActivity.getString(R.string.location_address));
                        cityTV.setText(baseActivity.getString(R.string.city_state));
                        zipTV.setText(baseActivity.getString(R.string.zip_code));
                        billno1TV.setText(baseActivity.getString(R.string.pkg_unit, data.getString("userUniqueId")));
                    } else {
                        for (int i = 0; i < location.length(); i++) {
                            JSONObject object = location.getJSONObject(i);
                            String address = object.getString("address");
                            String state = object.getString("state");
                            String country = object.getString("country");
                            String city = object.getString("city");

                            addressTV.setText(address);
                            if (country.equalsIgnoreCase("null")) {
                                log("if");
                                cityTV.setText(object.getString("city"));
                            } else {
                                log("else");
                                cityTV.setText(city + ", " + country);
                            }

                            if (state.equalsIgnoreCase("null")) {

                            } else {
                                stateTV.setText(state);
                            }

                            zipTV.setText(object.getString("zipcode"));
                            billno1TV.setText(baseActivity.getString(R.string.pkg_unit, data.getString("userUniqueId")));
                        }
                    }
                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
