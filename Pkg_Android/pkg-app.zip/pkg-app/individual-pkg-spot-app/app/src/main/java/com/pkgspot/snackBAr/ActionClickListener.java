package com.pkgspot.snackBAr;

public interface ActionClickListener {
    void onActionClicked(Snackbar snackbar);
}
