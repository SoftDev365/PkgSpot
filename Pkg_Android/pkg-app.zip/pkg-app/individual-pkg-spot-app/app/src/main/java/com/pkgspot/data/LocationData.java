package com.pkgspot.data;

/**
 * Created by TOXSL\chirag.tyagi on 11/9/17.
 */

public class LocationData {
    public int id;
    public String name;
    public String address;
    public String latitude;
    public String longitude;
    public String city;
    public String country;
    public String operating_as;
    public String zipcode;
    public boolean isChecked;
    public DaysData daysData;

}
