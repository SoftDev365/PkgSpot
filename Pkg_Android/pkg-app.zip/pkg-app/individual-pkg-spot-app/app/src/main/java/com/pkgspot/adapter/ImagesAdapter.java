package com.pkgspot.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by TOXSL\chirag.tyagi on 26/10/17.
 */

public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.MyViewHolder> {
    private BaseActivity baseActivity;
    private ArrayList<String> images = new ArrayList<>();

    public ImagesAdapter(BaseActivity baseActivity, ArrayList<String> imageList) {
        this.baseActivity = baseActivity;
        this.images = imageList;

    }

    @Override
    public ImagesAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(baseActivity).inflate(R.layout.adapter_image_dailog, parent, false);
        return new ImagesAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ImagesAdapter.MyViewHolder holder, int position) {
        try {
            Picasso.with(baseActivity).load(images.get(holder.getAdapterPosition())).into(holder.imageIV);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return images.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageIV;


        public MyViewHolder(View itemView) {
            super(itemView);
            imageIV = (ImageView) itemView.findViewById(R.id.imageIV);
        }
    }
}
