package com.pkgspot.fragment.login_phase;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pkgspot.BuildConfig;
import com.pkgspot.R;
import com.pkgspot.activity.MainActivity;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\chirag.tyagi on 23/8/17.
 */

public class LoginFragment extends BaseFragment {
    private View view;
    private EditText emailET, passwordET;
    private TextView forgotTV;
    private Button loginBT;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_login, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        emailET = (EditText) view.findViewById(R.id.emailET);
        passwordET = (EditText) view.findViewById(R.id.passwordET);

        forgotTV = (TextView) view.findViewById(R.id.forgotTV);
        loginBT = (Button) view.findViewById(R.id.loginBT);


        forgotTV.setOnClickListener(this);
        loginBT.setOnClickListener(this);


        if (BuildConfig.DEBUG) {
            emailET.setText("parwinderdeep95@gmail.com");
            passwordET.setText("aA@123");
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.forgotTV:
                Fragment fragment = new ForgotPasswordFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .addToBackStack(null)
                        .commit();
                break;
            case R.id.loginBT:
                if (isValidate()) {
                    hitLoginApi();
                }
                break;
        }
    }

    private boolean isValidate() {
        if (emailET.getText().toString().isEmpty()) {
            showToast(baseActivity.getString(R.string.enter_email));
            return false;
        } else if (!baseActivity.isValidMail(emailET.getText().toString())) {
            showToast(baseActivity.getString(R.string.enter_valid_email));
            return false;
        } else if (passwordET.getText().toString().isEmpty()) {
            showToast(baseActivity.getString(R.string.enter_password));
            return false;
        } else {
            return true;
        }
    }

    private void hitLoginApi() {
        RequestParams params = new RequestParams();
        params.put("email", emailET.getText().toString().trim());
        params.put("password", passwordET.getText().toString().trim());
        String device_token = store.getString(Const.DEVICE_TOKEN);
        if (device_token == null || device_token.isEmpty()) {
            params.put("device_token", baseActivity.getUniqueDeviceId());
            showToast(getString(R.string.not_reg_fcm));
        } else {
            params.put("device_token", device_token);
        }
        params.put("type", 1);
        syncManager.sendToServer(Const.LOGIN, params, this);
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.LOGIN)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    syncManager.setLoginStatus(jsonObject.optString("auth_code"));
                    store.saveString(Const.USER_ID, jsonObject.optString("userId"));
                    if (jsonObject.has("data")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject object = data.getJSONObject(i);
                            UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                            baseActivity.saveUserProfileDataInPrefStore(profileData);
                        }
                    }
                    gotoMainActivity();
                } else {
                    showToast(jsonObject.optString("error"));
                    if (jsonObject.has("step")) {
                        String userId = jsonObject.optString("userId");
                        switch (jsonObject.getInt("step")) {
                            case 1:
                                gotoAddPhoneFragment(userId);
                                break;
                            case 2:
                                gotoLocationFragment(true, userId);
                                break;
                            case 3:
                                gotoAddcardFragment(true, userId);
                                break;

                            case 0:
                                break;

                            default:
                                showToast(baseActivity.getString(R.string.error_in_streps));
                                break;

                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void gotoMainActivity() {
        startActivity(new Intent(baseActivity, MainActivity.class));
        baseActivity.finishAffinity();
    }
}
