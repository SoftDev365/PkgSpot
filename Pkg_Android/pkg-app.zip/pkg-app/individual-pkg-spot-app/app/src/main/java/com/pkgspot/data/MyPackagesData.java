package com.pkgspot.data;

import java.util.ArrayList;

/**
 * Created by TOXSL\chirag.tyagi on 26/10/17.
 */

public class MyPackagesData {
    public int id;
    public String cuid;
    public String customer_name;
    public String puid;
    public String business_name;
    public String package_count;
    public String recived_date;
    public String price_per_pkg;
    public String total_price;
    public String recived_time;
    public String pickedup_time;
    public String address;
    public ArrayList<String> imageList = new ArrayList<>();
}
