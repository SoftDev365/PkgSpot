package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.PhoneAuthProvider;
import com.hbb20.CountryCodePicker;
import com.pkgspot.BuildConfig;
import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;

/**
 * Created by TOXSL\chirag.tyagi on 28/8/17.
 */

public class AddPhoneFragment extends BaseFragment {
    private View view;
    private CountryCodePicker ccp;
    private EditText phoneET;
    private String user_id;
    private TextView msgTV;
    private boolean is_login = false;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("userId")) {
            user_id = bundle.getString("userId");
        } else if (store.containValue(Const.USER_ID)) {
            user_id = store.getString(Const.USER_ID);
        }


        if (bundle != null && bundle.containsKey("is_login")) {
            is_login = bundle.getBoolean("is_login");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_add_phone, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        ccp = (CountryCodePicker) view.findViewById(R.id.ccp);

        msgTV = (TextView) view.findViewById(R.id.msgTV);

        phoneET = (EditText) view.findViewById(R.id.phoneET);

        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);

        if (BuildConfig.DEBUG) {
            phoneET.setText("1234");
        }

        if (is_login) {
            msgTV.setText("Update your phone number");
        }

    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                if (phoneET.getText().toString().isEmpty()) {
                    showToast("Please enter phone number");
                } else {
                    gotoVerificationFragment();
                }
                break;
        }
    }


    private void gotoVerificationFragment() {
        Fragment fragment = new VerificationFragment();
        Bundle bundle = new Bundle();
        bundle.putString("user_id", user_id);
        bundle.putBoolean("is_login", is_login);
        bundle.putString("phone_no", ccp.getSelectedCountryCode() + phoneET.getText().toString());
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


}
