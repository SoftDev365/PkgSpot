package com.pkgspot.fragment.sign_up_phase;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.Html;
import android.text.Spannable;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.pkgspot.BuildConfig;
import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.pkgspot.utils.Mask;
import com.stripe.android.Stripe;
import com.stripe.android.TokenCallback;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class AddCardFragment extends BaseFragment {
    private View view;
    private TextView termTV, firstTV, secondTV;
    private Button nextBT;
    private EditText nameET, cardET, dateET, cvvET;
    private String user_id;
    private Spinner monthSP, yearSP;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_id");
        }

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_add_card, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        termTV = (TextView) view.findViewById(R.id.termsTV);
        firstTV = (TextView) view.findViewById(R.id.firstTV);
        secondTV = (TextView) view.findViewById(R.id.secondTV);

        nameET = (EditText) view.findViewById(R.id.nameET);
        cardET = (EditText) view.findViewById(R.id.cardET);
        dateET = (EditText) view.findViewById(R.id.dateET);
        cvvET = (EditText) view.findViewById(R.id.cvvET);

        nextBT = (Button) view.findViewById(R.id.nextBT);

        monthSP = (Spinner) view.findViewById(R.id.monthSP);
        yearSP = (Spinner) view.findViewById(R.id.yearSP);

        ArrayList<Integer> years = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < 15; i++) {
            years.add(calendar.get(Calendar.YEAR));
            calendar.add(Calendar.YEAR, 1);
        }
        ArrayAdapter adapterYears = new ArrayAdapter(baseActivity, android.R.layout.simple_spinner_item, years);
        adapterYears.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSP.setAdapter(adapterYears);


        TextWatcher cpfMask = Mask.insert("##/##", dateET);
        dateET.addTextChangedListener(cpfMask);


        nextBT.setOnClickListener(this);
        String styledText = getString(R.string.terms_one) + " " + getString(R.string.terms_condition) + " " + getString(R.string.and) + " " + getString(R.string.privacy);
        termTV.setText(Html.fromHtml(styledText), TextView.BufferType.SPANNABLE);

        int index = styledText.indexOf(getString(R.string.privacy));
        int len = getString(R.string.privacy).length();

        int index_privacy = styledText.indexOf(getString(R.string.terms_condition));
        int len_privacy = getString(R.string.terms_condition).length();


        Spannable span = Spannable.Factory.getInstance().newSpannable(styledText);

        ClickableSpan clickSpan = new ClickableSpan() {
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setColor(ContextCompat.getColor(baseActivity, R.color.colorPrimary));    // you can use custom color
                ds.setUnderlineText(false);    // this remove the underline
            }

            @Override
            public void onClick(View textView) {
                // handle click event
                syncManager.sendToServer(Const.TERMS_PAGE + "/" + Const.TYPE_POLICY_CUSTOMER, null, AddCardFragment.this);
            }
        };
        ClickableSpan clickSpan2 = new ClickableSpan() {
            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setColor(ContextCompat.getColor(baseActivity, R.color.colorPrimary));    // you can use custom color
                ds.setUnderlineText(false);    // this remove the underline
            }

            @Override
            public void onClick(View textView) {
                // handle click event
                syncManager.sendToServer(Const.TERMS_PAGE + "/" + Const.TYPE_TERMS_CUSTOMER, null, AddCardFragment.this);
            }
        };


        span.setSpan(clickSpan, index, index + len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        span.setSpan(clickSpan2, index_privacy, index_privacy + len_privacy, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        termTV.setText(span);
        termTV.setMovementMethod(LinkMovementMethod.getInstance());


        if (BuildConfig.DEBUG) {
            nameET.setText("Bob");
            cardET.setText("4111111111111111");
            dateET.setText("12/24");
        }

        hitgetContent();
    }

    private void hitgetContent() {
        syncManager.sendToServer(Const.CARD_INFO, null, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                if (isValidate()) {
                    submitDetails();
                }

                break;
        }
    }


    private boolean isValidate() {
        if (nameET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_name));
            return false;
        } else if (cardET.getText().toString().isEmpty()) {
            showToast(baseActivity.getString(R.string.enter_card_number));
            return false;
        } else if (cardET.getText().toString().length() != 16) {
            showToast(baseActivity.getString(R.string.enter_valid_16_digit_number));
            return false;
        } else if (cvvET.getText().toString().isEmpty()) {
            showToast(baseActivity.getString(R.string.enter_cvv_number));
            return false;
        } else {
            return true;
        }

    }


    private void submitDetails() {
        int year = (int) yearSP.getSelectedItem();
        Card card = new Card(cardET.getText().toString()
                , monthSP.getSelectedItemPosition() + 1
                , year
                , cvvET.getText().toString());

        boolean validation = card.validateCard();
        if (validation) {
            log("Card Validated");
            baseActivity.startProgressDialog();
            new Stripe().createToken(card, Const.PUBLISHABLE_KEY_TEST,
                    new TokenCallback() {
                        public void onSuccess(Token token) {
                            log("In success");
                            saveCardOnServer(token.getId());
                            baseActivity.stopProgressDialog();
                        }

                        public void onError(Exception error) {
                            log("In Error : " + error.getMessage());
                            log("In Error : " + error.getLocalizedMessage());
                            log("In Error : " + error.getCause());
                            log("In Error : " + error);
                            showToast(error.getLocalizedMessage());
                            baseActivity.stopProgressDialog();
                        }
                    });
        } else if (!card.validateNumber()) {
            showToast(baseActivity.getString(R.string.invalid_card_number));
            baseActivity.stopProgressDialog();
        } else if (!card.validateExpiryDate()) {
            showToast(baseActivity.getString(R.string.invalid_expiration_date));
            baseActivity.stopProgressDialog();
        } else if (!card.validateCVC()) {
            showToast(baseActivity.getString(R.string.invalid_cvc_code));
            baseActivity.stopProgressDialog();
        } else {
            showToast(baseActivity.getString(R.string.invalid_card_details));
            baseActivity.stopProgressDialog();
        }
    }

    private void saveCardOnServer(String id) {
        if (user_id != null && !user_id.isEmpty()) {
            RequestParams params = new RequestParams();
            params.put("name", nameET.getText().toString().trim());
            params.put("number", id);
            syncManager.sendToServer(Const.ADD_CARD + "/" + user_id, params, this);
        } else {
            baseActivity.showToastOne("Token:" + id);
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.ADD_CARD + "/" + user_id)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    gotoCongratsFragment(user_id);
                } else {
                    JSONObject error = jsonObject.getJSONObject("error");
                    baseActivity.showToastOne(error.getString("message"));
                }
            } else if (jsonObject.getString("url").equals(Const.TERMS_PAGE + "/" + Const.TYPE_TERMS_CUSTOMER)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        String title = object.getString("title");
                        String description = object.getString("description");
                        openAlertDialog(title, description);
                    }
                } else {
                    showToast(jsonObject.optString("error"));
                }
            } else if (jsonObject.getString("url").equals(Const.TERMS_PAGE + "/" + Const.TYPE_POLICY_CUSTOMER)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        String title = object.getString("title");
                        String description = object.getString("description");
                        openAlertDialog(title, description);
                    }

                } else {
                    showToast(jsonObject.optString("error"));
                }
            } else if (jsonObject.getString("url").equals(Const.CARD_INFO)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    firstTV.setText("Your first " + data.getString("freePackage") + " Packages are FREE");
                    secondTV.setText(baseActivity.getString(R.string.then) + " " + baseActivity.getString(R.string.money_unit, data.getString("amountPerPackage")) + " "
                            + baseActivity.getString(R.string.per_package) + " " + baseActivity.getString(R.string.days_unit, data.getString("validPickUpDay")) + " "
                            + baseActivity.getString(R.string.will_incure) + " " + baseActivity.getString(R.string.money_unit, data.getString("lateFeeAmount")) + " "
                            + getTypeFees(data.getString("timeDuration")) + " " + baseActivity.getString(R.string.credit_card_req));

                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private String getTypeFees(String timeDuration) {
        String s;
        switch (timeDuration) {
            case Const.TIME_DURATION_DAILY:
                s = getString(R.string.daily);
                break;
            case Const.TIME_DURATION_WEEKLY:
                s = getString(R.string.weekly);
                break;

            default:
                s = getString(R.string.weekly);
                break;

        }
        return s;
    }

    private void openAlertDialog(String title, String description) {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        builder.setTitle(title);
        builder.setMessage(description);
        builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }
}








