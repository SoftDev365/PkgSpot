package com.pkgspot.activity;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.adapter.DrawerAdapter;
import com.pkgspot.data.DrawerData;
import com.pkgspot.data.LocationData;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.MyLocationFragment;
import com.pkgspot.fragment.login_phase.QrCodeFragment;
import com.pkgspot.fragment.user_home.HelpFragment;
import com.pkgspot.fragment.user_home.MyAccountFrag;
import com.pkgspot.fragment.user_home.MyPackagesFrag;
import com.pkgspot.utils.Const;
import com.pkgspot.utils.ImageUtils;
import com.pkgspot.utils.PrefStore;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by neeraj.narwal on 5/7/16.
 */
public class MainActivity extends BaseActivity implements BaseActivity.PermCallback, ImageUtils.ImageSelectCallback {
    private DrawerLayout drawer;
    private List<DrawerData> heading = new ArrayList<>();
    private LinearLayout headLL;
    private ImageView profilePicCIV;
    private TextView nameTV, accountTV;
    private ExpandableListView drawerLV;
    private ActionBarDrawerToggle toggle;
    private ArrayList<DrawerData> drawerItems = new ArrayList<>();
    private ArrayList<DrawerData> childDrawerItems = new ArrayList<>();
    private DrawerAdapter drawerAdapter;
    private long times_in_millies = 60 * 1000 * 5;  // 5 minutes timer
    private CountDownTimer cTimer;
    private long remianing_times_in_millies;
    //////////////////Example set get Array list//////////////////
    private ArrayList<DrawerData> drawerDatas = new ArrayList<>();
    private PrefStore prefStore;
    private List<DrawerData> listDataHeader; // header titles
    // child data in format of header title, child title
    private HashMap<DrawerData, List<DrawerData>> listDataChild;
    private String userID;
    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            getNotificationBundleIfExist(intent);
        }
    };
    private ArrayList<LocationData> datas = new ArrayList<>();

    private void getNotificationBundleIfExist(Intent intent) {
        if (intent.getExtras().getBoolean("isPush", false)) {
            try {
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                r.play();
            } catch (Exception e) {
                e.printStackTrace();
            }

            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.cancelAll();
            Bundle notifyBundle = intent.getExtras();
            int id = notifyBundle.getInt("id");
            String action = notifyBundle.getString("action");
            String controller = notifyBundle.getString("controller");
            String message = notifyBundle.getString("message");

            Fragment fragment = null;
            Bundle bundle = new Bundle();
            assert controller != null;
            switch (controller) {
                case "package":
                    assert action != null;
                    if (action.equalsIgnoreCase("upload")) {
                        fragment = new QrCodeFragment();
                        showToast(message);
                    }
                    break;

                default:
                    init();
                    break;
            }
            if (fragment != null) {
                fragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, fragment)
                        .commit();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        gotoMyPackageFrag();
        init();
        initDrawer();
        savearraylist();

        if (prefStore.containValue(Const.USER_ID)) {
            userID = prefStore.getString(Const.USER_ID);
        }

    }
    ////////////////////////////////////////////////////


    @Override
    protected void onResume() {
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, new IntentFilter(Const.DISPLAY_MESSAGE_ACTION));
        super.onResume();
    }

    @Override
    public void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        super.onPause();
    }


    private void savearraylist() {
        prefStore = new PrefStore(this);
        for (int i = 0; i < 10; i++) {
            DrawerData drawerData = new DrawerData();
            drawerData.name = "name" + i;
            drawerDatas.add(drawerData);
        }
        //setdata
        prefStore.setData("key", drawerDatas);

        drawerDatas.clear();
        //getdata
        drawerDatas = prefStore.getData("key");
    }

    private void init() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawer = (DrawerLayout) findViewById(R.id.drawer);
        headLL = (LinearLayout) findViewById(R.id.headLL);
        profilePicCIV = (ImageView) findViewById(R.id.profilePicCIV);
        nameTV = (TextView) findViewById(R.id.nameTV);
        accountTV = (TextView) findViewById(R.id.accountTV);
        headLL.requestLayout();
        headLL.setOnClickListener(this);
        drawerLV = (ExpandableListView) findViewById(R.id.drawerLV);

        toggle = new ActionBarDrawerToggle(this, drawer, null,
                R.string.app_name, R.string.app_name) {

            @Override
            public void onDrawerOpened(View drawerView) {
                toggle.setHomeAsUpIndicator(R.mipmap.ic_more);
                invalidateOptionsMenu();
//                hitMyLocationApi();
                hitProfileApi();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                toggle.setHomeAsUpIndicator(R.mipmap.ic_menu);
                invalidateOptionsMenu();
            }
        };
        toggle.setDrawerIndicatorEnabled(false);
        toggle.setHomeAsUpIndicator(R.mipmap.ic_menu);

        drawer.addDrawerListener(toggle);
        updateDrawer();
    }

    private void hitProfileApi() {
        syncManager.sendToServer(Const.USER_PROFILE + "/" + userID, null, this);
    }

    private void hitMyLocationApi() {
        syncManager.sendToServer(Const.MY_LOCATION + "/" + userID, null, this);

    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        toggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else {
                    drawer.openDrawer(GravityCompat.START);
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void updateDrawer() {
        UserProfileData profileData = getUserProfileDataFromPrefStore();
        nameTV.setText(profileData.full_name);
        accountTV.setText(getString(R.string.account_unit, profileData.unique_id));
    }

    private void initDrawer() {
        UserProfileData profileData = getUserProfileDataFromPrefStore();
        Integer icons[] = {R.mipmap.ic_list
                , R.mipmap.ic_map_location_b
                , R.mipmap.ic_user
                , R.mipmap.ic_help
                , R.mipmap.ic_logout};
        String[] names = getResources().getStringArray(R.array.drawer_items);
        for (int i = 0; i < icons.length; i++) {
            DrawerData drawerData = new DrawerData();
            drawerData.icon = icons[i];
            drawerData.name = names[i];
            drawerItems.add(drawerData);
        }
        prepareListData(drawerItems, profileData.location);
        drawerAdapter = new DrawerAdapter(this, listDataHeader, listDataChild, datas);
        drawerLV.setAdapter(drawerAdapter);
        drawerLV.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                int count = parent.getExpandableListAdapter().getChildrenCount(groupPosition);
                if (count == 0) {
                    Fragment frag = null;
                    switch (groupPosition) {
                        case 0:
                            frag = new MyPackagesFrag();
                            break;
                        case 1:
                            frag = new MyLocationFragment();
                            break;
                        case 2:
                            frag = new MyAccountFrag();
                            break;
                        case 3:
                            frag = new HelpFragment();
//                            frag = new QrCodeFragment();
                            break;
                        case 4:
                            hitLogout();
                            break;
                        default:
                            frag = new MyPackagesFrag();
                            break;
                    }
                    if (frag != null) {
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container, frag)
                                .commit();
                    }
                    drawer.closeDrawers();
                }

                return false;
            }
        });
        // Listview Group expanded listener
        drawerLV.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {

            }
        });

        // Listview Group collasped listener
        drawerLV.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {

            }
        });

        // Listview on child click listener
        setClickChild(profileData);
    }

    private void setClickChild(UserProfileData profileData) {
        if (profileData.location != null && !profileData.location.isEmpty()) {
            drawerLV.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

                @Override
                public boolean onChildClick(ExpandableListView parent, View v,
                                            int groupPosition, int childPosition, long id) {

                    switch (childPosition) {
                        case 0:
                            Fragment fragment = new MyLocationFragment();
                            Bundle bundle = new Bundle();
                            bundle.putInt("position", childPosition);
                            bundle.putInt("type", Const.TYPE_MY_LOCATION);
                            fragment.setArguments(bundle);
                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.container, fragment)
                                    .commit();
                            drawer.closeDrawers();
                            break;
                        case 1:
                            Fragment fragment1 = new MyLocationFragment();
                            Bundle bundle1 = new Bundle();
                            bundle1.putInt("position", childPosition);
                            bundle1.putBoolean("is_sign_up", true);
                            bundle1.putInt("type", Const.TYPE_FIND_LOCATION);
                            fragment1.setArguments(bundle1);
                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.container, fragment1)
                                    .commit();
                            drawer.closeDrawers();
                            break;

                    }
                    return false;
                }
            });
        } else {
            drawerLV.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {

                @Override
                public boolean onChildClick(ExpandableListView parent, View v,
                                            int groupPosition, int childPosition, long id) {
                    switch (childPosition) {
                        case 0:
                            Fragment fragment1 = new MyLocationFragment();
                            Bundle bundle1 = new Bundle();
                            bundle1.putInt("position", childPosition);
                            bundle1.putBoolean("is_sign_up", true);
                            bundle1.putInt("type", Const.TYPE_FIND_LOCATION);
                            fragment1.setArguments(bundle1);
                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.container, fragment1)
                                    .commit();
                            drawer.closeDrawers();
                            break;

                    }
                    return false;
                }
            });
        }
    }

    private void hitLogout() {
        RequestParams params = new RequestParams();
        params.put("device_token", "device_token");
        syncManager.sendToServer(Const.LOGOUT, params, this);
    }

    @Override
    public void permGranted(int resultCode) {
        showToast("after permission");
    }

    @Override
    public void permDenied(int resultCode) {

    }

    private void prepareListData(ArrayList<DrawerData> drawerData, String location) {

        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<>();


        listDataHeader.clear();
        for (int i = 0; i < drawerData.size(); i++) {
            listDataHeader.add(drawerData.get(i));
        }

        childDrawerItems.clear();
        heading.clear();
        if (location != null && !location.isEmpty()) {
            Integer icons[] = {R.mipmap.ic_map_location
                    , R.mipmap.ic_add};
            String[] names = getResources().getStringArray(R.array.location_item);
            for (int i = 0; i < icons.length; i++) {
                DrawerData drawerData1 = new DrawerData();
                drawerData1.icon = icons[i];
                drawerData1.name = names[i];
                childDrawerItems.add(drawerData1);
            }

            for (int i = 0; i < childDrawerItems.size(); i++) {
                heading.add(childDrawerItems.get(i));
            }

            if (drawerAdapter != null) {
                drawerAdapter.notifyDataSetChanged();
            }

        } else {
            Integer icons[] = {R.mipmap.ic_add};
            String[] names = getResources().getStringArray(R.array.location);
            for (int i = 0; i < icons.length; i++) {
                DrawerData drawerData1 = new DrawerData();
                drawerData1.icon = icons[i];
                drawerData1.name = names[i];
                childDrawerItems.add(drawerData1);
            }

            for (int i = 0; i < childDrawerItems.size(); i++) {
                heading.add(childDrawerItems.get(i));
            }

            if (drawerAdapter != null) {
                drawerAdapter.notifyDataSetChanged();
            }
        }


        // Header, Child data
        listDataChild.put(listDataHeader.get(1), heading);
    }

    @Override
    public void onImageSelected(String imagePath, int resultCode) {

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.headRL:
                gotoMyaccountFrag();
                drawer.closeDrawers();
                break;
        }
    }

    private void gotoMyaccountFrag() {
        Fragment fragment = new MyAccountFrag();
        getSupportFragmentManager().
                beginTransaction().
                replace(R.id.container, fragment)
                .commit();
    }

    private void gotoMyPackageFrag() {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment fragment = new MyPackagesFrag();
        getSupportFragmentManager().
                beginTransaction().
                replace(R.id.container, fragment)
                .commit();
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        if (fragment instanceof MyPackagesFrag) {
            back();
        } else if (fragment instanceof MyAccountFrag) {
            gotoMyPackageFrag();
        } else {
            hideSoftKeyboard();
            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else {
                gotoMyPackageFrag();
            }
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.LOGOUT)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    syncManager.setLoginStatus(null);
                    store.cleanPref();
                    NotificationManager nMgr = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    nMgr.cancelAll();
                    gotoLoginScreen();
                } else {
                    showToast(jsonObject.optString("error"));
                }
            } else if (jsonObject.getString("url").equals(Const.MY_LOCATION + "/" + userID)) {
                datas.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        if (!object.getString("latitude").equals("null") && !object.getString("longitude").equals("null")) {
                            LocationData locationData = new LocationData();
                            locationData.id = object.getInt("id");
                            locationData.name = object.getString("business_name");
                            locationData.address = object.getString("address");
                            locationData.latitude = object.getString("latitude");
                            locationData.longitude = object.getString("longitude");
                            locationData.city = object.getString("city");
                            locationData.country = object.getString("country");
                            locationData.operating_as = object.getString("operating_as");
                            locationData.zipcode = object.getString("zipcode");
                            datas.add(locationData);
                        }
                    }
                    Collections.reverse(datas);

                    if (drawerAdapter != null) {
                        drawerAdapter.notifyDataSetChanged();
                    }

                } else {
                    if (drawerAdapter != null) {
                        drawerAdapter.notifyDataSetChanged();
                    }
                }
            } else if (jsonObject.getString("url").equals(Const.USER_PROFILE + "/" + userID)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        UserProfileData profileData = dataParsor.getUserProfileData(object);
                        saveUserProfileDataInPrefStore(profileData);
                        prepareListData(drawerItems, profileData.location);
                        setClickChild(profileData);
                    }
                } else {
                    showToast(jsonObject.optString("error"));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Const.GOOGLE_PLACE) {
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
            if (fragment instanceof MyLocationFragment) {
                ((MyLocationFragment) fragment).RecievePlaceData(requestCode, resultCode, data);
            }
        }
    }
}
