package com.pkgspot.utils;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

import java.util.List;

/**
 * Created by TOXSL\parwinder.deep on 6/11/17.
 */

public class HighlightDecorator implements DayViewDecorator {

    private static int color;
    List<CalendarDay> dates;

    public HighlightDecorator(List<CalendarDay> dates) {
        this.dates = dates;
    }

    private static Drawable generateBackgroundDrawable() {
        color = Color.parseColor("#CDCDCD");

        OvalShape rr = new OvalShape();

        ShapeDrawable drawable = new ShapeDrawable(rr);
        drawable.getPaint().setStrokeWidth(20);
        drawable.setShaderFactory(new ShapeDrawable.ShaderFactory() {
            @Override
            public Shader resize(int width, int height) {
                return new LinearGradient(0, 0, 0, 0, color, color, Shader.TileMode.MIRROR);
            }
        });
        return drawable;
    }

    @Override
    public boolean shouldDecorate(CalendarDay calendarDay) {
        return dates.contains(calendarDay);
    }

    @Override
    public void decorate(DayViewFacade dayViewFacade) {
        dayViewFacade.setBackgroundDrawable(generateBackgroundDrawable());
    }
}
