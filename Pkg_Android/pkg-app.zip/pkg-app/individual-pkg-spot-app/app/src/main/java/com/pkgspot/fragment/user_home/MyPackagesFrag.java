package com.pkgspot.fragment.user_home;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.adapter.ImagesAdapter;
import com.pkgspot.adapter.MyPackagesAdapter;
import com.pkgspot.data.MyPackagesData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.pkgspot.utils.HighlightDecorator;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.spans.DotSpan;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by TOXSL\riya.mahajan on 29/8/17.
 */

public class MyPackagesFrag extends BaseFragment implements OnDateSelectedListener, DayViewDecorator {
    private View view;
    private TextView calenderTV;
    private MaterialCalendarView calenderCV;
    private LinearLayout errorLL;
    private TextView errorTV;
    private String user_id;
    private RecyclerView listRV;
    private MyPackagesAdapter packagesAdapter;
    private ArrayList<MyPackagesData> packagesDatas = new ArrayList<>();
    private String selectDate;

    private int color;
    private ArrayList<CalendarDay> dates;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        user_id = store.getString(Const.USER_ID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_my_packages, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        color = getResources().getColor(R.color.Gray);
        dates = new ArrayList<>();

        errorTV = (TextView) view.findViewById(R.id.errorTV);
        errorLL = (LinearLayout) view.findViewById(R.id.errorLL);
        calenderTV = (TextView) view.findViewById(R.id.calenderTV);
        calenderCV = (MaterialCalendarView) view.findViewById(R.id.calenderCV);
        errorLL = (LinearLayout) view.findViewById(R.id.errorLL);
        listRV = (RecyclerView) view.findViewById(R.id.listRV);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity().getBaseContext());
        listRV.setLayoutManager(linearLayoutManager);

        calenderTV.setOnClickListener(this);
        calenderCV.setOnDateChangedListener(this);

        getPacageInfo();
    }

    private void getPacageInfo() {
        if (user_id != null && !user_id.isEmpty()) {
            syncManager.sendToServer(Const.PACKAGE_INDEX + "/" + user_id, null, this);
        } else {
            baseActivity.showToastOne(getString(R.string.user_id_not_found));
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.calenderTV:
                gotoCalenderDialog();
                break;
        }
    }

    public void openUrlIntent(int id) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Const.DOWNLOAD_PDF + id)));
        } catch (Exception e) {
            e.printStackTrace();
            showToast("Exception:" + e);
        }
    }

    private void gotoCalenderDialog() {
        if (calenderCV.getVisibility() == View.VISIBLE) {
            calenderTV.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.mipmap.ic_next, 0);
            calenderCV.setVisibility(View.GONE);
        } else {
            calenderTV.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.mipmap.ic_drop, 0);
            calenderCV.setVisibility(View.VISIBLE);
        }

        calenderCV.state().edit()
                .setFirstDayOfWeek(Calendar.MONDAY)
                .commit();

        calenderCV.addDecorator(new HighlightDecorator(dates));
    }

    private void hitFilterApi(String format) {
        this.selectDate = format;
        syncManager.sendToServer(Const.PACKAGE_FILTER + "/" + user_id + "/" + format, null, this);
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.PACKAGE_INDEX + "/" + user_id)) {
                dates.clear();
                packagesDatas.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    calenderTV.setVisibility(View.VISIBLE);
                    errorLL.setVisibility(View.GONE);
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        MyPackagesData packagesData = new MyPackagesData();
                        packagesData.id = object.getInt("id");
                        packagesData.cuid = object.getString("cuid");
                        packagesData.customer_name = object.getString("customer_name");
                        packagesData.puid = object.getString("puid");
                        packagesData.business_name = object.getString("business_name");
                        packagesData.package_count = object.getString("package_count");
                        packagesData.recived_date = object.getString("recived_date");
                        packagesData.price_per_pkg = object.getString("price_per_pkg");
                        packagesData.total_price = object.getString("total_price");
                        packagesData.recived_time = object.getString("recived_time");
                        packagesData.address = object.getString("address");

                        JSONArray images = object.getJSONArray("images");
                        for (int j = 0; j < images.length(); j++) {
                            packagesData.imageList.add(images.getString(j));
                        }

                        Date date = null;
                        String dtStart = object.getString("recived_date");
                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                        try {
                            date = format.parse(dtStart);
                            System.out.println(date);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(date);
                        dates.add(CalendarDay.from(calendar));
                        packagesDatas.add(packagesData);
                    }

                    setAdapter();
                } else {
                    calenderTV.setVisibility(View.GONE);
                    errorLL.setVisibility(View.VISIBLE);
                    if (packagesAdapter != null) {
                        packagesAdapter.notifyDataSetChanged();
                    }
                }
            } else if (jsonObject.getString("url").equals(Const.PACKAGE_FILTER + "/" + user_id + "/" + selectDate)) {
                calenderTV.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.mipmap.ic_next, 0);
                calenderCV.setVisibility(View.GONE);
                packagesDatas.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    errorLL.setVisibility(View.GONE);
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        MyPackagesData packagesData = new MyPackagesData();
                        packagesData.id = object.getInt("id");
                        packagesData.cuid = object.getString("cuid");
                        packagesData.customer_name = object.getString("customer_name");
                        packagesData.puid = object.getString("puid");
                        packagesData.business_name = object.getString("business_name");
                        packagesData.package_count = object.getString("package_count");
                        packagesData.recived_date = object.getString("recived_date");
                        packagesData.price_per_pkg = object.getString("price_per_pkg");
                        packagesData.total_price = object.getString("total_price");
                        packagesData.recived_time = object.getString("recived_time");
                        packagesData.address = object.getString("address");
                        packagesData.pickedup_time = object.getString("pickedup_time");
                        JSONArray images = object.getJSONArray("images");
                        for (int j = 0; j < images.length(); j++) {
                            packagesData.imageList.add(images.getString(j));
                        }

                        packagesDatas.add(packagesData);
                    }

                    setAdapter();

                } else {
                    errorLL.setVisibility(View.VISIBLE);
                    errorTV.setText("No Packages Received");
                    if (packagesAdapter != null) {
                        packagesAdapter.notifyDataSetChanged();
                    }
                    elseErrorMsg(jsonObject);
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setAdapter() {
        if (packagesAdapter == null) {
            packagesAdapter = new MyPackagesAdapter(baseActivity, packagesDatas, this);
            listRV.setAdapter(packagesAdapter);
        } else {
            packagesAdapter.notifyDataSetChanged();
        }
    }

    public void openImagesDailog(ArrayList<String> imageList) {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        builder.setTitle(baseActivity.getString(R.string.images));
        View view = baseActivity.inflater.inflate(R.layout.dailog_image_my_package, null);
        RecyclerView imgRV = (RecyclerView) view.findViewById(R.id.imgRV);
        imgRV.setLayoutManager(new LinearLayoutManager(baseActivity, LinearLayoutManager.HORIZONTAL, false));
        ImagesAdapter imagesAdapter = new ImagesAdapter(baseActivity, imageList);
        imgRV.setAdapter(imagesAdapter);
        builder.setView(view);
        builder.setNegativeButton(baseActivity.getString(R.string.close), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }

    @Override
    public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {

        SimpleDateFormat readFormat = new SimpleDateFormat("MMM dd, yyyy");
        SimpleDateFormat writeFormat = new SimpleDateFormat("yyyy-MM-dd");

        Date date1 = null;
        try {
            date1 = readFormat.parse(getSelectedDatesString());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        hitFilterApi(writeFormat.format(date1));
    }

    private String getSelectedDatesString() {
        DateFormat FORMATTER = SimpleDateFormat.getDateInstance();

        CalendarDay date = calenderCV.getSelectedDate();
        if (date == null) {
            return "No Selection";
        }
        return FORMATTER.format(date.getDate());
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        log("should Decorate " + dates.contains(day));
        return dates.contains(day);
    }

    @Override
    public void decorate(DayViewFacade view) {
        log("decorate");
        view.addSpan(new DotSpan(5, color));
    }
}
