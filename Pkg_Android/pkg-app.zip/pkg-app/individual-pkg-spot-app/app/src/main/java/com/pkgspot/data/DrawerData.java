package com.pkgspot.data;

/**
 * Created by TOXSL\neeraj.narwal on 3/12/16.
 */
public class DrawerData
{
    public Integer icon;
    public String name;
}
