package com.pkgspot.fragment;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;

import com.pkgspot.BuildConfig;
import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.fragment.login_phase.LoginFragment;
import com.pkgspot.fragment.sign_up_phase.AddCardFragment;
import com.pkgspot.fragment.sign_up_phase.AddPhoneFragment;
import com.pkgspot.fragment.sign_up_phase.CongratsFragment;
import com.pkgspot.fragment.sign_up_phase.ForgotOtpFragment;
import com.pkgspot.fragment.user_home.MyAccountFrag;
import com.pkgspot.fragment.user_home.MyPackagesFrag;
import com.pkgspot.utils.Const;
import com.pkgspot.utils.PrefStore;
import com.toxsl.volley.Request;
import com.toxsl.volley.VolleyError;
import com.toxsl.volley.toolbox.SyncEventListner;
import com.toxsl.volley.toolbox.SyncManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by TOXSL\neeraj.narwal on 2/2/16.
 */
public class BaseFragment extends Fragment implements AdapterView.OnItemClickListener,
        View.OnClickListener, SyncEventListner, AdapterView.OnItemSelectedListener,
        CompoundButton.OnCheckedChangeListener {

    public BaseActivity baseActivity;
    public SyncManager syncManager;
    public PrefStore store;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        baseActivity = (BaseActivity) getActivity();
        if (baseActivity.syncManager == null) {
            baseActivity.syncManager = SyncManager.getInstance(baseActivity, BuildConfig.DEBUG);
        }
        syncManager = baseActivity.syncManager;
        store = baseActivity.store;
    }

    @Override
    public void onResume() {
        super.onResume();
        baseActivity.hideSoftKeyboard();
        getActivity().invalidateOptionsMenu();
    }

    @Override
    public void onClick(View v) {

    }

    public void showToast(String msg) {
        baseActivity.showToast(msg);
    }

    @Override
    public void onSyncStart() {
        baseActivity.onSyncStart();
    }

    @Override
    public void onSyncFinish() {
        baseActivity.onSyncFinish();
    }

    @Override
    public void onSyncFailure(VolleyError error, Request mRequest) {
        baseActivity.onSyncFailure(error, mRequest);
    }

    public void log(String s) {
        baseActivity.log(s);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

    }

    public boolean isValidPassword(String password) {
        return password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{6,}$");
    }


    public void gotoMyPackagesFrag() {
        baseActivity.getSupportFragmentManager()
                .popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment fragment = new MyPackagesFrag();
        baseActivity.getSupportFragmentManager().
                beginTransaction().
                replace(R.id.container, fragment)
                .commit();
    }
    public void gotoMyAccountFragment() {
        baseActivity.getSupportFragmentManager()
                .popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment fragment = new MyAccountFrag();
        baseActivity.getSupportFragmentManager().
                beginTransaction().
                replace(R.id.container, fragment)
                .commit();
    }


    public boolean validateCardExpiryDate(String expiryDate) {
        return expiryDate.matches("(?:0[1-9]|1[0-2])/[0-9]{2}");
    }


    public Location getLastKnownLocation(LocationManager locationManager, LocationListener listener) {
        List<String> providers = locationManager.getProviders(true);
        Location bestLocation = null;
        if (ActivityCompat.checkSelfPermission(baseActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(baseActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        for (String provider : providers) {
            Location l = locationManager.getLastKnownLocation(provider);
            if (l == null) {
                locationManager.requestLocationUpdates(provider, 1000L, 10f, listener);
                l = locationManager.getLastKnownLocation(provider);
            }
            if (l != null && (bestLocation == null || l.getAccuracy() > bestLocation.getAccuracy())) {
                bestLocation = l;
            }
        }
        return bestLocation;
    }


    public void buildAlertMessageNoGps() {
        if (getActivity() != null && !getActivity().isFinishing()) {
            AlertDialog gpsAlert;
            AlertDialog.Builder alert = new AlertDialog.Builder(baseActivity);
            alert.setMessage("GPS is not enable")
                    .setCancelable(false)
                    .setPositiveButton(baseActivity.getString(R.string.yes), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        }
                    })
                    .setNegativeButton(baseActivity.getString(R.string.no), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                        }
                    });

            gpsAlert = alert.create();
            gpsAlert.show();
        }
    }


    public void gotoLocationFragment(boolean is_sign_up, String user_id) {
        Fragment fragment = new MyLocationFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean("is_sign_up", is_sign_up);
        bundle.putString("user_id", user_id);
        bundle.putInt("type", Const.TYPE_LOCATION_SIGN_UP);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


    public void gotoCongratsFragment(String user_id) {
        Fragment fragment = new CongratsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("user_id", user_id);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


    public void gotoAddcardFragment(boolean is_sign_up, String user_id) {
        if (is_sign_up) {
            Fragment fragment = new AddCardFragment();
            Bundle bundle = new Bundle();
            bundle.putString("user_id", user_id);
            fragment.setArguments(bundle);
            baseActivity.getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.login_frame, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }

    public void gotoAddPhoneFragment(String userId) {
        Fragment fragment = new AddPhoneFragment();
        Bundle bundle = new Bundle();
        bundle.putString("userId", userId);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


    public void gotoVerifyEmailFragment(String email) {
        Fragment fragment = new ForgotOtpFragment();
        Bundle bundle = new Bundle();
        bundle.putString("email", email);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


    public void elseErrorMsg(JSONObject jsonObject) throws JSONException {
        String error = getString(R.string.something_went_wrong);
        if (jsonObject.has("error")) {
            error = jsonObject.getString("error");
        }
        baseActivity.showToastOne(error);
    }

    public void gotoLoginPageFragment() {
        baseActivity.getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, new LoginFragment())
                .commit();
    }
}
