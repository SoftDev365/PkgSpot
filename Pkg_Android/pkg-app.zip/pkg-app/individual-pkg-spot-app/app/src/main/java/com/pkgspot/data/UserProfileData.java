package com.pkgspot.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by TOXSL\chirag.tyagi on 2/1/17.
 */

public class UserProfileData implements Parcelable {

    public static final Creator<UserProfileData> CREATOR = new Creator<UserProfileData>() {
        @Override
        public UserProfileData createFromParcel(Parcel in) {
            return new UserProfileData(in);
        }

        @Override
        public UserProfileData[] newArray(int size) {
            return new UserProfileData[size];
        }
    };
    public int id;
    public String customer_id;
    public String full_name;
    public String email;
    public String user_country;
    public String user_state;
    public String user_city;
    public String user_address;
    public String unique_id;
    public String contact_no;
    public String zipcode;
    public String location;

    public UserProfileData(Parcel in) {
        id = in.readInt();
        customer_id = in.readString();
        full_name = in.readString();
        email = in.readString();
        user_country = in.readString();
        user_state = in.readString();
        user_city = in.readString();
        user_address = in.readString();
        unique_id = in.readString();
        contact_no = in.readString();
        zipcode = in.readString();
        location = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(customer_id);
        dest.writeString(full_name);
        dest.writeString(email);
        dest.writeString(user_country);
        dest.writeString(user_state);
        dest.writeString(user_city);
        dest.writeString(user_address);
        dest.writeString(unique_id);
        dest.writeString(contact_no);
        dest.writeString(zipcode);
        dest.writeString(location);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
