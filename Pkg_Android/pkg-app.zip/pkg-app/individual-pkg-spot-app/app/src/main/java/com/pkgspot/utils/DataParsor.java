package com.pkgspot.utils;

import android.os.Parcel;

import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.UserProfileData;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\chirag.tyagi on 2/1/17.
 */

public class DataParsor {

    private BaseActivity baseActivity;

    public DataParsor(BaseActivity baseActivity) {
        this.baseActivity = baseActivity;
    }

    public UserProfileData getUserProfileData(JSONObject object) {

        UserProfileData profileData = new UserProfileData(Parcel.obtain());
        try {
            profileData.id = object.getInt("id");
            profileData.customer_id = object.getString("customer_id");
            profileData.full_name = object.getString("full_name");
            profileData.email = object.getString("email");
            profileData.unique_id = object.getString("unique_id");
            profileData.contact_no = object.getString("contact_no");
            profileData.zipcode = object.getString("zipcode");
            profileData.location = object.getString("location");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return profileData;
    }

}
