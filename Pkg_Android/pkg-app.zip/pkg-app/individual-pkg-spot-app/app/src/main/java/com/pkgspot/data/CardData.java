package com.pkgspot.data;

/**
 * Created by TOXSL\chirag.tyagi on 18/9/17.
 */

public class CardData {
    public String cardId;
    public String name;
    public String last4;
    public String token;
    public String exp_month;
    public String exp_year;
}
