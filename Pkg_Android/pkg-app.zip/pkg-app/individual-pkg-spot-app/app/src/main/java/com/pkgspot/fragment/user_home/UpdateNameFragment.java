package com.pkgspot.fragment.user_home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.pkgspot.R;
import com.pkgspot.activity.MainActivity;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\parwinder.deep on 2/11/17.
 */

public class UpdateNameFragment extends BaseFragment {

    private String userId;
    private View view;
    private EditText nameET;
    private Button doneBT;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userId = store.getString(Const.USER_ID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_update_name, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {

        nameET = (EditText) view.findViewById(R.id.nameET);
        doneBT = (Button) view.findViewById(R.id.doneBT);

        doneBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.doneBT:
                if (nameET.getText().toString().isEmpty()) {
                    baseActivity.showToastOne("Please enter name");
                } else if (baseActivity.isValidMail(nameET.getText().toString())) {
                    baseActivity.showToastOne("Please enter valid name");
                } else {
                    hitUpdateNameApi();
                }
                break;
        }
    }

    private void hitUpdateNameApi() {
        RequestParams params = new RequestParams();
        params.put("full_name", nameET.getText().toString());
        syncManager.sendToServer(Const.UPDATE_NAME + "/" + userId, params, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.UPDATE_NAME + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne(getString(R.string.name_changes_success));
                    if (jsonObject.has("data")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject object = data.getJSONObject(i);
                            UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                            baseActivity.saveUserProfileDataInPrefStore(profileData);
                        }
                        ((MainActivity) baseActivity).updateDrawer();
                        UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
                        nameET.setText(profileData.full_name);
                        baseActivity.getSupportFragmentManager().popBackStack();
                    }
                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
