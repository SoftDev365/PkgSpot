package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.fragment.user_home.ChangePasswordFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\chirag.tyagi on 20/9/17.
 */

public class ForgotOtpFragment extends BaseFragment {
    private View view;
    private TextView msgTV, resendTV, phoneTV;
    private EditText codeET;
    private String email;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            email = bundle.getString("email");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_verification, container, false);
        }

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        codeET = (EditText) view.findViewById(R.id.codeET);

        resendTV = (TextView) view.findViewById(R.id.resendTV);
        phoneTV = (TextView) view.findViewById(R.id.phoneTV);
        phoneTV.setText(email);

        codeET.setInputType(InputType.TYPE_CLASS_TEXT);
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);
        resendTV.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                hitVerifyApi();
                break;

            case R.id.resendTV:
                if (email != null && !email.isEmpty()) {
                    RequestParams params = new RequestParams();
                    params.put("email", email);
                    syncManager.sendToServer(Const.FORGOT_PASSWORD, params, this);
                } else {
                    baseActivity.showToastOne(getString(R.string.no_email_avail));
                }

                break;
        }
    }

    private void hitVerifyApi() {
        RequestParams params = new RequestParams();
        params.put("email", email);
        params.put("otp", codeET.getText().toString().trim());
        syncManager.sendToServer(Const.VERIFY_EMAIL, params, this);
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.VERIFY_EMAIL)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne(getString(R.string.code_verify_success));
                    gotoChangePasswordFragment(jsonObject.optString("userId"));

                } else {
                    elseErrorMsg(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.FORGOT_PASSWORD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne(getString(R.string.code_sent_success));
                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void gotoChangePasswordFragment(String userId) {
        Fragment fragment = new ChangePasswordFragment();
        Bundle bundle = new Bundle();
        bundle.putString("userId", userId);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }
}
