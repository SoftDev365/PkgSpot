package com.pkgspot.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.MyPackagesData;
import com.pkgspot.fragment.user_home.MyPackagesFrag;

import java.util.ArrayList;

/**
 * Created by TOXSL\chirag.tyagi on 26/10/17.
 */

public class MyPackagesAdapter extends RecyclerView.Adapter<MyPackagesAdapter.MyViewHolder> {
    private BaseActivity baseActivity;
    private ArrayList<MyPackagesData> datas = new ArrayList<>();
    private MyPackagesFrag packagesFrag;

    public MyPackagesAdapter(BaseActivity baseActivity, ArrayList<MyPackagesData> packagesDatas, MyPackagesFrag myPackagesFrag) {
        this.baseActivity = baseActivity;
        this.datas = packagesDatas;
        this.packagesFrag = myPackagesFrag;
    }

    @Override
    public MyPackagesAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(baseActivity).inflate(R.layout.adapter_my_packages, parent, false);
        return new MyPackagesAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyPackagesAdapter.MyViewHolder holder, int position) {
        holder.packagesData = datas.get(holder.getAdapterPosition());
        holder.dateReceivedTV.setText(holder.packagesData.recived_date);
        holder.locationTV.setText(holder.packagesData.address);
        holder.timeTV.setText(holder.packagesData.recived_time);

        if (holder.packagesData.pickedup_time == null) {
            holder.pickUpTimeTV.setText("Pending");
        } else {
            holder.pickUpTimeTV.setText(holder.packagesData.pickedup_time);
        }

        holder.pacNoTV.setText(holder.packagesData.package_count);

        holder.imageTV.setOnClickListener(new ClickClass(holder.packagesData) {
            @Override
            public void onClick(View v) {
                packagesFrag.openImagesDailog(packagesData.imageList);
            }
        });

        holder.billTV.setOnClickListener(new ClickClass(holder.packagesData) {
            @Override
            public void onClick(View v) {
                packagesFrag.openUrlIntent(packagesData.id);
            }
        });

    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView dateReceivedTV, locationTV, timeTV, pickUpTimeTV, pacNoTV, imageTV, billTV;
        MyPackagesData packagesData;

        public MyViewHolder(View itemView) {
            super(itemView);
            dateReceivedTV = (TextView) itemView.findViewById(R.id.dateReceivedTV);
            locationTV = (TextView) itemView.findViewById(R.id.locationTV);
            timeTV = (TextView) itemView.findViewById(R.id.timeTV);
            pickUpTimeTV = (TextView) itemView.findViewById(R.id.pickUpTimeTV);
            pacNoTV = (TextView) itemView.findViewById(R.id.pacNoTV);
            imageTV = (TextView) itemView.findViewById(R.id.imageTV);
            billTV = (TextView) itemView.findViewById(R.id.billTV);

        }
    }

    class ClickClass implements View.OnClickListener {
        MyPackagesData packagesData;

        public ClickClass(MyPackagesData packagesData) {
            this.packagesData = packagesData;
        }

        @Override
        public void onClick(View v) {

        }
    }

}
