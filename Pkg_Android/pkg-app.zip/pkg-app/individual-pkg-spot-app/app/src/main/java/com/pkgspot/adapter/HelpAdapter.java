package com.pkgspot.adapter;

import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.HelpData;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by TOXSL\neeraj.narwal on 3/12/16.
 */
public class HelpAdapter extends BaseExpandableListAdapter {
    private BaseActivity activity;
    private List<HelpData> _listDataHeader = new ArrayList<>(); // header titles
    // child data in format of header title, child title
    private ArrayList<String> childDrawerItems = new ArrayList<>();
    private ImageView LocationIconIV;

    public HelpAdapter(BaseActivity baseActivity, ArrayList<HelpData> lists, ArrayList<String> childDrawerItems) {
        this.activity = baseActivity;
        this._listDataHeader = lists;
        this.childDrawerItems = childDrawerItems;
    }


    @Override
    public int getGroupCount() {
        return this._listDataHeader.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return 1;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this._listDataHeader.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this.childDrawerItems.get(groupPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosititon) {
        return childPosititon;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = newView(parent);
        }
        bindViewGroup(groupPosition, convertView, isExpanded);

        return convertView;
    }

    private View newView(ViewGroup parent) {
        return (activity.getLayoutInflater().inflate(R.layout.list_item, parent, false));
    }

    private View newChildView(ViewGroup parent) {
        return (activity.getLayoutInflater().inflate(R.layout.adapter_help_child_item, parent, false));
    }

    private void bindViewGroup(int position, View convertView, boolean isExpanded) {
        HelpData helpData = _listDataHeader.get(position);
        TextView descTV = (TextView) convertView.findViewById(R.id.LocationTV);
        LocationIconIV = (ImageView) convertView.findViewById(R.id.LocationIconIV);
        LocationIconIV.setImageResource(isExpanded ? R.drawable.ic_sub : R.drawable.ic_add_b);
        descTV.setText(helpData.title);
    }

    private void bindViewChild(int groupPosition, int childPosition, View convertView) {
        TextView nameTV = (TextView) convertView.findViewById(R.id.descTV);
        String name = (String) getChild(groupPosition, childPosition);
        nameTV.setText(stripHtml(name));
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = newChildView(parent);
        }
        bindViewChild(groupPosition, childPosition, convertView);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }


    public String stripHtml(String html) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        } else {
            return Html.fromHtml(html).toString();
        }
    }
}
