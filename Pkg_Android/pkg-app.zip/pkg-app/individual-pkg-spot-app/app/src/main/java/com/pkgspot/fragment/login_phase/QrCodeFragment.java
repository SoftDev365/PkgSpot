package com.pkgspot.fragment.login_phase;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import net.glxn.qrgen.android.QRCode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\chirag.tyagi on 11/10/17.
 */

public class QrCodeFragment extends BaseFragment {
    private View view;
    private TextView linqTV, nameTV, pickTV, marketing_messageTV;
    private EditText codeET;
    private ImageView qrcodeIV;
    private String qrString, scheme, host;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            qrString = bundle.getString("code");
            scheme = bundle.getString("scheme");
            host = bundle.getString("host");


        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_login_qrcode, container, false);
        }

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        codeET = (EditText) view.findViewById(R.id.codeET);

//        linqTV = (TextView) view.findViewById(R.id.linqTV);
        nameTV = (TextView) view.findViewById(R.id.nameTV);
        pickTV = (TextView) view.findViewById(R.id.pickTV);
        marketing_messageTV = (TextView) view.findViewById(R.id.marketing_messageTV);

        qrcodeIV = (ImageView) view.findViewById(R.id.qrcodeIV);

        codeET.setText(qrString);

//        linqTV.setText(scheme + "://" + host);


        Bitmap myBitmap = QRCode.from(qrString).bitmap();
        qrcodeIV.setImageBitmap(myBitmap);

        if (qrString != null) {
            hitGetDetailApi();
        }

    }

    private void hitGetDetailApi() {
        RequestParams params = new RequestParams();
        params.put("qr_code", qrString);
        syncManager.sendToServer(Const.CODE_INFO, params, this);

    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.CODE_INFO)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        nameTV.setText(Html.fromHtml(object.getString("business_name") + "<br>" + object.getString("address") + "<br>" + object.getString("city") + "," + object.getString("zipcode")));
                        marketing_messageTV.setText(Html.fromHtml(object.getString("marketing_message")));
                    }
                } else {
                    nameTV.setVisibility(View.GONE);
                    pickTV.setVisibility(View.GONE);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
