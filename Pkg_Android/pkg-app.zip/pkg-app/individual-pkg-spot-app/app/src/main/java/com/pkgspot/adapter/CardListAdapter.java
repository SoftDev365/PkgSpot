package com.pkgspot.adapter;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.CardData;
import com.pkgspot.fragment.login_phase.CardListFragment;

import java.util.ArrayList;

/**
 * Created by TOXSL\chirag.tyagi on 18/9/17.
 */

public class CardListAdapter extends RecyclerView.Adapter<CardListAdapter.MyViewHolder> {
    private BaseActivity baseActivity;
    private ArrayList<CardData> cardDatas = new ArrayList<>();
    private CardListFragment fragment;


    public CardListAdapter(BaseActivity baseActivity, ArrayList<CardData> cardDatas, CardListFragment cardListFragment) {
        this.baseActivity = baseActivity;
        this.cardDatas = cardDatas;
        this.fragment = cardListFragment;
    }

    @Override
    public CardListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_card_list, parent, false);
        return new CardListAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CardListAdapter.MyViewHolder holder, int position) {
        holder.cardData = cardDatas.get(holder.getAdapterPosition());
        holder.expiryDateTV.setText(holder.cardData.exp_month + " - " + holder.cardData.exp_year);
        holder.cardNumberTV.setText(baseActivity.getString(R.string.last_four_unit, holder.cardData.last4));
        holder.cardCV.setOnClickListener(new ClickClass(holder.cardData) {
            @Override
            public void onClick(View v) {
                fragment.showCard(cardData.last4);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cardDatas.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cardNumberTV, expiryDateTV;
        CardView cardCV;
        CardData cardData;

        public MyViewHolder(View itemView) {
            super(itemView);
            expiryDateTV = (TextView) itemView.findViewById(R.id.expiryDateTV);
            cardNumberTV = (TextView) itemView.findViewById(R.id.cardNumberTV);
            cardCV = (CardView) itemView.findViewById(R.id.cardCV);
        }
    }

    abstract class ClickClass implements View.OnClickListener {
        CardData cardData;

        public ClickClass(CardData cardData) {
            this.cardData = cardData;
        }

        @Override
        public void onClick(View v) {

        }
    }


}
