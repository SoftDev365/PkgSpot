package com.pkgspot.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.view.Menu;
import android.view.MenuItem;

import com.pkgspot.R;
import com.pkgspot.fragment.MyLocationFragment;
import com.pkgspot.fragment.login_phase.LoginFragment;
import com.pkgspot.fragment.login_phase.LoginSignUpFragment;
import com.pkgspot.fragment.login_phase.QrCodeFragment;
import com.pkgspot.fragment.sign_up_phase.AddCardFragment;
import com.pkgspot.fragment.sign_up_phase.ThankYouFragment;
import com.pkgspot.fragment.sign_up_phase.VerificationFragment;
import com.pkgspot.utils.Const;

import java.util.List;

/**
 * Created by TOXSL\chirag.tyagi on 23/8/17.
 */

public class LoginSignUpActivity extends BaseActivity {
    ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frame_login);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        initUI();
    }

    private void initUI() {

        Uri data = getIntent().getData();
        if (data != null) {
            String scheme = data.getScheme(); // "http"
            String host = data.getHost(); // "twitter.com"
            List<String> params = data.getPathSegments();
            String first = params.get(0); // "status"

            if (!first.isEmpty()) {
                Fragment fragment = new QrCodeFragment();
                Bundle bundle = new Bundle();
                bundle.putString("code", first);
                bundle.putString("scheme", scheme);
                bundle.putString("host", host);
                fragment.setArguments(bundle);
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .commit();
            }

        } else {
            gotoLoginFragment();
        }
    }

    private void gotoLoginFragment() {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment fragment = new LoginSignUpFragment();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);

    }

    @Override
    public void onBackPressed() {
        hideSoftKeyboard();
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
        if (fragment instanceof LoginSignUpFragment) {
            back();
        } else if (fragment instanceof LoginFragment
                || fragment instanceof AddCardFragment
                || fragment instanceof VerificationFragment
                ) {
            gotoLoginFragment();
        } else if (fragment instanceof QrCodeFragment) {
            finishAffinity();
        } else {
            hideSoftKeyboard();
            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else {
                gotoLoginFragment();
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        actionBar = getSupportActionBar();
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
        if (fragment instanceof LoginSignUpFragment
                || fragment instanceof ThankYouFragment
                ) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        } else {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Const.GOOGLE_PLACE) {
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
            if (fragment instanceof MyLocationFragment) {
                ((MyLocationFragment) fragment).RecievePlaceData(requestCode, resultCode, data);
            }
        }
    }


}
