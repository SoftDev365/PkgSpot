package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

/**
 * Created by TOXSL\riya.mahajan on 28/8/17.
 */

public class VerificationFragment extends BaseFragment {
    private static final String TAG = "PhoneAuthActivity";
    private static final String KEY_VERIFY_IN_PROGRESS = "key_verify_in_progress";
    private static final int STATE_INITIALIZED = 1;
    private static final int STATE_CODE_SENT = 2;
    private static final int STATE_VERIFY_FAILED = 3;
    private static final int STATE_VERIFY_SUCCESS = 4;
    private static final int STATE_SIGNIN_FAILED = 5;
    private static final int STATE_SIGNIN_SUCCESS = 6;
    private View view;
    private TextView phoneTV, resendTV;
    private EditText codeET;
    private Button nextBT;
    private String user_id, phone_no;
    private FirebaseAuth mAuth;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private boolean mVerificationInProgress = false;
    private String mVerificationId;
    private boolean is_login = false;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // [START initialize_auth]
        mAuth = FirebaseAuth.getInstance();
        // [END initialize_auth]

        // Initialize phone auth callbacks
        // [START phone_auth_callbacks]
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                // This callback will be invoked in two situations:
                // 1 - Instant verification. In some cases the phone number can be instantly
                //     verified without needing to send or enter a verification code.
                // 2 - Auto-retrieval. On some devices Google Play services can automatically
                //     detect the incoming verification SMS and perform verificaiton without
                //     user action.
                Log.d(TAG, "onVerificationCompleted:" + credential);
                // [START_EXCLUDE silent]
                mVerificationInProgress = false;
                // [END_EXCLUDE]

                // [START_EXCLUDE silent]
                // Update the UI and attempt sign in with the phone credential
                updateUI(STATE_VERIFY_SUCCESS, credential);
                // [END_EXCLUDE]

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                Log.w(TAG, "onVerificationFailed", e);
                // [START_EXCLUDE silent]
                mVerificationInProgress = false;
                // [END_EXCLUDE]

                if (e instanceof FirebaseAuthInvalidCredentialsException) {
                    // Invalid request
                    // [START_EXCLUDE]
                    showToast(getString(R.string.phone_number_invalid));
                    // [END_EXCLUDE]
                } else if (e instanceof FirebaseTooManyRequestsException) {
                    // The SMS quota for the project has been exceeded
                    // [START_EXCLUDE]
                    showToast(getString(R.string.quota_eceed));
                    // [END_EXCLUDE]
                } else {
                    // Show a message and update the UI
                    // [START_EXCLUDE]
                    updateUI(STATE_VERIFY_FAILED);
                    // [END_EXCLUDE]
                }
            }


            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token) {
                // The SMS verification code has been sent to the provided phone number, we
                // now need to ask the user to enter the code and then construct a credential
                // by combining the code with a verification ID.
                Log.d(TAG, "onCodeSent:" + verificationId);

                // Save verification ID and resending token so we can use them later
                mVerificationId = verificationId;
                mResendToken = token;

                // [START_EXCLUDE]
                // Update UI
                updateUI(STATE_CODE_SENT);
                // [END_EXCLUDE]
            }
        };
        // [END phone_auth_callbacks]


        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_id");
            phone_no = bundle.getString("phone_no");
            is_login = bundle.getBoolean("is_login");
        }

    }


    private void updateUI(int uiState) {
        updateUI(uiState, mAuth.getCurrentUser(), null);
    }

    private void sendMessage(String phone_no) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+" + phone_no,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                baseActivity,               // Activity (for callback binding)
                mCallbacks);
        mVerificationInProgress = true;
    }

    // [START sign_in_with_phone]
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(baseActivity, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");

                            FirebaseUser user = task.getResult().getUser();
                            // [START_EXCLUDE]
                            updateUI(STATE_SIGNIN_SUCCESS, user);
                            // [END_EXCLUDE]
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                // [START_EXCLUDE silent]
                                baseActivity.showToastOne(getString(R.string.enter_code_is_invalid));
                                baseActivity.stopProgressDialog();
                                // [END_EXCLUDE]
                            } else {
                                // [START_EXCLUDE silent]
                                updateUI(STATE_SIGNIN_FAILED);
                                // [END_EXCLUDE]
                            }
                        }
                    }
                });
    }
    // [END sign_in_with_phone]


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_verification_phone, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        phoneTV = (TextView) view.findViewById(R.id.phoneTV);
        resendTV = (TextView) view.findViewById(R.id.resendTV);
        codeET = (EditText) view.findViewById(R.id.codeET);
        nextBT = (Button) view.findViewById(R.id.nextBT);

        nextBT.setOnClickListener(this);
        resendTV.setOnClickListener(this);


        if (phone_no != null) {
            phoneTV.setText("+" + phone_no);
        }


        sendMessage(phone_no);

    }


    private void updateUI(int uiState, FirebaseUser user) {
        updateUI(uiState, user, null);
    }

    private void updateUI(int uiState, PhoneAuthCredential cred) {
        updateUI(uiState, null, cred);
    }

    private void updateUI(int uiState, FirebaseUser user, PhoneAuthCredential cred) {
        switch (uiState) {
            case STATE_INITIALIZED:
                // Initialized state, show only the phone number field and start button

                break;
            case STATE_CODE_SENT:
                // Code sent state, show the verification field, the
                baseActivity.showToastOne(baseActivity.getString(R.string.code_sent_success));
                break;
            case STATE_VERIFY_FAILED:
                // Verification has failed, show all options
                baseActivity.showToastOne(getString(R.string.verification_failed));
                baseActivity.stopProgressDialog();
                break;
            case STATE_VERIFY_SUCCESS:
                // Verification has succeeded, proceed to firebase sign in
                break;
            case STATE_SIGNIN_FAILED:
                // No-op, handled by sign-in check
                baseActivity.showToastOne(getString(R.string.verification_not_success));
                baseActivity.stopProgressDialog();

                break;
            case STATE_SIGNIN_SUCCESS:
                // Np-op, handled by sign-in check
                baseActivity.showToastOne(getString(R.string.verification_success));
                baseActivity.stopProgressDialog();
                if (is_login) {
                    hitUpdatePhoneApi();
                } else {
                    hitVerifyApi();
                }
                break;
        }

    }

    private void hitUpdatePhoneApi() {
        RequestParams params = new RequestParams();
        params.put("contact_no", phone_no);
        syncManager.sendToServer(Const.USER_CHANGE_NUMBER + "/" + user_id, params, this);
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                String code = codeET.getText().toString();
                if (codeET.getText().toString().isEmpty()) {
                    showToast("Please enter verification code");
                } else {
                    verifyPhoneNumberWithCode(mVerificationId, code);
                }
                break;

            case R.id.resendTV:
                resendVerificationCode("+" + phone_no, mResendToken);
                break;
        }
    }

    private void resendVerificationCode(String phoneNumber,
                                        PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                baseActivity,               // Activity (for callback binding)
                mCallbacks,         // OnVerificationStateChangedCallbacks
                token);             // ForceResendingToken from callbacks
    }

    private void verifyPhoneNumberWithCode(String verificationId, String code) {
        baseActivity.startProgressDialog();
        // [START verify_with_code]
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        // [END verify_with_code]
        signInWithPhoneAuthCredential(credential);
    }


    private void hitVerifyApi() {
        RequestParams params = new RequestParams();
        params.put("id", user_id);
        params.put("contact_no", phone_no);
        syncManager.sendToServer(Const.STEP_2_SIGN_UP, params, this);
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.STEP_2_SIGN_UP)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    gotoLocationFragment(true, user_id);
                } else {
                    String error = "Something went wrong";
                    if (jsonObject.has("error")) {
                        error = jsonObject.getString("error");
                    }
                    baseActivity.showToastOne(error);
                }
            } else if (jsonObject.getString("url").equals(Const.USER_CHANGE_NUMBER + "/" + user_id)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("Phone no. updated successfully");
                    gotoMyPackagesFrag();

                } else {
                    String error = "Something went wrong";
                    if (jsonObject.has("error")) {
                        error = jsonObject.getString("error");
                    }
                    baseActivity.showToastOne(error);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}
