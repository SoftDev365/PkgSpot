package com.pkgspot.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.LocationData;
import com.pkgspot.fragment.MyLocationFragment;
import com.pkgspot.utils.Const;

import java.util.ArrayList;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.CustomHolder> {

    private ArrayList<LocationData> locationDatas = new ArrayList<>();
    private MyLocationFragment locationFragment;
    private int selected_position = -1, frag_type;
    private boolean onBind;

    public LocationAdapter(BaseActivity baseActivity, ArrayList<LocationData> datas, MyLocationFragment myLocationFragment, int frag_type) {
        this.locationDatas = datas;
        this.locationFragment = myLocationFragment;
        this.frag_type = frag_type;
    }

    @Override
    public LocationAdapter.CustomHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_item_select_my_adress, parent, false);
        return new LocationAdapter.CustomHolder(v);
    }

    @Override
    public void onBindViewHolder(LocationAdapter.CustomHolder holder, int position) {
        holder.locationData = locationDatas.get(holder.getAdapterPosition());
        holder.locationTV.setText(holder.locationData.name);
        holder.addressTV.setText(holder.locationData.address);
        holder.selectCB.setChecked(holder.getAdapterPosition() == selected_position);
        holder.selectCB.setOnClickListener(new ClickClassNew(holder.getAdapterPosition(), holder.selectCB) {
            @Override
            public void onClick(View v) {
                if (selectCB.isChecked()) {
                    onBind = false;
                    selected_position = position;
                    try {
                        if (locationDatas.get(position) == null) {

                        } else {
                            locationFragment.selected_id = locationDatas.get(position).id;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    locationFragment.isChecked = true;
                } else {
                    onBind = true;
                    selected_position = -1;
                    locationFragment.isChecked = false;
                }

                if (!onBind) {
                    notifyDataSetChanged();
                }

            }
        });

        holder.locationTV.setOnClickListener(new ClickClassNew(holder.getAdapterPosition(), holder.selectCB) {
            @Override
            public void onClick(View v) {
                locationFragment.showAlert(position);
            }
        });

        switch (frag_type) {
            case Const.TYPE_MY_LOCATION:
                holder.checkLL.setVisibility(View.GONE);
                break;

            default:
                holder.checkLL.setVisibility(View.VISIBLE);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return locationDatas.size();
    }

    class CustomHolder extends RecyclerView.ViewHolder {
        TextView locationTV, addressTV;
        CheckBox selectCB;
        LocationData locationData;
        LinearLayout checkLL;

        private CustomHolder(View itemView) {
            super(itemView);
            locationTV = (TextView) itemView.findViewById(R.id.locationTV);
            addressTV = (TextView) itemView.findViewById(R.id.addressTV);
            selectCB = (CheckBox) itemView.findViewById(R.id.selectCB);
            checkLL = (LinearLayout) itemView.findViewById(R.id.checkLL);
        }
    }

    private class ClickClassNew implements View.OnClickListener {
        int position;
        CheckBox selectCB;

        public ClickClassNew(int adapterPosition, CheckBox selectCB) {
            this.position = adapterPosition;
            this.selectCB = selectCB;
        }

        @Override
        public void onClick(View v) {

        }
    }
}
