package com.pkgspot.data;

/**
 * Created by TOXSL\chirag.tyagi on 16/9/17.
 */

public class HelpData {
    public String title;
    public int id;


}
