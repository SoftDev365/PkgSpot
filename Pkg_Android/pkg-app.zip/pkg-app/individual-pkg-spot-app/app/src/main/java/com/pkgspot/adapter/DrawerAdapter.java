package com.pkgspot.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.data.DrawerData;
import com.pkgspot.data.LocationData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by TOXSL\neeraj.narwal on 3/12/16.
 */
public class DrawerAdapter extends BaseExpandableListAdapter {
    BaseActivity activity;

    private List<DrawerData> _listDataHeader; // header titles
    // child data in format of header title, child title
    private HashMap<DrawerData, List<DrawerData>> _listDataChild;
    private ArrayList<LocationData> locationDatas = new ArrayList<>();

    public DrawerAdapter(BaseActivity context, List<DrawerData> listDataHeader, HashMap<DrawerData, List<DrawerData>> listDataChild, ArrayList<LocationData> datas) {
        this.activity = context;
        this._listDataHeader = listDataHeader;
        this._listDataChild = listDataChild;
        this.locationDatas = datas;
    }


    @Override
    public int getGroupCount() {
        return this._listDataHeader.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        if (this._listDataChild.get(this._listDataHeader.get(groupPosition)) != null)
            return this._listDataChild.get(this._listDataHeader.get(groupPosition))
                    .size();
        else
            return 0;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return this._listDataHeader.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosititon) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition))
                .get(childPosititon);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosititon) {
        return childPosititon;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = newView(parent);
        }
        bindView(groupPosition, convertView);

        return convertView;
    }

    private View newView(ViewGroup parent) {
        return (activity.getLayoutInflater().inflate(R.layout.adapter_drawer, parent, false));
    }

    private View newChildView(ViewGroup parent) {
        return (activity.getLayoutInflater().inflate(R.layout.item_adapter_drawer, parent, false));
    }

    private void bindView(int position, View convertView) {
        ImageView iconIV = (ImageView) convertView.findViewById(R.id.iconIV);
        TextView nameTV = (TextView) convertView.findViewById(R.id.nameTV);
        DrawerData data = (DrawerData) getGroup(position);

        iconIV.setImageResource(data.icon);
        nameTV.setText(data.name);
    }

    private void bindView(int groupPosition, int childPosition, View convertView) {
        ImageView iconIV = (ImageView) convertView.findViewById(R.id.LocationIconIV);
        TextView nameTV = (TextView) convertView.findViewById(R.id.LocationTV);
        LinearLayout linearLL = (LinearLayout) convertView.findViewById(R.id.linearLL);

        DrawerData data = (DrawerData) getChild(groupPosition, childPosition);


        linearLL.removeAllViews();
        if (childPosition == 0) {
            for (int i = 0; i < locationDatas.size(); i++) {
                View view = activity.getLayoutInflater().inflate(R.layout.layout_drawer, null, false);
                TextView locationTV = (TextView) view.findViewById(R.id.locationTV);
                TextView addressTV = (TextView) view.findViewById(R.id.addressTV);
                view.setTag(i);
                LocationData locationData = locationDatas.get(i);
                locationTV.setText(locationData.name);
                addressTV.setText(locationData.address);
                linearLL.addView(view);
            }

        }

        iconIV.setImageResource(data.icon);
        nameTV.setText(data.name);
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = newChildView(parent);
        }
        bindView(groupPosition, childPosition, convertView);

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}
