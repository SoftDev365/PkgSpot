package com.pkgspot.snackBAr;

public interface ActionSwipeListener {

    void onSwipeToDismiss();
}
