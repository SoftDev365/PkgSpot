package com.pkgspot.fragment;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.pkgspot.R;
import com.pkgspot.activity.BaseActivity;
import com.pkgspot.adapter.LocationAdapter;
import com.pkgspot.data.DaysData;
import com.pkgspot.data.Friday;
import com.pkgspot.data.LocationData;
import com.pkgspot.data.Monday;
import com.pkgspot.data.Saturday;
import com.pkgspot.data.Sunday;
import com.pkgspot.data.Thursday;
import com.pkgspot.data.Tuesday;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.data.Wednesday;
import com.pkgspot.utils.Const;
import com.pkgspot.utils.GoogleApisHandle;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class MyLocationFragment extends BaseFragment implements BaseActivity.PermCallback, LocationListener {
    public Location location;
    public LatLng latLng;
    public int selected_id, position;
    public boolean isChecked;
    private String mondayAM, mondayPM, tuesdayAM, tuesdayPM, wednesdayAM, wednesdayPM, thursdayAM, thursdayPM, fridayAM, fridayPM, saturdayAM, saturdayPM, sundayAM, sundayPM;
    private View view;
    private RecyclerView myloccRV;
    private LinearLayoutManager mLayoutManager;
    private Button nextBT;
    private boolean is_sign_up;
    private AlertDialog aleart;
    private String user_id, userID;
    private GoogleMap googleMap;
    private HashMap<String, Integer> mHashMap = new HashMap<>();
    private MarkerOptions marker;
    private Location myCurrentLocation;
    private LocationManager mLocationManager;
    private EditText locET, zipcdeET;
    private ArrayList<LocationData> datas = new ArrayList<>();
    private LocationAdapter locationAdapter;
    private TextView locTitleTV, errorTV, titleTV;
    private String[] zipST, cityST;
    private CheckBox selectCB;
    private ImageView searchIV;
    private double lat = 37.773972, lng = -122.431297;
    private ArrayList<LocationData> cityList = new ArrayList<>();
    private int frag_type;
    private String loc;
    private LinearLayout searchLL;
    private String updateLoc;
    private Paint p = new Paint();
    private ArrayList<DaysData> daysDatas = new ArrayList<>();


    private void initSwipe() {
        ItemTouchHelper.SimpleCallback itemSimpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();

                if (direction == ItemTouchHelper.LEFT) {
                    deleteLocation(datas.get(position).id);
                }

            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                Bitmap icon;
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {

                    View itemView = viewHolder.itemView;
                    float height = (float) itemView.getBottom() - (float) itemView.getTop();
                    float width = height / 3;

                    if (dX > 0) {
                        p.setColor(getResources().getColor(R.color.White));
                        RectF background = new RectF((float) itemView.getLeft(), (float) itemView.getTop(), dX, (float) itemView.getBottom());
                        c.drawRect(background, p);
                        icon = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_delete);
                        RectF icon_dest = new RectF((float) itemView.getLeft() + width, (float) itemView.getTop() + width, (float) itemView.getLeft() + 2 * width, (float) itemView.getBottom() - width);
                        c.drawBitmap(icon, null, icon_dest, p);
                    } else {
                        p.setColor(getResources().getColor(R.color.White));
                        RectF background = new RectF((float) itemView.getRight() + dX, (float) itemView.getTop(), (float) itemView.getRight(), (float) itemView.getBottom());
                        c.drawRect(background, p);
                        icon = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_delete);
                        RectF icon_dest = new RectF((float) itemView.getRight() - 2 * width, (float) itemView.getTop() + width, (float) itemView.getRight() - width, (float) itemView.getBottom() - width);
                        c.drawBitmap(icon, null, icon_dest, p);
                    }
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(itemSimpleCallback);
        itemTouchHelper.attachToRecyclerView(myloccRV);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("position")) {
//            position = bundle.getInt("position");
            is_sign_up = bundle.getBoolean("is_sign_up");
            frag_type = bundle.getInt("type");

            UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
            if (!profileData.location.equals("null") && profileData.location != null) {
                loc = profileData.location;
            }
        } else if (bundle != null) {
            is_sign_up = bundle.getBoolean("is_sign_up");
            user_id = bundle.getString("user_id");
            frag_type = bundle.getInt("type");
        }


        if (store.containValue(Const.USER_ID)) {
            userID = store.getString(Const.USER_ID);
        }

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (baseActivity.getSupportActionBar() != null)
            baseActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_find_my_location, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        if (baseActivity.checkPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 120, this)) {
            initializeMap();
            init();
        }
    }

    private void initializeMap() {
        if (googleMap == null) {
            SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            mapFragment.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    googleMap.getUiSettings().setZoomControlsEnabled(false);
                    googleMap.getUiSettings().setMapToolbarEnabled(false);
                    googleMap.getUiSettings().setMyLocationButtonEnabled(false);
                    if (ActivityCompat.checkSelfPermission(baseActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(baseActivity, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
//                    googleMap.setMyLocationEnabled(true);

                    MyLocationFragment.this.googleMap = googleMap;

//                    getAndSetCurrentLocation();
                    setLocation(lat, lng);

                    googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                        @Override
                        public boolean onMarkerClick(Marker marker) {
                            return false;
                        }
                    });
                }


            });
        }


    }

    private void init() {
        mLocationManager = (LocationManager) baseActivity.getSystemService(Context.LOCATION_SERVICE);

        searchLL = (LinearLayout) view.findViewById(R.id.searchLL);

        myloccRV = (RecyclerView) view.findViewById(R.id.myloccRV);
        mLayoutManager = new LinearLayoutManager(baseActivity);
        myloccRV.setLayoutManager(mLayoutManager);

        nextBT = (Button) view.findViewById(R.id.nextBT);

        locET = (EditText) view.findViewById(R.id.locET);
        zipcdeET = (EditText) view.findViewById(R.id.zipcdeET);

        locTitleTV = (TextView) view.findViewById(R.id.locTitleTV);
        errorTV = (TextView) view.findViewById(R.id.errorTV);
        titleTV = (TextView) view.findViewById(R.id.titleTV);

        searchIV = (ImageView) view.findViewById(R.id.searchIV);

        nextBT.setOnClickListener(this);

        GoogleApisHandle googleApisHandle = new GoogleApisHandle();
        location = googleApisHandle.getLastKnownLocation(baseActivity);


        switch (frag_type) {
            case Const.TYPE_MY_LOCATION:
                locTitleTV.setText("My Locations");
                break;
            case Const.TYPE_FIND_LOCATION:
                locTitleTV.setText("Find My Location");
                break;

            case Const.TYPE_LOCATION_SIGN_UP:
                locTitleTV.setText("Find My Location");
                break;
        }

        switch (frag_type) {
            case Const.TYPE_MY_LOCATION:
                titleTV.setText("My Locations");
                break;
            case Const.TYPE_FIND_LOCATION:
                titleTV.setText("Select My Location");
                break;

            case Const.TYPE_LOCATION_SIGN_UP:
                titleTV.setText("Select My Location");
                break;
        }

        switch (frag_type) {
            case Const.TYPE_LOCATION_SIGN_UP:
                locET.setOnClickListener(this);
                zipcdeET.setOnClickListener(this);
                searchIV.setOnClickListener(this);
                nextBT.setText("Select My Location");
                break;

            case Const.TYPE_MY_LOCATION:
                nextBT.setVisibility(View.GONE);
                errorTV.setText("No Location Selected");
                break;

            case Const.TYPE_FIND_LOCATION:
                locET.setOnClickListener(this);
                zipcdeET.setOnClickListener(this);
                searchIV.setOnClickListener(this);
                nextBT.setVisibility(View.VISIBLE);
                nextBT.setText("Update");
                break;
        }

        switch (frag_type) {
            case Const.TYPE_MY_LOCATION:
                searchLL.setVisibility(View.GONE);
                break;

            case Const.TYPE_LOCATION_SIGN_UP:
            case Const.TYPE_FIND_LOCATION:
                searchLL.setVisibility(View.VISIBLE);
                break;


        }

        getLocationList();
        getPrefilledData();
        hitZipcodeListApi();

        if (titleTV.getText() == "My Locations") {
            initSwipe();
        } else {
            log("else");
        }
    }

    private void getPrefilledData() {
        if (baseActivity.checkPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 200, this)) {
            getGeoLocation();
        }

    }

    private void getGeoLocation() {
        Geocoder geocoder = new Geocoder(baseActivity, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            String cityName = "San Francisco";
            locET.setText(cityName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setAdapter() {
        if (locationAdapter == null) {
            locationAdapter = new LocationAdapter(baseActivity, datas, this, frag_type);
            myloccRV.setAdapter(locationAdapter);
        } else {
            locationAdapter.notifyDataSetChanged();
        }
    }


    private void getLocationList() {
        if (is_sign_up) {
            RequestParams params = new RequestParams();
            params.put("lat", lat);
            params.put("lng", lng);
            syncManager.sendToServer(Const.SIGN_UP_LOCATION, params, this);
        } else {
            syncManager.sendToServer(Const.MY_LOCATION + "/" + userID, null, this);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.nextBT:
                switch (frag_type) {
                    case Const.TYPE_LOCATION_SIGN_UP:
                        if (isChecked) {
                            hitStepApi();
                        } else {
                            gotoAddcardFragment(true, user_id);
                        }
                        break;
                    case Const.TYPE_MY_LOCATION:
                        baseActivity.showToast("My Loc");
                        break;

                    case Const.TYPE_FIND_LOCATION:
                        if (isChecked) {
                            hitAddLocationApi();
                        } else {
                            baseActivity.showToastOne("Please select at least one location");
                        }
                        break;
                }

                break;

            case R.id.locET:
                getCitiesList();
                break;
            case R.id.zipcdeET:
                if (zipST.length != 0) {
                    openZipDailog();
                }
                break;

            case R.id.searchIV:
                callGoogleSearch(Const.GOOGLE_PLACE);
                break;

        }
    }

    private void hitAddLocationApi() {
        RequestParams params = new RequestParams();
        log("selected id " + selected_id);
        log("location " + loc);
        if (loc == null) {
            params.put("location", selected_id);
        } else {
            params.put("location", loc + "," + selected_id);
        }
        syncManager.sendToServer(Const.ADD_LOCATION + "/" + userID, params, this);
    }

    private void getCitiesList() {
        syncManager.sendToServer(Const.CITY_LIST, null, this);
    }

    private void openCitiesDailog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        builder.setTitle("Partner Locations");
        builder.setItems(cityST, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (!cityList.get(which).latitude.equals("null") && !cityList.get(which).latitude.isEmpty()) {
                    locET.setText(cityST[which]);
                    String lat, lng;
                    lat = cityList.get(which).latitude;
                    lng = cityList.get(which).longitude;
                    getProvidersList(lat, lng);
                    getZipCodeList(lat, lng);
                    setLocation(Double.parseDouble(lat), Double.parseDouble(lng));
                } else {
                    baseActivity.showToastOne("lat longs not available");
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();

    }

    private void getZipCodeList(String lat, String lng) {
        RequestParams params = new RequestParams();
        params.put("lat", lat);
        params.put("lng", lng);
        syncManager.sendToServer(Const.ZIP_CODE_LIST, params, this);
    }

    private void getProvidersList(String lat, String lng) {
        RequestParams params = new RequestParams();
        params.put("lat", lat);
        params.put("lng", lng);
        syncManager.sendToServer(Const.SIGN_UP_LOCATION, params, this);
    }

    private void openZipDailog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        builder.setTitle("Select Zip code");
        builder.setItems(zipST, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                zipcdeET.setText(zipST[i]);
                getFilterList(zipST[i]);
            }
        });
        builder.setNegativeButton(baseActivity.getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }

    private void getFilterList(String s) {
        log("getFilterList");
        RequestParams params = new RequestParams();
        params.put("zipcode", s);
        syncManager.sendToServer(Const.SIGN_UP_LOCATION, params, this);
    }

    private void callGoogleSearch(int reqCode) {
        try {
            Intent intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                    .build(getActivity());
            getActivity().startActivityForResult(intent, reqCode);
        } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }

    private void hitStepApi() {
        RequestParams params = new RequestParams();
        params.put("id", user_id);
        params.put("location", selected_id);
        syncManager.sendToServer(Const.STEP_3_SIGN_UP, params, this);
    }

    public void showAlert(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(baseActivity);
        View view = baseActivity.inflater.inflate(R.layout.dialog_hours_service, null);
        ImageView closeIV = (ImageView) view.findViewById(R.id.closeIV);
        CheckBox selectCB = (CheckBox) view.findViewById(R.id.selectCB);
        EditText mfromET = (EditText) view.findViewById(R.id.mfromET);
        EditText mtoET = (EditText) view.findViewById(R.id.mtoET);
        EditText tfromET = (EditText) view.findViewById(R.id.tfromET);
        EditText ttoET = (EditText) view.findViewById(R.id.ttoET);
        EditText wfromET = (EditText) view.findViewById(R.id.wfromET);
        EditText wtoET = (EditText) view.findViewById(R.id.wtoET);
        EditText ThfromET = (EditText) view.findViewById(R.id.ThfromET);
        EditText ThtoET = (EditText) view.findViewById(R.id.ThtoET);
        EditText ffromET = (EditText) view.findViewById(R.id.ffromET);
        EditText ftoET = (EditText) view.findViewById(R.id.ftoET);
        EditText safromET = (EditText) view.findViewById(R.id.safromET);
        EditText satoET = (EditText) view.findViewById(R.id.satoET);
        EditText sunfromET = (EditText) view.findViewById(R.id.sunfromET);
        EditText suntoET = (EditText) view.findViewById(R.id.suntoET);

        if (datas.get(position).daysData.getMonday() != null)
            mfromET.setText(datas.get(position).daysData.getMonday().getStartTime());

        if (datas.get(position).daysData.getMonday() != null)
            mtoET.setText(datas.get(position).daysData.getMonday().getEndTime());

        if (datas.get(position).daysData.getTuesday() != null)
            tfromET.setText(datas.get(position).daysData.getTuesday().getStartTime());

        if (datas.get(position).daysData.getTuesday() != null)
            ttoET.setText(datas.get(position).daysData.getTuesday().getEndTime());

        if (datas.get(position).daysData.getWednesday() != null)
            wfromET.setText(datas.get(position).daysData.getWednesday().getStartTime());

        if (datas.get(position).daysData.getWednesday() != null)
            wtoET.setText(datas.get(position).daysData.getWednesday().getEndTime());

        if (datas.get(position).daysData.getThursday() != null)
            ThfromET.setText(datas.get(position).daysData.getThursday().getStartTime());

        if (datas.get(position).daysData.getThursday() != null)
            ThtoET.setText(datas.get(position).daysData.getThursday().getStartTime());

        if (datas.get(position).daysData.getFriday() != null)
            ffromET.setText(datas.get(position).daysData.getFriday().getStartTime());

        if (datas.get(position).daysData.getFriday() != null)
            ftoET.setText(datas.get(position).daysData.getFriday().getStartTime());

        if (datas.get(position).daysData.getSaturday() != null)
            safromET.setText(datas.get(position).daysData.getSaturday().getStartTime());

        if (datas.get(position).daysData.getSaturday() != null)
            satoET.setText(datas.get(position).daysData.getSaturday().getEndTime());

        if (datas.get(position).daysData.getSunday() != null)
            sunfromET.setText(datas.get(position).daysData.getSunday().getStartTime());

        if (datas.get(position).daysData.getSunday() != null)
            suntoET.setText(datas.get(position).daysData.getSunday().getEndTime());

        selectCB.setOnClickListener(new ClickClass(position, selectCB) {
            @Override
            public void onClick(View v) {
                datas.get(position).isChecked = selectCB.isChecked();
                if (locationAdapter != null) {
                    locationAdapter.notifyDataSetChanged();
                }
            }
        });

        builder.setView(view);
        aleart = builder.create();
        aleart.show();
        closeIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aleart.dismiss();
            }
        });
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.SIGN_UP_LOCATION)) {
                datas.clear();
                daysDatas.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    if (data.length() == 0) {
                        errorTV.setVisibility(View.VISIBLE);
                    } else {
                        errorTV.setVisibility(View.GONE);
                    }
                    if (googleMap != null) {
                        googleMap.clear();
                    }

                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        if (!object.getString("latitude").equals("null") && !object.getString("longitude").equals("null")) {
                            LocationData locationData = new LocationData();
                            locationData.id = object.getInt("id");
                            locationData.name = object.getString("business_name");
                            locationData.address = object.getString("address");
                            locationData.latitude = object.getString("latitude");
                            locationData.longitude = object.getString("longitude");
                            locationData.city = object.getString("city");
                            locationData.country = object.getString("country");
                            locationData.operating_as = object.getString("operating_as");
                            locationData.zipcode = object.getString("zipcode");

                            String days_of_service = object.getString("days_of_service");
                            JSONArray jsonArray = new JSONArray(days_of_service);

                            DaysData daysData = new DaysData();
                            for (int k = 0; k < jsonArray.length(); k++) {
                                JSONObject days = jsonArray.getJSONObject(k);

                                if (days.has("monday")) {
                                    Monday monday = new Monday();
                                    JSONObject mondayObject = days.getJSONObject("monday");
                                    monday.setStartTime(mondayObject.get("start_time").toString());
                                    mondayAM = monday.getStartTime();
                                    monday.setEndTime(mondayObject.get("end_time").toString());
                                    mondayPM = monday.getEndTime();
                                    daysData.setMonday(monday);
                                }

                                if (days.has("tuesday")) {
                                    Tuesday tuesday = new Tuesday();
                                    JSONObject tuesdayObject = days.getJSONObject("tuesday");
                                    tuesday.setStartTime(tuesdayObject.get("start_time").toString());
                                    tuesdayAM = tuesday.getStartTime();
                                    tuesday.setEndTime(tuesdayObject.get("end_time").toString());
                                    tuesdayPM = tuesday.getEndTime();
                                    daysData.setTuesday(tuesday);
                                }

                                if (days.has("wednesday")) {
                                    Wednesday wednesday = new Wednesday();
                                    JSONObject wednesdayObject = days.getJSONObject("wednesday");
                                    wednesday.setStartTime(wednesdayObject.get("start_time").toString());
                                    wednesdayAM = wednesday.getStartTime();
                                    wednesday.setEndTime(wednesdayObject.get("end_time").toString());
                                    wednesdayPM = wednesday.getEndTime();
                                    daysData.setWednesday(wednesday);
                                }

                                if (days.has("thursday")) {
                                    Thursday thursday = new Thursday();
                                    JSONObject thursdayobject = days.getJSONObject("thursday");
                                    thursday.setStartTime(thursdayobject.get("start_time").toString());
                                    thursdayAM = thursday.getStartTime();
                                    thursday.setEndTime(thursdayobject.get("end_time").toString());
                                    thursdayPM = thursday.getEndTime();
                                    daysData.setThursday(thursday);
                                }

                                if (days.has("friday")) {
                                    Friday friday = new Friday();
                                    JSONObject fridayObject = days.getJSONObject("friday");
                                    friday.setStartTime(fridayObject.get("start_time").toString());
                                    fridayAM = friday.getStartTime();
                                    friday.setEndTime(fridayObject.get("end_time").toString());
                                    fridayPM = friday.getEndTime();
                                    daysData.setFriday(friday);
                                }

                                if (days.has("saturday")) {
                                    Saturday saturday = new Saturday();
                                    JSONObject saturdayObject = days.getJSONObject("saturday");
                                    saturday.setStartTime(saturdayObject.get("start_time").toString());
                                    saturdayAM = saturday.getStartTime();
                                    saturday.setEndTime(saturdayObject.get("end_time").toString());
                                    saturdayPM = saturday.getEndTime();
                                    daysData.setSaturday(saturday);
                                }

                                if (days.has("sunday")) {
                                    Sunday sunday = new Sunday();
                                    JSONObject sundayObject = days.getJSONObject("sunday");
                                    sunday.setStartTime(sundayObject.get("start_time").toString());
                                    sundayAM = sunday.getStartTime();
                                    sunday.setEndTime(sundayObject.get("end_time").toString());
                                    sundayPM = sunday.getEndTime();
                                    daysData.setSunday(sunday);
                                }
                            }
                            locationData.daysData = daysData;
                            datas.add(locationData);

                            if (googleMap != null) {
                                setMarker(locationData);
                            }
                        }
                    }
                    setAdapter();
                } else {
                    errorTV.setVisibility(View.VISIBLE);
                    if (locationAdapter != null) {
                        locationAdapter.notifyDataSetChanged();
                    }
                }
            } else if (jsonObject.getString("url").equals(Const.MY_LOCATION + "/" + userID)) {
                datas.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    if (data.length() == 0) {
                        errorTV.setVisibility(View.VISIBLE);
                    } else {
                        errorTV.setVisibility(View.GONE);
                    }
                    if (googleMap != null) {
                        googleMap.clear();
                    }
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        if (!object.getString("latitude").equals("null") && !object.getString("longitude").equals("null")) {
                            LocationData locationData = new LocationData();
                            locationData.id = object.getInt("id");
                            locationData.name = object.getString("business_name");
                            locationData.address = object.getString("address");
                            locationData.latitude = object.getString("latitude");
                            locationData.longitude = object.getString("longitude");
                            locationData.city = object.getString("city");
                            locationData.country = object.getString("country");
                            locationData.operating_as = object.getString("operating_as");
                            locationData.zipcode = object.getString("zipcode");

                            String days_of_service = object.getString("days_of_service");
                            JSONArray jsonArray = new JSONArray(days_of_service);

                            DaysData daysData = new DaysData();
                            for (int k = 0; k < jsonArray.length(); k++) {
                                JSONObject days = jsonArray.getJSONObject(k);

                                if (days.has("monday")) {
                                    Monday monday = new Monday();
                                    JSONObject mondayObject = days.getJSONObject("monday");
                                    monday.setStartTime(mondayObject.get("start_time").toString());
                                    mondayAM = monday.getStartTime();
                                    monday.setEndTime(mondayObject.get("end_time").toString());
                                    mondayPM = monday.getEndTime();
                                    daysData.setMonday(monday);
                                }

                                if (days.has("tuesday")) {
                                    Tuesday tuesday = new Tuesday();
                                    JSONObject tuesdayObject = days.getJSONObject("tuesday");
                                    tuesday.setStartTime(tuesdayObject.get("start_time").toString());
                                    tuesdayAM = tuesday.getStartTime();
                                    tuesday.setEndTime(tuesdayObject.get("end_time").toString());
                                    tuesdayPM = tuesday.getEndTime();
                                    daysData.setTuesday(tuesday);
                                }

                                if (days.has("wednesday")) {
                                    Wednesday wednesday = new Wednesday();
                                    JSONObject wednesdayObject = days.getJSONObject("wednesday");
                                    wednesday.setStartTime(wednesdayObject.get("start_time").toString());
                                    wednesdayAM = wednesday.getStartTime();
                                    wednesday.setEndTime(wednesdayObject.get("end_time").toString());
                                    wednesdayPM = wednesday.getEndTime();
                                    daysData.setWednesday(wednesday);
                                }

                                if (days.has("thursday")) {
                                    Thursday thursday = new Thursday();
                                    JSONObject thursdayobject = days.getJSONObject("thursday");
                                    thursday.setStartTime(thursdayobject.get("start_time").toString());
                                    thursdayAM = thursday.getStartTime();
                                    thursday.setEndTime(thursdayobject.get("end_time").toString());
                                    thursdayPM = thursday.getEndTime();
                                    daysData.setThursday(thursday);
                                }

                                if (days.has("friday")) {
                                    Friday friday = new Friday();
                                    JSONObject fridayObject = days.getJSONObject("friday");
                                    friday.setStartTime(fridayObject.get("start_time").toString());
                                    fridayAM = friday.getStartTime();
                                    friday.setEndTime(fridayObject.get("end_time").toString());
                                    fridayPM = friday.getEndTime();
                                    daysData.setFriday(friday);
                                }

                                if (days.has("saturday")) {
                                    Saturday saturday = new Saturday();
                                    JSONObject saturdayObject = days.getJSONObject("saturday");
                                    saturday.setStartTime(saturdayObject.get("start_time").toString());
                                    saturdayAM = saturday.getStartTime();
                                    saturday.setEndTime(saturdayObject.get("end_time").toString());
                                    saturdayPM = saturday.getEndTime();
                                    daysData.setSaturday(saturday);
                                }

                                if (days.has("sunday")) {
                                    Sunday sunday = new Sunday();
                                    JSONObject sundayObject = days.getJSONObject("sunday");
                                    sunday.setStartTime(sundayObject.get("start_time").toString());
                                    sundayAM = sunday.getStartTime();
                                    sunday.setEndTime(sundayObject.get("end_time").toString());
                                    sundayPM = sunday.getEndTime();
                                    daysData.setSunday(sunday);
                                }
                            }

                            locationData.daysData = daysData;
                            datas.add(locationData);

                            if (googleMap != null) {
                                setMarker(locationData);
                            }
                            setLocation(Double.parseDouble(datas.get(0).latitude), Double.parseDouble(datas.get(0).longitude));
                            locET.setText(datas.get(0).address);
                            zipcdeET.setText(datas.get(0).zipcode);
                        }
                    }
                    setAdapter();

                    Collections.reverse(datas);
                } else {
                    errorTV.setVisibility(View.VISIBLE);
                    errorTV.setText("No Location Selected");
                    if (locationAdapter != null) {
                        locationAdapter.notifyDataSetChanged();
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        try {
            if (jsonObject.getString("url").equals(Const.STEP_3_SIGN_UP)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    gotoAddcardFragment(is_sign_up, user_id);
                } else {
                    elseErrorMsg(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.ZIP_CODE_LIST)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    zipST = new String[data.length()];
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        zipcdeET.setText(object.getString("zipcode"));
                        zipST[i] = object.getString("zipcode");
                    }

                } else {
                    elseErrorMsg(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.CITY_LIST)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    cityST = new String[data.length()];
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        LocationData locationData = new LocationData();
                        locationData.id = object.getInt("id");
                        locationData.city = object.getString("city");
                        locationData.latitude = object.getString("latitude");
                        locationData.longitude = object.getString("longitude");
                        cityList.add(locationData);
                        cityST[i] = object.getString("city");
                    }
                    openCitiesDailog();
                } else {
                    elseErrorMsg(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.ADD_LOCATION + "/" + userID)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToast("Locations Updated Successfully");
                    gotoMyPackagesFrag();
                } else {
                    myloccRV.setVisibility(View.GONE);
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void hitZipcodeListApi() {
        RequestParams params = new RequestParams();
        params.put("lat", lat);
        params.put("lng", lng);
        syncManager.sendToServer(Const.ZIP_CODE_LIST, params, this);
    }

    private void setMarker(LocationData docData) {
        marker = new MarkerOptions();
        try {
            marker.position(new LatLng(Double.parseDouble(docData.latitude), Double.parseDouble(docData.longitude)));
            marker.title(docData.name);
            marker.icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_location_map));
            Marker markerr = googleMap.addMarker(marker);
            mHashMap.put(markerr.getId(), docData.id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {
            myCurrentLocation = location;
            setLocation(myCurrentLocation.getLatitude(), myCurrentLocation.getLongitude());
        }
    }

    private void setLocation(double latitude, double longitude) {
        if (googleMap != null) {
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(latitude, longitude)).zoom(14).build();
            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void permGranted(int resultCode) {
        switch (resultCode) {
            case 120:
                initializeMap();
                init();
                break;
            case 200:
                getGeoLocation();
                break;
        }
    }

    @Override
    public void permDenied(int resultCode) {
        switch (resultCode) {
            case 120:
                baseActivity.finishAffinity();
                break;
            case 200:
                baseActivity.finishAffinity();
                break;
        }
    }

    public void RecievePlaceData(int requestCode, int resultCode, Intent data) {
        if (requestCode == Const.GOOGLE_PLACE) {
            if (resultCode == baseActivity.RESULT_OK) {
                Place place = PlaceAutocomplete.getPlace(baseActivity, data);
                locET.setText(place.getAddress().toString());
                latLng = place.getLatLng();
                getList();
                getZipList();
                setLocation(latLng.latitude, latLng.longitude);
            } else if (resultCode == PlaceAutocomplete.RESULT_ERROR) {
                Status status = PlaceAutocomplete.getStatus(baseActivity, data);
                showToast(status.toString());
            }
        }
    }

    private void getZipList() {
        RequestParams params = new RequestParams();
        params.put("lat", latLng != null ? latLng.latitude : 0.0);
        params.put("lng", latLng != null ? latLng.longitude : 0.0);
        syncManager.sendToServer(Const.ZIP_CODE_LIST, params, this);

    }

    private void getList() {
        RequestParams params = new RequestParams();
        params.put("lat", latLng != null ? latLng.latitude : 0.0);
        params.put("lng", latLng != null ? latLng.longitude : 0.0);
        if (is_sign_up) {
            syncManager.sendToServer(Const.SIGN_UP_LOCATION, params, this);
        } else {
            syncManager.sendToServer(Const.MY_LOCATION + "/" + userID, params, this);
        }
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.skip, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.skipMN:
                gotoAddcardFragment(is_sign_up, user_id);
                break;
        }

        return true;
    }

    public void deleteLocation(int id) {
        String sid = String.valueOf(id);

        UserProfileData profileData = baseActivity.getUserProfileDataFromPrefStore();
        String location = profileData.location;

        if (location.contains(sid + ",")) {
            updateLoc = location.replace(sid + ",", "");
        } else if (location.contains("," + sid)) {
            updateLoc = location.replace("," + sid, "");
        } else {
            updateLoc = location.replace(sid, "");
        }
        RequestParams params = new RequestParams();
        params.put("location", updateLoc);
        syncManager.sendToServer(Const.ADD_LOCATION + "/" + userID, params, this);
    }

    private class ClickClass implements View.OnClickListener {
        int position;
        CheckBox selectCB;

        public ClickClass(int position, CheckBox selectCB) {
            this.position = position;
            this.selectCB = selectCB;
        }

        @Override
        public void onClick(View v) {

        }
    }
}
