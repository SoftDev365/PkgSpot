package com.pkgspot.fragment.user_home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ExpandableListView;

import com.pkgspot.R;
import com.pkgspot.adapter.HelpAdapter;
import com.pkgspot.data.HelpData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class HelpFragment extends BaseFragment {
    private View view;
    private ExpandableListView helpELV;
    private ArrayList<String> childDrawerItems = new ArrayList<>();
    private ArrayList<HelpData> lists = new ArrayList<>();
    private HelpAdapter helpAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_help, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        helpELV = (ExpandableListView) view.findViewById(R.id.helpELV);

        Display newDisplay = baseActivity.getWindowManager().getDefaultDisplay();
        int width = newDisplay.getWidth();
        helpELV.setIndicatorBounds(width - 50, width);

        Button contactBT = (Button) view.findViewById(R.id.contactBT);

        contactBT.setOnClickListener(this);
        hitGetHelpApi();

    }

    private void hitGetHelpApi() {
        syncManager.sendToServer(Const.HELP_PAGE, null, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.contactBT:
                try {
                    //for both email and gmail
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("mailto:" + "info@pkgspot.com"));
                    intent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
                    intent.putExtra(Intent.EXTRA_TEXT, "text here");
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    baseActivity.showToastOne("Exception:" + e);
                }
                break;
        }
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.HELP_PAGE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        HelpData helpData = new HelpData();
                        helpData.id = object.getInt("id");
                        helpData.title = object.getString("title");
                        lists.add(helpData);
                        String description = object.getString("description");
                        childDrawerItems.add(description);
                    }
                    setAdapter();
                } else {
                    if (helpAdapter != null) {
                        helpAdapter.notifyDataSetChanged();
                    }
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setAdapter() {
        if (helpAdapter == null) {
            helpAdapter = new HelpAdapter(baseActivity, lists, childDrawerItems);
            helpELV.setAdapter(helpAdapter);
        } else {
            helpAdapter.notifyDataSetChanged();
        }
    }
}