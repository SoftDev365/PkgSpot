package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.fragment.login_phase.LoginFragment;

/**
 * Created by TOXSL\gunjan.luthra on 31/8/17.
 */

public class ThankYouFragment extends BaseFragment {
    private View view;
    private Button nextBT;
    private boolean isFirst;
    private TextView thanksTV;
    private LinearLayout fbLL, twitterLL;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_thankx, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        nextBT = (Button) view.findViewById(R.id.nextBT);

        thanksTV = (TextView) view.findViewById(R.id.thanksTV);

        fbLL = (LinearLayout) view.findViewById(R.id.fbLL);
        twitterLL = (LinearLayout) view.findViewById(R.id.twitterLL);

        nextBT.setOnClickListener(this);
        twitterLL.setOnClickListener(this);
        fbLL.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.nextBT:
                gotoLoginFragment();
                break;

            case R.id.fbLL:
                showToast("Yet to imp");
                break;

            case R.id.twitterLL:
                showToast("Yet to imp");
                break;
        }
    }

    private void gotoLoginFragment() {
        Fragment fragment = new LoginFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }
}


