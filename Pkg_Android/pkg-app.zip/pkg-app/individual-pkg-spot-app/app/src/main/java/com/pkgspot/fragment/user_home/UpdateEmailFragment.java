package com.pkgspot.fragment.user_home;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.pkgspot.R;
import com.pkgspot.data.UserProfileData;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\parwinder.deep on 2/11/17.
 */

public class UpdateEmailFragment extends BaseFragment {
    private View view;
    private String userId;
    private EditText emailEt;
    private Button doneBT;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userId = store.getString(Const.USER_ID);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_update_email, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {

        emailEt = (EditText) view.findViewById(R.id.emailET);
        doneBT = (Button) view.findViewById(R.id.doneBT);

        doneBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.doneBT:
                if (validateEmail()) {
                    hitUpdateEmailApi();
                }
                break;
        }
    }

    private boolean validateEmail() {
        if (emailEt.getText().toString().isEmpty()) {
            baseActivity.showToastOne(getString(R.string.enter_email));
            return false;
        } else if (!baseActivity.isValidMail(emailEt.getText().toString())) {
            baseActivity.showToastOne(getString(R.string.enter_valid_email));
            return false;
        } else {
            return true;
        }
    }

    private void hitUpdateEmailApi() {
        RequestParams params = new RequestParams();
        params.put("email", emailEt.getText().toString());
        syncManager.sendToServer(Const.UPDATE_EMAIL + "/" + userId, params, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.UPDATE_EMAIL + "/" + userId)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("Email changed successfully");
                    baseActivity.getSupportFragmentManager().popBackStack();
                    if (jsonObject.has("data")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject object = data.getJSONObject(i);
                            UserProfileData profileData = baseActivity.dataParsor.getUserProfileData(object);
                            baseActivity.saveUserProfileDataInPrefStore(profileData);
                        }
                    }
                } else {
                    elseErrorMsg(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}