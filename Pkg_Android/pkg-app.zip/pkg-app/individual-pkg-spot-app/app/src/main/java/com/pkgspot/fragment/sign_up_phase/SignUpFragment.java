package com.pkgspot.fragment.sign_up_phase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.pkgspot.BuildConfig;
import com.pkgspot.R;
import com.pkgspot.fragment.BaseFragment;
import com.pkgspot.utils.Const;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by TOXSL\chirag.tyagi on 25/8/17.
 */

public class SignUpFragment extends BaseFragment {
    private View view;
    private EditText nameET, emailET, passwordET, zipET;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_sign_up, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        nameET = (EditText) view.findViewById(R.id.nameET);
        emailET = (EditText) view.findViewById(R.id.emailET);
        passwordET = (EditText) view.findViewById(R.id.passwordET);
        zipET = (EditText) view.findViewById(R.id.zipET);

        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);

        if (BuildConfig.DEBUG) {
            nameET.setText("parwinder");
            emailET.setText("parwinderdeep95@gmail.com");
            passwordET.setText("aA@123");
            zipET.setText("123456");
        }
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                if (isValidate()) {
                    hitSignApi();
                }
                break;
        }
    }

    private void hitSignApi() {
        RequestParams params = new RequestParams();
        params.put("full_name", nameET.getText().toString().trim());
        params.put("email", emailET.getText().toString().trim());
        params.put("password", passwordET.getText().toString().trim());
        params.put("zipcode", zipET.getText().toString().trim());
        syncManager.sendToServer(Const.STEP_1_SIGN_UP, params, this);
    }

    private boolean isValidate() {
        if (nameET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_full_name));
            return false;
        } else if (baseActivity.isValidMail(nameET.getText().toString())) {
            showToast(getString(R.string.enter_valid_name));
            return false;
        } else if (emailET.getText().toString().isEmpty()) {
            showToast(baseActivity.getString(R.string.enter_email));
            return false;
        } else if (!baseActivity.isValidMail(emailET.getText().toString())) {
            showToast(baseActivity.getString(R.string.enter_valid_email));
            return false;
        } else if (passwordET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_password));
            return false;
        } else if (passwordET.getText().toString().length() < 6) {
            showToast(getString(R.string.enter_min_6_char));
            return false;
        } else if (!isValidPassword(passwordET.getText().toString())) {
            showToast(getString(R.string.enter_valid_password));
            return false;
        } else if (zipET.getText().toString().isEmpty()) {
            showToast(getString(R.string.enter_zipcode));
            return false;
        } else {
            return true;
        }
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equalsIgnoreCase(Const.STEP_1_SIGN_UP)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    if (jsonObject.has("userId")) {
                        gotoAddPhoneFragment(jsonObject.getString("userId"));
                    } else {
                        showToast(baseActivity.getString(R.string.user_id_not_found));
                    }
                } else {
                    showToast(jsonObject.optString("error"));
                    if (jsonObject.has("step")) {
                        String userId = jsonObject.optString("userId");
                        switch (jsonObject.getInt("step")) {
                            case 1:
                                gotoAddPhoneFragment(userId);
                                break;
                            case 2:
                                gotoLocationFragment(true, userId);
                                break;
                            case 3:
                                gotoAddcardFragment(true, userId);
                                break;

                            case 0:
                                break;

                            default:
                                showToast(getString(R.string.error_in_streps));
                                break;

                        }
                    }

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
