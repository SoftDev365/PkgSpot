package pkgpartner.app.fragment.LoginPhase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\parwinder.deep on 18/10/17.
 */

public class ForgotPasswordFragment extends BaseFragment {
    private View view;
    private EditText emailET;
    private static Integer frame_id;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_forgot_password, container, false);
        }
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;

        Bundle bundle = getArguments();
        if (bundle.containsKey("frame_id")) {
            frame_id = bundle.getInt("frame_id");
        }
        initUI();
    }

    private void initUI() {
        emailET = (EditText) view.findViewById(R.id.emailET);
        TextView getOtpTV = (TextView) view.findViewById(R.id.getOtpTV);

        getOtpTV.setVisibility(View.GONE);
        Button sendBT = (Button) view.findViewById(R.id.sendBT);

        sendBT.setOnClickListener(this);
        getOtpTV.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.sendBT:
                if (isValidate()) {
                    hitDoneApi();
                }
                break;

            case R.id.getOtpTV:
                gotoForgotOtpFragment(emailET.getText().toString().trim(), frame_id);
                break;
        }
    }

    private void hitDoneApi() {
        RequestParams params = new RequestParams();
        params.put("email", emailET.getText().toString().trim());
        syncManager.sendToServer(Const.FORGOT_PASSWORD, params, this);
    }

    private boolean isValidate() {
        if (emailET.getText().toString().isEmpty()) {
            showToast("Please enter email address");
            return false;
        } else if (!baseActivity.isValidMail(emailET.getText().toString())) {
            showToast("Please enter valid email");
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.FORGOT_PASSWORD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("Email containing OTP has been sent to your registered Email address");
                    gotoForgotOtpFragment(emailET.getText().toString().trim(), frame_id);
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

