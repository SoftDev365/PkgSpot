package pkgpartner.app.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import pkgpartner.app.R;

/**
 * Created by TOXSL\parwinder.deep on 27/10/17.
 */

public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.MyViewHolder> {
    private ArrayList<String> images = new ArrayList<>();
    private Context context;

    public ImagesAdapter(Context context, ArrayList<String> imageList) {
        this.images = imageList;
        this.context = context;
    }

    @Override
    public ImagesAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.adapter_image_dailog, parent, false);
        return new ImagesAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ImagesAdapter.MyViewHolder holder, int position) {
        holder.deleteIV.setVisibility(View.GONE);
        try {
            Glide.with(context).load(images.get(position)).into(holder.imageIV);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return images.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageIV;
        ImageView deleteIV;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageIV = (ImageView) itemView.findViewById(R.id.imageIV);
            deleteIV = (ImageView) itemView.findViewById(R.id.deleteIV);
        }
    }
}
