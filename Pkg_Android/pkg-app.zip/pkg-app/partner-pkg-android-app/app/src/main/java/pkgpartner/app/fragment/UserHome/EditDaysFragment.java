package pkgpartner.app.fragment.UserHome;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TimePicker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

import pkgpartner.app.R;
import pkgpartner.app.data.DaysData;
import pkgpartner.app.data.Friday;
import pkgpartner.app.data.Monday;
import pkgpartner.app.data.Saturday;
import pkgpartner.app.data.Sunday;
import pkgpartner.app.data.Thursday;
import pkgpartner.app.data.Tuesday;
import pkgpartner.app.data.Wednesday;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 11/9/17.
 */

public class EditDaysFragment extends BaseFragment {

    String mondayAM, mondayPM;
    String tuesdayAM, tuesdayPM;
    String wednesdayAM, wednesdayPM;
    String thursdayAM, thursdayPM;
    String fridayAM, fridayPM;
    String saturdayAM, saturdayPM;
    String sundayAM, sundayPM;
    private View view;
    private CheckBox mondayCB, tuesdayCB, wednesdayCB, thursdayCB, fridayCB, saturdayCB, sundayCB, allHourCB, allHour_ssCB;
    private EditText mfromET, mtoET, tfromET, ttoET, wfromET, wtoET, ThfromET, ThtoET, ffromET, ftoET, safromET, satoET, sunfromET, suntoET;
    private String _hour, _minute, AM, PM, AMss, PMss;
    private Button nextBT, fill_in_allBT, fill_in_all_ssBT;
    private ArrayList<DaysData> daysDatas = new ArrayList<>();
    private String days_of_service;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        view = inflater.inflate(R.layout.fg_edit_days_hours_service, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
    }

    private void initUI() {

        hitGetProfileApi();

        mfromET = (EditText) view.findViewById(R.id.mfromET);
        mtoET = (EditText) view.findViewById(R.id.mtoET);
        tfromET = (EditText) view.findViewById(R.id.tfromET);
        ttoET = (EditText) view.findViewById(R.id.ttoET);
        wfromET = (EditText) view.findViewById(R.id.wfromET);
        wtoET = (EditText) view.findViewById(R.id.wtoET);
        ThfromET = (EditText) view.findViewById(R.id.ThfromET);
        ThtoET = (EditText) view.findViewById(R.id.ThtoET);
        ffromET = (EditText) view.findViewById(R.id.ffromET);
        ftoET = (EditText) view.findViewById(R.id.ftoET);
        safromET = (EditText) view.findViewById(R.id.safromET);
        satoET = (EditText) view.findViewById(R.id.satoET);
        sunfromET = (EditText) view.findViewById(R.id.sunfromET);
        suntoET = (EditText) view.findViewById(R.id.suntoET);

        mondayCB = (CheckBox) view.findViewById(R.id.mondayCB);
        tuesdayCB = (CheckBox) view.findViewById(R.id.tuesdayCB);
        wednesdayCB = (CheckBox) view.findViewById(R.id.wednesdayCB);
        thursdayCB = (CheckBox) view.findViewById(R.id.thursdayCB);
        fridayCB = (CheckBox) view.findViewById(R.id.fridayCB);
        saturdayCB = (CheckBox) view.findViewById(R.id.saturdayCB);
        sundayCB = (CheckBox) view.findViewById(R.id.sundayCB);
        allHourCB = (CheckBox) view.findViewById(R.id.allHourCB);
        allHour_ssCB = (CheckBox) view.findViewById(R.id.allHour_ssCB);

        nextBT = (Button) view.findViewById(R.id.nextBT);
        fill_in_allBT = (Button) view.findViewById(R.id.fill_in_allBT);
        fill_in_all_ssBT = (Button) view.findViewById(R.id.fill_in_all_ssBT);
        fill_in_allBT.setOnClickListener(this);
        fill_in_all_ssBT.setOnClickListener(this);
        nextBT.setOnClickListener(this);

        allHourCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mondayCB.setChecked(isChecked);
                tuesdayCB.setChecked(isChecked);
                wednesdayCB.setChecked(isChecked);
                thursdayCB.setChecked(isChecked);
                fridayCB.setChecked(isChecked);
                mfromET.setEnabled(isChecked);
                mtoET.setEnabled(isChecked);
                tfromET.setEnabled(isChecked);
                ttoET.setEnabled(isChecked);
                wfromET.setEnabled(isChecked);
                wtoET.setEnabled(isChecked);
                ThfromET.setEnabled(isChecked);
                ThtoET.setEnabled(isChecked);
                ffromET.setEnabled(isChecked);
                ftoET.setEnabled(isChecked);

                if (isChecked && mfromET.getText().toString().equals("") && mtoET.getText().toString().equals("") &&
                        tfromET.getText().toString().equals("") && ttoET.getText().toString().equals("") &&
                        wfromET.getText().toString().equals("") && wtoET.getText().toString().equals("") &&
                        ThfromET.getText().toString().equals("") && ThtoET.getText().toString().equals("") &&
                        ffromET.getText().toString().equals("") && ftoET.getText().toString().equals("")) {

                } else {
                    mfromET.setText("");
                    mtoET.setText("");
                    tfromET.setText("");
                    ttoET.setText("");
                    wfromET.setText("");
                    wtoET.setText("");
                    ThfromET.setText("");
                    ThtoET.setText("");
                    ffromET.setText("");
                    ftoET.setText("");

                }
            }
        });


        allHour_ssCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                saturdayCB.setChecked(isChecked);
                sundayCB.setChecked(isChecked);
                safromET.setEnabled(isChecked);
                satoET.setEnabled(isChecked);
                sunfromET.setEnabled(isChecked);
                suntoET.setEnabled(isChecked);

                if (isChecked && safromET.getText().toString().equals("") && satoET.getText().toString().equals("") &&
                        sunfromET.getText().toString().equals("") && suntoET.getText().toString().equals("")) {

                } else {
                    safromET.setText("");
                    satoET.setText("");
                    sunfromET.setText("");
                    suntoET.setText("");
                }
            }
        });

        mondayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mfromET.setEnabled(isChecked);
                mtoET.setEnabled(isChecked);

                if (isChecked) {
                    mondayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    mondayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    mondayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    mondayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    mondayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }
            }
        });

        tuesdayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                tfromET.setEnabled(isChecked);
                ttoET.setEnabled(isChecked);

                if (isChecked) {
                    tuesdayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    tuesdayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    tuesdayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    tuesdayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    tuesdayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }
            }
        });

        wednesdayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                wfromET.setEnabled(isChecked);
                wtoET.setEnabled(isChecked);

                if (isChecked) {
                    wednesdayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    wednesdayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    wednesdayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    wednesdayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                    wednesdayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                }
            }
        });

        thursdayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ThfromET.setEnabled(isChecked);
                ThtoET.setEnabled(isChecked);

                if (isChecked) {
                    thursdayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    thursdayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    thursdayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    thursdayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    thursdayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }
            }
        });

        fridayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ffromET.setEnabled(isChecked);
                ftoET.setEnabled(isChecked);

                if (isChecked) {
                    fridayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    fridayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    fridayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    fridayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    fridayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }
            }
        });

        saturdayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                safromET.setEnabled(isChecked);
                satoET.setEnabled(isChecked);

                if (isChecked) {
                    saturdayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    saturdayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    saturdayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    saturdayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    saturdayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }
            }
        });

        sundayCB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                sunfromET.setEnabled(isChecked);
                suntoET.setEnabled(isChecked);

                if (isChecked) {
                    sundayCB.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                    sundayCB.setTextColor(getResources().getColor(R.color.white));
                } else {
                    sundayCB.setBackgroundColor(getResources().getColor(R.color.white));
                    sundayCB.setTextColor(getResources().getColor(R.color.colorPrimary));
                    sundayCB.setBackground(getResources().getDrawable(R.drawable.textview_bg));
                }

            }
        });

        mfromET.setOnClickListener(this);
        mtoET.setOnClickListener(this);
        tfromET.setOnClickListener(this);
        ttoET.setOnClickListener(this);
        wfromET.setOnClickListener(this);
        wtoET.setOnClickListener(this);
        ThfromET.setOnClickListener(this);
        ThtoET.setOnClickListener(this);
        ffromET.setOnClickListener(this);
        ftoET.setOnClickListener(this);
        safromET.setOnClickListener(this);
        satoET.setOnClickListener(this);
        sunfromET.setOnClickListener(this);
        suntoET.setOnClickListener(this);
    }

    private void hitGetProfileApi() {
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.USER_PROFILE + user_id, null, this);
    }

    private String pickdate(final EditText dateET) {
        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        final int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {


                String status = "AM";

                if (selectedHour > 11) {
                    status = "PM";
                }

                int hour_of_12_hour_format;

                if (selectedHour > 11) {
                    hour_of_12_hour_format = selectedHour - 12;
                } else {
                    hour_of_12_hour_format = selectedHour;
                }

                dateET.setText(hour_of_12_hour_format + " : " + minute + " " + status);

            }
        }, hour, minute, false);
        mTimePicker.show();
        return _hour + ":" + _minute;
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {

            case R.id.mfromET:
                pickdate(mfromET);
                break;

            case R.id.mtoET:
                pickdate(mtoET);
                break;

            case R.id.tfromET:
                pickdate(tfromET);
                break;

            case R.id.ttoET:
                pickdate(ttoET);
                break;

            case R.id.wfromET:
                pickdate(wfromET);
                break;

            case R.id.wtoET:
                pickdate(wtoET);
                break;

            case R.id.ThfromET:
                pickdate(ThfromET);
                break;

            case R.id.ThtoET:
                pickdate(ThtoET);
                break;

            case R.id.ffromET:
                pickdate(ffromET);
                break;

            case R.id.ftoET:
                pickdate(ftoET);
                break;

            case R.id.safromET:
                pickdate(safromET);
                break;

            case R.id.satoET:
                pickdate(satoET);
                break;

            case R.id.sunfromET:
                pickdate(sunfromET);
                break;

            case R.id.suntoET:
                pickdate(suntoET);
                break;

            case R.id.fill_in_allBT:
                if (mondayCB.isChecked() && tuesdayCB.isChecked() && wednesdayCB.isChecked() &&
                        thursdayCB.isChecked() && fridayCB.isChecked()) {

                    if (!mfromET.getText().toString().isEmpty() && !mtoET.getText().toString().isEmpty()) {

                        AM = mfromET.getText().toString().trim();
                        PM = mtoET.getText().toString().trim();
                    } else if (!tfromET.getText().toString().isEmpty() && !ttoET.getText().toString().isEmpty()) {

                        AM = tfromET.getText().toString().trim();
                        PM = ttoET.getText().toString().trim();
                    } else if (!wfromET.getText().toString().isEmpty() && !wtoET.getText().toString().isEmpty()) {

                        AM = wfromET.getText().toString().trim();
                        PM = wtoET.getText().toString().trim();
                    } else if (!ThfromET.getText().toString().isEmpty() && !ThtoET.getText().toString().isEmpty()) {

                        AM = ThfromET.getText().toString().trim();
                        PM = ThtoET.getText().toString().trim();
                    } else if (!ffromET.getText().toString().isEmpty() && !ftoET.getText().toString().isEmpty()) {

                        AM = ffromET.getText().toString().trim();
                        PM = ftoET.getText().toString().trim();
                    } else {
                        showToast("Enter both AM and PM");
                    }

                    mfromET.setText(AM);
                    mtoET.setText(PM);
                    tfromET.setText(AM);
                    ttoET.setText(PM);
                    wfromET.setText(AM);
                    wtoET.setText(PM);
                    ThfromET.setText(AM);
                    ThtoET.setText(PM);
                    ffromET.setText(AM);
                    ftoET.setText(PM);

                } else {

                    showToast("Select Mon-Fri");
                }
                break;

            case R.id.fill_in_all_ssBT:

                if (saturdayCB.isChecked() && sundayCB.isChecked()) {

                    if (!safromET.getText().toString().isEmpty() && !satoET.getText().toString().isEmpty()) {

                        AMss = safromET.getText().toString().trim();
                        PMss = satoET.getText().toString().trim();
                    } else if (!sunfromET.getText().toString().isEmpty() && !suntoET.getText().toString().isEmpty()) {

                        AMss = sunfromET.getText().toString().trim();
                        PMss = suntoET.getText().toString().trim();
                    } else {
                        showToast("Enter both AM and PM");
                    }

                    safromET.setText(AMss);
                    satoET.setText(PMss);
                    sunfromET.setText(AMss);
                    suntoET.setText(PMss);

                } else {
                    showToast("Select Sat-Sun");
                }

                break;

            case R.id.nextBT:
                daysDatas.clear();

                if (mfromET.getText().toString().equals("") && mtoET.getText().toString().equals("") &&
                        tfromET.getText().toString().equals("") && ttoET.getText().toString().equals("") &&
                        wfromET.getText().toString().equals("") && wtoET.getText().toString().equals("") &&
                        ThfromET.getText().toString().equals("") && ThtoET.getText().toString().equals("") &&
                        ffromET.getText().toString().equals("") && ftoET.getText().toString().equals("") &&
                        safromET.getText().toString().equals("") && satoET.getText().toString().equals("") &&
                        suntoET.getText().toString().equals("") && suntoET.getText().toString().equals("")) {
                    showToast("Please enter atleast 1 field.");
                } else {
                    DaysData daysData = new DaysData();
                    if (!mfromET.getText().toString().isEmpty() && !mtoET.getText().toString().isEmpty()) {
                        Monday monday = new Monday();
                        monday.setStartTime(mfromET.getText().toString());
                        monday.setEndTime(mtoET.getText().toString());
                        daysData.setMonday(monday);
                    }

                    if (!tfromET.getText().toString().isEmpty() && !tfromET.getText().toString().isEmpty()) {
                        Tuesday tuesday = new Tuesday();
                        tuesday.setStartTime(tfromET.getText().toString());
                        tuesday.setEndTime(ttoET.getText().toString());
                        daysData.setTuesday(tuesday);
                    }

                    if (!wfromET.getText().toString().isEmpty() && !wfromET.getText().toString().isEmpty()) {
                        Wednesday wednesday = new Wednesday();
                        wednesday.setStartTime(wfromET.getText().toString());
                        wednesday.setEndTime(wfromET.getText().toString());
                        daysData.setWednesday(wednesday);
                    }

                    if (!ThfromET.getText().toString().isEmpty() && !ThtoET.getText().toString().isEmpty()) {
                        Thursday thursday = new Thursday();
                        thursday.setStartTime(ThfromET.getText().toString());
                        thursday.setEndTime(ThtoET.getText().toString());
                        daysData.setThursday(thursday);
                    }

                    if (!ffromET.getText().toString().isEmpty() && !ftoET.getText().toString().isEmpty()) {
                        Friday friday = new Friday();
                        friday.setStartTime(ffromET.getText().toString());
                        friday.setEndTime(ftoET.getText().toString());
                        daysData.setFriday(friday);
                    }

                    if (!safromET.getText().toString().isEmpty() && !satoET.getText().toString().isEmpty()) {
                        Saturday saturday = new Saturday();
                        saturday.setStartTime(safromET.getText().toString());
                        saturday.setEndTime(satoET.getText().toString());
                        daysData.setSaturday(saturday);
                    }

                    if (!sunfromET.getText().toString().isEmpty() && !suntoET.getText().toString().isEmpty()) {
                        Sunday sunday = new Sunday();
                        sunday.setStartTime(sunfromET.getText().toString());
                        sunday.setEndTime(suntoET.getText().toString());
                        daysData.setSunday(sunday);
                    }

                    daysDatas.add(daysData);

                    getDaysofService();
                    hitUpdateInfoApi();
                }
                break;
        }
    }

    private JsonArray getDaysofService() {
        Gson gson = new GsonBuilder().create();
        return gson.toJsonTree(daysDatas).getAsJsonArray();
    }

    private void hitUpdateInfoApi() {
        String user_id = baseActivity.store.getString("user_id");
        RequestParams requestParams = new RequestParams();
        requestParams.put("days_of_service", getDaysofService());
        syncManager.sendToServer(Const.INFO_UPDATE + user_id, requestParams, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.INFO_UPDATE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Information updated");
                    HomeFragment barCodeScannerFragment = new HomeFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, barCodeScannerFragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                }

            } else if (jsonObject.getString("url").contains(Const.USER_PROFILE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        days_of_service = object.getString("days_of_service");
                        String text = days_of_service;
                        text = text.replaceAll("\n", "");

                        JSONArray jsonArray = new JSONArray(text);

                        for (int k = 0; k < jsonArray.length(); k++) {
                            JSONObject days = jsonArray.getJSONObject(k);


                            if (days.has("monday")) {
                                Monday monday = new Monday();
                                JSONObject mondayObject = days.getJSONObject("monday");
                                monday.setStartTime(mondayObject.get("start_time").toString());
                                mondayAM = monday.getStartTime();
                                monday.setEndTime(mondayObject.get("end_time").toString());
                                mondayPM = monday.getEndTime();
                            }

                            if (days.has("tuesday")) {
                                Tuesday tuesday = new Tuesday();
                                JSONObject tuesdayObject = days.getJSONObject("tuesday");
                                tuesday.setStartTime(tuesdayObject.get("start_time").toString());
                                tuesdayAM = tuesday.getStartTime();
                                tuesday.setEndTime(tuesdayObject.get("end_time").toString());
                                tuesdayPM = tuesday.getEndTime();
                            }

                            if (days.has("wednesday")) {
                                Wednesday wednesday = new Wednesday();
                                JSONObject wednesdayObject = days.getJSONObject("wednesday");
                                wednesday.setStartTime(wednesdayObject.get("start_time").toString());
                                wednesdayAM = wednesday.getStartTime();
                                wednesday.setEndTime(wednesdayObject.get("end_time").toString());
                                wednesdayPM = wednesday.getEndTime();
                            }

                            if (days.has("thursday")) {
                                Thursday thursday = new Thursday();
                                JSONObject thursdayobject = days.getJSONObject("thursday");
                                thursday.setStartTime(thursdayobject.get("start_time").toString());
                                thursdayAM = thursday.getStartTime();
                                thursday.setEndTime(thursdayobject.get("end_time").toString());
                                thursdayPM = thursday.getEndTime();
                            }

                            if (days.has("friday")) {
                                Friday friday = new Friday();
                                JSONObject fridayObject = days.getJSONObject("friday");
                                friday.setStartTime(fridayObject.get("start_time").toString());
                                fridayAM = friday.getStartTime();
                                friday.setEndTime(fridayObject.get("end_time").toString());
                                fridayPM = friday.getEndTime();
                            }

                            if (days.has("saturday")) {
                                Saturday saturday = new Saturday();
                                JSONObject saturdayObject = days.getJSONObject("saturday");
                                saturday.setStartTime(saturdayObject.get("start_time").toString());
                                saturdayAM = saturday.getStartTime();
                                saturday.setEndTime(saturdayObject.get("end_time").toString());
                                saturdayPM = saturday.getEndTime();
                            }

                            if (days.has("sunday")) {
                                Sunday sunday = new Sunday();
                                JSONObject sundayObject = days.getJSONObject("sunday");
                                sunday.setStartTime(sundayObject.get("start_time").toString());
                                sundayAM = sunday.getStartTime();
                                sunday.setEndTime(sundayObject.get("end_time").toString());
                                sundayPM = sunday.getEndTime();
                            }
                        }

                        setData();
                    }
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setData() {
        mfromET.setText(mondayAM);
        mtoET.setText(mondayPM);
        tfromET.setText(tuesdayAM);
        ttoET.setText(tuesdayPM);
        wfromET.setText(wednesdayAM);
        wtoET.setText(wednesdayPM);
        ThfromET.setText(thursdayAM);
        ThtoET.setText(thursdayPM);
        ffromET.setText(fridayAM);
        ftoET.setText(fridayPM);
        safromET.setText(saturdayAM);
        satoET.setText(saturdayPM);
        sunfromET.setText(sundayAM);
        suntoET.setText(sundayPM);
    }
}
