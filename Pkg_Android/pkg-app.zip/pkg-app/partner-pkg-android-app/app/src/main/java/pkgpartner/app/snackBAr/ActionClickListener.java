package pkgpartner.app.snackBAr;

public interface ActionClickListener {
    void onActionClicked(Snackbar snackbar);
}
