package pkgpartner.app.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by TOXSL\parwinder.deep on 3/10/17.
 */

public class HistoryData {

    @SerializedName("id")
    @Expose
    public String id;

    @SerializedName("cuid")
    @Expose
    public String cuid;

    @SerializedName("customer_name")
    @Expose
    public String customerName;

    @SerializedName("puid")
    @Expose
    public String puid;

    @SerializedName("business_name")
    @Expose
    public String businessName;

    @SerializedName("package_count")
    @Expose
    public String packageCount;

    @SerializedName("recived_date")
    @Expose
    public String recivedDate;

    @SerializedName("pickedup_date")
    @Expose
    public String pickedupDate;

    @SerializedName("price_per_pkg")
    @Expose
    public String pricePerPkg;

    @SerializedName("late_per_pkg")
    @Expose
    public String latePerPkg;

    @SerializedName("pkg_price")
    @Expose
    public String pkgPrice;

    @SerializedName("extra_price")
    @Expose
    public String extraPrice;

    @SerializedName("total_price")
    @Expose
    public String totalPrice;

    @SerializedName("image_file")
    @Expose
    public String imageFile;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCuid() {
        return cuid;
    }

    public void setCuid(String cuid) {
        this.cuid = cuid;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPuid() {
        return puid;
    }

    public void setPuid(String puid) {
        this.puid = puid;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getPackageCount() {
        return packageCount;
    }

    public void setPackageCount(String packageCount) {
        this.packageCount = packageCount;
    }

    public String getRecivedDate() {
        return recivedDate;
    }

    public void setRecivedDate(String recivedDate) {
        this.recivedDate = recivedDate;
    }

    public String getPickedupDate() {
        return pickedupDate;
    }

    public void setPickedupDate(String pickedupDate) {
        this.pickedupDate = pickedupDate;
    }

    public String getPricePerPkg() {
        return pricePerPkg;
    }

    public void setPricePerPkg(String pricePerPkg) {
        this.pricePerPkg = pricePerPkg;
    }

    public String getLatePerPkg() {
        return latePerPkg;
    }

    public void setLatePerPkg(String latePerPkg) {
        this.latePerPkg = latePerPkg;
    }

    public String getPkgPrice() {
        return pkgPrice;
    }

    public void setPkgPrice(String pkgPrice) {
        this.pkgPrice = pkgPrice;
    }

    public String getExtraPrice() {
        return extraPrice;
    }

    public void setExtraPrice(String extraPrice) {
        this.extraPrice = extraPrice;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getImageFile() {
        return imageFile;
    }

    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }

}
