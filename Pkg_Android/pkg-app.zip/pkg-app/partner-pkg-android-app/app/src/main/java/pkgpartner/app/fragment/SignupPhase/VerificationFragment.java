package pkgpartner.app.fragment.SignupPhase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 7/9/17.
 */

public class VerificationFragment extends BaseFragment {

    TextView emailtext_TV, didTV;
    private View view;
    private String user_id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_id");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        return inflater.inflate(R.layout.fg_verfication, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void hitVerifyEmailApi(String user_id) {

        syncManager.sendToServer(Const.STEP_3_SIGN_UP + user_id, null, this);
    }

    private void initUI() {
        emailtext_TV = (TextView) view.findViewById(R.id.emailtext_TV);
        didTV = (TextView) view.findViewById(R.id.did_TV);
        String email = baseActivity.store.getString("email");
        emailtext_TV.setText(email);
        didTV.setText(Html.fromHtml("<u>Did not receive email</u>"));
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);
        didTV.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                hitVerifyEmailApi(user_id);
                break;

            case R.id.did_TV:
                String email = baseActivity.store.getString("email");
                emailtext_TV.setText(email);
                hitResenEmailApi(email);
        }
    }

    private void hitResenEmailApi(String email) {
        RequestParams params = new RequestParams();
        params.put("email", email);
        syncManager.sendToServer(Const.RESEND_EMAIL, params, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.STEP_3_SIGN_UP)) {
                if (jsonObject.getInt("status") == (Const.STATUS_OK)) {
                    Bundle bundle = new Bundle();
                    bundle.putString("user_id", user_id);
                    Fragment fragment = new CreateAccountFragment();
                    fragment.setArguments(bundle);
                    baseActivity.getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.login_frame, fragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}