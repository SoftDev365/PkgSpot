package pkgpartner.app.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;

import com.toxsl.volley.Request;
import com.toxsl.volley.VolleyError;
import com.toxsl.volley.toolbox.SyncEventListner;
import com.toxsl.volley.toolbox.SyncManager;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.BuildConfig;
import pkgpartner.app.R;
import pkgpartner.app.activity.BaseActivity;
import pkgpartner.app.fragment.LoginPhase.OtpFragment;
import pkgpartner.app.fragment.SignupPhase.Addmessage;
import pkgpartner.app.fragment.SignupPhase.TermsAndServiceFragment;
import pkgpartner.app.fragment.SignupPhase.VerificationFragment;

/**
 * Created by TOXSL\neeraj.narwal on 2/2/16.
 */
public class BaseFragment extends Fragment implements AdapterView.OnItemClickListener,
        View.OnClickListener, SyncEventListner, AdapterView.OnItemSelectedListener,
        CompoundButton.OnCheckedChangeListener {
    public SyncManager syncManager;
    public BaseActivity baseActivity;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        baseActivity = (BaseActivity) getActivity();
        syncManager = SyncManager.getInstance(baseActivity, !BuildConfig.DEBUG);
    }

    @Override
    public void onResume() {
        super.onResume();
        baseActivity.hideSoftKeyboard();
        getActivity().invalidateOptionsMenu();
    }

    public boolean isValidPassword(String password) {
        return password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{6,}$");
    }

    @Override
    public void onClick(View v) {

    }

    public void showToast(String msg) {
        baseActivity.showToast(msg);
    }

    @Override
    public void onSyncStart() {
        baseActivity.onSyncStart();
    }

    @Override
    public void onSyncFinish() {
        baseActivity.onSyncFinish();
    }

    @Override
    public void onSyncFailure(VolleyError error, Request mRequest) {
        baseActivity.onSyncFailure(error, mRequest);
    }

    public void log(String s) {
        baseActivity.log(s);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

    }

    public void gotoSignUpSecond(boolean b, String userId) {

        Fragment fragment = new Addmessage();
        Bundle bundle = new Bundle();
        bundle.putString("user_ID", userId);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();

    }

    public void gotoMarketingMessage(boolean b, String user_id) {
        Fragment fragment = new Addmessage();
        Bundle bundle = new Bundle();
        bundle.putString("user_Id", user_id);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();

    }

    public void gotoVerificationFragment(boolean b, String user_id) {
        Fragment fragment = new VerificationFragment();
        Bundle bundle = new Bundle();
        bundle.putString("user_Id", user_id);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void gotoForgotOtpFragment(String email, Integer frameID) {
        Fragment fragment = new OtpFragment();
        Bundle bundle = new Bundle();
        bundle.putString("email", email);
        bundle.putInt("frame_id", frameID);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(frameID, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void errorMessage(JSONObject jsonObject) throws JSONException {
        String error = "Something Went Wrong";
        if (jsonObject.has("error")) {
            error = jsonObject.getString("error");
        }
        showToast(error);
    }
}
