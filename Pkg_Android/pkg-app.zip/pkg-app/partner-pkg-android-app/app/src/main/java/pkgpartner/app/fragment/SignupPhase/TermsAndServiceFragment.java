package pkgpartner.app.fragment.SignupPhase;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.toxsl.volley.Request;
import com.toxsl.volley.VolleyError;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

import static pkgpartner.app.R.string.view;

/**
 * A simple {@link Fragment} subclass.
 */
public class TermsAndServiceFragment extends BaseFragment {
    TextView terms;
    View view;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_terms_and_service, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        terms = (TextView) view.findViewById(R.id.service_TV);
        hitTermApi();
    }

    private void hitTermApi() {

        syncManager.sendToServer(Const.TERMS_PAGE + "/" + Const.TYPE_TERMS_CUSTOMER, null, TermsAndServiceFragment.this);

    }

    @Override
        public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        log("success");
        try {
            if (jsonObject.getInt("status") == Const.STATUS_OK) {
                JSONArray array = jsonObject.getJSONArray("data");
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    String description = object.getString("description");
                    Spanned sp = Html.fromHtml(description.replace("&lt;", "<").replace("&gt;", ">"));
                    terms.setText(sp);
                }

            } else {
                showToast("User Id Not found");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSyncFailure(VolleyError error, Request mRequest) {
        super.onSyncFailure(error, mRequest);
        log("failure");
    }
}
