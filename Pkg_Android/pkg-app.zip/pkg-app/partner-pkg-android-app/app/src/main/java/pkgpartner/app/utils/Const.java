package pkgpartner.app.utils;

public class Const {

    public static final String SERVER_REMOTE_URL = "http://34.230.87.240/"; //live
    public static final String LOCAL_URL = "http://127.0.0.1:3040/"; //local
    public static final String DISPLAY_MESSAGE_ACTION = "com.packagename.DISPLAY_MESSAGE";
    public static final int PLAY_SERVICES_RESOLUTION_REQUEST = 1234;
    public static final int PLACE_SEARCH = 1222;
    /**
     * ******************************* App buy or Purchase Key *************************************
     */
    public static final String IN_APP_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiwmkXRr/Ui6Onc3hZl8gvxe2D9DIyAELLBMryE2+iz1X6ToPAl2D+Lypytja+xc5u1s5yyfX5PzsruerkUfwm6nMjXwX2v64+syV3QjC1yQ3HuMCL4IJgu+jSymj8PQ+tBK9i8ehWm4NvYZ8KG6uCXnR2xqWQKgJEm0E96aMl7jwb7BvAvfn62/Frqlxw9n3V1f11CbgbQUbY8rOjpZvTZ+LF+Ly5NdFAM+H8BafdF7WQ0N3mmQfqmEBLamiqS/+5F5nGjSYrn2cjjBCbfDlQMxUS0fSjACQm+Ri6r5Qzi+cYyYt9Zn/i/U6Aimj/9qyoDwTV3TTMm2tv7lVn7VLnQIDAQAB";
    public static final int GALLERY_REQ = 1;
    public static final int CAMERA_REQ = 2;
    public static final String ROW_ID = "news_id";
    public static final String TITLE = "title";
    public static final int STATUS_OK = 200;
    public static final String USER_ID = "user_id";
    public static final String STEP_1_SIGN_UP = "/api/partner/partner-signup";
    public static final String STEP_2_SIGN_UP = "/api/partner/partner-step2/";
    public static final String STEP_3_SIGN_UP = "/api/partner/email-verify/";
    public static final String RESEND_EMAIL = "api/partner/resend-mail/";
    public static final String CREATE_ACCOUNT = "/api/partner/complete-signup/";
    public static final String LOGIN = "/api/partner/login";
    public static final String LOGOUT = "/api/user/logout";
    public static final String USER_CHECK = "/api/user/check";
    public static final String TERMS_PAGE = "/api/partner/terms";
    public static final int TYPE_POLICY_CUSTOMER = 3;
    public static final int TYPE_TERMS_CUSTOMER = 2;
    public static final int TYPE_HELP_CUSTOMER = 6;
    public static final String INFO_UPDATE = "/api/partner/info-update/";
    public static final String UPDATE_PARTNER = "/api/partner/partner-update/";
    public static final String USER_PROFILE = "/api/partner/profile/";
    public static final String CHANGE_PASSWORD = "/api/user/change-password/";
    public static final String UPDATE_EMAIL = "/api/user/upadte-email/";
    public static final String FILTER_DATA = "api/package/filter/";
    public static final String GET_HISTORY = "api/package/index/";
    public static final String FORGOT_PASSWORD = "/api/user/forgot-password";
    public static final String SCANNER = "/api/package/scane/";
    public static final String PACKAGE_UPLOAD = "api/package/upload/";
    public static final String VERIFY_CODE = "api/package/verify-code/";
    public static final String HELP_PAGE = "/api/user/help-page";
    public static final String VERIFY_EMAIL = "/api/user/confirm-otp";
    public static final String CONFIRM_PACKAGE = "/api/package/confirm-package/";
    public static final String CONFIRM_PACKAGE_EMAIL = "/api/package/confirm-package-email";
    public static final String CONFIRM_PACKAGE_SEND_MESSAGE = "/api/package/send-message/";
}