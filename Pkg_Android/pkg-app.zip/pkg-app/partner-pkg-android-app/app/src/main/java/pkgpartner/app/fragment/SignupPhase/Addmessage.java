package pkgpartner.app.fragment.SignupPhase;


import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.StringDef;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.JsonArray;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * A simple {@link Fragment} subclass.
 */
public class Addmessage extends BaseFragment {

    private View view;
    private String user_id;
    EditText Enter_messageET;
    TextView Enter_messageTV;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_Id");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_addmessage, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        Enter_messageET = (EditText) view.findViewById(R.id.Enter_messageET);
        Enter_messageTV = (TextView) view.findViewById(R.id.Enter_messageTV);
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);
    }

    private void hitAddMessageApi(String user_id) {
        String text = Enter_messageET.getText().toString().trim();
        RequestParams params = new RequestParams();
        params.put("id", user_id);
        params.put("marketing_message", text);
        syncManager.sendToServer(Const.STEP_2_SIGN_UP + user_id, params, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                hitAddMessageApi(user_id);
                Bundle bundle = new Bundle();
                bundle.putString("user_id", user_id);
                Fragment fragment = new VerificationFragment();
                fragment.setArguments(bundle);
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .addToBackStack(null)
                        .commit();
                break;
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.STEP_2_SIGN_UP)) {
                if (jsonObject.getInt("status") == (Const.STATUS_OK)) {
                    JSONObject data = jsonObject.getJSONObject("data");
                    JSONArray accepted = data.getJSONArray("accepted");
                    String email = accepted.getString(0);
                    baseActivity.store.saveString("email", email);

                } else {
                    showToast("User Id Not found");
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
