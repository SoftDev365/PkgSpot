package pkgpartner.app.fragment.UserHome;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.ScannerListener;

/**
 * Created by TOXSL\parwinder.deep on 12/10/17.
 */

public class BarCodeScannerFragment extends BaseFragment {

    ScannerListener scannerListener;
    private View view;
    private SurfaceView scannerSV;
    private CameraSource cameraSource_BarCode;
    private File dir;
    private SparseArray<Barcode> barcodes;
    private ArrayList<String> scannedBarCodeImages = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
//        showToast("Please wait, code is being scanned.");
        view = inflater.inflate(R.layout.fragment_ocr_scanner, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
    }

    public void initUI() {
        scannerListener = ScannerListener.getInstance();
        scannerSV = (SurfaceView) view.findViewById(R.id.scannerSV);
        scanBarCode();
    }

    public void scanBarCode() {

        final BarcodeDetector barcodeDetector =
                new BarcodeDetector.Builder(getActivity())
                        .setBarcodeFormats(Barcode.ALL_FORMATS)
                        .build();

        cameraSource_BarCode = new CameraSource
                .Builder(getActivity(), barcodeDetector)
                .setRequestedPreviewSize(640, 480)
                .build();

        scannerSV.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {

                try {
                    if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    cameraSource_BarCode.start(scannerSV.getHolder());

                    cameraSource_BarCode.takePicture(null, new CameraSource.PictureCallback() {
                        private File imageFile;

                        @Override
                        public void onPictureTaken(byte[] bytes) {

                            try {
                                Bitmap loadedImage = null;
                                Bitmap rotatedBitmap = null;
                                loadedImage = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

                                Matrix rotateMatrix = new Matrix();
                                rotateMatrix.postRotate(0);
                                rotatedBitmap = Bitmap.createBitmap(loadedImage, 0, 0, loadedImage.getWidth(), loadedImage.getHeight(), rotateMatrix, false);

                                dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "PKG-Partner");

                                boolean success = true;
                                if (!dir.exists()) {
                                    success = dir.mkdirs();
                                }

                                if (success) {
                                    imageFile = new File(dir.getAbsolutePath() + File.separator + System.currentTimeMillis() + "Image.jpg");
                                    scannedBarCodeImages.add(imageFile.getAbsolutePath());
                                    imageFile.createNewFile();
                                } else {
                                    log("Image Not saved");
                                    return;
                                }

                                ByteArrayOutputStream ostream = new ByteArrayOutputStream();
                                rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, ostream);

                                FileOutputStream fout = new FileOutputStream(imageFile);
                                fout.write(ostream.toByteArray());
                                fout.close();

                                ContentValues values = new ContentValues();
                                values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
                                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                                values.put(MediaStore.MediaColumns.DATA, imageFile.getAbsolutePath());

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });


                } catch (IOException ie) {
                    ie.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource_BarCode.stop();
            }
        });


        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {

                barcodes = detections.getDetectedItems();

                if (barcodes.size() != 0) {
                    scannerSV.post(new Runnable() {
                        public void run() {
                            try {
                                scannerListener.sendImagesData("bar_code", barcodes.valueAt(0).displayValue, scannedBarCodeImages);
                                if (isAdded()) {
                                    ImagePackageFragment ocrScannerFragment = new ImagePackageFragment();
                                    baseActivity.getSupportFragmentManager().beginTransaction()
                                            .replace(R.id.container, ocrScannerFragment)
                                            .addToBackStack(null)
                                            .commit();
//                                    baseActivity.getSupportFragmentManager().popBackStack();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
    }
}
