package pkgpartner.app.data;

import java.io.File;

/**
 * Created by TOXSL\visha.sehgal on 28/7/17.
 */

public class DataToSend {
    public String customer_id;   //package_id
    public File image;

}
