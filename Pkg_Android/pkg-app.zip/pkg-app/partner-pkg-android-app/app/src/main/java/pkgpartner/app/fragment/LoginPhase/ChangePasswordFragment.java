package pkgpartner.app.fragment.LoginPhase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\parwinder.deep on 18/10/17.
 */

public class ChangePasswordFragment extends BaseFragment {
    private View view;
    private EditText passwordET, confET;
    private Button doneBT;
    private String user_id;
    private Integer frame_id;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("userId")) {
            user_id = bundle.getString("userId");
        } else {
            user_id = baseActivity.prefStore.getString(Const.USER_ID);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_change_password, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();

        Bundle bundle = getArguments();
        if (bundle.containsKey("frame_id")) {
            frame_id = bundle.getInt("frame_id");
        }
    }

    private void initUI() {
        passwordET = (EditText) view.findViewById(R.id.passwordET);
        confET = (EditText) view.findViewById(R.id.confET);

        doneBT = (Button) view.findViewById(R.id.doneBT);

        doneBT.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.doneBT:
                if (isValidate()) {
                    hitChangePwdApi();
                }
                break;
        }
    }

    private void hitChangePwdApi() {
        if (user_id != null) {
            RequestParams params = new RequestParams();
            params.put("id", user_id);
            params.put("password", confET.getText().toString().trim());
            syncManager.sendToServer(Const.CHANGE_PASSWORD, params, this);
        } else {
            showToast("User id not available");
        }
    }

    private boolean isValidate() {
        if (passwordET.getText().toString().isEmpty()) {
            showToast("Please enter new password");
            return false;
        } else if (passwordET.getText().toString().length() < 6) {
            showToast("Please enter minimum 6 characters");
            return false;
        } else if (!isValidPassword(passwordET.getText().toString())) {
            showToast("Please enter valid password");
            return false;
        } else if (confET.getText().toString().isEmpty()) {
            showToast("Please enter confirm password");
            return false;
        } else if (!confET.getText().toString().equals(passwordET.getText().toString())) {
            showToast("Password and confirm password does not match");
            return false;
        } else {
            return true;
        }

    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.get("url").equals(Const.CHANGE_PASSWORD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Your password has been changed successfully");
                    baseActivity.gotoLoginScreen();
                } else {
                    showToast(jsonObject.optString("error"));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
