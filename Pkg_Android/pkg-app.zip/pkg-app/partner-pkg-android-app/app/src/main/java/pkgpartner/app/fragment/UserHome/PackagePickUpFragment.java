package pkgpartner.app.fragment.UserHome;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.ScannerListener;

/**
 * A simple {@link Fragment} subclass.
 */
public class PackagePickUpFragment extends BaseFragment implements View.OnClickListener, ScannerListener.MyScannerListener {

    private static boolean first = true;
    private ImageView starIV;
    private String name, noOfPackages, address, zipcode, city, country, pkgSpotId;
    private ScannerListener scannerListener;
    private Button verify_Customer_NameBT, scanQR_TV, nextBT;
    private EditText enter_qrET;
    private TextView name_TV, address_TV, city_TV, country_TV, zipcode_TV, noOfPacakges_TV, pkgspot_TV, okTV, error1TV;
    private View view;
    private String qr_data, exists;
    private LinearLayout errorLL, qr_dataLL;
    private int count = 1;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        baseActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (view == null) {
            view = inflater.inflate(R.layout.fragment_package_pick_up_finish, container, false);
            initUI();
        }
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void initUI() {

        scannerListener = ScannerListener.getInstance();
        scannerListener.setDataListener(this);

        starIV = (ImageView) view.findViewById(R.id.starIV);
        error1TV = (TextView) view.findViewById(R.id.error1TV);
        scanQR_TV = (Button) view.findViewById(R.id.scanQR_TV);
        okTV = (TextView) view.findViewById(R.id.okTV);
        verify_Customer_NameBT = (Button) view.findViewById(R.id.verify_Customer_NameBT);
        nextBT = (Button) view.findViewById(R.id.nextBT);
        enter_qrET = (EditText) view.findViewById(R.id.enter_qrET);
        address_TV = (TextView) view.findViewById(R.id.address_TV);
        city_TV = (TextView) view.findViewById(R.id.city_TV);
        country_TV = (TextView) view.findViewById(R.id.country_TV);
        zipcode_TV = (TextView) view.findViewById(R.id.zipcode_TV);
        name_TV = (TextView) view.findViewById(R.id.name_TV);
        noOfPacakges_TV = (TextView) view.findViewById(R.id.noOfPacakges_TV);
        pkgspot_TV = (TextView) view.findViewById(R.id.pkgspot_TV);
        qr_dataLL = (LinearLayout) view.findViewById(R.id.qr_dataLL);
        errorLL = (LinearLayout) view.findViewById(R.id.errorLL);

        nextBT.setOnClickListener(this);
        scanQR_TV.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);

        switch (v.getId()) {
            case R.id.scanQR_TV:
                QrCodeScannerFragment qrCodeScannerFragment = new QrCodeScannerFragment();
                baseActivity.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, qrCodeScannerFragment)
                        .addToBackStack(null)
                        .commit();
                break;

            case R.id.nextBT:
                qr_data = enter_qrET.getText().toString().trim();
                if (qr_data.equalsIgnoreCase("")) {
                    showToast("Please enter QR Code to proceed.");
                } else {
                    qr_data = enter_qrET.getText().toString().trim();
                    hitVerifyCodeApi();
                }
                break;
        }
    }

    private void hitVerifyCodeApi() {
        RequestParams requestParams = new RequestParams();
        requestParams.put("qr_code", qr_data);
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.VERIFY_CODE + user_id, requestParams, PackagePickUpFragment.this);
        first = false;
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.VERIFY_CODE)) {

                if (jsonObject.getInt("status") == Const.STATUS_OK) {

                    qr_dataLL.setVisibility(View.VISIBLE);
                    starIV.setVisibility(View.VISIBLE);
                    verify_Customer_NameBT.setVisibility(View.GONE);
                    okTV.setVisibility(View.VISIBLE);
                    error1TV.setVisibility(View.GONE);
                    errorLL.setVisibility(View.GONE);
                    nextBT.setVisibility(View.GONE);

                    JSONArray array = jsonObject.getJSONArray("data");
                    JSONObject object = array.getJSONObject(0);
                    name = object.getString("name");
                    address = object.getString("address");
                    zipcode = object.getString("zipcode");
                    city = object.getString("city");
                    country = object.getString("country");
                    noOfPackages = object.getString("package_count");
                    pkgSpotId = object.getString("cuid");

                    if (name != null) {
                        name_TV.setText(name);
                    } else {
                        name_TV.setVisibility(View.GONE);
                    }

                    if (noOfPackages != null) {
                        noOfPacakges_TV.setText("Number of packages to Pick Up: " + noOfPackages);
                    } else {
                        noOfPacakges_TV.setVisibility(View.GONE);
                    }

                    if (pkgSpotId != null) {
                        pkgspot_TV.setText("PkgSpot: " + pkgSpotId);
                    } else {
                        pkgspot_TV.setVisibility(View.GONE);
                    }

                    if (address != null) {
                        address_TV.setText(address);
                    } else {
                        address_TV.setVisibility(View.GONE);
                    }

                    if (zipcode != null) {
                        zipcode_TV.setText(zipcode);
                    } else {
                        zipcode_TV.setVisibility(View.GONE);
                    }

                    if (city != null) {
                        city_TV.setText(city);
                    } else {
                        city_TV.setVisibility(View.GONE);
                    }

                    if (country.contains("null")) {
                        country_TV.setVisibility(View.GONE);
                    } else {
                        country_TV.setText(country);
                    }
                } else {
                    exists = jsonObject.getString("exists");
                    errorLL.setVisibility(View.VISIBLE);
                    if (exists.equalsIgnoreCase("1")) {
                        error1TV.setText("Package(s) have already been picked up.  Please verify number is correct.");
                    } else {
                        if (count == 1) {
                            error1TV.setText("Please verify number and try again");
                            count++;
                        } else {
                            error1TV.setText("Please contact customer service");
                        }
                    }
                    qr_dataLL.setVisibility(View.GONE);
                    okTV.setVisibility(View.GONE);
                    noOfPacakges_TV.setVisibility(View.GONE);
                    starIV.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onImageScanned(String param, String imageData, ArrayList<String> imageList) {
        if (first) {
            if (param.equals("qr_code")) {
                first = false;
                qr_data = imageData;
                hitVerifyCodeApi();
            }
        }
    }
}
