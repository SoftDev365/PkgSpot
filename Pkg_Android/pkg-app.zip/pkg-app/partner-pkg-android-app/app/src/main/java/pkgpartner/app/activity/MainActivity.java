package pkgpartner.app.activity;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import pkgpartner.app.R;
import pkgpartner.app.adapter.DrawerAdapter;
import pkgpartner.app.data.DrawerData;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.fragment.UserHome.AdditionalPackagesFragment;
import pkgpartner.app.fragment.UserHome.EditDaysFragment;
import pkgpartner.app.fragment.UserHome.EditMarketingFragment;
import pkgpartner.app.fragment.UserHome.EditpartnerInfoFragment;
import pkgpartner.app.fragment.UserHome.HelpFragment;
import pkgpartner.app.fragment.UserHome.HistoryFragment;
import pkgpartner.app.fragment.UserHome.ImagePackageFragment;
import pkgpartner.app.fragment.UserHome.PackagePickUpFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.ImageUtils;
import pkgpartner.app.utils.PrefStore;

/**
 * Created by neeraj.narwal on 5/7/16.
 */
public class MainActivity extends BaseActivity implements BaseActivity.PermCallback, ImageUtils.ImageSelectCallback {
    private DrawerLayout drawer;
    private TextView nameTV, streetTV;
    private ExpandableListView drawerLV;
    private ActionBarDrawerToggle toggle;
    private ArrayList<DrawerData> drawerItems = new ArrayList<>();
    private ArrayList<DrawerData> childDrawerItems = new ArrayList<>();
    private List<DrawerData> listDataHeader;
    private HashMap<DrawerData, List<DrawerData>> listDataChild;
    private ArrayList<DrawerData> drawerDatas = new ArrayList<>();
    private PrefStore prefStore;
    private String userID, address, business_name, city, state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        prefStore = new PrefStore(getApplication());
        init();
        initDrawer();
        savearraylist();

        if (prefStore.containValue(Const.USER_ID)) {
            userID = prefStore.getString(Const.USER_ID);
        }

        gotoHomeFragment();
    }

    private void gotoHomeFragment() {
        Bundle bundle = new Bundle();
        bundle.putString("call", "sec");
        Fragment fragment = new HomeFragment();
        fragment.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void savearraylist() {
        prefStore = new PrefStore(this);
        for (int i = 0; i < 10; i++) {
            DrawerData drawerData = new DrawerData();
            drawerData.name = "name" + i;
            drawerDatas.add(drawerData);
        }

        prefStore.setData("key", drawerDatas);
        drawerDatas.clear();
        drawerDatas = prefStore.getData("key");
    }

    private void init() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawer = (DrawerLayout) findViewById(R.id.drawer);
        LinearLayout headLL = (LinearLayout) findViewById(R.id.headLL);
        nameTV = (TextView) findViewById(R.id.nameTV);
        streetTV = (TextView) findViewById(R.id.streetTV);

        headLL.requestLayout();
        headLL.setOnClickListener(this);
        drawerLV = (ExpandableListView) findViewById(R.id.drawerLV);
        toggle = new ActionBarDrawerToggle(this, drawer, null,
                R.string.app_name, R.string.app_name) {

            @Override
            public void onDrawerOpened(View drawerView) {
                toggle.setHomeAsUpIndicator(R.mipmap.ic_more);
                invalidateOptionsMenu();
                hitProfileApi();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                toggle.setHomeAsUpIndicator(R.mipmap.ic_menu);
                invalidateOptionsMenu();
            }
        };
        toggle.setDrawerIndicatorEnabled(false);
        toggle.setHomeAsUpIndicator(R.mipmap.ic_menu);

        drawer.addDrawerListener(toggle);
        updateDrawer();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        toggle.syncState();
    }

    private void hitProfileApi() {
        syncManager.sendToServer(Const.USER_PROFILE + userID, null, this);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (drawer.isDrawerOpen(GravityCompat.START)) {
                    drawer.closeDrawer(GravityCompat.START);
                } else {
                    drawer.openDrawer(GravityCompat.START);
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateDrawer() {
        nameTV.setText(business_name);
        log("address ---------- " + address);
        log("city ---------- " + city);
        log("state ---------- " + state);
        streetTV.setText(address + " " + city + " " + state);
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        if (fragment instanceof HomeFragment) {
            back();
        } else if (fragment instanceof ImagePackageFragment) {
            gotoHomeFragment();
        } else if (fragment instanceof PackagePickUpFragment) {
            gotoHomeFragment();
        } else if (fragment instanceof AdditionalPackagesFragment) {
            gotoHomeFragment();
        } else {
            hideSoftKeyboard();
            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else {
                gotoHomeFragment();
            }
        }
    }

    public void initDrawer() {
        Integer icons[] =
                {R.mipmap.ic_van0
                        , R.mipmap.ic_packg
                        , R.mipmap.ic_list
                        , R.mipmap.ic_user
                        , R.mipmap.ic_help
                        , R.mipmap.ic_logout
                };
        String[] names = this.getResources().getStringArray(R.array.drawer_items);
        for (int i = 0; i < icons.length; i++) {
            DrawerData drawerData = new DrawerData();
            drawerData.icon = icons[i];
            drawerData.name = names[i];
            drawerItems.add(drawerData);
        }
        prepareListData(drawerItems);
        DrawerAdapter drawerAdapter = new DrawerAdapter(this, listDataHeader, listDataChild);
        drawerLV.setAdapter(drawerAdapter);
        drawerLV.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                int count = parent.getExpandableListAdapter().getChildrenCount(groupPosition);
                if (count == 0) {
                    Fragment frag = null;
                    switch (groupPosition) {
                        case 0:
                            frag = new ImagePackageFragment();
                            break;
                        case 1:
                            frag = new PackagePickUpFragment();
                            break;
                        case 2:
                            frag = new HistoryFragment();
                            break;
                        case 4:
                            frag = new HelpFragment();
                            break;
                        case 5:
                            hitLogout();
                            break;

                        default:
                            frag = new HelpFragment();
                            break;
                    }
                    if (frag != null) {
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.container, frag)
                                .addToBackStack(null)
                                .commit();
                    }
                    drawer.closeDrawers();
                }

                return false;
            }
        });

        drawerLV.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Fragment frag = null;
                if (groupPosition == 3)
                    switch (childPosition) {
                        case 0:
                            frag = new EditpartnerInfoFragment();
                            break;
                        case 1:
                            frag = new EditDaysFragment();
                            break;
                        case 2:
                            frag = new EditMarketingFragment();
                            break;
                    }
                if (frag != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, frag)
                            .addToBackStack(null)
                            .commit();
                }
                drawer.closeDrawers();
                return false;
            }
        });

        drawerLV.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {

            }
        });

        // Listview Group collasped listener
        drawerLV.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {

            }
        });
    }

    @Override
    public void permGranted(int resultCode) {
        showToast("after permission");
    }

    @Override
    public void permDenied(int resultCode) {

    }

    private void prepareListData(ArrayList<DrawerData> drawerData) {

        listDataHeader = new ArrayList<DrawerData>();
        listDataChild = new HashMap<DrawerData, List<DrawerData>>();

        for (int i = 0; i < drawerData.size(); i++) {
            listDataHeader.add(drawerData.get(i));
        }

        List<DrawerData> heading = new ArrayList<>();
        Integer icons[] = {R.mipmap.ic_map_location
                , R.mipmap.ic_add, R.mipmap.ic_add};
        String[] names = getResources().getStringArray(R.array.profile_item);
        for (int i = 0; i < icons.length; i++) {
            DrawerData drawerData1 = new DrawerData();
            drawerData1.icon = icons[i];
            drawerData1.name = names[i];
            childDrawerItems.add(drawerData1);
        }
        for (int i = 0; i < childDrawerItems.size(); i++) {
            heading.add(childDrawerItems.get(i));
        }

        listDataChild.put(listDataHeader.get(3), heading);
    }

    private void hitLogout() {
        RequestParams params = new RequestParams();
        params.put("device_token", "device_token");
        syncManager.sendToServer(Const.LOGOUT, params, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.LOGOUT)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    syncManager.setLoginStatus(null);
                    store.cleanPref();
                    NotificationManager nMgr = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                    nMgr.cancelAll();
                    gotoLoginScreen();
                } else {
                    String error = "Something Went Wrong";
                    if (jsonObject.has("error")) {
                        error = jsonObject.getString("error");
                    }
                    showToast(error);
                }
            } else if (jsonObject.getString("url").contains(Const.USER_PROFILE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        address = object.getString("address");
                        business_name = object.getString("business_name");
                        city = object.getString("city");
                        state = object.getString("state");
                        updateDrawer();
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onImageSelected(String imagePath, int resultCode) {

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        fragment.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IntentIntegrator.REQUEST_CODE) {
            if (resultCode == 0) {
                if (data != null) {

                    Bundle bundle = data.getExtras();
                    if (bundle != null) {
                        Set<String> keys = bundle.keySet();
                        for (String key : keys) {
                            Log.e("data >>", "[" + key + "=" + bundle.get(key) + "]");
                        }
                    }

                }
            } else {
                Toast.makeText(MainActivity.this, "Scan Failed", Toast.LENGTH_LONG).show();
            }
        } else {
            fragment = getSupportFragmentManager().findFragmentById(R.id.container);
            if (fragment instanceof EditpartnerInfoFragment) {
                ((EditpartnerInfoFragment) fragment).onActivityResult(data, requestCode);
            }
        }
    }
}
