package pkgpartner.app.fragment.UserHome;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * A simple {@link Fragment} subclass.
 */

public class HelpFragment extends BaseFragment {
    private View view;
    private TextView titleTV, descTV;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_help, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {

        titleTV = (TextView) view.findViewById(R.id.titleTV);
        descTV = (TextView) view.findViewById(R.id.descTV);

        Button contactBT = (Button) view.findViewById(R.id.contactBT);

        contactBT.setOnClickListener(this);
        hitGetHelpApi();

    }

    private void hitGetHelpApi() {
        syncManager.sendToServer(Const.TERMS_PAGE + "/" + Const.TYPE_HELP_CUSTOMER, null, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.contactBT:
                try {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/html");
                    intent.putExtra(Intent.EXTRA_EMAIL, "info@pkgspot.com");
                    intent.putExtra(Intent.EXTRA_SUBJECT, "");
                    intent.putExtra(Intent.EXTRA_TEXT, "");
                    startActivity(Intent.createChooser(intent, "Send Email"));
                } catch (Exception e) {
                    e.printStackTrace();
                    baseActivity.showToastOne("Exception:" + e);
                }
                break;
        }
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.TERMS_PAGE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);
                        String title = object.getString("title");
                        String description = object.getString("description");
                        titleTV.setText(title);
                        Spanned sp = Html.fromHtml(description.replace("&lt;", "<").replace("&gt;", ">"));
                        descTV.setText(sp);
                    }
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}

