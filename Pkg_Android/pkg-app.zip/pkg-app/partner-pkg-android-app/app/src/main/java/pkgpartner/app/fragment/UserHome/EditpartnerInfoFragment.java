package pkgpartner.app.fragment.UserHome;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.toxsl.volley.toolbox.RequestParams;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.ForgotPasswordFragment;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 11/9/17.
 */

public class EditpartnerInfoFragment extends BaseFragment implements View.OnClickListener {

    ArrayAdapter<String> adapter;
    String[] operating_as_DD = {"Individual/Sole proprietor or single-member LLC", "C Corporation", "S Corporation", "Partnership", "Limited Liability Company", "Other"};
    private View rootview;
    private Spinner operating_as_S;
    private String streetAddress_S = null, route_S = null, state_S = null, city_S = null, country_S = null, zip_S = null;
    private EditText Legal_Business_NameET, streetaddressET, CityET, StateET, zipET, nameET, positionET, websiteET, email_addressET, phone_numberET, passwordET;
    private String email, contact_no, address, latitude, longitude, city, state, country, operating_as, zipcode, business_name, position, marketing_message, website, full_name;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (rootview != null) {
            return rootview;
        } else {
            return inflater.inflate(R.layout.fg_editpartnerinfo, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.rootview = view;
        initUI(view);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setRetainInstance(true);
        super.onCreate(savedInstanceState);
    }

    private void initUI(View view) {

        nameET = (EditText) view.findViewById(R.id.nameET);
        email_addressET = (EditText) view.findViewById(R.id.email_addressET);
        zipET = (EditText) view.findViewById(R.id.zipET);
        operating_as_S = (Spinner) view.findViewById(R.id.operating_as_S);
        CityET = (EditText) view.findViewById(R.id.CityET);
        StateET = (EditText) view.findViewById(R.id.StateET);
        phone_numberET = (EditText) view.findViewById(R.id.phone_numberET);
        streetaddressET = (EditText) view.findViewById(R.id.streetaddressET);
        Legal_Business_NameET = (EditText) view.findViewById(R.id.Legal_Business_NameET);
        positionET = (EditText) view.findViewById(R.id.positionET);
        websiteET = (EditText) view.findViewById(R.id.websiteET);
        Button doneBTN = (Button) view.findViewById(R.id.doneBTN);
        passwordET = (EditText) view.findViewById(R.id.passwordET);
        ImageView emailEDIT = (ImageView) view.findViewById(R.id.edit_emailBTN);

        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, operating_as_DD);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operating_as_S.setAdapter(adapter);
        operating_as_S.setOnItemSelectedListener(this);

        nameET.setOnClickListener(this);
        email_addressET.setOnClickListener(this);
        zipET.setOnClickListener(this);
        CityET.setOnClickListener(this);
        StateET.setOnClickListener(this);
        phone_numberET.setOnClickListener(this);
        streetaddressET.setOnClickListener(this);
        Legal_Business_NameET.setOnClickListener(this);
        positionET.setOnClickListener(this);
        websiteET.setOnClickListener(this);
        passwordET.setOnClickListener(this);
        doneBTN.setOnClickListener(this);
        emailEDIT.setOnClickListener(this);

        hitGetProfileApi();

    }

    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 1:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 2:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 3:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 4:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 5:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 6:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
        }
    }

    private void hitGetProfileApi() {
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.USER_PROFILE + user_id, null, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.doneBTN:
                if (isValidate())
                    hitProfileUpdateApi();
                break;

            case R.id.nameET:
                nameET.setEnabled(true);
                break;

            case R.id.zipET:
                zipET.setEnabled(true);
                break;

            case R.id.CityET:
                CityET.setEnabled(true);
                break;

            case R.id.StateET:
                StateET.setEnabled(true);
                break;

            case R.id.phone_numberET:
                phone_numberET.setEnabled(true);
                break;

            case R.id.Legal_Business_NameET:
                Legal_Business_NameET.setEnabled(true);
                break;

            case R.id.positionET:
                positionET.setEnabled(true);
                break;

            case R.id.websiteET:
                websiteET.setEnabled(true);
                break;

            case R.id.edit_emailBTN:
                if (!email_addressET.getText().toString().isEmpty()) {
                    if (baseActivity.isValidMail(email_addressET.getText().toString())) {
                        hitEmailChangeApi();
                    }
                }
                break;

            case R.id.passwordET:
                Bundle bundle = new Bundle();
                bundle.putInt("frame_id", R.id.container);
                Fragment fragment = new ForgotPasswordFragment();
                fragment.setArguments(bundle);
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, fragment)
                        .addToBackStack(null)
                        .commit();

                break;

            case R.id.streetaddressET:
                streetaddressET.setEnabled(true);
                getAutoLocation();
                break;
        }

    }

    private void hitEmailChangeApi() {
        String user_id = baseActivity.store.getString("user_id");
        RequestParams params = new RequestParams();
        params.put("email", email_addressET.getText().toString());
        syncManager.sendToServer(Const.UPDATE_EMAIL + user_id, params, this);
    }

    private boolean isValidate() {
        if (nameET.getText().toString().isEmpty()) {
            showToast("Please enter Name");
            return false;
        } else if (zipET.getText().toString().isEmpty()) {
            showToast("Please enter Zip Code");
            return false;
        } else if (operating_as.equalsIgnoreCase("")) {
            showToast("Please enter Operating As");
            return false;
        } else if (Legal_Business_NameET.getText().toString().isEmpty()) {
            showToast("Please enter Business Name");
            return false;
        } else if (streetaddressET.getText().toString().isEmpty()) {
            showToast("Please enter Street");
            return false;
        } else if (CityET.getText().toString().isEmpty()) {
            showToast("Please enter City");
            return false;
        } else if (positionET.getText().toString().isEmpty()) {
            showToast("Please enter Position");
            return false;
        } else if (phone_numberET.getText().toString().isEmpty()) {
            showToast("Please enter Phone Number");
            return false;
        } else {
            return true;
        }
    }

    private void hitProfileUpdateApi() {

        RequestParams params = new RequestParams();
        params.put("full_name", nameET.getText().toString().trim());
        params.put("zipcode", zipET.getText().toString().trim());
        params.put("operating_as", operating_as);
        params.put("city", CityET.getText().toString().trim());
        params.put("state", StateET.getText().toString().trim());
        params.put("contact_no", phone_numberET.getText().toString().trim());
        Log.e("", "hitProfileUpdateApi: " + streetaddressET.getText());
        params.put("address", streetaddressET.getText().toString());
        params.put("business_name", Legal_Business_NameET.getText().toString().trim());
        params.put("position", positionET.getText().toString().trim());
        params.put("website", websiteET.getText().toString().trim());
        params.put("latitude", latitude);
        params.put("longitude", longitude);
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.UPDATE_PARTNER + user_id, params, this);

    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.USER_PROFILE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        full_name = object.getString("full_name");
                        email = object.getString("email");
                        contact_no = object.getString("contact_no");
                        address = object.getString("address");
                        latitude = object.getString("latitude");
                        longitude = object.getString("longitude");
                        operating_as = object.getString("operating_as");
                        city = object.getString("city");
                        state = object.getString("state");
                        country = object.getString("country");
                        zipcode = object.getString("zipcode");
                        business_name = object.getString("business_name");
                        operating_as = object.getString("operating_as");
                        position = object.getString("position");
                        marketing_message = object.getString("marketing_message");
                        website = object.getString("website");
                        setData();
                    }
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.UPDATE_EMAIL)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Email Updated");
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.CHANGE_PASSWORD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Password Changed");
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.UPDATE_PARTNER)) {
                showToast("Profile Updated");
                HomeFragment barCodeScannerFragment = new HomeFragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, barCodeScannerFragment)
                        .addToBackStack(null)
                        .commit();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void setData() {
        Legal_Business_NameET.setText(business_name);
        streetaddressET.setText(address);
        CityET.setText(city);
        StateET.setText(state);
        zipET.setText(zipcode);
        nameET.setText(full_name);
        positionET.setText(position);
        websiteET.setText(website);
        email_addressET.setText(email);
        phone_numberET.setText(contact_no);

        if (!operating_as.isEmpty()) {
            int spinnerPosition = adapter.getPosition(operating_as);
            operating_as_S.setSelection(spinnerPosition);
        }
    }

    private void getAutoLocation() {
        Intent intent = null;
        try {
            intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(baseActivity);
            getActivity().startActivityForResult(intent, 111);
        } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(Intent data, int requestCode) {
        if (requestCode == 111) {
            if (data != null) {
                Place place = PlaceAutocomplete.getPlace(baseActivity, data);
                if (place == null) {


                } else {
                    String s = place.getLatLng().toString();
                    s = s.substring(s.indexOf("(") + 1);
                    s = s.substring(0, s.indexOf(")"));
                    String str = s;
                    latitude = str.substring(0, str.indexOf(","));
                    longitude = str.substring(str.indexOf(",") + 1, str.length());

                    getLocationInfo(place.getAddress().toString());
                }
            }
        }
    }

    public JSONObject getLocationInfo(String address) {
        String mAddress = address.replace(" ", "%20");
        HttpGet httpGet = new HttpGet("https://maps.googleapis.com/maps/api/geocode/json?address=" + mAddress + "&sensor=true&key=AIzaSyCzc-H6fTsX68hKZwoJwlXAHSjcMU-QIQQ");
        HttpClient client = new DefaultHttpClient();
        HttpResponse response;
        StringBuilder stringBuilder = new StringBuilder();

        try {
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            InputStream stream = entity.getContent();
            int b;
            while ((b = stream.read()) != -1) {
                stringBuilder.append((char) b);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(stringBuilder.toString());
            String text = stringBuilder.toString();
            text = text.replaceAll("\n", "");
            log("response -------------- " + text);
            JSONObject jsonObject1 = new JSONObject(text);
            JSONArray results = jsonObject1.getJSONArray("results");
            log("1111111");
            JSONObject jsonObject2 = results.getJSONObject(0);
            JSONArray address_components = jsonObject2.getJSONArray("address_components");
            log("2222222");
            for (int i = 0; i < address_components.length(); i++) {
                JSONObject object = address_components.optJSONObject(i);

                log("333333");

                JSONArray types = object.getJSONArray("types");
                String types_S = types.get(0).toString();

                if (types_S.equals("street_number")) {
                    streetAddress_S = object.getString("long_name");
                    log("street " + streetAddress_S);
                }

                if (types_S.equals("route")) {
                    route_S = object.getString("long_name");
                    log("route " + route_S);
                }

                if (types_S.equals("locality")) {
                    city_S = object.getString("long_name");
                    log("city " + city_S);
                }

                if (types_S.equals("administrative_area_level_1")) {
                    state_S = object.getString("long_name");
                    log("state " + state_S);
                }

                if (types_S.equals("country")) {
                    country_S = object.getString("short_name");
                    log("country " + country_S);
                }

                if (types_S.equals("postal_code")) {
                    zip_S = object.getString("long_name");
                    log("zip " + zip_S);
                }
            }

            if (city_S != null) {
                CityET.setText(city_S);
            } else {
                CityET.setText("");
            }

            if (route_S == null) {
                streetaddressET.setText(streetAddress_S);
            } else if (streetAddress_S == null) {
                streetaddressET.setText(route_S);
            } else {
                if (route_S.equals("") && streetAddress_S.equals("")) {
                    streetaddressET.setText("");
                } else {
                    streetaddressET.setText(streetAddress_S + " " + route_S);
                }
            }

            if (state_S == null) {
                StateET.setText(country_S);
            } else if (country_S == null) {
                StateET.setText(state_S);
            } else {
                if (state_S.equals("") && country_S.equals("")) {
                    StateET.setText("");
                } else {
                    StateET.setText(state_S + " " + country_S);
                }
            }

            if (zip_S != null) {
                zipET.setText(zip_S);
            } else {
                zipET.setText("");
            }

            zip_S = "";
            state_S = "";
            country_S = "";
            city_S = "";
            route_S = "";
            streetAddress_S = "";

        } catch (JSONException e) {
            showToast("Network Problem!");
            e.printStackTrace();
        }

        return jsonObject;
    }
}