package pkgpartner.app.fragment.UserHome;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.ArrayRes;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 11/9/17.
 */

public class EditMarketingFragment extends BaseFragment {
    private View view;
    private EditText update_marketing_msgET;
    private Button saveBTN;
    private String marketing_message;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_marketing_message, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {

        hitGetProfileApi();

        update_marketing_msgET = (EditText) view.findViewById(R.id.update_marketing_msgET);
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(update_marketing_msgET.getWindowToken(), 0);


        saveBTN = (Button) view.findViewById(R.id.saveBTN);
        saveBTN.setOnClickListener(this);
    }

    private void hitGetProfileApi() {
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.USER_PROFILE + user_id, null, this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.saveBTN:
                hitInfoUpdateApi();
                break;
        }
    }

    private void hitInfoUpdateApi() {
        String user_id = baseActivity.store.getString("user_id");
        RequestParams requestParams = new RequestParams();
        requestParams.put("marketing_message", update_marketing_msgET.getText().toString().trim());
        syncManager.sendToServer(Const.INFO_UPDATE + user_id, requestParams, this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.USER_PROFILE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray array = jsonObject.getJSONArray("data");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        marketing_message = object.getString("marketing_message");
                        setData();
                    }
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.INFO_UPDATE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Information updated");
                    HomeFragment barCodeScannerFragment = new HomeFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, barCodeScannerFragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setData() {
        update_marketing_msgET.setText(marketing_message);
    }

}
