package pkgpartner.app.fragment.LoginPhase;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\parwinder.deep on 18/10/17.
 */

public class OtpFragment extends BaseFragment {
    private View view;
    private TextView resendTV, phoneTV;
    private EditText codeET;
    private String email;
    private Integer frame_id;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        Bundle bundle = getArguments();
        if (bundle != null) {
            email = bundle.getString("email");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_verification, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();

        Bundle bundle = getArguments();
        if (bundle.containsKey("frame_id")) {
            frame_id = bundle.getInt("frame_id");
        }
    }

    private void initUI() {
        codeET = (EditText) view.findViewById(R.id.codeET);
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(codeET.getWindowToken(), 0);
        resendTV = (TextView) view.findViewById(R.id.resendTV);
        phoneTV = (TextView) view.findViewById(R.id.phoneTV);
        phoneTV.setText(email);

        codeET.setInputType(InputType.TYPE_CLASS_TEXT);
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);
        resendTV.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                if (codeET.getText().toString().isEmpty()) {
                    baseActivity.showToastOne("Please enter code");
                } else {
                    hitVerifyApi();
                }
                break;

            case R.id.resendTV:
                if (email != null && !email.isEmpty()) {
                    RequestParams params = new RequestParams();
                    params.put("email", email);
                    syncManager.sendToServer(Const.FORGOT_PASSWORD, params, this);
                } else {
                    baseActivity.showToastOne("No email available");
                }

                break;
        }
    }

    private void hitVerifyApi() {
        RequestParams params = new RequestParams();
        params.put("email", email);
        params.put("otp", codeET.getText().toString().trim());
        syncManager.sendToServer(Const.VERIFY_EMAIL, params, this);
    }


    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.VERIFY_EMAIL)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("OTP verified successfully");
                    gotoChangePasswordFragment(jsonObject.optString("userId"), frame_id);

                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").equals(Const.FORGOT_PASSWORD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    baseActivity.showToastOne("OTP sent successfully");
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void gotoChangePasswordFragment(String userId, Integer frame_id) {
        Fragment fragment = new ChangePasswordFragment();
        Bundle bundle = new Bundle();
        bundle.putString("userId", userId);
        fragment.setArguments(bundle);
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(frame_id, fragment)
                .addToBackStack(null)
                .commit();
    }
}
