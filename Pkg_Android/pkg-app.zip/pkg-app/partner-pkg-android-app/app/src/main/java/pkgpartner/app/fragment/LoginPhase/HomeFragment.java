package pkgpartner.app.fragment.LoginPhase;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import pkgpartner.app.R;
import pkgpartner.app.activity.MainActivity;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.UserHome.ImagePackageFragment;
import pkgpartner.app.fragment.UserHome.PackagePickUpFragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends BaseFragment {


    MainActivity mainActivity;
    private View view;
    private String call;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        baseActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        return inflater.inflate(R.layout.fg_home, container, false);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        baseActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mainActivity = new MainActivity();

        this.view = view;
        initUI();
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            call = bundle.getString("call");
        }
    }

    private void initUI() {

        Button ReceivePackageBT = (Button) view.findViewById(R.id.ReceivePackageBT);
        Button PackagePickUpBT = (Button) view.findViewById(R.id.PackagePickUpBT);
        ReceivePackageBT.setOnClickListener(this);
        PackagePickUpBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.ReceivePackageBT:
                Fragment fragment = new ImagePackageFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, fragment)
                        .addToBackStack(null)
                        .commit();
                break;

            case R.id.PackagePickUpBT:
                fragment = new PackagePickUpFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, fragment)
                        .addToBackStack(null)
                        .commit();
                break;
        }
    }


}
