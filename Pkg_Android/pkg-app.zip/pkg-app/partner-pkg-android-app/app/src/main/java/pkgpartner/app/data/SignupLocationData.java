package pkgpartner.app.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by TOXSL\parwinder.deep on 29/11/17.
 */

public class SignupLocationData {

    @SerializedName("results")
    @Expose
    public Result results;
    @SerializedName("status")
    @Expose
    public String status;


    public class AddressComponent {

        @SerializedName("long_name")
        @Expose
        public String longName;
        @SerializedName("short_name")
        @Expose
        public String shortName;
        @SerializedName("types")
        @Expose
        public List<String> types = null;

    }

    public class Geometry {

        @SerializedName("location")
        @Expose
        public Location location;
        @SerializedName("location_type")
        @Expose
        public String locationType;
        @SerializedName("viewport")
        @Expose
        public Viewport viewport;

    }

    public class Location {

        @SerializedName("lat")
        @Expose
        public Double lat;
        @SerializedName("lng")
        @Expose
        public Double lng;

    }

    public class Northeast {

        @SerializedName("lat")
        @Expose
        public Double lat;
        @SerializedName("lng")
        @Expose
        public Double lng;

    }

    public class Result {

        @SerializedName("address_components")
        @Expose
        public AddressComponent addressComponents = null;
        @SerializedName("formatted_address")
        @Expose
        public String formattedAddress;
        @SerializedName("geometry")
        @Expose
        public Geometry geometry;
        @SerializedName("place_id")
        @Expose
        public String placeId;
        @SerializedName("types")
        @Expose
        public List<String> types = null;

    }

    public class Southwest {

        @SerializedName("lat")
        @Expose
        public Double lat;
        @SerializedName("lng")
        @Expose
        public Double lng;

    }

    public class Viewport {

        @SerializedName("northeast")
        @Expose
        public Northeast northeast;
        @SerializedName("southwest")
        @Expose
        public Southwest southwest;

    }
}
