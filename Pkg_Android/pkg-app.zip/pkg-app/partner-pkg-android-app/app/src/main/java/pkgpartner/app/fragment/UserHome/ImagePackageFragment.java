package pkgpartner.app.fragment.UserHome;

import android.Manifest;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.toxsl.volley.toolbox.RequestParams;
import com.toxsl.volley.toolbox.SyncManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import pkgpartner.app.BuildConfig;
import pkgpartner.app.R;
import pkgpartner.app.activity.BaseActivity;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.ScannerListener;

/**
 * A simple {@link Fragment} subclass.
 */

public class ImagePackageFragment extends BaseFragment implements View.OnClickListener, ScannerListener.MyScannerListener, BaseActivity.PermCallback {

    private static String flag = "false";
    private static ImageButton qrscanBT;
    public SyncManager syncManager;
    ScannerListener scannerListener;
    private ArrayList<String> scannedImagesObject = new ArrayList<>();
    private ArrayList<String> qrcode_list = new ArrayList<String>();
    private ArrayList<String> pkgIdList = new ArrayList<String>();
    private boolean first = true;
    private View view;
    private String bar_code;
    private String pkgid;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        baseActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        syncManager = SyncManager.getInstance(baseActivity, !BuildConfig.DEBUG);
        view = inflater.inflate(R.layout.activity_package_pick_up, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        scannedImagesObject.clear();
        qrcode_list.clear();
        initUI(view);
    }

    private void initUI(View view) {

        scannerListener = ScannerListener.getInstance();
        scannerListener.setDataListener(this);

        qrscanBT = (ImageButton) view.findViewById(R.id.qrscanBT);
        qrscanBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {

            case R.id.qrscanBT:
                baseActivity.store.setData("imageList", new ArrayList<String>());
                baseActivity.store.setData("codeList", new ArrayList<String>());
                baseActivity.store.setData("pkgIdList", new ArrayList<String>());
                qrcode_list = baseActivity.store.getData("codeList");
                if (baseActivity.checkPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, 101, this)) {
//                    openScanDialogBox();
                    Fragment ocrScannerFragment = new OCRScannerFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, ocrScannerFragment)
                            .addToBackStack(null)
                            .commit();
                }
                break;
        }
    }

    private void hitPackageScannerApi() {
        log("hit package scanner api " + baseActivity.scanned_data);
        RequestParams requestParams = new RequestParams();
        requestParams.put("text", baseActivity.scanned_data);
//        requestParams.put("qr_code", bar_code);
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.SCANNER + user_id, requestParams, this);
    }

    public void openScanDialogBox() {

        if (qrcode_list.isEmpty() || scannedImagesObject.isEmpty()) {

        } else {
            qrcode_list.clear();
            scannedImagesObject.clear();
        }

        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(getActivity(), R.style.Theme_AppCompat_Dialog);
        } else {
            builder = new AlertDialog.Builder(getActivity());
        }

        builder.setMessage("Choose scanning options")
                .setPositiveButton("Scan Pkg ID", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        if (flag.equals("false")) {
                            showToast("First scan Package Spot ID");
                        } else if (flag.equals("true")) {
                            BarCodeScannerFragment barCodeScannerFragment = new BarCodeScannerFragment();
                            baseActivity.getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.container, barCodeScannerFragment)
                                    .addToBackStack(null)
                                    .commit();
                        }
                    }
                })

                .setNegativeButton("Scan Pkg Spot ID", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        flag = "true";
                        OCRScannerFragment ocrScannerFragment = new OCRScannerFragment();
                        baseActivity.getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container, ocrScannerFragment)
                                .addToBackStack(null)
                                .commit();
                    }
                })

                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.SCANNER)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("ID confirmed");

                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        pkgid = object.getString("pkgid");
                    }

                    Bundle bundle = new Bundle();
                    log("scannedImagesObject " + scannedImagesObject.size());
                    log("qrcode_list " + qrcode_list.size());
                    if (baseActivity.store.containValue("pkgIdList") && baseActivity.store.getData("pkgIdList").size() > 0) {
                        pkgIdList = baseActivity.store.getData("pkgIdList");
                    }
                    pkgIdList.add(pkgid);
                    baseActivity.store.setData("pkgIdList", pkgIdList);
                    bundle.putSerializable("ocr_image_list", scannedImagesObject);
                    bundle.putSerializable("ocr_code_list", qrcode_list);
                    bundle.putSerializable("pkgIdList", pkgIdList);
                    bundle.putSerializable("pkgid", pkgid);


                    Fragment additionalPackagesFragment = new AdditionalPackagesFragment();
                    additionalPackagesFragment.setArguments(bundle);
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, additionalPackagesFragment)
                            .addToBackStack(null)
                            .commit();

                } else {
                    if (scannedImagesObject.contains(baseActivity.scanned_data)) {
                        scannedImagesObject.remove(baseActivity.scanned_data);
                    }
                    errorMessage(jsonObject);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ocr_image_list", scannedImagesObject);
                    bundle.putSerializable("ocr_code_list", qrcode_list);
                    Fragment idNotVerifiedFragment = new IDNotVerifiedFragment();
                    idNotVerifiedFragment.setArguments(bundle);
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, idNotVerifiedFragment)
                            .commit();

                }
            } else if (jsonObject.getString("url").contains(Const.PACKAGE_UPLOAD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Package uploaded successfully");
                    bar_code = null;
                    qrcode_list.clear();
                    scannedImagesObject.clear();
                    HomeFragment ocrScannerFragment = new HomeFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, ocrScannerFragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                    bar_code = null;
                    qrcode_list.clear();
                    scannedImagesObject.clear();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private boolean isValidate() {
        if (baseActivity.scanned_data == null) {
            showToast("Please scan OCR");
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onImageScanned(String param, String imageData, ArrayList<String> qrImageList) {
        if (param.equals("ocr_text")) {
            if (baseActivity.store.containValue("imageList")) {
                scannedImagesObject = baseActivity.store.getData("imageList");
                qrcode_list = baseActivity.store.getData("codeList");
            }
            baseActivity.scanned_data = imageData;
            if (!qrcode_list.contains(baseActivity.scanned_data)) {
                qrcode_list.add(baseActivity.scanned_data);
            }
        } else if (param.equals("bar_code")) {
            bar_code = imageData;
            if (!qrcode_list.contains(bar_code)) {
                qrcode_list.add(bar_code);
            }
        }

        if (qrImageList.isEmpty()) {

        } else {
            for (int i = 0; i < qrImageList.size(); i++) {
                String imagePath = qrImageList.get(i);
                if (!scannedImagesObject.contains(imagePath)) {
                    scannedImagesObject.add(imagePath);
                }
            }
        }

        if (first) {
            if (isValidate()) {
                first = false;
                hitPackageScannerApi();
            } else {
                showToast("Please scan Customer ID");
            }
        }
        baseActivity.store.setData("imageList", scannedImagesObject);
        baseActivity.store.setData("codeList", qrcode_list);
    }

    @Override
    public void permGranted(int resultCode) {

    }

    @Override
    public void permDenied(int resultCode) {

    }
}
