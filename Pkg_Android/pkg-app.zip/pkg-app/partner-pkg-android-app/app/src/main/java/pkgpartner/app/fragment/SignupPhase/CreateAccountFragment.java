package pkgpartner.app.fragment.SignupPhase;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 7/9/17.
 */

public class CreateAccountFragment extends BaseFragment {
    private View view;
    private String user_id;
    private TextView Terms_of_service_TV, Privacy_Policy_TV;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            user_id = bundle.getString("user_id");
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_create_account, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        Terms_of_service_TV = (TextView) view.findViewById(R.id.Terms_of_service_TV);
        Privacy_Policy_TV = (TextView) view.findViewById(R.id.Privacy_Policy_TV);
        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        Terms_of_service_TV.setText(Html.fromHtml("<u>Terms of Service</u>"));
        Privacy_Policy_TV.setText(Html.fromHtml("<u>Privacy Policy.</u>"));
        Privacy_Policy_TV.setOnClickListener(this);
        Terms_of_service_TV.setOnClickListener(this);
        nextBT.setOnClickListener(this);
    }

    private void hitAddMessageApi(String user_id) {
        syncManager.sendToServer(Const.CREATE_ACCOUNT + user_id, null, this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                SharedPreferences mobilePreference = getActivity().getSharedPreferences("email_verification", Context.MODE_PRIVATE);
                mobilePreference.edit().remove("mobileString").commit();

                hitAddMessageApi(user_id);
                break;
            case R.id.Terms_of_service_TV:
                Fragment fragment = new TermsAndServiceFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .addToBackStack(null)
                        .commit();
                break;
            case R.id.Privacy_Policy_TV:
                fragment = new PrivacyPolicyFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .addToBackStack(null)
                        .commit();
                break;

        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.CREATE_ACCOUNT)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    Fragment fragment = new ThanksFragment();
                    baseActivity.getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.login_frame, fragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}
