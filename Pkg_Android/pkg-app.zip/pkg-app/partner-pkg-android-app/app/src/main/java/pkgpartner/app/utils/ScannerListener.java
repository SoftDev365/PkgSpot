package pkgpartner.app.utils;

import java.util.ArrayList;

/**
 * Created by TOXSL\parwinder.deep on 13/10/17.
 */

public class ScannerListener {

    MyScannerListener myScannerListener;

    private static final ScannerListener instance = new ScannerListener();

    public interface MyScannerListener {
        void onImageScanned(String param, String imageData, ArrayList<String> imageList);
    }

    public static ScannerListener getInstance() {
        return instance;
    }

    public void sendImagesData(String param, String imageData, ArrayList<String> imagesList) {
        if (myScannerListener != null)
            myScannerListener.onImageScanned(param, imageData, imagesList);
    }

    public void setDataListener(MyScannerListener myScannerListener) {
        this.myScannerListener = myScannerListener;
    }

}
