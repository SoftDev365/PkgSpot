package pkgpartner.app.fragment.UserHome;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.adapter.HistoryAdapter;
import pkgpartner.app.data.History_Data;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * A simple {@link Fragment} subclass.
 */
public class HistoryFragment extends BaseFragment {

    private View rootView;
    private boolean open = true;
    private String date;
    private TextView calenderTV;
    private RecyclerView historyRV;
    private CalendarView filterCalendar;
    private HistoryAdapter historyAdapter;
    private ArrayList<History_Data> historyDataList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (rootView != null) {
            return rootView;
        } else {
            return inflater.inflate(R.layout.fg_history, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.rootView = view;
        initUI();
    }

    private void initUI() {
        historyRV = (RecyclerView) rootView.findViewById(R.id.historyRV);
        calenderTV = (TextView) rootView.findViewById(R.id.calenderTV);
        filterCalendar = (CalendarView) rootView.findViewById(R.id.filterCalendar);
        filterCalendar.setVisibility(View.GONE);

        calenderTV.setOnClickListener(this);

        hitHistoryApi();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.calenderTV:
                if (open) {
                    open = false;
                    filterCalendar.setVisibility(View.GONE);

                } else {
                    open = true;
                    filterCalendar.setVisibility(View.VISIBLE);
                    gotoCalenderDialog();
                }

                break;
        }
    }

    private void gotoCalenderDialog() {
        filterCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                date = year + "-" + (month + 1) + "-" + dayOfMonth;
                filterCalendar.setVisibility(View.GONE);
                hitFilterApi();
            }
        });
    }

    private void hitFilterApi() {
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.FILTER_DATA + user_id + "/" + date, null, HistoryFragment.this);
    }

    private void hitHistoryApi() {
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.GET_HISTORY + user_id, null, HistoryFragment.this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.GET_HISTORY)) {
                historyDataList.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {

                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);

                        History_Data historyData = new History_Data();
                        historyData.id = object.getString("id");
                        historyData.cuid = object.getString("cuid");
                        historyData.customerName = object.getString("customer_name");
                        historyData.puid = object.getString("puid");
                        historyData.businessName = object.getString("business_name");
                        historyData.packageCount = object.getString("package_count");
                        historyData.recivedDate = object.getString("recived_date");
                        historyData.pricePerPkg = object.getString("price_per_pkg");
                        historyData.totalPrice = object.getString("total_price");
                        historyData.recivedTime = object.getString("recived_time");
                        historyData.address = object.getString("address");
                        historyData.pickedupTime = object.getString("pickedup_time");
                        JSONArray imageArray = object.getJSONArray("images");
                        for (int j = 0; j < imageArray.length(); j++) {
                            historyData.images.add(imageArray.getString(j));
                        }

                        historyDataList.add(historyData);
                        calenderTV.setText("Sort by packages not picked up");
                    }

                    setAdapter();
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.FILTER_DATA)) {
                historyDataList.clear();
                if (jsonObject.getInt("status") == Const.STATUS_OK) {

                    JSONArray data = jsonObject.getJSONArray("data");
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject object = data.getJSONObject(i);

                        History_Data historyData = new History_Data();
                        historyData.id = object.getString("id");
                        historyData.cuid = object.getString("cuid");
                        historyData.customerName = object.getString("customer_name");
                        historyData.puid = object.getString("puid");
                        historyData.businessName = object.getString("business_name");
                        historyData.packageCount = object.getString("package_count");
                        historyData.recivedDate = object.getString("recived_date");
                        historyData.pricePerPkg = object.getString("price_per_pkg");
                        historyData.totalPrice = object.getString("total_price");
                        historyData.pickedupTime = object.getString("pickedup_time");
                        historyData.recivedTime = object.getString("recived_time");
                        historyData.address = object.getString("address");

                        JSONArray imageArray = object.getJSONArray("images");
                        for (int j = 0; j < imageArray.length(); j++) {
                            historyData.images.add(imageArray.getString(j));
                        }

                        historyDataList.add(historyData);

                        calenderTV.setText("Sort by date");
                    }

                    setAdapter();
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setAdapter() {
        historyAdapter = new HistoryAdapter(baseActivity, historyDataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        historyRV.setLayoutManager(mLayoutManager);
        historyRV.setItemAnimator(new DefaultItemAnimator());
        historyRV.setAdapter(historyAdapter);
    }

}
