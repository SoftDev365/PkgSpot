package pkgpartner.app.adapter;

import android.content.DialogInterface;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.activity.BaseActivity;
import pkgpartner.app.fragment.UserHome.AdditionalPackagesFragment;
import pkgpartner.app.fragment.UserHome.IDNotVerifiedFragment;

/**
 * Created by TOXSL\parwinder.deep on 8/11/17.
 */

public class AdditionalPackagesAdapter extends RecyclerView.Adapter<AdditionalPackagesAdapter.MyViewHolder> {
    private ArrayList<String> images = new ArrayList<>();
    private ArrayList<String> codes = new ArrayList<>();
    private ArrayList<String> images1 = new ArrayList<>();
    private ArrayList<String> codes1 = new ArrayList<>();
    private BaseActivity context;
    private String mString;
    private int mImg;
    private Fragment fragment;

    public AdditionalPackagesAdapter(BaseActivity context, ArrayList<String> imageList, int sImg, ArrayList<String> codeList, String mString, Fragment idNotVerifiedFragment) {
        this.images = imageList;
        this.codes = codeList;
        this.images1 = imageList;
        this.codes1 = codeList;
        this.context = context;
        this.mString = mString;
        this.mImg = sImg;
        this.fragment = idNotVerifiedFragment;
    }


    @Override
    public AdditionalPackagesAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.adapter_image_dailog, parent, false);
        return new AdditionalPackagesAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(AdditionalPackagesAdapter.MyViewHolder holder, int position) {
        holder.package_noTV.setText(context.getString(R.string.package_, (position + 1)));

        if (mString.equals("IDNotVerified")) {
            try {
                Glide.with(context).load(images.get(mImg)).into(holder.imageIV);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                Glide.with(context).load(images.get(position)).into(holder.imageIV);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        holder.deleteIV.setTag(position);
        holder.deleteIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = (int) v.getTag();
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(context, R.style.Theme_AppCompat_Dialog);
                } else {
                    builder = new AlertDialog.Builder(context);
                }

                builder.setMessage(context.getResources().getString(R.string.are_you_sure_you_want_to_delete))
                        .setPositiveButton("YES", new DialogOnClick(position) {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                removeAt(position);
                            }
                        })

                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
    }

    private void removeAt(int position) {
        Log.e("", "removeAt: " + "9999999999999999999999999");
        if (fragment instanceof AdditionalPackagesFragment) {
            Log.e("", "removeAt: " + "ADDITIONAL ---------------");
            codes.remove(position);
            images.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, images.size());
            notifyItemRangeChanged(position, codes.size());
        } else if (fragment instanceof IDNotVerifiedFragment) {
            Log.e("", "removeAt: " + "ELSE ---------------");

            codes1.remove(position);
            images1.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, images1.size());
            notifyItemRangeChanged(position, codes1.size());

            if (images.size() > 0) {
                context.getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Fragment additionalPackagesFragment = new AdditionalPackagesFragment();
                context.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, additionalPackagesFragment)
                        .commit();
            } else {
                context.getSupportFragmentManager().popBackStack();
            }
        }
    }

    @Override
    public int getItemCount() {
        if (mString.equals("IDNotVerified")) {
            return 1;
        } else {
            return images.size();
        }
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageIV, deleteIV;
        TextView package_idTV, package_noTV;


        MyViewHolder(View itemView) {
            super(itemView);
            imageIV = (ImageView) itemView.findViewById(R.id.imageIV);
            deleteIV = (ImageView) itemView.findViewById(R.id.deleteIV);
            package_idTV = (TextView) itemView.findViewById(R.id.package_idTV);
            package_noTV = (TextView) itemView.findViewById(R.id.package_noTV);
        }
    }

    abstract class DialogOnClick implements DialogInterface.OnClickListener {
        int position;

        DialogOnClick(int position) {
            this.position = position;
        }
    }
}
