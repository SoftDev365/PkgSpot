package pkgpartner.app.fragment.LoginPhase;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.SignupPhase.SignUpFragment;

public class LoginSignUpFragment extends BaseFragment {
    private View view;
    private Button loginBT, signupBT;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        return inflater.inflate(R.layout.fragment_login_sign_up, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        loginBT = (Button) view.findViewById(R.id.loginBT);
        signupBT = (Button) view.findViewById(R.id.signupBT);

        loginBT.setOnClickListener(this);
        signupBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.loginBT:
                gotoLoginFragment();
                break;

            case R.id.signupBT:
                gotoSignUpFragment();
                break;

        }
    }

    private void gotoSignUpFragment() {
        Fragment fragment = new SignUpFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void gotoLoginFragment() {
        Fragment fragment = new LoginFragment();
        baseActivity.getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .addToBackStack(null)
                .commit();
    }


}
