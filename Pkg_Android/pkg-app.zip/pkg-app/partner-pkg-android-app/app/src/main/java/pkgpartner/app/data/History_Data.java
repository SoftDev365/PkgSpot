package pkgpartner.app.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by TOXSL\parwinder.deep on 27/10/17.
 */

public class History_Data {

    @SerializedName("price_per_pkg")
    @Expose
    public String pricePerPkg;
    @SerializedName("recived_time")
    @Expose
    public String recivedTime;
    @SerializedName("zipcode")
    @Expose
    public String zipcode;
    @SerializedName("state")
    @Expose
    public Object state;
    @SerializedName("pkg_price")
    @Expose
    public Object pkgPrice;
    @SerializedName("customer_name")
    @Expose
    public String customerName;
    @SerializedName("extra_price")
    @Expose
    public Object extraPrice;
    @SerializedName("total_price")
    @Expose
    public String totalPrice;
    @SerializedName("country")
    @Expose
    public Object country;
    @SerializedName("city")
    @Expose
    public String city;
    @SerializedName("business_name")
    @Expose
    public String businessName;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("cuid")
    @Expose
    public String cuid;
    @SerializedName("recived_date")
    @Expose
    public String recivedDate;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("package_count")
    @Expose
    public String packageCount;
    @SerializedName("pickedup_date")
    @Expose
    public String pickedupDate;
    @SerializedName("images")
    @Expose
    public ArrayList<String> images = new ArrayList<>();
    @SerializedName("pickedup_time")
    @Expose
    public String pickedupTime;
    @SerializedName("late_per_pkg")
    @Expose
    public Object latePerPkg;
    @SerializedName("puid")
    @Expose
    public String puid;
}
