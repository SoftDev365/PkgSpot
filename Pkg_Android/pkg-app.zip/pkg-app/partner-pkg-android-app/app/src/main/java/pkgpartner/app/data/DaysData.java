package pkgpartner.app.data;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by TOXSL\chirag.tyagi on 21/9/17.
 */

public class DaysData {

    @SerializedName("monday")
    @Expose
    public Monday monday;
    @SerializedName("tuesday")
    @Expose
    public Tuesday tuesday;
    @SerializedName("wednesday")
    @Expose
    public Wednesday wednesday;
    @SerializedName("thursday")
    @Expose
    public Thursday thursday;
    @SerializedName("friday")
    @Expose
    public Friday friday;
    @SerializedName("saturday")
    @Expose
    public Saturday saturday;
    @SerializedName("sunday")
    @Expose
    public Sunday sunday;

    public Monday getMonday() {
        return monday;
    }

    public void setMonday(Monday monday) {
        this.monday = monday;
    }

    public Tuesday getTuesday() {
        return tuesday;
    }

    public void setTuesday(Tuesday tuesday) {
        this.tuesday = tuesday;
    }

    public Wednesday getWednesday() {
        return wednesday;
    }

    public void setWednesday(Wednesday wednesday) {
        this.wednesday = wednesday;
    }

    public Thursday getThursday() {
        return thursday;
    }

    public void setThursday(Thursday thursday) {
        this.thursday = thursday;
    }

    public Friday getFriday() {
        return friday;
    }

    public void setFriday(Friday friday) {
        this.friday = friday;
    }

    public Saturday getSaturday() {
        return saturday;
    }

    public void setSaturday(Saturday saturday) {
        this.saturday = saturday;
    }

    public Sunday getSunday() {
        return sunday;
    }

    public void setSunday(Sunday sunday) {
        this.sunday = sunday;
    }


}

