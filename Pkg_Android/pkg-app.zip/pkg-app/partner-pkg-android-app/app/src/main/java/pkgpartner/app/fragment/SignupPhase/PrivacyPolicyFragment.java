package pkgpartner.app.fragment.SignupPhase;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.toxsl.volley.Request;
import com.toxsl.volley.VolleyError;
import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;


/**
 * A simple {@link Fragment} subclass.
 */
public class PrivacyPolicyFragment extends BaseFragment {
    View view;
    TextView Policy_TV;

    public PrivacyPolicyFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_privacy_policy, container, false);
        }

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        init();
    }

    private void init() {
        Policy_TV = (TextView) view.findViewById(R.id.Policy_TV);
        hitPrivacyPolicyApi();
    }

    private void hitPrivacyPolicyApi() {
        syncManager.sendToServer(Const.TERMS_PAGE + "/" + Const.TYPE_POLICY_CUSTOMER, null, PrivacyPolicyFragment.this);
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        log("success");
        try {
            if (jsonObject.getInt("status") == Const.STATUS_OK) {
                JSONArray array = jsonObject.getJSONArray("data");
                for (int i = 0; i < array.length(); i++) {
                    JSONObject object = array.getJSONObject(i);
                    String description = object.getString("description");
                    Policy_TV.setText(description);
                }
            } else {
                log("not ok");
                showToast("User Id Not found");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSyncFailure(VolleyError error, Request mRequest) {
        super.onSyncFailure(error, mRequest);
        log("failure");
    }

}
