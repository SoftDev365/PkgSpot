package pkgpartner.app.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;

import pkgpartner.app.R;
import pkgpartner.app.fragment.LoginPhase.LoginFragment;
import pkgpartner.app.fragment.LoginPhase.LoginSignUpFragment;
import pkgpartner.app.fragment.SignupPhase.SignUpFragment;
import pkgpartner.app.fragment.SignupPhase.ThanksFragment;

public class LoginSignUpActivity extends BaseActivity {
    ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sign_up);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        gotoLoginFragment();
    }

    private void gotoLoginFragment() {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        Fragment fragment = new LoginSignUpFragment();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.login_frame, fragment)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        actionBar = getSupportActionBar();
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
        if (fragment instanceof LoginSignUpFragment
                ) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        } else {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
                hideSoftKeyboard();
                onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
        if (fragment instanceof LoginSignUpFragment) {
            back();
        } else if (fragment instanceof LoginFragment || fragment instanceof ThanksFragment) {
            gotoLoginFragment();
        } else {
            hideSoftKeyboard();
            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else {
                gotoLoginFragment();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.login_frame);
        if (fragment instanceof SignUpFragment) {
            ((SignUpFragment) fragment).onActivityResult(data, requestCode);
        }
    }
}