package pkgpartner.app.fragment.SignupPhase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.LoginFragment;
import pkgpartner.app.fragment.LoginPhase.LoginSignUpFragment;

/**
 * Created by TOXSL\ankan.tiwari on 7/9/17.
 */

public class ThanksFragment extends BaseFragment {

    private View view;
    private Button go_to_loginBT;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        view = inflater.inflate(R.layout.fg_thankyou, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        go_to_loginBT = (Button) view.findViewById(R.id.go_to_loginBT);
        go_to_loginBT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.go_to_loginBT:
                LoginSignUpFragment loginFragment = new LoginSignUpFragment();
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.id.login_frame, loginFragment)
                        .addToBackStack(null)
                        .commit();
                break;
        }
    }
}
