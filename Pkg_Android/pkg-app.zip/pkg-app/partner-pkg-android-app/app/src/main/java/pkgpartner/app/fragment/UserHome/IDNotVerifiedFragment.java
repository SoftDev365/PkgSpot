package pkgpartner.app.fragment.UserHome;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.adapter.AdditionalPackagesAdapter;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.ImageUtils;

/**
 * Created by TOXSL\parwinder.deep on 8/11/17.
 */

public class IDNotVerifiedFragment extends BaseFragment {
    private View view;
    private EditText customer_idET;
    private String pkgid;
    private RecyclerView scannedImagesRV;
    private ArrayList<String> imgList = new ArrayList<>();
    private ArrayList<String> codeList = new ArrayList<>();
    private ArrayList<String> pkgIdList = new ArrayList<String>();
    private AdditionalPackagesAdapter additionalPackagesAdapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_id_not_verified, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle bundle = this.getArguments();
        if (bundle.containsKey("ocr_image_list")) {
            imgList = (ArrayList<String>) bundle.getSerializable("ocr_image_list");
            codeList = (ArrayList<String>) bundle.getSerializable("ocr_code_list");
        }

        initUI();
    }

    private void initUI() {

        Button submitBT = (Button) view.findViewById(R.id.submitBT);
        Button send_imagesBT = (Button) view.findViewById(R.id.send_imagesBT);
        customer_idET = (EditText) view.findViewById(R.id.customer_idET);
        scannedImagesRV = (RecyclerView) view.findViewById(R.id.scannedImagesRV);

        submitBT.setOnClickListener(this);
        send_imagesBT.setOnClickListener(this);

        setadapter();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.submitBT:
                hitPackageScannerApi();
                break;

            case R.id.send_imagesBT:
                RequestParams params = new RequestParams();
                for (int i = 0; i < imgList.size(); i++) {
                    Bitmap bitmap = ImageUtils.imageCompress(imgList.get(i));
                    File file = ImageUtils.bitmapToFile(bitmap, baseActivity);
                    try {
                        params.put("image", file);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

                baseActivity.syncManager.sendToServer(Const.CONFIRM_PACKAGE + baseActivity.store.getString("user_id"), params, this);

                break;
        }
    }

    private void hitPackageScannerApi() {
        RequestParams requestParams = new RequestParams();
        requestParams.put("text", customer_idET.getText().toString().trim());
//        requestParams.put("qr_code", codeList.get(0));
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.SCANNER + user_id, requestParams, this);
    }

    private void setadapter() {
        int img;
        if (imgList.size() == 1) {
            img = 0;
        } else {
            img = imgList.size() - 1;
        }
        additionalPackagesAdapter = new AdditionalPackagesAdapter(baseActivity, imgList, img, codeList, "IDNotVerified", this);
        scannedImagesRV.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        scannedImagesRV.setAdapter(additionalPackagesAdapter);
        scannedImagesRV.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").contains(Const.SCANNER)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("ID confirmed");

                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        pkgid = object.getString("pkgid");
                    }
                    if (baseActivity.store.containValue("pkgIdList") && baseActivity.store.getData("pkgIdList").size() > 0) {
                        pkgIdList = baseActivity.store.getData("pkgIdList");
                    }
                    pkgIdList.add(pkgid);
                    baseActivity.store.setData("pkgIdList", pkgIdList);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ocr_image_list", imgList);
                    bundle.putSerializable("ocr_code_list", codeList);
                    bundle.putSerializable("pkgid", pkgid);
                    bundle.putSerializable("pkgIdList", pkgIdList);
                    Fragment additionalPackagesFragment = new AdditionalPackagesFragment();
                    additionalPackagesFragment.setArguments(bundle);
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, additionalPackagesFragment)
                            .addToBackStack(null)
                            .commit();

                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.CONFIRM_PACKAGE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {

                    JSONArray data = jsonObject.getJSONArray("data");
                    JSONObject object = data.getJSONObject(0);
                    log("file name" + object.getString("filename") + "--");
                    hitApi(object.getString("filename"));
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").equalsIgnoreCase(Const.CONFIRM_PACKAGE_EMAIL)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Email sent successfully.");
                    ImagePackageFragment imagePackageFragment = new ImagePackageFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, imagePackageFragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void hitApi(String filename) {
        RequestParams params = new RequestParams();
        params.put("filename", filename);
        syncManager.sendToServer(Const.CONFIRM_PACKAGE_EMAIL, params, this);
    }
}
