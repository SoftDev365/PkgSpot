package pkgpartner.app.data;

/**
 * Created by TOXSL\parwinder.deep on 18/10/17.
 */

public class HelpData {
    public String title;
    public int id;

}
