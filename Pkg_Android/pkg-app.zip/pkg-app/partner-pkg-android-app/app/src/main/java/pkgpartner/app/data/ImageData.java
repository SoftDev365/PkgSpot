package pkgpartner.app.data;

import java.io.File;

/**
 * Created by TOXSL\parwinder.deep on 27/10/17.
 */

public class ImageData {
    public File image;
}
