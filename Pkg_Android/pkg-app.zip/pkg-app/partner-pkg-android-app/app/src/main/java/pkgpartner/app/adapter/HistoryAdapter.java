package pkgpartner.app.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import pkgpartner.app.R;
import pkgpartner.app.activity.BaseActivity;
import pkgpartner.app.data.History_Data;

/**
 * Created by TOXSL\parwinder.deep on 3/10/17.
 */

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyViewHolder> {

    private List<History_Data> historyDataList;
    private BaseActivity baseActivity;
    private Context context;

    public HistoryAdapter(Context context, List<History_Data> historyDataList) {
        this.historyDataList = historyDataList;
        this.context = context;
        baseActivity = new BaseActivity();
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_history, parent, false);
        return new HistoryAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.historyData = historyDataList.get(holder.getAdapterPosition());
        holder.customer_nameTV.setText(holder.historyData.customerName);
        holder.customer_idTV.setText(holder.historyData.cuid);
        holder.packagesTV.setText(holder.historyData.packageCount);
        if (holder.historyData.pickedupTime == null || holder.historyData.pickedupTime.equals("")) {
            holder.pickup_timeTV.setText("Pending");
        } else {
            holder.pickup_timeTV.setText(holder.historyData.pickedupTime);
        }

        holder.dateReceivedTV.setText(baseActivity.changeDateFormat(holder.historyData.recivedDate, "yyyy-MM-dd", "EEEE MMM dd, yyyy"));
        holder.imagesTV.setTag(holder);
        holder.imagesTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyViewHolder holder = (MyViewHolder) v.getTag();
                openImagesDailog(holder.historyData.images);

            }
        });
    }

    public void openImagesDailog(ArrayList<String> imageList) {
        LayoutInflater myLayout = LayoutInflater.from(context);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Images");
        View view = myLayout.inflate(R.layout.dailog_image_my_package, null);
        RecyclerView imgRV = (RecyclerView) view.findViewById(R.id.imgRV);
        imgRV.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        ImagesAdapter imagesAdapter = new ImagesAdapter(context, imageList);
        imgRV.setAdapter(imagesAdapter);
        builder.setView(view);
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }


    @Override
    public int getItemCount() {
        return historyDataList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView dateReceivedTV, customer_nameTV, customer_idTV, pickup_timeTV, packagesTV, imagesTV;
        History_Data historyData;

        public MyViewHolder(View itemView) {
            super(itemView);
            dateReceivedTV = (TextView) itemView.findViewById(R.id.dateReceivedTV);
            customer_nameTV = (TextView) itemView.findViewById(R.id.customer_nameTV);
            customer_idTV = (TextView) itemView.findViewById(R.id.customer_idTV);
            pickup_timeTV = (TextView) itemView.findViewById(R.id.pickup_timeTV);
            packagesTV = (TextView) itemView.findViewById(R.id.packagesTV);
            imagesTV = (TextView) itemView.findViewById(R.id.imagesTV);

        }
    }
}
