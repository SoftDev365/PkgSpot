package pkgpartner.app.fragment.SignupPhase;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

import pkgpartner.app.BuildConfig;
import pkgpartner.app.R;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;

/**
 * Created by TOXSL\ankan.tiwari on 6/9/17.
 */

public class SignUpFragment extends BaseFragment {
    private String latitude, longitude;
    private String[] operating_as_DD = {"Individual/Sole proprietor or single-member LLC", "C Corporation", "S Corporation", "Partnership", "Limited Liability Company", "Other"};
    private View view;
    private String streetAddress_S, route_S, state_S, city_S, country_S, zip_S;
    private String operating_as;
    private EditText nameET, emailET, passwordET, zipET, CityET, StateET, phone_numberET, streetaddressET, Legal_Business_NameET, positionET, websiteET;

    public JSONObject getLocationInfo(String address) {
        String mAddress = address.replace(" ", "%20");
        HttpGet httpGet = new HttpGet("https://maps.googleapis.com/maps/api/geocode/json?address=" + mAddress + "&sensor=true&key=AIzaSyCzc-H6fTsX68hKZwoJwlXAHSjcMU-QIQQ");
        HttpClient client = new DefaultHttpClient();
        HttpResponse response;
        StringBuilder stringBuilder = new StringBuilder();

        try {
            response = client.execute(httpGet);
            HttpEntity entity = response.getEntity();
            InputStream stream = entity.getContent();
            int b;
            while ((b = stream.read()) != -1) {
                stringBuilder.append((char) b);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(stringBuilder.toString());
            String text = stringBuilder.toString();
            text = text.replaceAll("\n", "");
            log("response -------------- " + text);
            JSONObject jsonObject1 = new JSONObject(text);
            JSONArray results = jsonObject1.getJSONArray("results");
            log("1111111");
            JSONObject jsonObject2 = results.getJSONObject(0);
            JSONArray address_components = jsonObject2.getJSONArray("address_components");
            log("2222222");
            for (int i = 0; i < address_components.length(); i++) {
                JSONObject object = address_components.optJSONObject(i);

                log("333333");

                JSONArray types = object.getJSONArray("types");
                String types_S = types.get(0).toString();

                if (types_S.equals("street_number")) {
                    streetAddress_S = object.getString("long_name");
                    log("street " + streetAddress_S);
                }

                if (types_S.equals("route")) {
                    route_S = object.getString("long_name");
                    log("route " + route_S);
                }

                if (types_S.equals("locality")) {
                    city_S = object.getString("long_name");
                    log("city " + city_S);
                }

                if (types_S.equals("administrative_area_level_1")) {
                    state_S = object.getString("long_name");
                    log("state " + state_S);
                }

                if (types_S.equals("country")) {
                    country_S = object.getString("short_name");
                    log("country " + country_S);
                }

                if (types_S.equals("postal_code")) {
                    zip_S = object.getString("long_name");
                    log("zip " + zip_S);
                }
            }

            if (city_S != null) {
                CityET.setText(city_S);
            } else {
                CityET.setText("");
            }

            if (route_S == null) {
                streetaddressET.setText(streetAddress_S);
            } else if (streetAddress_S == null) {
                streetaddressET.setText(route_S);
            } else {
                if (route_S.equals("") && streetAddress_S.equals("")) {
                    streetaddressET.setText("");
                } else {
                    streetaddressET.setText(streetAddress_S + " " + route_S);
                }
            }

            if (state_S == null) {
                StateET.setText(country_S);
            } else if (country_S == null) {
                StateET.setText(state_S);
            } else {
                if (state_S.equals("") && country_S.equals("")) {
                    StateET.setText("");
                } else {
                    StateET.setText(state_S + " " + country_S);
                }
            }

            if (zip_S != null) {
                zipET.setText(zip_S);
            } else {
                zipET.setText("");
            }

            zip_S = "";
            state_S = "";
            country_S = "";
            city_S = "";
            route_S = "";
            streetAddress_S = "";

        } catch (JSONException e) {
            showToast("Network Problem!");
            e.printStackTrace();
        }

        return jsonObject;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        if (view != null) {
            return view;
        } else {
            return inflater.inflate(R.layout.fg_sign_up, container, false);
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        initUI();
    }

    private void initUI() {
        nameET = (EditText) view.findViewById(R.id.nameET);
        emailET = (EditText) view.findViewById(R.id.email_addressET);
        passwordET = (EditText) view.findViewById(R.id.passwordET);
        zipET = (EditText) view.findViewById(R.id.zipET);
        CityET = (EditText) view.findViewById(R.id.CityET);
        websiteET = (EditText) view.findViewById(R.id.websiteET);
        StateET = (EditText) view.findViewById(R.id.StateET);
        phone_numberET = (EditText) view.findViewById(R.id.phone_numberET);
        streetaddressET = (EditText) view.findViewById(R.id.streetaddressET);
        Legal_Business_NameET = (EditText) view.findViewById(R.id.Legal_Business_NameET);
        positionET = (EditText) view.findViewById(R.id.positionET);
        Spinner operating_as_S = (Spinner) view.findViewById(R.id.operating_as_S);
        streetaddressET.setOnClickListener(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item, operating_as_DD);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operating_as_S.setAdapter(adapter);
        operating_as_S.setOnItemSelectedListener(this);

        Button nextBT = (Button) view.findViewById(R.id.nextBT);
        nextBT.setOnClickListener(this);
        CityET.setOnClickListener(this);

        if (BuildConfig.DEBUG) {
            websiteET.setText("oippiopo");
            Legal_Business_NameET.setText("iopipoi");
            phone_numberET.setText("987653210");
            positionET.setText("oiop");
            nameET.setText("poipoi");
            StateET.setText("ouipoipo");
            CityET.setText("iopoip");
            streetaddressET.setText("iop");
            Legal_Business_NameET.setText("ipoiopo");
            zipET.setText("123");
            emailET.setText("parwinder.deep@toxsltech.com");
            passwordET.setText("aA@123");
        }
    }

    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {

        switch (position) {
            case 0:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 1:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 2:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 3:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 4:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 5:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
            case 6:
                operating_as = parent.getItemAtPosition(position).toString();
                break;
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.nextBT:
                if (isValidate()) {
                    baseActivity.store.saveString("email", emailET.getText().toString().trim());

                    Fragment fragment = new SignUpSecondStepFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("full_name", nameET.getText().toString().trim());
                    bundle.putString("email", emailET.getText().toString().trim());
                    bundle.putString("password", passwordET.getText().toString().trim());
                    bundle.putString("zipcode", zipET.getText().toString().trim());
                    bundle.putString("operatininitg_as", operating_as);
                    bundle.putString("city", CityET.getText().toString().trim());
                    bundle.putString("state", StateET.getText().toString().trim());
                    bundle.putString("latitude", latitude);
                    bundle.putString("longitude", longitude);
                    bundle.putString("contact_no", phone_numberET.getText().toString().trim());
                    bundle.putString("address", streetaddressET.getText().toString().trim());
                    bundle.putString("business_name", Legal_Business_NameET.getText().toString().trim());
                    bundle.putString("position", positionET.getText().toString().trim());
                    bundle.putString("website", websiteET.getText().toString().trim());
                    fragment.setArguments(bundle);
                    baseActivity.getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.login_frame, fragment)
                            .addToBackStack(null)
                            .commit();
                }
                break;

            case R.id.CityET:

                break;
            case R.id.streetaddressET:
                streetaddressET.setEnabled(true);
                getAutoLocation();
                break;
        }
    }

    private boolean isValidate() {
        if (nameET.getText().toString().isEmpty()) {
            showToast("Please enter Name");
            return false;
        } else if (emailET.getText().toString().isEmpty()) {
            showToast("Please enter Email");
            return false;
        } else if (!baseActivity.isValidMail(emailET.getText().toString())) {
            showToast("Please enter valid Email");
            return false;
        } else if (passwordET.getText().toString().isEmpty()) {
            showToast("Please enter Password");
            return false;
        } else if (passwordET.getText().toString().length() < 6) {
            showToast("Please enter minimum 6 characters");
            return false;
        } else if (!isValidPassword(passwordET.getText().toString())) {
            showToast("Please enter valid Password");
            return false;
        } else if (zipET.getText().toString().isEmpty()) {
            showToast("Please enter Zip Code");
            return false;
        } else if (operating_as.equalsIgnoreCase("")) {
            showToast("Please enter Operating As");
            return false;
        } else if (Legal_Business_NameET.getText().toString().isEmpty()) {
            showToast("Please enter Business Name");
            return false;
        } else if (streetaddressET.getText().toString().isEmpty()) {
            showToast("Please enter valid address");
            return false;
        } else if (CityET.getText().toString().isEmpty()) {
            showToast("Please enter City");
            return false;
        } else if (positionET.getText().toString().isEmpty()) {
            showToast("Please enter Position");
            return false;
        } else if (phone_numberET.getText().toString().isEmpty()) {
            showToast("Please enter Phone Number");
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equalsIgnoreCase(Const.STEP_1_SIGN_UP)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Success");
                    if (jsonObject.has("userId")) {
                        String userId = jsonObject.getString("userId");
                        baseActivity.store.saveString("user_id", userId);
                        gotoMarketingMessage(true, userId);
                    } else {
                        showToast("User Id Not found");
                    }

                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.has("results")) {
            } else {
                showToast(jsonObject.optString("error"));
                if (jsonObject.has("step")) {
                    String userId = jsonObject.optString("userId");
                    switch (jsonObject.getInt("step")) {
                        case 1:
                            gotoSignUpSecond(true, userId);
                            break;
                        case 2:
                            gotoMarketingMessage(true, userId);
                            break;
                        case 3:
                            gotoVerificationFragment(true, userId);
                            break;

                        case 0:
                            break;

                        default:
                            showToast("Error in loading steps");
                            break;
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getAutoLocation() {
        Intent intent = null;
        try {
            intent = new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_OVERLAY).build(baseActivity);
            getActivity().startActivityForResult(intent, 111);
        } catch (GooglePlayServicesRepairableException | GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }

    public void onActivityResult(Intent data, int requestCode) {
        if (requestCode == 111) {
            if (data != null) {
                Place place = PlaceAutocomplete.getPlace(baseActivity, data);
                if (place != null) {
                    String s = place.getLatLng().toString();
                    s = s.substring(s.indexOf("(") + 1);
                    s = s.substring(0, s.indexOf(")"));
                    String str = s;
                    latitude = str.substring(0, str.indexOf(","));
                    longitude = str.substring(str.indexOf(",") + 1, str.length());

                    getLocationInfo(place.getAddress().toString());
                }
            }
        }
    }
}