package pkgpartner.app.fragment.LoginPhase;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import pkgpartner.app.BuildConfig;
import pkgpartner.app.R;
import pkgpartner.app.activity.MainActivity;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.PrefStore;


public class LoginFragment extends BaseFragment {

    private View view;
    private EditText emailET, passwordET;
    private PrefStore prefStore;
    private Button password_help_BT;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        return inflater.inflate(R.layout.fg_login, container, false);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view = view;
        prefStore = new PrefStore(getActivity());
        initUI();
    }

    private void hitLoginApi() {
        RequestParams params = new RequestParams();
        params.put("email", emailET.getText().toString().trim());
        params.put("password", passwordET.getText().toString().trim());
        params.put("device_token", baseActivity.getUniqueDeviceId());
        params.put("type", "1");

        syncManager.sendToServer(Const.LOGIN, params, this);
    }


    private void initUI() {
        emailET = (EditText) view.findViewById(R.id.emailET);
        passwordET = (EditText) view.findViewById(R.id.passwordET);
        password_help_BT = (Button) view.findViewById(R.id.password_help_BT);
        password_help_BT.setOnClickListener(this);

        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(passwordET.getWindowToken(), 0);

        Button loginBT = (Button) view.findViewById(R.id.loginBT);
        loginBT.setOnClickListener(this);
        if (BuildConfig.DEBUG) {
            emailET.setText("parwinder.deep@toxsltech.com");
            passwordET.setText("aA@123");
        }
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.loginBT:
                if (isValidate()) {
                    hitLoginApi();
                }
                break;

            case R.id.password_help_BT:
                Bundle bundle = new Bundle();
                bundle.putInt("frame_id", R.id.login_frame);
                Fragment fragment = new ForgotPasswordFragment();
                fragment.setArguments(bundle);
                baseActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.login_frame, fragment)
                        .addToBackStack(null)
                        .commit();
                break;
        }
    }

    private boolean isValidate() {
        if (emailET.getText().toString().isEmpty()) {
            showToast("Please enter email address");
            return false;
        } else if (!baseActivity.isValidMail(emailET.getText().toString())) {
            showToast("Please enter valid email");
            return false;
        } else if (passwordET.getText().toString().isEmpty()) {
            showToast("Please enter password");
            return false;
        }else {
            return true;
        }
    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);
        try {
            if (jsonObject.getString("url").equals(Const.LOGIN)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {

                    syncManager.setLoginStatus(jsonObject.optString("auth_code"));
                    baseActivity.store.saveString(Const.USER_ID, jsonObject.optString("userId"));

                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        String business_name = object.getString("business_name");
                        String address = object.getString("address");
                        String city = object.getString("city");
                        String state = object.getString("state");
                        String zipcode = object.getString("zipcode");
                        String unique_id = object.getString("unique_id");
                        log("unique id " + unique_id);
                        prefStore.saveString("unique_id", unique_id);

                        prefStore.saveString("business_name", business_name);
                        prefStore.saveString("address", address);
                        prefStore.saveString("city", city);
                        prefStore.saveString("state", state);
                        prefStore.saveString("zipcode", zipcode);
                    }
                    goToMainActivity();

                } else {
                    errorMessage(jsonObject);

                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void goToMainActivity() {
        Intent intent = new Intent(baseActivity, MainActivity.class);
        startActivity(intent);
        baseActivity.finish();
    }
}
