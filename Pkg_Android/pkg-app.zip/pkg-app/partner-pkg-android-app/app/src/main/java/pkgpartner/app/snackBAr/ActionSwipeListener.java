package pkgpartner.app.snackBAr;

public interface ActionSwipeListener {

    void onSwipeToDismiss();
}
