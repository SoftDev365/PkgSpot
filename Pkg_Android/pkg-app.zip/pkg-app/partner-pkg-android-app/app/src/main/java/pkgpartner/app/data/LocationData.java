package pkgpartner.app.data;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by TOXSL\anshul.mittal on 2/11/16.
 */
public class LocationData implements Parcelable {
    public static final Creator<LocationData> CREATOR = new Creator<LocationData>() {
        @Override
        public LocationData createFromParcel(Parcel in) {
            return new LocationData(in);
        }

        @Override
        public LocationData[] newArray(int size) {
            return new LocationData[size];
        }
    };
    public int id;
    public String title;
    public String description;
    public double lat;
    public double lng;
    public String imageFile;
    public String totalDistance;
    public String totalFare;

    public LocationData(Parcel in) {
        id = in.readInt();
        title = in.readString();
        description = in.readString();
        lat = in.readDouble();
        lng = in.readDouble();
        imageFile = in.readString();
        totalDistance = in.readString();
        totalFare = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeDouble(lat);
        dest.writeDouble(lng);
        dest.writeString(imageFile);
        dest.writeString(totalDistance);
        dest.writeString(totalFare);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
