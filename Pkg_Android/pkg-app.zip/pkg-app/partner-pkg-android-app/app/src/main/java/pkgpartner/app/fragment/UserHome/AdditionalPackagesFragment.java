package pkgpartner.app.fragment.UserHome;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.toxsl.volley.toolbox.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import pkgpartner.app.R;
import pkgpartner.app.activity.BaseActivity;
import pkgpartner.app.adapter.AdditionalPackagesAdapter;
import pkgpartner.app.data.DataToSend;
import pkgpartner.app.fragment.BaseFragment;
import pkgpartner.app.fragment.LoginPhase.HomeFragment;
import pkgpartner.app.utils.Const;
import pkgpartner.app.utils.ImageUtils;
import pkgpartner.app.utils.ScannerListener;

/**
 * Created by TOXSL\parwinder.deep on 8/11/17.
 */

public class AdditionalPackagesFragment extends BaseFragment implements View.OnClickListener, ScannerListener.MyScannerListener, BaseActivity.PermCallback {

    private View view;
    private String pkgid, bar_code;
    private ArrayList<String> imgList = new ArrayList<>();
    private ArrayList<String> codeList = new ArrayList<>();
    private ArrayList<String> pkgIdList = new ArrayList<>();
    private RecyclerView scannedImagesRV;
    private ArrayList<DataToSend> dataToSends = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle!=null&& bundle.containsKey("ocr_image_list")) {
            imgList = (ArrayList<String>) bundle.getSerializable("ocr_image_list");
            codeList = (ArrayList<String>) bundle.getSerializable("ocr_code_list");
            pkgIdList = (ArrayList<String>) bundle.getSerializable("pkgIdList");
            pkgid = bundle.getString("pkgid");
        }



    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_additional_packages, container, false);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        initUI();
    }

    private void initUI() {
        Button additional_packagesBT = (Button) view.findViewById(R.id.additional_packagesBT);
        Button finishedBT = (Button) view.findViewById(R.id.finishedBT);

        additional_packagesBT.setOnClickListener(this);
        finishedBT.setOnClickListener(this);

        scannedImagesRV = (RecyclerView) view.findViewById(R.id.scannedImagesRV);
        setadapter();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        switch (v.getId()) {
            case R.id.additional_packagesBT:
                Fragment ocrScannerFragment = new OCRScannerFragment();
                if (getArguments()!=null&&getArguments().containsKey("ocr_image_list")) {
                    imgList = (ArrayList<String>) getArguments().getSerializable("ocr_image_list");
                    codeList = (ArrayList<String>) getArguments().getSerializable("ocr_code_list");
                    pkgid = getArguments().getString("pkgid");

                    Bundle bundle = new Bundle();
                    bundle.putSerializable("ocr_image_list", imgList);
                    bundle.putSerializable("ocr_code_list", codeList);
                    bundle.putSerializable("pkgid", pkgid);
                    ocrScannerFragment.setArguments(bundle);
                }

                baseActivity.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container, ocrScannerFragment)
                        .commit();
                break;

            case R.id.finishedBT:
                if (imgList.isEmpty()) {
                    showToast("Scan Package ID");
                } else if (codeList.isEmpty()) {
                    showToast("Scan Package ID");
                } else {
                    baseActivity.startProgressDialog();
                    hitPackageUploadApi();
                }
                break;
        }
    }

    private void hitPackageUploadApi() {
        String unique_id = baseActivity.prefStore.getString("unique_id");
        if (pkgIdList != null) {
            JSONArray jsArray = new JSONArray(pkgIdList);
            RequestParams params = new RequestParams();
            params.put("customer_pkg_id", jsArray);
            params.put("partner", unique_id);

            log("pkgid " + pkgid);
            log("qr_code " + jsArray);
            log("partner " + unique_id);

            for (int i = 0; i < imgList.size(); i++) {
                Bitmap bitmap = ImageUtils.imageCompress(imgList.get(i));
                File file = ImageUtils.bitmapToFile(bitmap, baseActivity);
                try {
                    params.put("image[" + i + "]", file);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }

            syncManager.sendToServer(Const.PACKAGE_UPLOAD + baseActivity.store.getString("user_id"), params, this);
        }
    }

    @Override
    public void onImageScanned(String param, String imageData, ArrayList<String> imageList) {
        if (param.equals("ocr_text")) {
            baseActivity.scanned_data = imageData;
        } else if (param.equals("bar_code")) {
            bar_code = imageData;
            if (!codeList.contains(bar_code)) {
                codeList.add(bar_code);
            }
        }

        if (!imageList.isEmpty()) {
            for (int i = 0; i < imageList.size(); i++) {
                String imagePath = imageList.get(i);
                if (!imgList.contains(imagePath)) {
                    imgList.add(imagePath);
                }
            }
            setadapter();
        }
    }

    private void setadapter() {
        AdditionalPackagesAdapter additionalPackagesAdapter = new AdditionalPackagesAdapter(baseActivity, imgList, 0, codeList, "AdditionalPackages", this);
        scannedImagesRV.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        scannedImagesRV.setAdapter(additionalPackagesAdapter);
        scannedImagesRV.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public void permGranted(int resultCode) {

    }

    @Override
    public void permDenied(int resultCode) {

    }

    @Override
    public void onSyncSuccess(String controller, String action, boolean status, JSONObject jsonObject) {
        super.onSyncSuccess(controller, action, status, jsonObject);

        try {
            if (jsonObject.getString("url").contains(Const.PACKAGE_UPLOAD)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    hitMessageApi(data);
                } else {
                    errorMessage(jsonObject);
                }
            } else if (jsonObject.getString("url").contains(Const.CONFIRM_PACKAGE_SEND_MESSAGE)) {
                if (jsonObject.getInt("status") == Const.STATUS_OK) {
                    showToast("Package uploaded successfully");

                    bar_code = null;
                    codeList.clear();
                    imgList.clear();

                    HomeFragment ocrScannerFragment = new HomeFragment();
                    baseActivity.getSupportFragmentManager().beginTransaction()
                            .replace(R.id.container, ocrScannerFragment)
                            .addToBackStack(null)
                            .commit();
                } else {
                    errorMessage(jsonObject);

                    bar_code = null;
                    codeList.clear();
                    imgList.clear();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void hitMessageApi(JSONArray data) {
        RequestParams params = new RequestParams();
        params.put("data", data);
        String user_id = baseActivity.store.getString("user_id");
        syncManager.sendToServer(Const.CONFIRM_PACKAGE_SEND_MESSAGE + user_id, params, this);
    }

}
