package com.toxsl.volley;

/**
 * Created by TOXSL\ankush.walia on 3/2/17.
 */

public class AppExpiredError extends VolleyError {
    public AppExpiredError(String message) {
        super(message);
    }
}
