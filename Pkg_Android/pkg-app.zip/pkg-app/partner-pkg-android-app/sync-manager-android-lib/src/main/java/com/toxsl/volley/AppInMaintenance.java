package com.toxsl.volley;

/**
 * Created by TOXSL\ankush.walia on 6/2/17.
 */

public class AppInMaintenance extends VolleyError {
    public AppInMaintenance(String message) {
        super(message);
    }
}
