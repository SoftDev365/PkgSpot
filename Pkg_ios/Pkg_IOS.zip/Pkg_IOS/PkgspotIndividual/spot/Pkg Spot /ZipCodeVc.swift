//
//  ZipCodeVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 15/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

protocol ZipCodeDelegate {
    func getZipCode(zipcode: LocationModel)
}

var zipCodeDelegateObj : ZipCodeDelegate?

class ZipCodeVc: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableViewZipCode: UITableView!
    var arrZipCode = [LocationModel]()
    //var partnerLocation = PartnerDropeDownModel()
     var strURL = ""
     var comeTO = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if !(partnerAdressLocation.latitude == "") || !(partnerAdressLocation.longitude == "") {
            self.takeZipcode(latitude: partnerAdressLocation.latitude, longitude: partnerAdressLocation.longitude)
        }else {
            self.takeZipcode(latitude: "37.773972", longitude: "-122.431297")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrZipCode.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = arrZipCode[indexPath.row].zipCode
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // zipCodeDelegateObj?.getZipCode(zipcode: arrZipCode[indexPath.row])
        
        zipCodeDelegateObj?.getZipCode(zipcode: arrZipCode[indexPath.row])
        locationModel = arrZipCode[indexPath.row]
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }

    
    @IBAction func btnActionBack(_ sender: Any) {
       self.dismiss(animated: true, completion: nil)
    }
    
    func takeZipcode(latitude: String, longitude: String) {
        let param = [
         "lat":  latitude,
         "lng" : longitude,
        ] as [String:AnyObject]
            arrZipCode.removeAll()
        let creatAccount = "\(KServerUrl)\(kZipCode)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
            
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.arrZipCode.removeAll()
                                self.serviceResponse(lat:latitude, long:longitude, JSON: JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Server: Not responding ")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(lat: String,long: String, JSON:NSMutableDictionary){
        KAppDelegate.hideActivityIndicator()
          self.arrZipCode.removeAll()
        if (JSON["url"]! as AnyObject).isEqual ("\(kZipCode)") {
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSArray {
                    for i in 0..<data.count {
                        if  let dictData = data.object(at: i) as? NSDictionary{
                            let partnerLocation =  LocationModel()
                            let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
                            partnerLocation.setUserLocation(dictDetail: mutatedDic)
                            self.arrZipCode.append(partnerLocation)
                            
                        partnerLocation.latitude = lat
                        partnerLocation.longitude = long
                        }
                    }
                    
                    self.tableViewZipCode.delegate = self
                    self.tableViewZipCode.dataSource = self
                    self.tableViewZipCode.reloadData()

            
                }
              }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
    }

       
}
