

import UIKit

class TableViewCellSortPkg: UITableViewCell {
    
    // MARK:- OUTLETS
    @IBOutlet weak var lblDateRec: UILabel!
    @IBOutlet weak var lblCustomerName: UILabel!
    @IBOutlet weak var lblCustomerNumb: UILabel!
    @IBOutlet weak var lblPickUp: UILabel!
    @IBOutlet weak var lblPackagesCount: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnPackageImages: UIButton!
    @IBOutlet weak var btnPackageBilling: UIButton!
}
