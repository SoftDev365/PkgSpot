//
//  proxy.swift
//  Taxi Now
//
//  Created by Toxsl on 24/12/15.
//  Copyright © 2015 ToXSL Technologies Pvt. Ltd. All rights reserved.
//

import UIKit
import Alamofire
var KAppDelegate = UIApplication.shared.delegate as! AppDelegate

var shareInstance:proxy = proxy()

let  KMode = "development"
let  KAppName = "PkgSpot"
let  KVersion =  "1.0"
let usewrAgent = "\(KMode)" + "\(KAppName)"



//let KServerUrl = "http://192.168.2.26:3040"
let KServerUrl = "http://34.230.87.240"
let KLogin = "/api/user/login"
let KSignup =  "/api/user/customer"
let KVerifyOtp = "/api/user/customer-step2"
let KPartnerLocation = "/api/user/plocation"
let KUserLocation  =  "/api/user/customer-step3"
let KUserCard  =   "/api/user/add-card/"
let completSignUp = "/api/user/signup-complete/"
let userProfile = "/api/user/profile/"
let userInfo = "/api/user/info/"
let KLogout = "/api/user/logout"
let KUserCheck =  "/api/user/check"
let kPayment = ""
let kUserCancel = ""
let KAddNewCard = "/api/user/card-detail/"

//Mark : userLogin Api
let KMyAccount = "/api/user/profile/"
let googleBaseURL = "https://maps.googleapis.com/maps/api/"
let KUserUpate = "/api/user/customer-update/"
let KChangePassword = "/api/user/change-password"
let KHelpPage  = "/api/user/help-page"
let KChangeEmail = "/api/user/upadte-email/"
let KGetCardDetial = "/api/user/get-card-detail/"
let KRemoveCardDetials = "/api/user/remove-card"
let KForgotPassword = "/api/user/forgot-password"
let kOtpVerify = "/api/user/confirm-otp"
let KPrivacyPolicy = "/api/partner/terms/"
let KPackageIndex = "/api/package/index/"
let KUpDateCreditCard = "/api/user/update-card/"
let kZipCode = "/api/user/partner-zipcode"
let KUserCity = "/api/user/city"
let KupdateLocation = "/api/user/location/"
let KMylocation = "/api/user/my-location"
let changeMobileNumber = "/api/user/change-number/"
let createAccountDetial = "/api/user/amount-detail"
let getInfo = "/api/package/message-detail"
let packageFilterDate = "/api/package/filter/"
let packageImageBilling = "/api/package/download/"


//MARK: - USER DEFAULT
let kUserName = "user_name"
let kAccountName = "unique_id"
let kPassword = "pass_word"

let reachability = Reachability()
// MARK: - Protocol

@objc protocol WebServiceDelegate
{
    func retryMethod(_ paramsDic:Dictionary<String,AnyObject>, withServiceUrl:NSString, error:NSError?)
}

var delegateObject: WebServiceDelegate?

class proxy: NSObject {
    
    // MARK: - Class Variables
    
    class func sharedProxy() -> proxy {
        
        shareInstance = proxy()
        return shareInstance
    }
    
    
    
    func checkStringIfNull(_ content: String) -> String {
        if ((content == "null")) || ((content == "(null)")) || ((content == "<null>")) || ((content == "nil")) || ((content == "")) || ((content == "<nil>")) || (content.characters.count == 0){
            return ""
        }
        else {
            return content
        }
    }
    
    func authNil () -> String
    {
        if(UserDefaults.standard.object(forKey: "auth_code") == nil){
            return ""
        }
        else{
            return String(describing: UserDefaults.standard.object(forKey: "auth_code") as AnyObject)
        }
    }
    
    func expiryDateCheckMethod(_ expiryDate: String)->Bool  {
        let DateInFormat = DateFormatter()
        DateInFormat.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        DateInFormat.dateFormat = "yyyy-MM-dd"
        let expiryDate = DateInFormat.date(from: expiryDate)
        
        let f:DateFormatter = DateFormatter()
        f.timeZone = NSTimeZone.local
        f.dateFormat = "yyyy-MM-dd"
        
        let now = f.string(from: NSDate() as Date)
        let currentDate = f.date(from: now)
        let offsetTime = NSTimeZone.local.secondsFromGMT()
        let finalTime = currentDate!.addingTimeInterval(TimeInterval(offsetTime))
        
        if finalTime.compare(expiryDate!) == ComparisonResult.orderedDescending {
            return false
        } else if currentDate!.compare(expiryDate!) == ComparisonResult.orderedAscending  {
            return true
        } else{
            return true
        }
    }
    
    //Mark:- check email
    
    func isValidEmail(_ testStr:String) -> Bool
    {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let range = testStr.range(of: emailRegEx, options:.regularExpression)
        let result = range != nil ? true : false
        return result
    }
    
    
    
    
    func getDateFormat(_ dateStr: String) -> String {
        let formattr = DateFormatter()
        formattr.dateFormat = "YYYY-MM-dd HH:mm:ss"
        let dt = formattr.date(from: dateStr)
        formattr.dateFormat = "hh:mm a"
        if dt != nil {
            return formattr.string(from: dt!)
        }else {
            proxy.sharedProxy().displayStatusCodeAlert("Date format is wrong")
            return ""
        }
    }
    
    //MARK: - check password
    
    func isValidPassword(_ testStr:String) -> Bool
    {
         let alphaBaticLetterRegEx = ".*[A-Z]+.*"
         let texttest4 = NSPredicate(format:"SELF MATCHES %@", alphaBaticLetterRegEx)
         let capitalResult = texttest4.evaluate(with: testStr)
        
        let capitalLetterRegEx  = ".*[A-Za-z]+.*"
        let texttest = NSPredicate(format:"SELF MATCHES %@", capitalLetterRegEx)
        let capitalresult = texttest.evaluate(with: testStr)
        
        let numberRegEx  = ".*[0-9]+.*"
        let texttest1 = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        let numberresult = texttest1.evaluate(with: testStr)
        
        //        let specialCharacterRegEx  = ".*[!&^%$#@()/]+.*"
        //        let texttest2 = NSPredicate(format:"SELF MATCHES %@", specialCharacterRegEx)
        //
        //        let specialresult = texttest2.evaluate(with: testStr)
        
        let eightRegEx  = ".{6,}"
        let texttest3 = NSPredicate(format:"SELF MATCHES %@", eightRegEx)
        let eightresult = texttest3.evaluate(with: testStr)
        return  capitalResult && capitalresult && numberresult && eightresult
        
    }
    
    
    
    func isValidInput(_ Input:String) -> Bool {
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ ")
            // string contains non-whitespace characters
     
        if Input.rangeOfCharacter(from: characterset.inverted) != nil {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Name ")
            return false
            
        }
         else {
            return true
        }
    }
    
    
    // MARK: - Error Handling
    func stautsHandler(_ url:String, parameter:Dictionary<String,AnyObject>? = nil, response:HTTPURLResponse?, data:Data?, error:NSError?)
    {
        if response != nil  {
            if  response?.statusCode == 400
            {
                displayStatusCodeAlert("bad url")
            }
            else if response?.statusCode == 401
            {
                displayStatusCodeAlert("unauthorized")
            }
            else if response?.statusCode == 403
            {
                UserDefaults.standard.set("", forKey: "auth_code")
                UserDefaults.standard.synchronize()
                displayStatusCodeAlert("session not found")
                KAppDelegate.gotoSelectionVC()
            }
            else if response?.statusCode == 404
            {
                displayStatusCodeAlert("file not found")
            }
            else if response?.statusCode ==  500
            {
                //                proxy.sharedProxy().displayStatusCodeAlert("Server Error")
                
                proxy.sharedProxy().displayStatusCodeAlert(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String)
                
                
            }
                
            else if response?.statusCode == 408
            {
                RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            else if error?.code == -1001
            {
                RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            else if error?.code == -1009
            {
                RequestTimeOutAlertMessage("\(error?.localizedDescription)" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            
        }else {
            proxy.sharedProxy().displayStatusCodeAlert("Network Error")
        }
    }
    
    func displayStatusCodeAlert(_ userMessage: String)
    {
        UIView.hr_setToastThemeColor(appColor)
        KAppDelegate.window!.makeToast(message: userMessage)
    }
    
    
    func openSettingApp()
    {
        var settingAlert = UIAlertController()
        DispatchQueue.main.async
            {
                settingAlert = UIAlertController(title: "Connection Problem", message: "Please check your internet connection", preferredStyle: UIAlertControllerStyle.alert)
                
                let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
                settingAlert.addAction(okAction)
                
                
                let openSetting = UIAlertAction(title:"Setting", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                    
                    UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
                    
                })
                
                settingAlert.addAction(openSetting)
                
                UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
                
        }
    }
    
    
    func RequestTimeOutAlertMessage(_ alrtMessage:NSString, Url:String, Parameter:Dictionary<String, AnyObject>? = nil, Response: HTTPURLResponse? , data: Data? , Error:NSError?)
    {
        
        if (Parameter!.count) > 0
        {
            
            var timeOutAlert = UIAlertController()
            
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title:"Cancel", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                
                delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
                
            })
            
            timeOutAlert.addAction(retryAction)
            
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
            
        }
        else
        {
            DispatchQueue.main.async
                {
                    
                    var timeOutAlert = UIAlertController()
                    
                    timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
                    
                    let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: nil)
                    timeOutAlert.addAction(okAction)
                    
                    let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                        
                        delegateObject?.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
                        
                    })
                    
                    timeOutAlert.addAction(retryAction)
                    
                    UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
                    
            }
        }
    }
    
    
    //MARKK:- API Interaction
    func postData(_ urlStr: String, params: Dictionary<String, AnyObject>? = nil, showIndicator: Bool, completion: @escaping (_ response: NSMutableDictionary) -> Void) {
       
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
            request(urlStr, method: .post, parameters: params, encoding: URLEncoding.httpBody, headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                if let JSON = response.result.value as? NSDictionary {
                                    
                                    completion(JSON .mutableCopy() as! NSMutableDictionary)
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                        }
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func getData(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ responseDict: NSMutableDictionary) -> Void) {
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
          
            request(urlStr, method: .get, parameters: nil, encoding: JSONEncoding.default, headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                if let JSON = response.result.value as? NSDictionary {
                                    completion(JSON.mutableCopy() as! NSMutableDictionary)
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                        }
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    
    func getDataHandler(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ responseDict: NSMutableDictionary) -> Void,failure: @escaping (_ error: NSError) -> Void){
        
        //        debug  print"URL RESPONSE:", urlStr)
        //
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
            
            request(urlStr, method: .get, parameters: nil, encoding: JSONEncoding.default, headers:["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                KAppDelegate.hideActivityIndicator()
                                if let JSON = response.result.value as? NSDictionary {
                                    completion(JSON.mutableCopy() as! NSMutableDictionary)
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                            failure(response.result.error! as NSError)
                        }
                    }catch {
                    failure(error as NSError)
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    func getDataFromGoogle(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ responseDict: NSMutableDictionary) -> Void) {
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
           
            request(urlStr, method: .get, parameters: nil, encoding: JSONEncoding.default, headers:nil)
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                if let JSON = response.result.value as? NSDictionary {
                                    completion(JSON.mutableCopy() as! NSMutableDictionary)
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                // proxy.sharedProxy().statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            // proxy.sharedProxy().displayStatusCodeAlert("Error: Unable to get response from server")
                        }
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    
    
    // MARK: - Error Handling
    func statusHandler(_ response:HTTPURLResponse?, error:NSError?) {
        if let code = response?.statusCode {
            switch code {
            case 400:
                displayStatusCodeAlert("Please heck the URL : 400")
            case 401:
                displayStatusCodeAlert("Unauthorized to perform this action : 401")
            case 403:
                UserDefaults.standard.set("", forKey: "auth_code")
                UserDefaults.standard.synchronize()
                KAppDelegate.gotoSelectionVC()
            case 404:
                displayStatusCodeAlert("URL does not exists : 404")
            case 500:
                displayStatusCodeAlert("Status code 500 : Server error")
            case 408:
                displayStatusCodeAlert("Server error, Please try again..")
            default:
                displayStatusCodeAlert("Server error, Please try again..")
            }
        } else {
            displayStatusCodeAlert("Server error, Please try again..")
        }
        
        if let errorCode = error?.code {
            switch errorCode {
            default:
                displayStatusCodeAlert("Server error, Please try again..")
            }
        }
    }
    
}
extension String {
    
    func isEmpty() -> Bool{
        if self.trimmingCharacters(in: .whitespacesAndNewlines).characters.count > 0 {
            return false
        }
        return true
    }
    
}
