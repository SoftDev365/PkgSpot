//
//  MyPakagesVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 28/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class MyPakagesVC: UIViewController,CalenderVCDelegate{
    
    @IBOutlet weak var txtFldPackagesCount: UITextField!
    @IBOutlet weak var txtFldPickupTime: UITextField!
    @IBOutlet weak var txtFldPackageReceivedTime: UITextField!
    @IBOutlet weak var btnBlueLine: SetCornerButton!
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var lblShowDate: UILabel!
    @IBOutlet weak var lblPackageAddress: UILabel!
    @IBOutlet weak var pkgMsgUiview: UIView!
    @IBOutlet weak var myPackageStackView: UIStackView!
    @IBOutlet weak var lblMsgShow: UILabel!
    
    var strURL = ""
    var recivedDate = String()
    var packageCount = String()
    override func viewDidLoad() {
        super.viewDidLoad()
         lblMsgShow.isHidden = true
        //lblUserName.text = userProperProfileModel.fullName
       // lblAccountNumber.text = "Account  \(userProperProfileModel.accountNumber)"
       // lblPackageAddress.text = "Package Address"
        self.navigationController?.isNavigationBarHidden = true
        delegate1 = self
      
        strURL = ("\(KServerUrl)\(KPackageIndex)\(profileModel.id)")
        KpackageIndex(strURL: strURL, param: nil)

    }
    
    //Mark: Delegate func
    func datecustomDelegate(date: String) {
    lblShowDate.text = date

    }
   //Mark: - BtnAction
  @IBAction func btnDrawerAction(_ sender: Any) {
    KAppDelegate.sideMenuVC.openLeft()
  }
   @IBAction func btnCalenderAction(_ sender: Any) {
    let calenderVC = storyboard?.instantiateViewController(withIdentifier: "CalenderVC") as! CalenderVC
    self.navigationController?.pushViewController(calenderVC, animated: false)
  }
    
      override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func KpackageIndex(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let arrayDes = responseDict["data"] as? NSArray {
                   let getDic = arrayDes[0] as! NSDictionary
                    if let recived_date = getDic["recived_date"] as? String{
                        self.recivedDate = recived_date
                   }
                    if let package_count = getDic["package_count"] as? String{
                        self.packageCount  = package_count
                    }
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat =  "yyyy-MM-dd"
                    let date = dateFormatter.date(from: self.recivedDate)
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    self.lblShowDate.text = dateFormatter.string(from: date!)
                    self.txtFldPackagesCount.text = self.packageCount

               }
                
            }
            else{
                 self.myPackageStackView.isHidden = true
                self.btnBlueLine.isHidden = true
                self.lblMsgShow.isHidden = false
                
                
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KpackageIndex(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
}
  extension MyPakagesVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {

    }
    
    func leftDidOpen() {

    }
    
    func leftWillClose() {

    }
    
    func leftDidClose() {

    }
    
    func rightWillOpen() {
     
    }
    
    func rightDidOpen() {

    }
    
    func rightWillClose() {
   
    }
    
    func rightDidClose() {

    }

}
