//
//  LoginVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 21/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift

class LoginVc: UIViewController {

    @IBOutlet weak var txt_Fld_Email: UITextField!
    @IBOutlet weak var txt_Fld_Password: UITextField!
    @IBOutlet weak var ScrollViewOutlet: UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       ScrollViewOutlet.bounces = false
        txt_Fld_Email.attributedPlaceholder = NSAttributedString(string: "Your Email Address", attributes: [NSForegroundColorAttributeName: UIColor.gray
            ])
        txt_Fld_Password.attributedPlaceholder = NSAttributedString(string: "Your Password", attributes: [NSForegroundColorAttributeName: UIColor.gray])
       
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    

    @IBAction func btnBack(_ sender: Any) {
        KAppDelegate.gotoSelectionVC()
        
    }
    
    
    @IBAction func btnForgotPasswordAction(_ sender: Any) {
        let gotoForgotPasswordVc = self.storyboard?.instantiateViewController(withIdentifier:"ForgotPasswordVc") as! ForgotPasswordVc
        self.navigationController?.pushViewController(gotoForgotPasswordVc,animated: true)
    }
    
    
    @IBAction func btnActionNextorLogin(_ sender: UIButton) {
        signIn()
    }
    
    
    func signIn() {
        
        if txt_Fld_Email.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email Address")
            return
        } else if proxy.sharedProxy().isValidEmail(txt_Fld_Email.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email")
            return
        } else if txt_Fld_Password.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
            return
        }
        else {
            var deviceTokken =  ""
            if UserDefaults.standard.object(forKey: "device_token") == nil {
                deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
            } else {
                deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
            }
            let param = [
                "email": "\(txt_Fld_Email.text!)" ,
                "password": "\(txt_Fld_Password.text!)" ,
                "device_token": "\(deviceTokken)",
                "type":"2"
            ]
            
            let loginInUrl = "\(KServerUrl)" + "\(KLogin)"
             
            if  reachability?.isReachable  == true {
                KAppDelegate.showActivityIndicator()
                request(loginInUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                    .responseJSON { response in
                        let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                  
                        do
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                KAppDelegate.hideActivityIndicator()
                                if response.response?.statusCode == 200 {
                                    self.serviceResponse(JSONDIC)
                          
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(loginInUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Server: Not responding")
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
            }
        }
    }
    // MARK: - Get Api Response 
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KLogin) {
    
            if (JSON["status"]! as AnyObject).isEqual(200) {
                let authcode = ((JSON.value(forKey: "auth_code")!)) as! String
                UserDefaults.standard.set(authcode, forKey: "auth_code")
                if  let data = JSON["data"] as? NSArray {
                    if let dictData = data[0] as? NSDictionary {
                        IQKeyboardManager.sharedManager().resignFirstResponder()
                        UserDefaults.standard.set(dictData.object(forKey: "full_name") as! String, forKey: kUserName)
                        UserDefaults.standard.set(dictData.object(forKey: "unique_id") as! String, forKey: kAccountName)
                         UserDefaults.standard.set(txt_Fld_Password.text!, forKey: kPassword)
                        UserDefaults.standard.synchronize()
                        let id = JSON.value(forKey: "userId")! as? Int32
                        profileModel.id = id!
                        profileModel.password = txt_Fld_Password.text!
                        KAppDelegate.gotoMyPackagesScreen()
                    }
                }
            }else{
                if let errorMessage = JSON["error"] {
                    if let userid = JSON["userId"] as? Int{
                        profileModel.id = Int32(userid)
                    }else{

                        if  proxy.sharedProxy().checkStringIfNull(JSON["userId"] as! String).characters.count > 0 {
                            profileModel.id = Int32(JSON["userId"] as! String)!
                        }
                    }
                    if profileModel.id == 0 {
                        proxy.sharedProxy().displayStatusCodeAlert("Error: User not found!")
                        
                    }else{
                        if  let steps = JSON.object(forKey: "step") as? Int{
                            switch steps{
                            case 0:
                                KAppDelegate.gotoMyLocationViewController()
                                let mainNav = KAppDelegate.sideMenuVC.mainViewController as! UINavigationController
                                let createVC = self.storyboard?.instantiateViewController(withIdentifier: "CongratulationsVC") as! CongratulationsVC
                                mainNav.pushViewController(createVC, animated: false)
                                break
                            case 1:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "AddYourphoneNumberVc") as! AddYourphoneNumberVc
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 2:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 3:
                                let createVC = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountVC") as! CreateAccountVC
                                self.navigationController?.pushViewController(createVC, animated: false)
                                break
                            default:
                                
                                break
                            }
                        }
                        
                    }
                    
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }

            }
        }
     
}
   
}


extension LoginVc : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
}



