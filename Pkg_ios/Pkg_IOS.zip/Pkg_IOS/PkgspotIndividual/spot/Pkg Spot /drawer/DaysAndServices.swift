
import Foundation

var DaysAndServices = DaysAndService()

class DaysAndService {
    
    var day = NSDictionary()
    var starttime = String()
    var endtime = String()
    var dayKey = Int()
    let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

    
    var dayOfService = NSArray()
    
    func userData(dictDetail: NSDictionary, index: Int){
        
         dayKey = index
        
        if let day = dictDetail[arrDay[dayKey]] as? NSDictionary{
            self.day = day
            
            if let starttime = day["start_time"] as? String{
                self.starttime = starttime
            }
            if let endtime = day["end_time"] as? String{
                self.endtime = endtime
            }
        }
    }
}
