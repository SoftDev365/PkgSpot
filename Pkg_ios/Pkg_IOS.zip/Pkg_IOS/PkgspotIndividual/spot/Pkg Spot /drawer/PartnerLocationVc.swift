//
//  PartnerLocationVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 27/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

protocol PartnerLocationDelegate {
    func getPartnerLocation(partnerAdress: PartnerDropeDownModel)
}

var partnerLocationDelegateObj : PartnerLocationDelegate?

class PartnerLocationVc: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tblvwPartnerAdress: UITableView!
    
    var arrPartnerLocation = [PartnerDropeDownModel]()
    var strURL = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        strURL = "\(KServerUrl)\(KUserCity)"
        KUsercity(strURL: strURL, param: nil)
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPartnerLocation.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = arrPartnerLocation[indexPath.row].city
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //zipCodeDelegateObj?.getZipCode(zipcode: arrZipCode[indexPath.row])
        partnerLocationDelegateObj?.getPartnerLocation(partnerAdress: arrPartnerLocation[indexPath.row])
        partnerAdressLocation = arrPartnerLocation[indexPath.row]
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func KUsercity(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if  let data = responseDict["data"] as? NSArray {
                    for i in 0..<data.count {
                        if let dic = data[i] as? NSDictionary {
                            let mutatedDic = dic.mutableCopy() as! NSMutableDictionary
                            let partnerLocation =  PartnerDropeDownModel()
                            partnerLocation.setUserPartnerAdress(dictDetail: mutatedDic)
                            
                            if let latitude = mutatedDic["latitude"] as? String,  let longitude = mutatedDic["longitude"] as? String{
                                if  proxy.sharedProxy().checkStringIfNull(latitude).characters.count > 0 &&   proxy.sharedProxy().checkStringIfNull(longitude).characters.count > 0{
                                    self.arrPartnerLocation.append(partnerLocation)
                                    self.tblvwPartnerAdress.delegate = self
                                    self.tblvwPartnerAdress.dataSource = self
                                    self.tblvwPartnerAdress.reloadData()

                                }
                               
                            }
                            
                        
                        }
                    }
                }
            }
            else{
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KUsercity(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    
}

