
import UIKit

class MyStorePackagesVC: UIViewController,UITableViewDelegate,UITableViewDataSource,CalanderDateSelectedDelegate {
   
    //MARK:- OUTLETS
    @IBOutlet weak var lblSortPkg: UILabel!
    @IBOutlet weak var tblView: UITableView!
    var strURL = ""
    var arrayPackages = [RecievedPackageModel]()
    var selectedDateArray = NSMutableArray()
    
    @IBOutlet weak var vwNoPackage: UIView!
      override func viewDidLoad() {
        self.navigationController?.isNavigationBarHidden = true
        tblView.dataSource = self
        tblView.delegate = self
        tblView.reloadData()
        tblView.rowHeight = UITableViewAutomaticDimension
        tblView.estimatedRowHeight = 50
        protocolCalender = self

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        strURL = ("\(KServerUrl)\(KPackageIndex)\(profileModel.id)")
        KpackageIndex(strURL: strURL, param: nil)
    }
    
    func calanderDateSelected(arrReceived: [RecievedPackageModel]){
        if arrReceived.count > 0 {
            self.arrayPackages = arrReceived
        }
        tblView.reloadData()

    }
    
    //MARK:- TABLE VIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayPackages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCellSortPkg
         cell.lblDateRec.text = arrayPackages[indexPath.row].recived_date
         cell.lblTime.text = arrayPackages[indexPath.row].recived_time
         let packageCounts = (arrayPackages[indexPath.row].package_count)
         cell.lblPackagesCount.text = "\(packageCounts)"
         let  adress = arrayPackages[indexPath.row].address
         let city = arrayPackages[indexPath.row].city
         let zipCode = arrayPackages[indexPath.row].zipcode
         let state = arrayPackages[indexPath.row].state
         cell.lblCustomerName.text = "\(adress)\n\(city)\n\(state)\n\(zipCode)"
         cell.btnPackageImages.tag = indexPath.row
         cell.btnPackageBilling.tag = indexPath.row
         cell.lblPickUp.text = arrayPackages[indexPath.row].pickUpTime
         return cell
    }
    
    @IBAction func btnActionPackageImages(_ sender: Any) {
        
        let index = (sender as AnyObject).tag
         let modal = arrayPackages[index!]
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"PackageImagesViewController") as! PackageImagesViewController
        signup.packageImages = modal.images
        signup.comeFrom = "PackageImages"
        self.present(signup, animated: true)
        
        
    }
    
    @IBAction func btnActionPackageBilings(_ sender: Any) {
        let index = (sender as AnyObject).tag
        let modal = arrayPackages[index!]
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"PackageImagesViewController") as! PackageImagesViewController
        signup.packageId = modal.id
        self.present(signup, animated: true)

    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }

    
    
    //MARK:- BUTTON ACTION
    @IBAction func btnActionDrop(_ sender: Any) {
      KAppDelegate.sideMenuVC.openLeft()
    }
    
    @IBAction func btnActionSortPkg(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"MyStorePkgCalanderViewController") as! MyStorePkgCalanderViewController
        signup.dateSecectArray = selectedDateArray
        self.navigationController?.present(signup, animated: true)

    }
    
    func KpackageIndex(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if  let data = responseDict["data"] as? NSArray {
                    for i in 0..<data.count {
                        let dic = data[i] as? NSDictionary
                        let packageDetials = RecievedPackageModel()
                        let mutatedDic = dic?.mutableCopy() as! NSMutableDictionary
                        packageDetials.setUserPackageDetial(dictDetail: mutatedDic)
                        self.arrayPackages.append(packageDetials)
                        
                        let dates = (data.object(at: i) as! NSDictionary).value(forKey: "recived_date") as! String
                        self.selectedDateArray.add(dates)
                    }
                    if self.arrayPackages.count > 0{
                        self.vwNoPackage.isHidden = true
                    }
                   self.tblView.reloadData()
                }
            }
            else{
                
                
            }
        })
            
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KpackageIndex(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    

 }
extension MyStorePackagesVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        
    }
    
    func leftDidOpen() {
        
    }
    
    func leftWillClose() {
        
    }
    
    func leftDidClose() {
        
    }
    
    func rightWillOpen() {
        
    }
    
    func rightDidOpen() {
        
    }
    
    func rightWillClose() {
        
    }
    
    func rightDidClose() {
        
    }
    
}


