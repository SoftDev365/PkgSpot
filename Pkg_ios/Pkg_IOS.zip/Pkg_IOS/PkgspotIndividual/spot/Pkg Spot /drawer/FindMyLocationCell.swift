//
//  FindMyLocationCell.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class FindMyLocationCell: UITableViewCell {

    @IBOutlet weak var lblSelection: UILabel!
  
  @IBOutlet weak var btnSelect: UIButton!
  @IBOutlet weak var btnLocationDetail: UIButton!
  @IBOutlet weak var lblLocationName: UILabel!
  @IBOutlet weak var lblCompanyName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
