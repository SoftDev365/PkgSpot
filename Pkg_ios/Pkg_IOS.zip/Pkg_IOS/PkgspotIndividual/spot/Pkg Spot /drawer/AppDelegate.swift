                                                          //
//  AppDelegate.swift
//  drawer
//
//  Created by Tajinder Singh on 23/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import SWRevealViewController
import IQKeyboardManagerSwift
import Alamofire
//import SwiftSpinner
import UserNotifications
import Kingfisher
import Firebase
import SwiftSpinner
import Stripe


var appColor = UIColor(colorLiteralRed: 23/255, green: 153/255, blue: 243/255, alpha: 1.0)

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,UNUserNotificationCenterDelegate,SWRevealViewControllerDelegate {
    var didStartFromNotification = Bool()
    
    var window: UIWindow?
    var sideMenuVC = SlideMenuController()
    var viewController: SWRevealViewController!
    var firstNavController = UINavigationController()
    var mainStoryBoard = UIStoryboard()
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    var window2: UIWindow?
    var splashView:UIImageView = UIImageView()
    var DrawerNavController = UINavigationController()
    var arrUserUpdateLocation = [UpdatePartnerLocation]()
    var networkOff = Bool()
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        STPPaymentConfiguration.shared().publishableKey = "pk_test_yxQ3QEFMkJK1xLAAIJb33mK3"
        // do any other necessary launch configuration
        
        application.applicationIconBadgeNumber = 0
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().removeAllDeliveredNotifications()
        } else {
            application.cancelAllLocalNotifications()
        }
        registerForPushNotifications(application: application)
        
        FirebaseApp.configure()
        
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true
        
       
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let blankController:UIViewController = UIViewController()
        firstNavController = UINavigationController.init(rootViewController: blankController)
        self.window!.rootViewController = firstNavController
        
        self.window!.makeKeyAndVisible()
        splashView.frame = CGRect(x: 0, y: 0, width: (self.window?.frame.width)!, height: (self.window?.frame.height)!)
        splashView.image = #imageLiteral(resourceName: "Splash")
        blankController.view .addSubview(splashView)
        self.window?.addSubview(splashView)
        
        var deviceTokken =  ""
        if UserDefaults.standard.object(forKey: "device_token") == nil {
            deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
        } else {
            deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
        }
        
        
        if proxy.sharedProxy().expiryDateCheckMethod("2018-1-30") {
            
            if ((UserDefaults.standard.object(forKey: "First")) != nil) {
                let authCode: String = proxy.sharedProxy().authNil()
                if((authCode == "" )) {
                    gotoSelectionVC()
                }
                else {
                    let contentUrl = "\(KServerUrl)\(KUserCheck)"
                     
                    if  reachability?.isReachable  == true {
                        networkOff = false
                        let locationManager = locationManagerClass.sharedLocationManager()
                        locationManager.startStandardUpdates()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                            locationManager.stopStandardUpdate()
                            
                        }
                        self.showActivityIndicator()
                        request("\(contentUrl)", method: .get, parameters: nil, encoding: URLEncoding.default,headers: ["device_token":"\(deviceTokken)","auth_code":"\(authCode)"] )
                            .responseJSON  { response in
                                if response.response != nil {
                                    self.hideActivityIndicator()
                                    if let JSON = response.result.value as? NSDictionary {
                                        
                                        if (JSON["status"]! as AnyObject).isEqual(200) {
                                            locationManagerClass.sharedLocationManager().startStandardUpdates()
                                     
                                            if let data = JSON["data"] as? NSArray
                                            {
                                                if let dictData = data[0] as? NSDictionary{
                                                    if let id = dictData["id"] as? Int32 {
                                                        if let custId = dictData["customer_id"] as?  String{
                                                        profileModel.setUserProfile(dictDetail: dictData .mutableCopy() as! NSMutableDictionary)
                                                        }
                                                    }
                                                }
                                            }
                                            self.gotoMyPackagesScreen()
                                            self.window!.makeKeyAndVisible()
                                            
                                        } else if (JSON["status"]! as AnyObject).isEqual(1000) {
                                            self.gotoSelectionVC()
                                            self.window!.makeKeyAndVisible()
                                            
                                        } else {
                                            self.hideActivityIndicator()
                                            proxy.sharedProxy().stautsHandler("\(contentUrl)"+"\(authCode)", response: response.response, data: response.data, error: response.result.error as NSError?)
                                        }
                                    }
                                    
                                }
                        }
                    }
                    else
                    {
                        networkOff = true
                 
                    }
                }
            } else {
                UserDefaults.standard.set("Yes", forKey:"First")
                UserDefaults.standard.synchronize()
                gotoSelectionVC()
            }
        } else {
      
        }
        return true
    }
    func gotoSelectionVC() {
        let viewControllerVC = storyBoard.instantiateViewController(withIdentifier:"SelectionVc") as! SelectionVc
      // let viewControllerVC = storyBoard.instantiateViewController(withIdentifier: "CongratulationsVC") as! CongratulationsVC
        firstNavController  = UINavigationController(rootViewController: viewControllerVC)
        firstNavController.isNavigationBarHidden = true
        self.window!.rootViewController = firstNavController
        self.window!.makeKeyAndVisible()
    }
    
    func goToLoginVC(){
        let loginVC = storyBoard.instantiateViewController(withIdentifier: "LoginVc") as! LoginVc
        firstNavController  = UINavigationController(rootViewController: loginVC)
        firstNavController.isNavigationBarHidden = true
        self.window!.rootViewController = firstNavController
        self.window!.makeKeyAndVisible()

    }
    
    func gotoMyAccountScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "MyAccountViewController") as! MyAccountViewController
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
    }
    
    func gotoMyPackagesScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier:"MyStorePackagesVC") as! MyStorePackagesVC
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
        
    }
    func FindMyLocation() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
        mainViewController.comeFrom = "Drawer"
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
       }
    
    func gotoHelpViewController()
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "HelpViewController") as! HelpViewController
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
       }
    
    func gotoMyLocationViewController()
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController as! SlideMenuControllerDelegate
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
        }
    
    
    
    func gotoChangePassword()
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "ChangePasswordScreen") as! ChangePasswordScreen
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController as! SlideMenuControllerDelegate
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
       }
    
    
    func gotoProfileVC()
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainViewController = storyboard.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        let sideViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController as! SlideMenuControllerDelegate
        sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
    }
    
    
    //MARK:- Activity Indicator Method
    func showActivityIndicator() {
        SwiftSpinner.show("Loading", animated: true)
    }
    
    func hideActivityIndicator() {
        SwiftSpinner.hide()
    }
    
    //MARK: - NOTIFICATION METHODS
    func registerForPushNotifications(application: UIApplication) {
        if #available(iOS 10.0, *){
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: {(granted, error) in
                if (granted) {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            })
        } else {
            let notificationSettings = UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil)
            application.registerUserNotificationSettings(notificationSettings)
        }
    }
    
    func registerForPushNotifications(_ application: UIApplication) {
        let notificationSettings = UIUserNotificationSettings(
            types: [.badge, .sound, .alert], categories: nil)
        application.registerUserNotificationSettings(notificationSettings)
    }
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        UIApplication.shared.registerForRemoteNotifications()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        UserDefaults.standard.set(tokenString, forKey: "device_token")
        UserDefaults.standard.synchronize()
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
            var deviceTokken =  ""
            if UserDefaults.standard.object(forKey: "device_token") == nil {
                deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
                 UserDefaults.standard.set(deviceTokken, forKey: "device_token")
            } else {
                deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
                 UserDefaults.standard.set("000000000000000000000000000000000000000000000000000000000000055", forKey: "device_token")
            }
        
        
            UserDefaults.standard.synchronize()
    }
    
    private func application(_ application: UIApplication,
                             didReceiveRemoteNotification notification: [AnyHashable : Any],
                             fetchCompletionHandler completionHandler: @escaping () -> Void) {
        if Auth.auth().canHandleNotification(notification) {
            completionHandler()
            return
        }
        // This notification is not auth related, developer should handle it.
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options: UNNotificationPresentationOptions) -> Void) {
        var userInfo = NSDictionary()
        userInfo = notification.request.content.userInfo as NSDictionary
        completionHandler([.sound, .alert])
        
        if didStartFromNotification != true {
            handleNotifications(userInfo: userInfo)
        }
     }
    
    
    func  handleNotifications(userInfo: NSDictionary) {
           let pay = userInfo as NSDictionary
           if (pay["action"]! as AnyObject).isEqual("pick-up")  && (pay["controller"]! as AnyObject).isEqual("bus") {
           let notificatinVCObj = self.storyBoard.instantiateViewController(withIdentifier: "QRCodeGeneratVc") as! QRCodeGeneratVc
            let navigationVC = sideMenuVC.mainViewController as! UINavigationController
                navigationVC.navigationController?.pushViewController(notificatinVCObj, animated: true)
        }
    }
    
          @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        var userInfo = NSDictionary()
        userInfo = response.notification.request.content.userInfo as NSDictionary
        
        if didStartFromNotification != true {
            handleNotifications(userInfo: userInfo)
        }
    }
    
    //MARK: - displayDateChaeckAlert
    func displayDateCheckAlert()
    {
        let alert: UIAlertView = UIAlertView(title: "Demo Expired", message: "Please contact the team", delegate: nil, cancelButtonTitle: "Ok")
        alert.show()
    }
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        let trackingId = url.absoluteString.replacingOccurrences(of: "pkgspot://", with: "")
        openQRCode(trackingId: trackingId)
       
        return true
    }

    func openQRCode(trackingId:String){
        let mainViewController = self.storyBoard.instantiateViewController(withIdentifier: "QRCodeGeneratVc") as! QRCodeGeneratVc
        mainViewController.qrCode = trackingId
        let sideViewController = self.storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        self.sideMenuVC = slideMenuController
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()

    }
    
    
    func applicationWillResignActive(_ application: UIApplication) {
 
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {

        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
      activeApp()
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
      func activeApp(){
        if networkOff
        {
            var deviceTokken =  ""
            if UserDefaults.standard.object(forKey: "device_token") == nil {
                deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
            } else {
                deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
            }
            
          
                
                if ((UserDefaults.standard.object(forKey: "First")) != nil) {
                    let authCode: String = proxy.sharedProxy().authNil()
                    if((authCode == "" )) {
                        gotoSelectionVC()
                    }
                    else {
                        let contentUrl = "\(KServerUrl)\(KUserCheck)"
                        
                        if  reachability?.isReachable  == true {
                            networkOff = false
                            let locationManager = locationManagerClass.sharedLocationManager()
                            locationManager.startStandardUpdates()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                                locationManager.stopStandardUpdate()
                                
                            }
                            
                            self.showActivityIndicator()
                            request("\(contentUrl)", method: .get, parameters: nil, encoding: URLEncoding.default,headers: ["device_token":"\(deviceTokken)","auth_code":"\(authCode)"] )
                                .responseJSON  { response in
                                    if response.response != nil {
                                        self.hideActivityIndicator()
                                        if let JSON = response.result.value as? NSDictionary {
                                            
                                            if (JSON["status"]! as AnyObject).isEqual(200) {
                                                locationManagerClass.sharedLocationManager().startStandardUpdates()
                                                
                                                if let data = JSON["data"] as? NSArray
                                                {
                                                    if let dictData = data[0] as? NSDictionary{
                                                        if let id = dictData["id"] as? Int32 {
                                                            if let custId = dictData["customer_id"] as?  String{
                                                                profileModel.setUserProfile(dictDetail: dictData .mutableCopy() as! NSMutableDictionary)
                                                            }
                                                        }
                                                    }
                                                }
                                                self.gotoMyPackagesScreen()
                                                self.window!.makeKeyAndVisible()
                                                
                                            } else if (JSON["status"]! as AnyObject).isEqual(1000) {
                                                self.gotoSelectionVC()
                                                self.window!.makeKeyAndVisible()
                                                
                                            } else {
                                                self.hideActivityIndicator()
                                                proxy.sharedProxy().stautsHandler("\(contentUrl)"+"\(authCode)", response: response.response, data: response.data, error: response.result.error as NSError?)
                                            }
                                        }
                                        
                                    }
                            }
                        }
                        else
                        {
                            networkOff = true
                        }
                    }
                } else {
                    UserDefaults.standard.set("Yes", forKey:"First")
                    UserDefaults.standard.synchronize()
                    gotoSelectionVC()
                }
            } else {
            
            }
            
        }
            
    }
    


