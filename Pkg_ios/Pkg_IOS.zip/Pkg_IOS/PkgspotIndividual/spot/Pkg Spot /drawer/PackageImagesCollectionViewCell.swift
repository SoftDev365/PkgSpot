//
//  PackageImagesCollectionViewCell.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 27/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class PackageImagesCollectionViewCell: UICollectionViewCell {
        
    @IBOutlet weak var imgVwPackages: UIImageView!
  
    
}
