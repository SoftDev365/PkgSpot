//
//  MyAccountViewController.swift
//  IndividualLoginMobile
//
//  Created by Rajat Duggal on 22/08/17.
//  Copyright © 2017 Rajat Duggal. All rights reserved.
//

import UIKit
import Alamofire
class MyAccountViewController: UIViewController ,ChangePasswordDelegate{
    
    //Mark:- OutletBtn
    @IBOutlet weak var btnEditemail: UIButton!
    @IBOutlet weak var btnEditMobile: UIButton!
    @IBOutlet weak var btnEditPassword: UIButton!
    @IBOutlet weak var btnEditPaymentInformation: UIButton!
    @IBOutlet weak var btnEditAddNewCard: UIButton!
    @IBOutlet weak var lblAccountNo: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserAddress: UILabel!
    @IBOutlet weak var lblAccountNumber: UILabel!
    @IBOutlet weak var txtFldFullName: UITextField!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldMobileNumber: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldPaymentInformation: UITextField!
   // @IBOutlet weak var txtFldAddNewCard: UITextField!
    
    //Mark:- Varriable 
    var count : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldPassword.text = ""
       // lblUserAddress.text = userAddressObj.address
        self.navigationController?.navigationBar.isHidden=true
        txtFldFullName.isUserInteractionEnabled = false
        txtFldEmail.isUserInteractionEnabled = false
        txtFldMobileNumber.isUserInteractionEnabled = false
        txtFldPassword.isUserInteractionEnabled = false
        txtFldPaymentInformation.isUserInteractionEnabled = false
        protocolChangePassword = self
        if let password = UserDefaults.standard.object(forKey: kPassword) as? String{
            txtFldPassword.text = password

        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getMyAccountDetail()
    }
    
    //MARK:- EditBtnAction
    
    @IBAction func actionEditEmailFullName(_ sender: Any) {
        let phoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        phoneNumberVc.openWith = "ProfileName"
        self.navigationController?.pushViewController(phoneNumberVc,animated: true)

        }
        
    @IBAction func btnEditMailAction(_ sender: Any) {
        let phoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(phoneNumberVc,animated: true)
    }
    
    
    
    @IBAction func actionEditMobileNumber(_ sender: Any) {
        
        let phoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "AddYourphoneNumberVc") as! AddYourphoneNumberVc
       phoneNumberVc.getId = 1
      
       self.navigationController?.pushViewController(phoneNumberVc,animated: true)
    }
    
    @IBAction func actionEditPassword(_ sender: Any) {
      let mainViewController = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordScreen") as! ChangePasswordScreen
        self.navigationController?.pushViewController(mainViewController, animated: true)
    }
    
    @IBAction func actionEditPaymentInformation(_ sender: Any) {
        
        let paymentInfoVc = self.storyboard?.instantiateViewController(withIdentifier: "PaymentInfoVc") as! PaymentInfoVc
        self.present(paymentInfoVc, animated: true, completion: nil)
        
    }
    
    @IBAction func actionAddNewCard(_ sender: Any) {
        
        let gotoAddCardVc = self.storyboard?.instantiateViewController(withIdentifier:"AddNewCardVC") as! AddNewCardVC
        self.navigationController?.pushViewController(gotoAddCardVc,animated: true)    
    }
    
  
  @IBAction func btnActionOpenDrawer(_ sender: UIButton) {
    KAppDelegate.sideMenuVC.openLeft()
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
  }
    //MARK:- MyAccount API
    
    func getMyAccountDetail() {
        let userId = profileModel.id
      
        let creatAccount = "\(KServerUrl)\(KMyAccount)\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
               
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponseMyAccount(JSONDIC)
                             
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponseMyAccount(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KMyAccount)\(profileModel.id)") {
             if JSON["status"] as! Int == 200 {
                // IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSArray
                {
                    let dic  = data[0] as? NSDictionary
                    userProperProfileModel.setUserAddress(dictDetail: dic?.mutableCopy() as! NSMutableDictionary)
                    txtFldEmail.text = userProperProfileModel.email
                    txtFldFullName.text = userProperProfileModel.fullName
                    txtFldMobileNumber.text = userProperProfileModel.contactNo
                    lblAccountNumber.text = userProperProfileModel.accountNumber
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
    
    func sendPassword(_ strPassword: String){
        self.txtFldPassword.text = strPassword
    }
    
    
}

extension MyAccountViewController : SlideMenuControllerDelegate {
    
    func leftWillOpen() {

    }
    
    func leftDidOpen() {
  
    }
    
    func leftWillClose() {
  
    }
    
    func leftDidClose() {

    }
    
    func rightWillOpen() {
 
    }
    
    func rightDidOpen() {

    }
    
    func rightWillClose() {
  
    }
    
    func rightDidClose() {

    }
}
