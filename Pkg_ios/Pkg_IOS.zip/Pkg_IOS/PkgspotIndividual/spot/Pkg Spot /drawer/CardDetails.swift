//
//  StripePaymentVC.swift
//  Unewride
//
//  Created by Ankit Pahwa on 11/08/16.
//  Copyright © 2016 Srishtipal Singh. All rights reserved.
//

import UIKit
import Stripe
import Alamofire
import IQKeyboardManagerSwift

class CardDetails: UIViewController ,WebServiceDelegate, UITextFieldDelegate,UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var cardViewCenter: NSLayoutConstraint!
    @IBOutlet weak var txtCVCNo: UITextField!
   
    @IBOutlet weak var txtCardNumber: UITextField!
    
    @IBOutlet weak var imgViewCardType: UIImageView!
    @IBOutlet weak var txtFldMonth: UITextField!
    @IBOutlet weak var txtFldYear: UITextField!
    
    @IBOutlet weak var viewCenter: UIView!
    @IBOutlet weak var btnOk: UIButton!
    
    var pickerString = String()
    var monthArray = Array(1...12)
    var yearArray = [Int]()
    var bookingId = String()
     var usecureFee = String()
     var invoiceId = String()
    var amount = Int()
    var pickerView = UIPickerView()
    var pickerVwYear = UIPickerView()
     var  paymentType = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        btnOk.layer.cornerRadius = 5
        btnOk.layer.masksToBounds = true
        
        viewCenter.layer.cornerRadius = 5
        viewCenter.layer.masksToBounds = true
        viewCenter.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        let date = Date()
        let calendar = Calendar.current
        let components = (calendar as NSCalendar).components([.day , .month , .year], from: date)
        let year =  components.year
        yearArray = Array(year!...year! + 32)

        txtFldYear.delegate = self
        txtFldMonth.delegate = self
        txtCVCNo.delegate = self
        txtCardNumber.delegate = self
    }

    @IBAction func btnPay(_ sender: AnyObject) {
        IQKeyboardManager.sharedManager().resignFirstResponder()
        let whitespaceSet = NSCharacterSet.whitespaces
        if txtCardNumber.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Card Number")
        } else if txtFldMonth.text!.isEmpty || txtFldYear.text!.isEmpty{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Exp. Date")
        } else if txtCVCNo.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter CVV")
        } else if txtCVCNo.text!.trimmingCharacters(in: whitespaceSet).characters.count != 3{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid CVV")
        }else {
            if txtCardNumber.text!.trimmingCharacters(in: whitespaceSet) != "" {
                let stripCard = STPCardParams()
                
                // Split the expiration date to extract Month & Year
                
                stripCard.number = self.txtCardNumber.text!.trimmingCharacters(in: whitespaceSet)
                stripCard.cvc = self.txtCVCNo.text!.trimmingCharacters(in: whitespaceSet)
                stripCard.expMonth = UInt(txtFldMonth.text!.trimmingCharacters(in: whitespaceSet))!
                stripCard.expYear = UInt(txtFldYear.text!.trimmingCharacters(in: whitespaceSet))!
                KAppDelegate.showActivityIndicator()
                
                STPAPIClient.shared().createToken(withCard: stripCard, completion: { (token, error) -> Void in
                    
                    if error != nil {
                        self.handleError(error! as NSError)
                        return
                    }
                    
                    self.postStripeToken(token!)
                })
            } else {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter valid card details")
            }
        }
    }
    
    func handleError(_ error: NSError) {
        KAppDelegate.hideActivityIndicator()
        UIAlertView(title: "Please Try Again",
                    message: error.localizedDescription,
                    delegate: nil,
                    cancelButtonTitle: "OK").show()
    }

    func postStripeToken(_ token: STPToken) {
          var URL = ""
         var params = NSDictionary()
       
         URL = "\(KServerUrl)\(kPayment)"
         params = [
            "Transaction[token]":"\(token.tokenId)",
            "Transaction[booking_id]":"\(bookingId)",
            "Transaction[invoice_id]":"\(invoiceId)",
             "Transaction[usecure_fee]":"\(usecureFee)",
            "Transaction[amount]":"\(amount)"
        ]
        
         
        if  reachability?.isReachable  == true
        {
            KAppDelegate.showActivityIndicator()
            
            let usewrAgent = "\(KMode)\(KAppName)"
            
            request(URL, method: .post, parameters: params as! Parameters, encoding: URLEncoding.httpBody , headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                
                .responseJSON { response in
                    do
                    {
                        KAppDelegate.hideActivityIndicator()
                        if(response.response?.statusCode == 200)
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary{
                                
                                self.serviceResponse(JSONDIC)
                                
                            }else {
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                            }
                        } else if(response.response?.statusCode == 403) {
                           
                        }
                        else
                        {
                            delegateObject = self
                            proxy.sharedProxy().stautsHandler(URL, parameter: params as? Dictionary<String, AnyObject> as Dictionary<String, AnyObject>? , response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                        }
                    }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    //MARK : - WebService Delegate
    func serviceResponse(_ JSON: NSDictionary){
        KAppDelegate.hideActivityIndicator()
        if (JSON["action"]! as AnyObject).isEqual("payment") && (JSON["controller"]! as AnyObject).isEqual("user") {
            if (JSON["status"]! as AnyObject).isEqual("Ok") || (JSON["status"]! as AnyObject).isEqual("OK") {
                proxy.sharedProxy().displayStatusCodeAlert("Payment Completed")
                self.dismiss(animated: true, completion: {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "moveFurther"), object: nil)
                })
            } else {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
       else if (JSON["action"]! as AnyObject).isEqual("cancel") && (JSON["controller"]! as AnyObject).isEqual("user") {
            if (JSON["status"]! as AnyObject).isEqual("Ok") || (JSON["status"]! as AnyObject).isEqual("OK") {
                proxy.sharedProxy().displayStatusCodeAlert("Payment Completed")
                self.dismiss(animated: true, completion: {
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "moveFurther"), object: nil)
                })
            } else {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
        
    }
    
    // MARK:- textField Delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.30, animations:{
            self.cardViewCenter.constant = -100
            self.view.layoutIfNeeded()
        })
        pickerView.dataSource = self
        pickerView.delegate = self
        pickerVwYear.delegate = self
        pickerVwYear.dataSource = self
        pickerVwYear.reloadAllComponents()
        pickerView.reloadAllComponents()
        pickerVwYear.selectRow(0, inComponent: 0, animated: true)
        pickerView.selectRow(0, inComponent: 0, animated: true)
        if textField == txtFldMonth{
            txtFldMonth.inputView = pickerView
            let row = pickerView.selectedRow(inComponent: 0)
            txtFldMonth.text = "\(monthArray[row])"
            pickerString = "txtMonth"
        }
        else if textField == txtFldYear{
            txtFldYear.inputView = pickerVwYear
            let row = pickerVwYear.selectedRow(inComponent: 0)
            txtFldYear.text = "\(yearArray[row])"
            pickerString = "txtYear"
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.30, animations:{
            self.cardViewCenter.constant = 0
            self.view.layoutIfNeeded()
        })
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtCardNumber {
            let length = txtCardNumber.text!.characters.count + string.characters.count - range.length
            if length >= 16 {
                if length == 16 {
                    let cardBrand = STPCardValidator.brand(forNumber: txtCardNumber.text!)
                    let cardImage = STPImageLibrary.brandImage(for: cardBrand)
                    
                    imgViewCardType.image = cardImage
                }
                if string != "" {
                    if length == 17 {
                        return false
                    }
                    else{
                        return true
                    }
                }
                else {
                    imgViewCardType.image = UIImage(named:  "")
                    return true
                }
            } else
            {
                imgViewCardType.image = UIImage(named:  "")
                return true
            }
        } else if textField == txtCVCNo {
            txtCardNumber.resignFirstResponder()
            if textField.text!.characters.count >= 3 {
                if string != "" {
                    return false
                } else {
                    return true
                }
            } else {
                return true
            }
        } else {
            txtCardNumber.resignFirstResponder()
            return true
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.dismiss(animated: true, completion: nil)
    }

    // MARK:- Picker Delegate
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        var returnCount = Int()
        if pickerString == "txtMonth" {
            returnCount = monthArray.count
        } else if pickerString == "txtYear" {
            returnCount = yearArray.count
        }
        return returnCount
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        var returnString = String()
        if pickerString == "txtMonth"{
            returnString = "\(monthArray[row])"
        }
        else if pickerString == "txtYear"{
            returnString = "\(yearArray[row])"
        }
        return returnString
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerString == "txtMonth"{
            txtFldMonth.text = "\(monthArray[row])"
        }
        else if pickerString == "txtYear"{
            txtFldYear.text = "\(yearArray[row])"
        }
    }

    //MARK:- Retry Method
    func retryMethod(_ paramsDic: Dictionary<String, AnyObject>, withServiceUrl: NSString, error: NSError?)
    {
        let retryURL = "\(withServiceUrl)"
        
        let reachable = Reachability()
        if reachable?.isReachable == true {
            if(paramsDic.count>0)
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .post, parameters: paramsDic, encoding: URLEncoding.httpBody, headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = (response.result.value as! NSDictionary).mutableCopy() as! NSDictionary
                                self.serviceResponse(JSON)
                            } else if(response.response?.statusCode == 403) {
                              //  KAppDelegate.goToLoginVC()
                            }
                            else
                            {
                                delegateObject = self
                                proxy.sharedProxy().stautsHandler(retryURL, parameter:paramsDic, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                }
            }
            else
            {
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(retryURL, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            if(response.response?.statusCode == 200)
                            {
                                let JSON = (response.result.value as! NSDictionary).mutableCopy() as! NSDictionary
                                self.serviceResponse(JSON)
                            } else if(response.response?.statusCode == 403) {
                                //KAppDelegate.goToLoginVC()
                            }
                            else
                            {
                                delegateObject = self
                                proxy.sharedProxy().stautsHandler(retryURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                }
            }
        }
        else
        {
            proxy.sharedProxy().openSettingApp()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
