//
//  ProfileVC.swift
//  drawer
//
//  Created by Tajinder Singh on 08/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift

class ProfileVC: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var emailView: UIView!
    //Mark : - Varriable 
    
     var openWith = String()

    
    @IBOutlet weak var txtFldName: UITextField!
    
    @IBOutlet weak var txtFldEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if openWith == "ProfileName"{
            txtFldEmail.isHidden = true
            lblEmail.isHidden = true
            
        }else{
            txtFldName.isHidden = true
            lblName.isHidden = true
        }
        
        self.navigationController?.navigationBar.isHidden=true
        
        txtFldEmail.attributedPlaceholder = NSAttributedString(string: "Enter your email address", attributes: [NSForegroundColorAttributeName: UIColor.gray])
        txtFldName.attributedPlaceholder = NSAttributedString(string: "Enter your Name", attributes: [NSForegroundColorAttributeName: UIColor.gray])
    
    }
    
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func actionDone(_ sender: Any) {
        
        if openWith == "ProfileName" {
            
            if txtFldName.isBlank {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
                return
            }
             else if  proxy.sharedProxy().isValidInput(txtFldName.text!) == false  {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter Valid Name")
                return
            }
               else {
                updateApi()
            }
        }else {
            if txtFldEmail.isBlank{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email Address")
            return
        } else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email")
            return
        } else {
             changeEmail()     
        }
    }
    }
    
   
    //Mark:- Update API
    
    func updateApi() {
        let userId = profileModel.id
        let param = [
            "full_name" : "\(txtFldName.text!)" ,
            //"email" :  "\(txtFldEmail.text!)" ,
        ]
        
        let userUpdateUrl = "\(KServerUrl)\(KUserUpate)\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
            request(userUpdateUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponseUpdate(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().stautsHandler(userUpdateUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
        
    }
     // Mark: - Change Email
    func changeEmail(){
        let userId = profileModel.id
        let param = [
            //"full_name" : "\(txtFldName.text!)" ,
            "email" :  "\(txtFldEmail.text!)" ,
        ]
        let userUpdateUrl = "\(KServerUrl)\(KChangeEmail)\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
            request(userUpdateUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                IQKeyboardManager.sharedManager().resignFirstResponder()
                                self.navigationController?.popViewController(animated: false)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(userUpdateUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: server not responding ")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }

   
    }
       func serviceResponseUpdate(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if let strUrl = JSON.object(forKey: "url") as? String{
        if (JSON["url"]! as AnyObject).isEqual("\(KUserUpate)\(profileModel.id)")  {
            if JSON["status"] as! Int == 200 {
                UserDefaults.standard.set(txtFldName.text!, forKey: kUserName)
                UserDefaults.standard.synchronize()
                IQKeyboardManager.sharedManager().resignFirstResponder()
                
                self.navigationController?.popViewController(animated: false)
                
            }
        
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
          }
        }
          else if let strUrl = JSON.object(forKey: "url") as? String{
             if (JSON["url"]! as AnyObject).isEqual("\(KChangeEmail)\(profileModel.id)")  {
            if JSON["status"] as! Int == 200 {
            IQKeyboardManager.sharedManager().resignFirstResponder()
                self.navigationController?.popViewController(animated: false)
                
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
      }
    }
}



extension ProfileVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
}
