//
//  proxy.swift
//  trippack
//
//  Created by Toxsl on 24/12/15.
//  Copyright © 2015 ToXSL Technologies Pvt. Ltd. All rights reserved.

import UIKit
import CoreMotion
import CoreLocation
import Alamofire
var locationUpdates = Bool()
var locationShareInstance:locationManagerClass = locationManagerClass()

class locationManagerClass: NSObject, CLLocationManagerDelegate , UIAlertViewDelegate
{
//    // MARK: - Class Variables


    var locationManager = CLLocationManager()
    
    
    class func sharedLocationManager() -> locationManagerClass
    {
        locationShareInstance = locationManagerClass()
        return locationShareInstance
    }
    
    var timer = Timer()
    func startStandardUpdates() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.activityType = .automotiveNavigation
        locationManager.distanceFilter = 10
        // meters
        locationManager.pausesLocationUpdatesAutomatically = false
        
        
        if (Bundle.main.object(forInfoDictionaryKey: "NSLocationWhenInUseUsageDescription") != nil) {
            locationManager.requestWhenInUseAuthorization()
                   }
        locationUpdates = true
        locationManager.startUpdatingLocation()
        if #available(iOS 9.0, *) {
            
            locationManager.allowsBackgroundLocationUpdates  = false
        } else {
            // Fallback on earlier versions
        }
//        timer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(locationManagerClass.updateLocationToServer), userInfo: nil, repeats: true)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // If it's a relatively recent event, turn off updates to save power.
        
        let location: CLLocation = locations.last!
       
        
        UserDefaults.standard.set("\(location.coordinate.latitude)", forKey: "lat")
        UserDefaults.standard.set("\(location.coordinate.longitude)", forKey: "long")
        UserDefaults.standard.synchronize()
        //MARK:- FOR CURRENT USER ADDRESS
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil)
            {
                  print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0
            {
                let pm = placemarks?[0]
               // self.displayLocationInfo(placemark: pm)
            }
            else
            {
                  print("Problem with the data received from geocoder")
            }
        })
    }
    
    func displayLocationInfo(placemark: CLPlacemark?)
    {
        if let containsPlacemark = placemark
        {
            //stop updating location to save battery life
            locationManager.stopUpdatingLocation()
            
            let locality = (containsPlacemark.locality != nil) ? containsPlacemark.locality : ""
            let postalCode = (containsPlacemark.postalCode != nil) ? containsPlacemark.postalCode : ""
            let administrativeArea = (containsPlacemark.administrativeArea != nil) ? containsPlacemark.administrativeArea : ""
            let country = (containsPlacemark.country != nil) ? containsPlacemark.country : ""
            UserDefaults.standard.set("\(locality!)", forKey: "currentAddress")
            UserDefaults.standard.synchronize()
            UserDefaults.standard.set("\(postalCode!)", forKey: "zipCode")
            UserDefaults.standard.synchronize()
        }
    }
    func stopStandardUpdate(){
        DispatchQueue.main.async  {
            self.timer.invalidate()
        }
        if #available(iOS 9.0, *) {
            locationManager.allowsBackgroundLocationUpdates = false
        } else {
            // Fallback on earlier versions
        }
        locationUpdates = false
        locationManager.stopUpdatingLocation()
    }
    
    
    //MARK:- WHEN DENIED
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == CLAuthorizationStatus.denied {
            
            
            UserDefaults.standard.set("\(0.0)", forKey: "lat")
            UserDefaults.standard.set("\(0.0)", forKey: "long")
            
            self.generateAlertToNotifyUser()
        }
    }
    
    func generateAlertToNotifyUser() {
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined{
            
            var title: String
            title = ""
            let message: String = "Location Services are not able to determine your location"
            
            let alertView: UIAlertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: "Cancel", otherButtonTitles: "Settings")
            alertView.show()
        }
        
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.denied{
            
            var title: String
            
            title = "Location services are off"
            let message: String = "To use this service efficiently, you must turn on Location Services from Settings"
            
            let alertView: UIAlertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: "Cancel", otherButtonTitles: "Settings")
            alertView.show()
        }
        
        if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.notDetermined
        {
            startStandardUpdates()
        }
    }
    
   
    //MARK:- Serviece Response
    func serviceResponse(_ JSON:NSMutableDictionary) {

        if (JSON["action"]! as AnyObject).isEqual("location-update") && (JSON["controller"]! as AnyObject).isEqual("user") {
            if (JSON["status"]! as AnyObject).isEqual("OK") {
                
            } else
            {
            }
        }
    }
 
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int) {
        if buttonIndex == 1 {
            // Send the user to the Settings for this app
            let settingsURL: URL = URL(string: UIApplicationOpenSettingsURLString)!
            UIApplication.shared.openURL(settingsURL)
        }
        
    }
    
    
}

