//
//  RecievedPackageModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 26/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation


class RecievedPackageModel {
    
    var  address  = String()
    var business_name = String()
     var  city  = String()
     var  images  = NSArray()
     var  package_count  = Int()
     var  recived_date  = String()
     var  recived_time  = String()
     var  state  = String()
     var  zipcode  = String()
     var  id  = Int()
     var pickUpTime = String()
    
    func setUserPackageDetial(dictDetail:NSMutableDictionary){
        
        if let  address  = dictDetail["address"] as? String {
            self.address = address
        }
        
        if let  business_name  = dictDetail["business_name"] as? String {
            self.business_name = business_name
        }
        if let  city  = dictDetail["city"] as? String {
            self.city = city
        }
        if let  images  = dictDetail["images"] as? NSArray {
           
            self.images = images
        }
        if let  package_count  = dictDetail["package_count"] as? Int {
            self.package_count = package_count
        }
        if let  state  = dictDetail["state"] as? String {
            self.state = state
        }
        if let  zipcode  = dictDetail["zipcode"] as? String {
            self.zipcode = zipcode
        }
        if let  recived_date  = dictDetail["recived_date"] as? String {
            self.recived_date = recived_date
        }
        if let  recived_time  = dictDetail["recived_time"] as? String {
            self.recived_time = recived_time
        }
        if let  id  = dictDetail["id"] as? Int {
            self.id = id
        }
        if let  pickUpTime  = dictDetail["pickedup_time"] as? String {
            if pickUpTime == "" {
            self.pickUpTime = "Pending"
            }else{
                self.pickUpTime = pickUpTime
            }
        }
     }
}

        
        

