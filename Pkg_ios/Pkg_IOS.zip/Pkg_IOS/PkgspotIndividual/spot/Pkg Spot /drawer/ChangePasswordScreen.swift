//
//  ChangePasswordScreen.swift
//  drawer
//
//  Created by Tajinder Singh on 08/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift

protocol ChangePasswordDelegate {
    func sendPassword(_ strPassword: String)
}

var protocolChangePassword: ChangePasswordDelegate?

class ChangePasswordScreen: UIViewController {
    
    var changeController = Int()
    @IBOutlet weak var txtFldNewPassWord: UITextField!
    
    @IBOutlet weak var txtFldConfirmPassword: UITextField!
    
    var changePassword = String()
    
    override func viewDidLoad() {  //pssworrdKey
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden=true
        
        txtFldNewPassWord.setLeftImage(#imageLiteral(resourceName: "pssworrdKey"))
        txtFldConfirmPassword.setLeftImage(#imageLiteral(resourceName: "pssworrdKey"))
        
        txtFldNewPassWord.attributedPlaceholder = NSAttributedString(string: "Your new password", attributes: [NSForegroundColorAttributeName: UIColor.lightGray])
        txtFldConfirmPassword.attributedPlaceholder = NSAttributedString(string: "confirm new password", attributes: [NSForegroundColorAttributeName: UIColor.lightGray])

    }
    
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionDone(_ sender: Any) {
        
         changePasswordApi()
        
    }
    
    
    
    func changePasswordApi(){
    
        if txtFldNewPassWord.text!.isEmpty() {
            proxy.sharedProxy().displayStatusCodeAlert("Please Enter New Password")
            return
            
        } else if txtFldConfirmPassword.text!.isEmpty() {
            proxy.sharedProxy().displayStatusCodeAlert("Please Enter Confirm Password")
            return
            
        } else if proxy.sharedProxy().isValidPassword(txtFldNewPassWord.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Password should have minimum 6 characters")
        } else if txtFldNewPassWord.text! != txtFldConfirmPassword.text! {
            proxy.sharedProxy().displayStatusCodeAlert("Confirm Password does not match")
            return
        }
        else {
            let userId = profileModel.id
            let ChangePasswordUrl = "\(KServerUrl)\(KChangePassword)"
            let param = [
                "id": userId,
                "password": txtFldNewPassWord.text!
            ] as [String : Any]
             
            if  (reachability?.isReachable)!
            {
                KAppDelegate.showActivityIndicator()
                
                request(ChangePasswordUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody , headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        do
                        {
                            KAppDelegate.hideActivityIndicator()
                            if response.data != nil && response.result.error == nil {
                                
                                
                                if(response.response?.statusCode == 200)
                                {
                                    
                                    if let JSONDIC = response.result.value as? NSDictionary{
                                        self.serviceResponse(JSONDIC.mutableCopy() as! NSMutableDictionary)
                                    }else {
                                        proxy.sharedProxy().displayStatusCodeAlert("Internet Problem Please Try Again")
                                    }
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(ChangePasswordUrl, parameter: param as Dictionary<String, AnyObject>, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Connectivity Problem")
                            }
                        }
                }
            } else {
                proxy.sharedProxy().openSettingApp()
            }
        }

        
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary)
    {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KChangePassword) {
            if (JSON["status"]! as AnyObject).isEqual(200){
                proxy.sharedProxy().displayStatusCodeAlert("Password changed successfully")
                protocolChangePassword?.sendPassword(txtFldConfirmPassword.text!)
                self.navigationController?.popViewController(animated: true)
            } else {
                if  JSON["error"] != nil{
                    let errorMessage = JSON["error"] as! String
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage)
                }
            }
        }
    }

  
}



extension ChangePasswordScreen : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
}
