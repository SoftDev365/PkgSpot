//
//  CustomerId.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 18/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Foundation
var custId = CustomerId()
class CustomerId {
    
    
    var   customer_id = String()
    func setUserCustId(dictDetail:NSMutableDictionary){
    if let customer_id  = dictDetail["customer_id"] as? String{
        self.customer_id = customer_id
            
            
        }
    }
}

    
    

