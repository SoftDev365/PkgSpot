//
//  HelpVcCell.swift
//  drawer
//
//  Created by Tajinder Singh on 13/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class HelpVcCell: UITableViewCell {
    

    @IBOutlet weak var lblDiscriptionDetail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
