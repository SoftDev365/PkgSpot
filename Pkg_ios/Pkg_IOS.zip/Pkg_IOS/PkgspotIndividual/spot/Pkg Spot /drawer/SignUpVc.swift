//
//  SignUpVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 21/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift
class SignUpVc: UIViewController {
      // Mark Outlet
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldZipCode: UITextField!
    // Mark Varriabl
        override func viewDidLoad() {
        super.viewDidLoad()
            
            txtFldName.attributedPlaceholder = NSAttributedString(string: "First Name  - Last Name", attributes: [NSForegroundColorAttributeName: UIColor.gray
                ])
            txtFldEmail.attributedPlaceholder = NSAttributedString(string: "Your email address", attributes: [NSForegroundColorAttributeName: UIColor.gray])
            txtFldPassword.attributedPlaceholder = NSAttributedString(string: "Your Password", attributes: [NSForegroundColorAttributeName: UIColor.gray])
            txtFldZipCode.attributedPlaceholder = NSAttributedString(string: "Your Zip code", attributes: [NSForegroundColorAttributeName: UIColor.gray])
           }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }


    @IBAction func btnBack(_ sender: UIButton) {
     _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnNext(_ sender: Any) {
       signUp()
    }
    func signUp() {
        if txtFldName.isBlank {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
            return
         }
        else if proxy.sharedProxy().isValidInput(txtFldName.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Name ")
            return
        }
        else if txtFldEmail.isBlank {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email Address")
            return
        } else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email")
            return
        }
        else if txtFldPassword.isBlank {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
            return
        } else if proxy.sharedProxy().isValidPassword(txtFldPassword.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Minimum of 6 characters,at least one Upper Case")
        }else if txtFldZipCode.isBlank{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter ZipCode")
            return
        }else{
            let param = [
                "full_name" : "\(txtFldName.text!)" ,
                "email" :  "\(txtFldEmail.text!)" ,
                "password" :  "\(txtFldPassword.text!)",
                "zipcode":  "\(txtFldZipCode.text!)",
               
            ]
           
            let signUpUrl = "\(KServerUrl)" + "\(KSignup)"
            if  reachability?.isReachable  == true {
                KAppDelegate.showActivityIndicator()
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(signUpUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                    .responseJSON { response in
                        let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                 
                        do
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                KAppDelegate.hideActivityIndicator()
                                if response.response?.statusCode == 200   {
                                    self.serviceResponse(JSONDIC)
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(signUpUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
            }
        }
    }
    
     func serviceResponse(_ JSON:NSMutableDictionary) {
      KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KSignup)  {
      
              if JSON["status"] as! Int == 200 {
                IQKeyboardManager.sharedManager().resignFirstResponder()
                    if  let data = JSON["data"] as? NSArray {
                    if let dic = data[0] as? NSDictionary {
                   profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                        UserDefaults.standard.set(profileModel.userName, forKey: kUserName)
                        UserDefaults.standard.set(profileModel.unique_id, forKey: kAccountName)
                        UserDefaults.standard.synchronize()
                        let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "AddYourphoneNumberVc") as! AddYourphoneNumberVc
                       self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                    }
                    
                    }
                }else {
                if let errorMessage = JSON["error"] {
                    if let userid = JSON["userId"] as? Int{
                        profileModel.id = Int32(userid)
                    }else{
                        if let userid = JSON.object(forKey: "userId") as? String{
                        if proxy.sharedProxy().checkStringIfNull(JSON["userId"] as! String).characters.count > 0 {
                             profileModel.id = Int32(JSON["userId"] as! String)!
                        }
                        }
                    }
                    if profileModel.id == 0 {
                         proxy.sharedProxy().displayStatusCodeAlert("Error: User not found!")
                        
                    }else{
                        if  let steps = JSON.object(forKey: "step") as? Int{
                            switch steps{
                            case 0:
                                KAppDelegate.gotoMyLocationViewController()
                                let mainNav = KAppDelegate.sideMenuVC.mainViewController as! UINavigationController
                                let createVC = self.storyboard?.instantiateViewController(withIdentifier: "CongratulationsVC") as! CongratulationsVC
                                mainNav.pushViewController(createVC, animated: false)
                                break
                            case 1:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "AddYourphoneNumberVc") as! AddYourphoneNumberVc
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 2:
                                let findLocation = self.storyboard?.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
                                self.navigationController?.pushViewController(findLocation,animated: true)
                                break
                            case 3:
                                let createVC = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountVC") as! CreateAccountVC
                                self.navigationController?.pushViewController(createVC, animated: false)
                                break
                            default:
                                
                                break
                            }
                        }
                    
                    }
                 
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
     }
    
     }
//MARK:- TextFieldExtension
extension UITextField {
    var isBlank : Bool {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!
    }
    var trimmedValue : String {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines))!
    }
    
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[NSForegroundColorAttributeName: newValue!])
        }
    }
}
