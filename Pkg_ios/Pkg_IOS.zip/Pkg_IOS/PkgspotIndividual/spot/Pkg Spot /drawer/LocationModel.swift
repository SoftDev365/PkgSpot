//
//  LocationModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 01/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation

var locationModel = LocationModel()

class LocationModel {
    
    var latitude = String()
    var longitude = String()
    var zipCode = String()
    var address = String()
    var step = Int32()
    var password = String()
    var phoneNumber = String()
    var business_name = String()
    var sepratedId = String()
    var id = Int()
    var isSeleced = Int()
    var city = String()
    var days_of_service  = NSArray()
     let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    var dayOfServiceArray = [DaysAndService]()
    func setUserLocation(dictDetail:NSMutableDictionary){
        if let latitude  = dictDetail["latitude"] as? String{
            self.latitude = latitude
        }
        if let longitude = dictDetail["longitude"] as? String{
            self.longitude =  longitude
        }
        
        if let zipCode  = dictDetail["zipcode"] as? String {
            if zipCode != ""
            {
                self.zipCode = zipCode
            }else{
                self.zipCode = "Not Found"
            }
        }else{
           self.zipCode = "Not Found"
        }
        if let address = dictDetail["address"] as? String {
            self.address = address
            
        }
        if let business_name = dictDetail["business_name"] as? String {
            self.business_name = business_name
            
        }
        if let id = dictDetail["id"] as? Int {
            self.id = id
            
        }
        if let city = dictDetail["city"] as? String {
            self.city = city
        }
  
     if let dayOfService = dictDetail["days_of_service"] as? String{
        // Code used to remove \n and '\'
        let strDaysOfServices = dayOfService.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil)
        let  strdayOfService =  strDaysOfServices.replacingOccurrences(of: "'\'", with: "", options: .literal, range: nil)
        
        if strdayOfService != ""{
            let data: Data? = strdayOfService.data(using: String.Encoding.utf8)
            let values:NSArray = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSArray
            
            for index in 0..<values.count{
                
                
                let serviceVal = DaysAndService()
                serviceVal.userData(dictDetail: values[index] as! NSDictionary, index: index)
                dayOfServiceArray.append(serviceVal)
            }
        }
    }
    }

}
