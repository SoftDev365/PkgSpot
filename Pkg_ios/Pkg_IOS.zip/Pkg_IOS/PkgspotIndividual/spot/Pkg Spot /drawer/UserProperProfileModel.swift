//
//  UserProperProfileModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 06/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
let userProperProfileModel = UserProperProfileModel()
class UserProperProfileModel {
    
    var contactNo = String()
    var fullName = String()
    var email = String()
    var address  = String()
    var accountNumber = String()
    var customer_id = String()

    
    
    func setUserAddress(dictDetail:NSMutableDictionary){
        if let contactNo = dictDetail["contact_no"] as? String {
            self.contactNo = contactNo
        }
        if let fullName = dictDetail["full_name"] as? String{
            self.fullName =  fullName
        }
        
        if let email  = dictDetail["email"] as? String {
            self.email = email
            
        }
        if let  address  = dictDetail["address"] as? String {
            self.address = address
        }
        if let  accountNumber  = dictDetail["unique_id"] as? String {
            self.accountNumber = accountNumber
        }
        if let  customer_id  = dictDetail["customer_id"] as? String {
            self.customer_id = customer_id
        }
        
             
    }
}

