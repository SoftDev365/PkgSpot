//
//  HelpDetailModel.swift
//  drawer
//
//  Created by Tajinder Singh on 13/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class HelpDetailModel: NSObject {
    
    var descriptionTitle = String()
    var title = String()
    
    func setUserInfo(dictDetail:NSMutableDictionary){
        if let description = dictDetail["description"] as? String {
            self.descriptionTitle = description
        }
        if let title = dictDetail["title"] as? String{
            self.title = title
        }
    }
}
