//
//  PartnersAnnotation.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 01/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
import UIKit
import MapKit
class  PartnersAnnotation: NSObject,MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var estimatedDestance = ""
    var title: String?
    var subtitle: String?
    var index = Int()
    
    init(coordinate: CLLocationCoordinate2D,index:Int,name:String,address:String,estimatedDestance:String) {
        
        self.coordinate = coordinate
        self.index = index
        self.estimatedDestance = estimatedDestance
        self.title = name
        self.subtitle = address
        super.init()
    }
}
