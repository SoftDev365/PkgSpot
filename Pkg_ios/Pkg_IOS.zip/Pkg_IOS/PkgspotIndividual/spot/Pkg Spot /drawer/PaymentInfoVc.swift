//
//  PaymentInfoVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 16/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class PaymentInfoVc: UIViewController,UITableViewDelegate,UITableViewDataSource {

    // Mark :- Outlet
    @IBOutlet weak var tblviewPaymentInfo: UITableView!
    
    
    var custCardDetials = [CustomerCardDetials]()
   
    override func viewDidLoad() {
        super.viewDidLoad()
           getCardDetials()
    }
    
       //Mark: TableView Delegate and Datasource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return custCardDetials.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblviewPaymentInfo.dequeueReusableCell(withIdentifier: "PaymentInfoCell", for: indexPath) as! PaymentInfoCell
          let cardExpiryMonth = (custCardDetials[indexPath.row].exp_month)
          let cardExpiryYear =  (custCardDetials[indexPath.row].exp_year)
         cell.lblUserName.text = "ExpiryDate:- \(cardExpiryMonth)" + "/" + "\(cardExpiryYear)"
        let cardNumberStr =   (custCardDetials[indexPath.row].last4)
        cell.lblUserCardNumber.text = "XXXXXXXXXXXX\(cardNumberStr)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
//     func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
//        let deleteAction = UITableViewRowAction(style: .destructive , title: "Delete") { (action, indexPath) in
//            let customerModal = self.custCardDetials[indexPath.row] 
//            
//            let alertController = UIAlertController(title: "", message: "Are you sure you want to remove this  Card ?", preferredStyle: .alert)
//            let yesAction = UIAlertAction(title: "Yes", style: .default) { (action) in
//                self.removeCardDetials(strCardId: "\(customerModal.id)")
//            }
//            
//            let noAction = UIAlertAction(title: "No", style: .default) { (action) in
//                
//                self.dismiss(animated: true, completion: nil)
//                
//            }
//           KAppDelegate.window?.currentViewController()?.present(alertController, animated: true, completion: nil)
//            alertController.addAction(yesAction)
//           alertController.addAction(noAction)
//            
//        }
//         deleteAction.backgroundColor = UIColor(red: 23/255, green: 153/255, blue: 243/255, alpha: 1)
//        return[deleteAction]
//    }

    
   
    @IBAction func btnCanncelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
      //  This code is needed for future  then i dont delete.
      // Mark: - Remove Card Detials
//    func removeCardDetials(strCardId:String){
//        
//        let param = [
//            "customer_id" : "\(userProperProfileModel.customer_id)",
//            "card_id" :  strCardId  ,
//        ]
//        let getCardUrl = "\(KServerUrl)\(KRemoveCardDetials)"
//         
//        if  reachability?.isReachable  == true {
//            KAppDelegate.showActivityIndicator()
//            // let usewrAgent = "\(KMode)\(KAppName)"
//            request(getCardUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
//                .responseJSON { response in
//                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
//              
//                    do
//                    {
//                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
//                            KAppDelegate.hideActivityIndicator()
//                            if response.response?.statusCode == 200   {
//                                self.serviceResponseRemoveCard(JSONDIC)
//                           
//                               
//                            } else {
//                                KAppDelegate.hideActivityIndicator()
//                                proxy.sharedProxy().stautsHandler(getCardUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
//                            }
//                        } else {
//                            KAppDelegate.hideActivityIndicator()
//                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding!")
//                        }
//                    }
//            }
//        } else {
//            KAppDelegate.hideActivityIndicator()
//            proxy.sharedProxy().openSettingApp()
//        }
//    }
    
    
          // Mark :- SERVICE RESPONSE REMOVE CARD
//       func serviceResponseRemoveCard(_ JSON:NSMutableDictionary) {
//        KAppDelegate.hideActivityIndicator()
//        
//      
//            if JSON["status"] as! Int == 200 {
//                if let arrData = JSON["data"] as? NSArray {
//                    self.custCardDetials.removeAll()
//                    for i in 0 ..< arrData.count {
//                        if let dictData = arrData[i] as? NSDictionary{
//                            let customerCardDetials = CustomerCardDetials()
//                            let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
//                            customerCardDetials.getUserCardDetials(dictDetail: mutatedDic)
//                            self.custCardDetials.append(customerCardDetials)
//                        }
//                        
//                    }
//                    self.tblviewPaymentInfo.reloadData()
//                    self.dismiss(animated: true, completion: nil)
//                }
//
//           }
//        
//        else
//        {
//            
//            if let errorMessage =   JSON["error"] as? String{
//                if proxy.sharedProxy().checkStringIfNull(errorMessage).characters.count > 0{
//                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage )
//                }
//            }
//        }
//    }
       //Mark : - GetCardDetials
    func getCardDetials(){
        
    let userId = profileModel.id
    let cstId = userProperProfileModel.customer_id
    let getCardUrl = "\(KServerUrl)\(KGetCardDetial)\(cstId)" + "/" + "\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            // let usewrAgent = "\(KMode)\(KAppName)"
            request(getCardUrl, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponseAddNewCard(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(getCardUrl, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding!")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    func serviceResponseAddNewCard(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        let url = "\(KGetCardDetial)\(userProperProfileModel.customer_id)" + "/" + "\( profileModel.id)"
        
           if (JSON["url"]! as AnyObject).isEqual (url) {
         
            if JSON["status"] as! Int == 200 {
                if let arrData = JSON["data"] as? NSArray{
                    for i in 0 ..< arrData.count {
                    if let dictData = arrData[i] as? NSDictionary{
                        let customerCardDetials = CustomerCardDetials()
                        let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
                        customerCardDetials.getUserCardDetials(dictDetail: mutatedDic)
                        self.custCardDetials.append(customerCardDetials)
                    }
                  }
                }
                
                tblviewPaymentInfo.delegate = self
                tblviewPaymentInfo.dataSource = self
                tblviewPaymentInfo.reloadData()
            }
        }
        else
        {
            
            if let errorMessage =   JSON["error"] as? String{
                if proxy.sharedProxy().checkStringIfNull(errorMessage).characters.count > 0{
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage )
                }
            }
        }
    }
}
