//
//  PartnerDropeDownModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 03/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation

var partnerAdressLocation = PartnerDropeDownModel()

class PartnerDropeDownModel {
    
    var  city = String()
    var latitude = String()
    var longitude = String()
    
    func setUserPartnerAdress(dictDetail:NSMutableDictionary){
        
        if let  city  = dictDetail["city"] as? String {
            self.city = city
        }
        if let latitude  = dictDetail["latitude"] as? String{
            self.latitude = latitude
        }
        if let longitude = dictDetail["longitude"] as? String{
            self.longitude =  longitude
        }
    }
    
}
