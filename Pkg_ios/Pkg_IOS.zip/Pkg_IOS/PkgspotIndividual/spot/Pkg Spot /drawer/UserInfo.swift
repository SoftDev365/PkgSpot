//
//  UserInfo.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 05/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation



class UserInfo {
    var  cardNumber = Int()
    var  expiryDate = String()
    var  created_by_id = Int()
    var user_id = Int32()
 
    func setUserInfo(dictDetail:NSMutableDictionary){
            if let created_by_id = dictDetail["created_by_id"] as? Int {
            self.created_by_id = created_by_id
        }
        if let cardNumber = dictDetail["number"] as? Int32{
            self.cardNumber =  Int(cardNumber)
        }
        
        if let expiryDate  = dictDetail["expiryDate"] as? String {
            self.expiryDate = expiryDate
            
        }
        if let  userId  = dictDetail["user_id"] as? Int32 {
            self.user_id = userId
            
        }

        
        
        
                
    }
    
}
