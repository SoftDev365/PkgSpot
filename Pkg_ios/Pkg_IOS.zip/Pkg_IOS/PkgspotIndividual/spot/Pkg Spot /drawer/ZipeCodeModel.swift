//
//  ZipeCodeModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 04/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
let  ZipeCodeObj = ZipeCodeModel()

class ZipeCodeModel {
    
    var  zipcode  = String()
    var id = Int()
    
    func setUserZipCode(dictDetail:NSMutableDictionary){
        
        if let  zipcode  = dictDetail["zipcode"] as? String {
            self.zipcode = zipcode
        }
        
        if let  id  = dictDetail["id"] as? Int {
            self.id = id
        }

    }
}

