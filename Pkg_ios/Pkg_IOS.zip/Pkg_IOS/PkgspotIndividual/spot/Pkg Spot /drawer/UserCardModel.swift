//
//  UserCardModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 04/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
var userCardModel = UserCardModel()
class UserCardModel {
    
    var  created_by_id = Int32()
    var  step = Int32()
    var  cardUserName = String()
    var  cardNumber = Int()
    var  expiryDate = String()
    
    func setUserCardDetials(dictDetail:NSMutableDictionary){
        if let cardUserName  = dictDetail["name"] as? String{
            self.cardUserName = cardUserName
            
        
}
    }
}
        
        

