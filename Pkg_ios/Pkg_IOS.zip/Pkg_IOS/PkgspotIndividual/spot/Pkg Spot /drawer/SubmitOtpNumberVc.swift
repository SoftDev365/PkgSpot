//
//  SubmitOtpNumberVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 20/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class SubmitOtpNumberVc: UIViewController {
    
    
    @IBOutlet weak var lblEntereCode: UILabel!
    
    @IBOutlet weak var lblEmailVerify: UILabel!
    @IBOutlet weak var txtFldOtpCode: UITextField!
    
    var userVerifyEmail = String()
    var entercode1 = "We just sent you a six digit one-time password to:"

    override func viewDidLoad() {
        super.viewDidLoad()
        lblEmailVerify.text = userVerifyEmail
        lblEntereCode.text = "\(entercode1)"
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func btnResendOtpAction(_ sender: Any) {
        resendOtp()
    }
     // Mark :ResendOtp Api
      func resendOtp(){
        let resendOtpUrl = "\(KServerUrl)\(KForgotPassword)"
        let param = [
            
            "email":"\(userVerifyEmail)"
        ]
         
        if  (reachability?.isReachable)!
        {
            KAppDelegate.showActivityIndicator()
            
            request(resendOtpUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody , headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do
                    {
                        KAppDelegate.hideActivityIndicator()
                        if response.data != nil && response.result.error == nil {
                            
                            
                            if(response.response?.statusCode == 200)
                            {
                                
                                if let JSONDIC = response.result.value as? NSDictionary{
                                    self.serviceResponseOtpResend(JSONDIC.mutableCopy() as! NSMutableDictionary)
                                }else {
                                    proxy.sharedProxy().displayStatusCodeAlert("Internet Problem Please Try Again")
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(resendOtpUrl, parameter: nil, response: response.response, data: response.data as Data? , error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Connectivity Problem")
                        }
                    }
            }
        } else {                proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    
    func serviceResponseOtpResend(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KForgotPassword)") {
            
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        if let email = dic ["email"] as? String{
                            let userEmail = email
                         
                            self.dismiss(animated: true, completion: nil)
                        }
                        
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        otpVerifyAPI()
        }
    
    // Mark : OtpVerify Api
    func otpVerifyAPI(){
        
        let ForgotPasswordUrl = "\(KServerUrl)\(kOtpVerify)"
        let param = [
            
            "otp":"\(txtFldOtpCode.text!)",
            "email": "\(userVerifyEmail)"
        ]
         
        if reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
            request(ForgotPasswordUrl, method:.post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                     do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                    
                                
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(ForgotPasswordUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(kOtpVerify)") {
       
            if JSON["status"] as! Int == 200 {
                let submitOtpVc = self.storyboard?.instantiateViewController(withIdentifier:"ChangePasswordVc") as! ChangePasswordVc
                if let strUserId = JSON.object(forKey: "userId") as? String{
                    submitOtpVc.strUserId = strUserId
                    self.navigationController?.pushViewController(submitOtpVc,animated: true)
                }else{
                    if let userId = JSON.object(forKey: "userId") as? Int{
                        submitOtpVc.strUserId = "\(userId)"
                        self.navigationController?.pushViewController(submitOtpVc,animated: true)
                    }else{
                        proxy.sharedProxy().displayStatusCodeAlert("Error: User not found!")
                        
                    }
                    
                }
                
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
        
    }
}


















