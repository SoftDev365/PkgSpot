//
//  PaymentInfoCell.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 16/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class PaymentInfoCell: UITableViewCell {

    
    @IBOutlet weak var imgViewCard: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblUserCardNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
