//
//  OtpCodeVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 22/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import FirebaseAuth
import Alamofire
import FirebaseAuth

class OtpCodeVc: UIViewController {

  @IBOutlet weak var txtfldEnterOTP: UITextField!
  @IBOutlet weak var lblNumber: UILabel!
    
    //Mark:- Varriable
  var userNumber = String()
  var locationData = LocationModel()
  var locationArray = [LocationModel]()
  var verificationID = UserDefaults.standard.string(forKey: "authVerificationID")
    var formatedStr = ""
    var comeId = Int()
    var comeFrom = String()
    override func viewDidLoad() {
        super.viewDidLoad()
     lblNumber.text = userNumber
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        txtfldEnterOTP.text = ""
    }
     @IBAction func btnResendCodeAction(_ sender: Any) {
    
        let firebaseAuth = Auth.auth()
        KAppDelegate.showActivityIndicator()
        do {
            try firebaseAuth.signOut()
            PhoneAuthProvider.provider().verifyPhoneNumber("\(userNumber)"){ (verifiedID, error) in
                if let error = error {
                    KAppDelegate.hideActivityIndicator()
                    proxy.sharedProxy().displayStatusCodeAlert(error.localizedDescription)
                    return
                }
                KAppDelegate.hideActivityIndicator()
                self.verificationID = verifiedID
            }
        } catch let signOutError as NSError {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().displayStatusCodeAlert("Error signing out: \(signOutError.localizedDescription)")
        }
    }
    @IBAction func btnBack(_ sender: Any) {
     _ = self.navigationController?.popViewController(animated: true)
    }
    
  @IBAction func btnNextAction(_ sender: Any) {
    
    
    if comeId == 1 {
        comeToDrawer()
        
    }else{
    
    if (txtfldEnterOTP.text?.isEmpty)! {
      proxy.sharedProxy().displayStatusCodeAlert("Enter OTP first")
    }else{
      KAppDelegate.showActivityIndicator()
      let credential = PhoneAuthProvider.provider().credential(
        withVerificationID: verificationID!,
        verificationCode: txtfldEnterOTP.text!)
      Auth.auth().signIn(with: credential) { (user, error) in
        if let error = error {
          KAppDelegate.hideActivityIndicator()
          proxy.sharedProxy().displayStatusCodeAlert("\(error.localizedDescription)")
          return
        }
       KAppDelegate.hideActivityIndicator()
      proxy.sharedProxy().displayStatusCodeAlert("\(user?.displayName ?? "") verification successfully")
        
        self.formatedStr = (self.userNumber as NSString).replacingOccurrences(of: "+", with: "")
        if self.formatedStr.contains(" ") {
            self.formatedStr = self.formatedStr.replacingOccurrences(of:" ", with: "")
        }
        
        let param = [
            "contact_no"    : "\(self.formatedStr)" ,
            "id" :       profileModel.id
        ] as [String : Any]
            let verifyNumber = "\(KServerUrl)\(KVerifyOtp)"
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(verifyNumber, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                                
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(verifyNumber, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
        }
        
        let firebaseAuth = Auth.auth()
        do {
          try firebaseAuth.signOut()
        } catch let signOutError as NSError {
          KAppDelegate.hideActivityIndicator()
          proxy.sharedProxy().displayStatusCodeAlert("Error signing out: \(signOutError.localizedDescription)")
        }
    
          }
      }
    }
       func getPartnerslocations(dictData:NSDictionary){
        let verifyNumber = "\(KServerUrl)\(KPartnerLocation)"
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(verifyNumber, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                   do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                               self.serviceResponse(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(verifyNumber, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KVerifyOtp) ||  (JSON["url"]! as AnyObject).isEqual("\(changeMobileNumber)\(profileModel.id)")   {
                if JSON["status"] as! Int == 200 {
               // proxy.sharedProxy().displayStatusCodeAlert("verification successfully")
                //IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                    }
                }
                    if comeId == 1 {
                    KAppDelegate.gotoMyAccountScreen()
                }else{
                    let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"FindMyLocationVC") as! FindMyLocationVC
                    self.navigationController?.pushViewController(otpCodeVc,animated: true)
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }else  if (JSON["url"]! as AnyObject).isEqual(KPartnerLocation)  {
                    if JSON["status"] as! Int == 200 {
                
                if  let data = JSON["data"] as? NSArray {
                    for i in 0..<data.count {
                    if let dic = data[i] as? NSDictionary {
                        let mutatedDic = dic.mutableCopy() as! NSMutableDictionary
                        let locationData = LocationModel()
                        mutatedDic.setValue(0, forKey: "isSelected")
                        locationData.setUserLocation(dictDetail: mutatedDic)
                        self.locationArray.append(locationData)//add(locationData)
                    }
                }
                }
                let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"FindMyLocationVC") as! FindMyLocationVC
                otpCodeVc.arrayLocationDetials = locationArray
                self.navigationController?.pushViewController(otpCodeVc,animated: true)
    
                }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
    }
    
    
    func comeToDrawer(){
        if (txtfldEnterOTP.text?.isEmpty)! {
            proxy.sharedProxy().displayStatusCodeAlert("Enter OTP first")
        }else{
            KAppDelegate.showActivityIndicator()
            let credential = PhoneAuthProvider.provider().credential(
                withVerificationID: verificationID!,
                verificationCode: txtfldEnterOTP.text!)
            Auth.auth().signIn(with: credential) { (user, error) in
                if let error = error {
                    KAppDelegate.hideActivityIndicator()
                    proxy.sharedProxy().displayStatusCodeAlert("\(error.localizedDescription)")
                    return
                }
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().displayStatusCodeAlert("\(user?.displayName ?? "") verification successfully")
                self.formatedStr = (self.userNumber as NSString).replacingOccurrences(of: "+", with: "")
                if self.formatedStr.contains(" ") {
                self.formatedStr = self.formatedStr.replacingOccurrences(of:" ", with: "")
                }
                
                let param = [
                    "contact_no"    : "\(self.formatedStr)" ,
                  
                    ] as [String : Any]
                let verifyNumber = "\(KServerUrl)\(changeMobileNumber)\(profileModel.id)"
                if  reachability?.isReachable  == true {
                    KAppDelegate.showActivityIndicator()
                    let usewrAgent = "\(KMode)\(KAppName)"
                    request(verifyNumber, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                        .responseJSON { response in
                            let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as?
                             NSMutableDictionary
                            print(JSONDIC)
                            do
                            {
                                if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                    KAppDelegate.hideActivityIndicator()
                                    if response.response?.statusCode == 200   {
                                        self.serviceResponse(JSONDIC)
                                        
                                    } else {
                                        KAppDelegate.hideActivityIndicator()
                                        proxy.sharedProxy().stautsHandler(verifyNumber, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                    }
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                                }
                            }
                    }
                } else {
                    KAppDelegate.hideActivityIndicator()
                    proxy.sharedProxy().openSettingApp()
                }
            }
            
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
            } catch let signOutError as NSError {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().displayStatusCodeAlert("Error signing out: \(signOutError.localizedDescription)")
            }
            
        }
    }

}












