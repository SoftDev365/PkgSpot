//
//  DrawerTVC.swift
//  drawer
//
//  Created by Ankit Pahwa on 05/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class DrawerTVC: UITableViewCell {
    
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var imageView1: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
