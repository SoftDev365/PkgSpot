//
//  ProfileModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 31/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
var profileModel = ProfileModel()
class ProfileModel {
    
    var  user_id = Int32()
    var  id = Int32()
    var  userName = String()
    var  zipCode = Int32()
    var  userEmail =  String()
    var  step = Int32()
    var  password = String()
    var  phoneNumber = String()
    var   unique_id   = String()
    var arrLocations = NSArray()
    var customer_id = String()
    var idLocation = String()
    func setUserProfile(dictDetail:NSMutableDictionary){
        if let userName  = dictDetail["full_name"] as? String{
           self.userName = userName
        }
        
        if let  userEmail = dictDetail["email"] as? String {
            self.userEmail =  userEmail
        }
        if let password = dictDetail["password"] as? String{
             self.password =  password
        }
        
        if let zipCode  = dictDetail["zipcode"] as? Int32 {
            self.zipCode = zipCode
            
        }
        if let  id  = dictDetail["id"] as? Int32 {
            self.id = id
            
        }
        
        if let  unique_id   = dictDetail["unique_id"] as? String {
            self.unique_id  = unique_id 
            
        }
        if let  customer_id   = dictDetail["customer_id"] as? String {
             self.customer_id = customer_id
        }
        if let idLocation = dictDetail["location"] as? String {
             self.idLocation = idLocation
        }
    }
    
        
    }
    

