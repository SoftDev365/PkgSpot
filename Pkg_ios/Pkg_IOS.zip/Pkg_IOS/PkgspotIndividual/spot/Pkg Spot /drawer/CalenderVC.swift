//
//  CalenderVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 29/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import FSCalendar

protocol CalenderVCDelegate {
    func datecustomDelegate(date: String)
}

var delegate1 : CalenderVCDelegate?

class CalenderVC: UIViewController, FSCalendarDataSource, FSCalendarDelegate,UIGestureRecognizerDelegate {

  @IBOutlet weak var lblAccountNo: UILabel!
  @IBOutlet weak var lblUserName: UILabel!
  @IBOutlet weak var calender: FSCalendar!
  @IBOutlet weak var vwScroll: UIView!
    // Mark:- Varriable 
    var selectedDates = String()
    var strURL = String()
    
    fileprivate lazy var dateFormatter: DateFormatter = {5
        let formatter = DateFormatter()
        formatter.dateFormat = "MM-dd-yyyy"
        return formatter
    }()
    
    fileprivate lazy var scopeGesture: UIPanGestureRecognizer = {
        [unowned self] in
        let panGesture = UIPanGestureRecognizer(target: self.calendar, action: #selector(self.calender.handleScopeGesture(_:)))
        panGesture.delegate = self
        panGesture.minimumNumberOfTouches = 1
        panGesture.maximumNumberOfTouches = 2
        return panGesture
    }()
 
  override func viewDidLoad() {
    super.viewDidLoad()
    calender.dataSource = self
    calender.delegate = self
    self.calender.select(Date())
    self.view.addGestureRecognizer(self.scopeGesture)

//    strURL = ("\(KServerUrl)\(packageFilterDate)\(profileModel.id)\(selectedDates)")
//    KpackageIndex(strURL: strURL, param: nil)
    
    
  }
  
  //MARK:- IBAction
  @IBAction func btnBackAction(_ sender: Any) {
    self.navigationController?.popViewController(animated: false)
  }
  
  //MARK:- Calender delegate
  func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
    selectedDates = "\(self.dateFormatter.string(from: date))"
    if monthPosition == .previous || monthPosition == .next {
      calendar.setCurrentPage(date, animated: true)
    }
  }
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
          print("\(self.dateFormatter.string(from: calendar.currentPage))")
    }
    
    @IBAction func btnBackPushButtonAction(_ sender: Any) {
        delegate1?.datecustomDelegate(date: selectedDates)
        strURL = ("\(KServerUrl)\(packageFilterDate)\(profileModel.id)\("/")\(selectedDates)")
        KpackageIndex(strURL: strURL, param: nil)

        self.navigationController?.popViewController(animated: false)
    }

    func KpackageIndex(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let arrayDes = responseDict["data"] as? NSArray {
                }
                
            }
            else{
                
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KpackageIndex(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
}
