//
//  extensionClass.swift
//  extensions
//
//  Created by Tajinder Singh on 11/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

extension UITextField
{
    func setLeftImage(_ leftImage: UIImage)
    {
        leftViewMode = .always
        var size : CGSize = leftImage.size
        size.width += 16
        let imgview = UIImageView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(size.width), height: CGFloat(bounds.size.height)))
        imgview.image = leftImage
        imgview.contentMode = .center
        leftView = imgview
    }
}


