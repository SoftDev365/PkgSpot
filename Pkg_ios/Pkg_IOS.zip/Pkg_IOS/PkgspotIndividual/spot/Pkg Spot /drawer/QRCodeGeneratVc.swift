//
//  QRCodeGeneratVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 12/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Alamofire


class QRCodeGeneratVc: UIViewController ,UITextFieldDelegate{
        //Mark:- Outlet
    @IBOutlet weak var imgVwQRCode: UIImageView!
    @IBOutlet weak var vwQrcode: UIView!
    @IBOutlet weak var txtFldQrCode: UITextField!
    @IBOutlet weak var lblAdress: UILabel!
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var lblQRCodeLink: UILabel!
    //Mark:- Varriable
    var qrCode = String()
    var address = String()
    var businessName = String()
    var zipCode = String()
    var strcity = String()
    var country = String()
    var messages = String ()
    var stateName =  String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldQrCode.delegate = self
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true
        self.navigationController?.isNavigationBarHidden = true
        txtFldQrCode.text = qrCode
        //lblQRCodeLink.text = "pkgspot://)"
        generateQRCode(strQRCode: qrCode)
         fetchProfile()
        // Do any additional setup after loading the view.
    }
    @IBAction func btnBackAction(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()

    }
    
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @available(iOS 10.0, *)
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        qrCode = txtFldQrCode.text!
        if let qrCodeString = txtFldQrCode.text {
            if txtFldQrCode.isBlank {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter QR code")
            }else if !(txtFldQrCode.text == qrCode) {
                proxy.sharedProxy().displayStatusCodeAlert("Qr code not matched")
            }else {
                generateQRCode(strQRCode: qrCodeString)
            
            }
        }

    }
    
    func generateQRCode(strQRCode:String){
        let data = strQRCode.data(using: .ascii, allowLossyConversion: false)
        let filter = CIFilter(name: "CIQRCodeGenerator")
        filter?.setValue(data, forKey: "inputMessage")
        let img = UIImage(ciImage: (filter?.outputImage)!)
        imgVwQRCode.image = img
    }
    
      //MARK Post Qrcode get Data Partner Api
        func fetchProfile(){
            
            let param = [
                 "qr_code"     : txtFldQrCode.text!]
                let creatAccount = "\(KServerUrl)\(getInfo)"
                if  reachability?.isReachable  == true {
                    KAppDelegate.showActivityIndicator()
                    let usewrAgent = "\(KMode)\(KAppName)"
                    request(creatAccount, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                        .responseJSON { response in
                            let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                            
                            do
                            {
                                if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                    KAppDelegate.hideActivityIndicator()
                                    if response.response?.statusCode == 200   {
                                        self.serviceResponse(JSONDIC)
                                        
                                    } else {
                                        KAppDelegate.hideActivityIndicator()
                                        proxy.sharedProxy().stautsHandler(creatAccount, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                    }
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().displayStatusCodeAlert("Server: Not responding ")
                                }
                            }
                    }
                } else {
                    KAppDelegate.hideActivityIndicator()
                    proxy.sharedProxy().openSettingApp()
                }
            }
            
            
            
            func serviceResponse(_ JSON:NSMutableDictionary) {
                KAppDelegate.hideActivityIndicator()
              
                    if JSON["status"] as! Int == 200 {
                     if let data = JSON["data"] as? NSArray{
                        if let dictData = data.firstObject as? NSDictionary{
                            
                            if let adress = dictData["address"] as? String{
                                address = adress
                            }
                            if let business_name = dictData["business_name"] as? String{
                                businessName = business_name
                            }
                            if let city = dictData["city"] as? String{
                                strcity = city
                            }
                            if let zipcode = dictData["zipcode"] as? String{
                                zipCode = zipcode
                            }
                            if let state = dictData["state"] as? String{
                                stateName = state
                            }

                            if let marketing_message = dictData["marketing_message"] as? String{
                                messages = marketing_message
                            }
                             lblMsg.text = "\(messages)"
                             lblAdress.text = "\(businessName)\n\(address)\n\(strcity)\n\(stateName)\n\(zipCode)"
                        }
                      }
                   }
                    else
                    {
                        if let errorMessage = JSON["error"] {
                            proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
       }
 }

