//
//  AddNewCardVC.swift
//  drawer
//
//  Created by Tajinder Singh on 15/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire
import Stripe
import IQKeyboardManagerSwift

class AddNewCardVC: UIViewController,UITextFieldDelegate,MonthYearPickerViewDelegate{
    
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldCardNumber: UITextField!
    @IBOutlet weak var txtFlddate: UITextField!
    @IBOutlet weak var imgViewCardNo: UIImageView!
    
    
    var strYear = String()
    var strMonth = String()
    var monthYearDatePicker = MonthYearPickerView()

    let limitLength = 16
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldName.attributedPlaceholder = NSAttributedString(string: "Name on Card", attributes: [NSForegroundColorAttributeName: UIColor.gray
            ])
        txtFldCardNumber.attributedPlaceholder = NSAttributedString(string: "Card Number", attributes: [NSForegroundColorAttributeName: UIColor.gray])
        
        txtFlddate.attributedPlaceholder = NSAttributedString(string: "MM/YY", attributes: [NSForegroundColorAttributeName: UIColor.gray])
                protocolMonthYearPickerView = self
        }
    
    @IBAction func btnActionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func txtFldActionDatePic(_ sender: UITextField) {
        sender.inputView = monthYearDatePicker
    }
    
       func datePickerValueChanged(sender:UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        
        dateFormatter.dateFormat =   "MM/yyyy"
        txtFlddate.text = dateFormatter.string(from: sender.date)
        
        let monthFormatter = DateFormatter()
        monthFormatter.dateFormat =   "MM"
        strMonth = monthFormatter.string(from: sender.date)
        
        monthFormatter.dateFormat =   "yyyy"
        let calendar = Calendar.current
        let year = calendar.component(.year, from: sender.date)
        strYear = "\(year)"
    }
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        //        guard let text = textField.text else { return true }
        //        let newLength = text.characters.count + string.characters.count - range.length
        //        return newLength <= limitLength
        //
        
        if textField == txtFldCardNumber {
            let length = txtFldCardNumber.text!.characters.count + string.characters.count - range.length
            if length >= 16 {
                if length == 16 {
                    let cardBrand = STPCardValidator.brand(forNumber: txtFldCardNumber.text!)
                    let cardImage = STPImageLibrary.brandImage(for: cardBrand)
                    
                    imgViewCardNo.image = cardImage
                }
                if string != "" {
                    if length == 17 {
                        return false
                    }
                    else{
                        return true
                    }
                }
                else {
                    imgViewCardNo.image = UIImage(named:  "")
                    return true
                }
            } else
            {
                imgViewCardNo.image = #imageLiteral(resourceName: "icnCard")
                return true
            }
        }
        return true
        
           
    }
    
    
    @IBAction func btnActionAddCard(_ sender: Any) {
        
        IQKeyboardManager.sharedManager().resignFirstResponder()
        let whitespaceSet = NSCharacterSet.whitespaces
        if txtFldCardNumber.text!.isEmpty() {
            imgViewCardNo.image = #imageLiteral(resourceName: "icnCard")
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Card Number")
        } else  if txtFldCardNumber.text!.characters.count != 16 {
            imgViewCardNo.image = #imageLiteral(resourceName: "icnCard")
            proxy.sharedProxy().displayStatusCodeAlert("incorrect card Number")
        }  else if txtFlddate.text!.isEmpty() {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Exp. Date")
        } else if txtFldName.text!.isEmpty() {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
        }else {
            if txtFldCardNumber.text!.trimmingCharacters(in: whitespaceSet) != "" {
                
                let stripCard = STPCardParams()
                
                // Split the expiration date to extract Month & Year
                
                stripCard.number = self.txtFldCardNumber.text!.trimmingCharacters(in: whitespaceSet)
                stripCard.expMonth = UInt(strMonth)!
                stripCard.expYear = UInt(strYear)!
                stripCard.name = String(txtFldName.text!.trimmingCharacters(in: whitespaceSet))!
                KAppDelegate.showActivityIndicator()
                
                STPAPIClient.shared().createToken(withCard: stripCard, completion: { (token, error) -> Void in
                    
                    if error != nil {
                        self.handleError(error! as NSError)
                        return
                    }else{
                        self.addNewCard(strToken: token!)
                        
                    }
                    
                    
                })
            } else {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter valid card details")
            }
        }
          proxy.sharedProxy().displayStatusCodeAlert("Credit Card UpDate Successfully")
    }
    
    
    // MARK : Method error Handler .
    func handleError(_ error: NSError) {
        KAppDelegate.hideActivityIndicator()
        UIAlertView(title: "In valid card number Please Try Again",
                    message: error.localizedDescription,
                    delegate: nil,
                    cancelButtonTitle: "OK").show()
    }
    
    
    func addNewCard(strToken:STPToken) {
        let userId = profileModel.id
        let param = [
            "number" :   "\(strToken.tokenId)",
            "customer_id" : "\(userProperProfileModel.customer_id)",
            ] as [String : Any]
        let newCardUrl = "\(KServerUrl)\(KUpDateCreditCard)\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            // let usewrAgent = "\(KMode)\(KAppName)"
            request(newCardUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponseAddNewCard(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(newCardUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding!")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }

    
    func serviceResponseAddNewCard(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KUpDateCreditCard)\(profileModel.id)") {
            if JSON["status"] as! Int == 200 {
                self.navigationController?.popViewController(animated: true)
           }
        }
        else
        {
            
            if let errorMessage =   JSON["error"] as? String{
                if proxy.sharedProxy().checkStringIfNull(errorMessage).characters.count > 0{
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage )
                }
            }
       }
    }
    
    func selectedMonthYear( month: Int,  year: Int){
        txtFlddate.text = "\(month)/\(year)"
        strMonth = "\(month)"
        strYear = "\(year)"
    }

   }
