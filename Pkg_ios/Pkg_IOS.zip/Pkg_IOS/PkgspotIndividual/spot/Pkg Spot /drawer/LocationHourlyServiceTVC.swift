//
//  LocationHourlyServiceTVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 28/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class LocationHourlyServiceTVC: UITableViewCell {

  @IBOutlet weak var btnDay: SetCornerButton!
  
    @IBOutlet weak var lblStartTime: UILabel!
  
    @IBOutlet weak var lblEndTime: UILabel!
  
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
