//
//  AddYourphoneNumberVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 22/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import CountryPicker
import FirebaseAuth



class AddYourphoneNumberVc: UIViewController,UITextFieldDelegate,CountryPickerDelegate{
  
  var  countryPicker = CountryPicker()
  var   getId =  Int()

  
  @IBOutlet weak var lblPhoneCode: UILabel!
  @IBOutlet weak var txtfldPhoneCode: UITextField!
  @IBOutlet weak var txtfldPhoneNo: UITextField!
  override func viewDidLoad() {
    super.viewDidLoad()

    let locale = Locale.current
    let code = (locale as NSLocale).object(forKey: NSLocale.Key.countryCode) as! String?
    countryPicker.countryPickerDelegate = self
    countryPicker.showPhoneNumbers = true
    countryPicker.setCountry(code!)
    txtfldPhoneCode.inputView = countryPicker
     }
   @IBAction func btnBack(_ sender: UIButton) {
    _ = self.navigationController?.popViewController(animated: true)
  }
    override func viewWillAppear(_ animated: Bool) {
    self.navigationController?.isNavigationBarHidden = true
    IQKeyboardManager.sharedManager().enable = true
  }
   //MARK:- picker view delegate
  func countryPhoneCodePicker(_ picker: CountryPicker, didSelectCountryWithName name: String, countryCode: String, phoneCode: String, flag: UIImage) {
    txtfldPhoneCode.text = name
    lblPhoneCode.text = phoneCode
  }
  
   @IBAction func btnNext(_ sender: Any) {
        if (txtfldPhoneNo.text?.isEmpty)! || (lblPhoneCode.text?.isEmpty)! {
      proxy.sharedProxy().displayStatusCodeAlert("Please enter PhoneNumber and Country Code")
    }else{
      let firebaseAuth = Auth.auth()
      KAppDelegate.showActivityIndicator()
      do {
        try firebaseAuth.signOut()
        PhoneAuthProvider.provider().verifyPhoneNumber("\(lblPhoneCode.text!)\(txtfldPhoneNo.text!)") { (verificationID, error) in
          
          if error != nil {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().displayStatusCodeAlert("The format of the phone number provided is incorrect")
            return
          }
          KAppDelegate.hideActivityIndicator()
          UserDefaults.standard.set(verificationID, forKey: "authVerificationID")
          let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"OtpCodeVc") as! OtpCodeVc
            otpCodeVc.comeId = self.getId
            otpCodeVc.userNumber = "\(self.lblPhoneCode.text!) \(self.txtfldPhoneNo.text!)"
          self.navigationController?.pushViewController(otpCodeVc,animated: true)
        }
      } catch let signOutError as NSError {
        KAppDelegate.hideActivityIndicator()
        proxy.sharedProxy().displayStatusCodeAlert("Error signing out: \(signOutError.localizedDescription)")
      }
    }
  }
}










