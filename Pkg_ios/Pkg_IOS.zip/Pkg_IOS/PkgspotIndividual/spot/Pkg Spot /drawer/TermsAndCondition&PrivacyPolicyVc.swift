//
//  TermsAndCondition&PrivacyPolicyVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 22/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class TermsAndCondition_PrivacyPolicyVc: UIViewController,UIWebViewDelegate
 {
    
    @IBOutlet weak var webVw: UIWebView!
    @IBOutlet weak var lblTitle: UILabel!
    var selectedValue = ""
    var descriptionStr = ""
     var strURL = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        strURL = "\(KServerUrl)\(KPrivacyPolicy)\(selectedValue)"
        KSignUpTermsStep3(strURL: strURL, param: nil)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
      func KSignUpTermsStep3(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let arrayDes = responseDict["data"] as? NSArray {
                
                    let getDic = arrayDes[0] as! NSDictionary
                    self.lblTitle.text = getDic["title"] as! String
                    if let descript = getDic["description"] as? String {
                       
                        self.webVw.loadHTMLString(descript as String, baseURL: nil)
                        self.webVw.delegate = self 
                   }
                }
            }
            else{
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KSignUpTermsStep3(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)

        
    }
    
}
