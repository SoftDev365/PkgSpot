

import UIKit
import FSCalendar

protocol CalanderDateSelectedDelegate {
    func calanderDateSelected(arrReceived: [RecievedPackageModel])
}

var protocolCalender: CalanderDateSelectedDelegate?

class MyStorePkgCalanderViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate,FSCalendarDelegateAppearance {
   
    //MARK:- OUTLETS
    @IBOutlet weak var calender: FSCalendar!
    var arrayPackages = [RecievedPackageModel]()
    var dateSecectArray = NSMutableArray()
    var CurrentDate = String()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        calender.dataSource = self
        calender.delegate = self
        calender.reloadData()
    }

    //MARK:- Calender delegate
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let result = formatter.string(from: date)
        print(result)
        
        let strURL = "\(KServerUrl)\(packageFilterDate)\(profileModel.id)/\(result)"
        filterCalendar(strURL: strURL, param: nil)
        
    }
    
    //MARK:- Hide Calender On Tap Any Where
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillDefaultColorFor date: Date) -> UIColor? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        CurrentDate = formatter.string(from: date)
        
        if dateSecectArray.contains(CurrentDate) {
            return UIColor.gray
        }
        else if date == calender.today {
            return UIColor.blue
        }
        else {
            return UIColor.clear
        }
  
    }
    
    //MARK: - Get Webservice Response
    func filterCalendar(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200){
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray{
                    for i in 0..<arr.count{
                        if let dict = arr[i] as? NSDictionary {
                            let packageDetials = RecievedPackageModel()
                            let mutatedDic = dict.mutableCopy() as! NSMutableDictionary
                            packageDetials.setUserPackageDetial(dictDetail: mutatedDic)
                            self.arrayPackages.append(packageDetials)
                        }
                    }
                    self.dismiss(animated: true, completion: {
                        protocolCalender?.calanderDateSelected(arrReceived: self.arrayPackages)
                    })
                }
            }else{
                
                if let error = responseDict.object(forKey: "error")as? String{
                    proxy.sharedProxy().displayStatusCodeAlert(error)
                    self.dismiss(animated: true, completion: {
                        protocolCalender?.calanderDateSelected(arrReceived: self.arrayPackages)
                    })
                }
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.filterCalendar(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}

