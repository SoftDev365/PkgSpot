//
//  CustomerCardDetials.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 18/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
class  CustomerCardDetials{
    
 var  exp_month = Int32()
 var  exp_year = Int32()
 var  id = String()
 var  last4 = String()


func getUserCardDetials(dictDetail:NSMutableDictionary){
    
    if let exp_month  = dictDetail["exp_month"] as? Int32{
        self.exp_month = exp_month
        }
    if let exp_year  = dictDetail["exp_year"] as? Int32{
        self.exp_year = exp_year
      }
    if let id  = dictDetail["id"] as? String{
        self.id = id
    }
    if let last4  = dictDetail["last4"] as? String{
        self.last4 = last4
         
    }
}
}

