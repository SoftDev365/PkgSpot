//
//  UserAddressModel.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 06/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation
let  userAddressObj = UserAddressModel()
class UserAddressModel {
    var  address  = String()
    var  city = String()
    var  unique_id = String()
    var  country = String()
    var  userUniqueId = Int32()
    var  zipcode  = String()
    var  State  = String()
    
    func setUserAddress(dictDetail:NSMutableDictionary){
        if let city = dictDetail["city"] as? String {
            self.city = city
        }
        if let country = dictDetail["country"] as? String{
            self.country =  country
        }
        
        if let address  = dictDetail["address"] as? String {
            self.address = address
            
        }
        if let  unique_id  = dictDetail["unique_id"] as? String {
            self.unique_id = unique_id
       }
        
        if let  zipcode  = dictDetail["zipcode"] as? String {
            self.zipcode = zipcode
        }
        
        if let  state  = dictDetail["state"] as? String {
            self.State = state
        }
    }
}
    

