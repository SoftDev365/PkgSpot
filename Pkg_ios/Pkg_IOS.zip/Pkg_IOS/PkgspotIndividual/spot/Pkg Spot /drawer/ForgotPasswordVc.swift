//
//  ForgotPasswordVc.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 19/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class ForgotPasswordVc: UIViewController {

    @IBOutlet weak var txtFldEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFldEmail.attributedPlaceholder = NSAttributedString(string: "Your Email Address ", attributes: [NSForegroundColorAttributeName: UIColor.gray
            ])

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
    self.navigationController?.popViewController(animated: true)

    }
    
    
    
    @IBAction func btnForgotPaaswordSubmitAction(_ sender: Any) {
        
       if txtFldEmail.text!.isEmpty{
            proxy.sharedProxy().displayStatusCodeAlert("Please Enter Email")
            return
        }
        else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please Enter Valid Email")
            return
        }
        else{
           // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
            let ForgotPasswordUrl = "\(KServerUrl)\(KForgotPassword)"
            let param = [
                
                "email":"\(txtFldEmail.text!)"
            ]
             
            if  (reachability?.isReachable)!
            {
                KAppDelegate.showActivityIndicator()

                request(ForgotPasswordUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody , headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                 .responseJSON { response in
                       do
                        {
                            KAppDelegate.hideActivityIndicator()
                           if response.data != nil && response.result.error == nil {
                            
                            
                                if(response.response?.statusCode == 200)
                                {
                                    
                                   if let JSONDIC = response.result.value as? NSDictionary{
                                       self.serviceResponse(JSONDIC.mutableCopy() as! NSMutableDictionary)
                                    }else {
                                       proxy.sharedProxy().displayStatusCodeAlert("Internet Problem Please Try Again")
                                    }
                               } else {
                                   KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(ForgotPasswordUrl, parameter: nil, response: response.response, data: response.data as Data? , error: response.result.error as NSError?)
                                }
                           } else {
                               KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Connectivity Problem")
                           }
                        }
                }
           } else {                proxy.sharedProxy().openSettingApp()
            }
       }
    }
    
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KForgotPassword)") {
       
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        if let email = dic ["email"] as? String{
                            let userEmail = email
               
                            
                            let submitOtpVc = self.storyboard?.instantiateViewController(withIdentifier:"SubmitOtpNumberVc") as! SubmitOtpNumberVc
                            submitOtpVc.userVerifyEmail = userEmail
                            self.navigationController?.pushViewController(submitOtpVc,animated: true)
                            
 
                        }
                        
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
    

}

    
    
    
    




