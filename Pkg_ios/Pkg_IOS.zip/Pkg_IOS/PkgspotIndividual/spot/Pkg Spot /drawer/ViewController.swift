//
//  ViewController.swift
//  drawer
//
//  Created by Tajinder Singh on 23/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblAccountNubber: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var arrUpdatePartner = [UpdatePartnerLocation]()
    let arrayimages = ["DrawerMyPackage", "ic_map_location_b", "DrawerMyAccount", "DrawerHelp", "DrawerLogout"]
    let arraycellimages = ["MyLocation", "ic_add"]
    let array1 = ["My Packages", "Locations", "My Account", "Help", "Log Out"]
    
    // var arrRows = [[],["My Location","Add New Location"],[], [],[]]
    var arrRows = [Any]()
    var totalArrray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        initTableView()
        getMyUserLocation()
    }
    
    
    @IBAction func btnCanncelAction(_ sender: Any) {
        KAppDelegate.sideMenuVC.changeLeftViewController(KAppDelegate.sideMenuVC.leftViewController!, closeLeft: true)
    }
    
    
    func initTableView(){
        for i in 0 ..< 5{
            if i == 1 {
                let modalMyLocation = UpdatePartnerLocation()
                modalMyLocation.business_name = "My Locations"
                let modalAddLocation =  UpdatePartnerLocation()
                modalAddLocation.business_name = "Add new location"

                if arrUpdatePartner.count > 0 {
                    arrRows.append([modalMyLocation,modalAddLocation])

                }else{
                    arrRows.append([modalAddLocation])

                }
            }else{
                arrRows.append([])
            }
        }
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if  let name = UserDefaults.standard.object(forKey: kUserName) as? String {
            lblUserName.text = name
        }else{
            lblUserName.text = userProperProfileModel.fullName
        }
          if let accountNumber = UserDefaults.standard.object(forKey: kAccountName) as? String{
            lblAccountNubber.text = "Account # " + accountNumber
        }else{
            lblAccountNubber.text = "Account # \(userProperProfileModel.accountNumber)"
        }
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return array1.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //  if totalArrray.contains(section) {
        if arrRows.count > 0 {
            return (arrRows[section] as! NSArray).count
        }
        //  }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cellAddress", for: indexPath) as! DrawerTVC
        let arrData = arrRows[indexPath.section] as! NSArray
        if indexPath.row == arrData.count - 1{
            cell.imageView1.image = UIImage(named: "ic_add")
        }else if indexPath.row == 0 {
            cell.imageView1.image = UIImage(named: "MyLocation")
        }else{
            cell.imageView1.image = #imageLiteral(resourceName: "DrawerLocation")
        }
        cell.imageView1.contentMode = .scaleAspectFit
        cell.imageView1.clipsToBounds = true
        let modal = (arrRows[indexPath.section] as! NSArray).object(at: indexPath.row) as! UpdatePartnerLocation
        if modal.business_name == "" {
            let strData = (modal.address)
            cell.lblAddress.text = strData
        }else{
            let strData = "\(modal.business_name)\n\(modal.address)"
            cell.lblAddress.text = strData
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view1 = UIView.init()
        let label = UILabel()
        label.frame = CGRect(x: 58, y: 5, width: 200, height: 20)
        label.text = array1[section]
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(clickedSection(_:)))
        tapGesture.accessibilityHint = String(section)
        
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 20, y: 5, width: 20, height: 20)
        image.image = UIImage(named: arrayimages[section])
        view1.addSubview(image)
        view1.addSubview(label)
        view1.addGestureRecognizer(tapGesture)
        self.tableView.backgroundColor = UIColor.clear
        return view1
    }
    
    func clickedSection(_ sender: UITapGestureRecognizer) -> Void {
        let section : Int = Int(sender.accessibilityHint!)!
        switch section {
        case 0:
            KAppDelegate.gotoMyPackagesScreen()
            break
        case 1:
            break
            //            if totalArrray.contains(section) {
            //                 totalArrray.remove(section)
            //            } else {
            //                totalArrray.add(section)
            //            }
        // tableView.reloadData()
        case 2:
            KAppDelegate.gotoMyAccountScreen()
            // getMyAccountDetail()
            break
        case 3:
            KAppDelegate.gotoHelpViewController()
            break
        case 4:
            logOut()
            break
        default:
            break
        }
    }
    
    func logOut() {
        // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
        let logoutURL = "\(KServerUrl)\(KLogout)"
        if  reachability!.isReachable {
            KAppDelegate.showActivityIndicator()
            request(logoutURL, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do  {
                        KAppDelegate.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary {
                            if (JSON["status"]! as AnyObject).isEqual(200) {
                                UserDefaults.standard.set("", forKey: "auth_code")
                                UserDefaults.standard.synchronize()
                                KAppDelegate.gotoSelectionVC()
                                proxy.sharedProxy().displayStatusCodeAlert("You are Logged Out Successfully")
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(logoutURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                    }
            }
        }
    }
    
    //Mark: UserLocation Api
    func getMyUserLocation(){
        let contentUrl = "\(KServerUrl)\(KMylocation)" + "/\(profileModel.id)"
        if  reachability?.isReachable  == true {
            // KAppDelegate.showActivityIndicator()
            request(contentUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 || response.response?.statusCode == 1000  {
                            if let JSON = response.result.value as? NSDictionary{
                                self.serviceResponseMyLocation(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().stautsHandler(contentUrl, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                        }
                    } else {
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().openSettingApp()
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponseMyLocation(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()

        if JSON["status"] as! Int == 200 {
            // IQKeyboardManager.sharedManager().resignFirstResponder()
            if  let data = JSON["data"] as? NSArray {
                arrUpdatePartner.removeAll()
                
                for i in 0..<data.count {
                    if let dic = data[i] as? NSDictionary {
                        let mutatedDic = dic.mutableCopy() as! NSMutableDictionary
                        let partnerLocation =  UpdatePartnerLocation()
                        partnerLocation.setUpdatePartnerLocation(dictDetail: mutatedDic)
                        arrUpdatePartner.append(partnerLocation)
                        
                    }
                }
                arrRows.removeAll()
                
                for i in 0 ..< 5{
                    if i == 1 {
                        var arrData = [Any]()
                        let modalMyLocation = UpdatePartnerLocation()
                        modalMyLocation.business_name = "My Locations"
                        let modalAddLocation =  UpdatePartnerLocation()
                        arrData.append(modalMyLocation)
//                        for i in 0 ..< arrUpdatePartner.count {
//                            let modal = arrUpdatePartner[i]
//                            arrData.append(modal)
//                        }
                        modalAddLocation.business_name = "Add new location"
                        arrData.append(modalAddLocation)
                        arrRows.append(arrData)
                    }else{
                        arrRows.append([])
                    }
                }
                tableView.reloadData()
            }
            
        }
        else
        {
            if let errorMessage = JSON["error"] {
                // proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
            }
            initTableView()
        }
    }
    
    
    
    //MARK : - TABLE VIEW DELEGATE AND DATASOURCE.
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if arrRows.count > 0  {
            let arrData = arrRows[indexPath.section] as! NSArray
            if arrData.count > 0 {
                if arrUpdatePartner.count == 0 {
                    let findLocationVc = self.storyboard?.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
                    let snapNav = KAppDelegate.sideMenuVC.mainViewController as! UINavigationController
                    findLocationVc.getId = 1
                    snapNav.pushViewController(findLocationVc, animated: true)
                    partnerAdressLocation = PartnerDropeDownModel()
                    snapNav.closeLeft()
                    return
                }
                
                if indexPath.row == 0 {
                    KAppDelegate.FindMyLocation()
                } else if indexPath.row == arrData.count - 1{
                    let findLocationVc = self.storyboard?.instantiateViewController(withIdentifier: "FindMyLocationVC") as! FindMyLocationVC
                    let snapNav = KAppDelegate.sideMenuVC.mainViewController as! UINavigationController
                    findLocationVc.getId = 1
                    snapNav.pushViewController(findLocationVc, animated: true)
                    partnerAdressLocation = PartnerDropeDownModel()
                    snapNav.closeLeft()
                    
                }else{
                    KAppDelegate.FindMyLocation()
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 30.0
        let dimensions = UITableViewAutomaticDimension
        return dimensions
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 30
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
