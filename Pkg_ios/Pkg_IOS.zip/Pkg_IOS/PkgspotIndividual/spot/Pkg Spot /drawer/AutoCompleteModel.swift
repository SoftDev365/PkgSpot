//
//  AutoCompleteModel.swift
//  SLYYK
//
//  Created by Shivam Kheterpal on 19/04/16.
//  Copyright © 2016 ToXSL Technologies Pvt Ltd. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation


class AutoCompleteModel: NSObject
{
    
    var descriptionName = String()
    var placeId = String()
    var zipCode  = String()
    var locationCoordinate = CLLocationCoordinate2D()
    
    
}

