//
//  HelpViewController.swift
//  IndividualLoginMobile
//
//  Created by Rajat Duggal on 23/08/17.
//  Copyright © 2017 Rajat Duggal. All rights reserved.
//

import UIKit
import Alamofire
import MessageUI

class HelpViewController: UIViewController, UITableViewDataSource, UITableViewDelegate , MFMailComposeViewControllerDelegate {
    
  @IBOutlet weak var tblvwHelp: UITableView!
  
  // let arrSection = ["How is my price determined?","Can I get my order sooner?","What file format should I submit?","Do order have a per size minimum?", "What is the minimum order quantity?","How long is the turnaround time?"]
    var arrayHelpDetailModel = [HelpDetailModel]()
    var count : Int = 0
    var  BoolArr = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
     self.navigationController?.navigationBar.isHidden=true
     
      tblvwHelp.dataSource = self
      tblvwHelp.delegate = self
      tblvwHelp.reloadData()
        if !MFMailComposeViewController.canSendMail() {
              print("Mail services are not available")
            return
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getHelpDetail()
    }

  
  //MARK:- action
  
  @IBAction func btnContactUsAction(_ sender: Any) {
    if !MFMailComposeViewController.canSendMail() {
          print("Mail services are not available")
        return
    }else{
    let composeVC = MFMailComposeViewController()
    composeVC.mailComposeDelegate = self
    
    // Configure the fields of the interface.
    composeVC.setToRecipients(["info@pkgspot.com"])
    composeVC.setSubject("")
    composeVC.setMessageBody("", isHTML: false)
    
    // Present the view controller modally.
    self.present(composeVC, animated: true, completion: nil)
    }
    
  }
  @IBAction func btnActionOpenDrawer(_ sender: UIButton) {
    KAppDelegate.sideMenuVC.openLeft()
  }
  
  
  
  //MARK:- tableviewDelegate and datasource
  func numberOfSections(in tableView: UITableView) -> Int {
    return arrayHelpDetailModel.count
  }
  
  func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    return 40
  }

  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    tableView.estimatedRowHeight = 44.0
    return UITableViewAutomaticDimension
  }
    
   

  func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    let vwHeader = UIView()
    vwHeader.layer.cornerRadius = 5
    vwHeader.clipsToBounds = true
    vwHeader.backgroundColor = UIColor.white
    
    let screenSize: CGRect = UIScreen.main.bounds
    
    let title  = UILabel(frame: CGRect(x: 8, y: 7, width:self.view.frame.size.width - 60, height: 33))
    title.font = UIFont(name:"HelveticaNeue", size: 13.5)
    let helpDetailObj = arrayHelpDetailModel[section]
    title.text = helpDetailObj.title
    //title.text = arrSection[section]
    title.numberOfLines = 0
    title.textColor = UIColor.black
    vwHeader.addSubview(title)
    
    let imgvwGratr = UIImageView()
    imgvwGratr.frame = CGRect(x:self.view.frame.size.width - 60, y: 15, width: 15 , height: 15)
    if BoolArr.contains(section) {
        imgvwGratr.image = #imageLiteral(resourceName: "ic-minus-")
    }else{
        imgvwGratr.image = #imageLiteral(resourceName: "ic_add_b")
    }
    vwHeader.addSubview(imgvwGratr)
    
    let lblLine  = UILabel(frame: CGRect(x: 0, y: 39, width: tblvwHelp.frame.width, height: 0.6))
    lblLine.backgroundColor = UIColor.black.withAlphaComponent(0.3)
    vwHeader.addSubview(lblLine)
    
    let btnHeader = UIButton(frame: CGRect(x: 0, y: 0, width: screenSize.width * 0.95, height: 210))
    btnHeader.titleLabel?.font = btnHeader.titleLabel?.font.withSize(14)
    btnHeader.contentHorizontalAlignment = UIControlContentHorizontalAlignment.left
    btnHeader.accessibilityHint = String(section)
    btnHeader.addTarget(self, action: #selector(HelpViewController.expandOptions(_:)), for: .touchUpInside)
    vwHeader.addSubview(btnHeader)
    return vwHeader
    }
  
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
 
    if BoolArr.contains(section) {
        return 1
    }
    return 0
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "cellHelp") as! HelpVcCell
      let helpDetailObj = arrayHelpDetailModel[indexPath.section]
      cell.lblDiscriptionDetail.text = helpDetailObj.descriptionTitle
    return cell
  }
  
    //MARK: - MFMAILCOMPOSER DELEGATE
    
    func mailComposeController(_ controller: MFMailComposeViewController,
                               didFinishWith result: MFMailComposeResult, error: Error?) {
        // Check the result or perform other tasks.
        
        // Dismiss the mail compose view controller.
        controller.dismiss(animated: true, completion: nil)
    }

    
  //MARK:- header Expand
  
  func expandOptions(_ sender : UIButton) {
    let section : Int = Int(sender.accessibilityHint!)!
    if BoolArr.contains(section) {
        BoolArr.remove(section)
    } else {
        BoolArr.add(section)
    }
    tblvwHelp.reloadData()
    }
    
    //MARK:- Help API
    
    func getHelpDetail() {
        let heplUrl = "\(KServerUrl)\(KHelpPage)"
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
           // let usewrAgent = "\(KMode)\(KAppName)"
            request(heplUrl, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                  
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponseHelp(JSONDIC)
                              
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(heplUrl, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not Responding")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponseHelp(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        arrayHelpDetailModel.removeAll()
        if (JSON["url"]! as AnyObject).isEqual ("\(KHelpPage)") {
          
            if JSON["status"] as! Int == 200 {
             
                if  let data = JSON["data"] as? NSArray {
                    for i in 0..<data.count {
                        let dic = data[i] as? NSDictionary
                        let getHelpDetailModel = HelpDetailModel()
                        let mutatedDic = dic?.mutableCopy() as! NSMutableDictionary
                        getHelpDetailModel.setUserInfo(dictDetail: mutatedDic)
                        self.arrayHelpDetailModel.append(getHelpDetailModel)
                    }
                    
                    for _ in 0..<arrayHelpDetailModel.count {
                        BoolArr.add("0")
                    }
                    tblvwHelp.reloadData()
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
  
}
extension HelpViewController : SlideMenuControllerDelegate {
  
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
  
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
}


