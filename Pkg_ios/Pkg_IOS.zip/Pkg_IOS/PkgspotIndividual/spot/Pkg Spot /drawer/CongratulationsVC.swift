//
//  CongratulationsVC.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class CongratulationsVC: UIViewController {
    
    //MARK: - VARIABLE
    var currentLocation = LocationModel()
    var userUnique = String()
    var userName = String()
    
    //MAR: - IBOUTLET
    @IBOutlet weak var btnNext: SetCornerButton!
    @IBOutlet weak var lblPkgSpotNumber: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchProfile()
        
        
    }
    // Mark :- Button Action
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        completeSingUp()     }
    
    // MARK Complete SignUp  Api
    func completeSingUp() {
        let userId = profileModel.id
        let creatAccount = "\(KServerUrl)\(completSignUp)\(userId)"
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .post, parameters: nil, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                 
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                        
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Server: Not responding ")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(completSignUp)\(profileModel.id)") {
            if JSON["status"] as! Int == 200 {
                
                let ThanksVC = self.storyboard?.instantiateViewController(withIdentifier:"ThanksVC") as! ThanksVC
                self.navigationController?.pushViewController(ThanksVC,animated: true)
                
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
    
    //MARK Fetch Profile Api
       func fetchProfile() {
        let userId = profileModel.id
        let creatAccount = "\(KServerUrl)\(userInfo)\(userId)"
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serResponse(JSONDIC)
                   
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(userInfo)\(profileModel.id)") {
         
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSDictionary {
                    let userUniqueId = data["userUniqueId"] as! String
                         userUnique = userUniqueId
                    let strUserName = data["userName"] as! String
                          userName = strUserName
                    if let location = data["location"] as? NSArray {
                        if location.count>0 {
                            if let dic = location[0] as? NSDictionary {
                                userAddressObj.setUserAddress(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                                let string = userAddressObj.address
                                let separator = "," // A single(!) backslash
                                var address = ""
                                if let range = string.range(of: separator, options: .forcedOrdering) {
                                    let prefix = string.substring(to: range.lowerBound)
                                    address = prefix
                                } else {
                                    address = userAddressObj.address
                                }
                                
                                lblPkgSpotNumber.text = ("Pkg.Spot-\(userUnique)")
                                lblAddress.text = "\(userName)\nPkg.Spot-\(userUnique)\n\(address)\n\(userAddressObj.city)\n\(userAddressObj.State)\(" ")\(userAddressObj.country)\(",")\(" ")\(userAddressObj.zipcode)"
                            }
                        }else{
                            lblPkgSpotNumber.text =   ("Pkg.Spot-\(userUnique)")
                             lblAddress.text = "\(userName)\nlocation Address\nPkg.Spot-\ncity,State\nZipCode"
                        }
                    }
                }
            }
            else
            {
                    lblAddress.text = "location Address\nPkg.Spot-\(10)\ncity,State\nZipCode"
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    }
}






