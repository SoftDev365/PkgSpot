//
//  ViewController.swift
//  IndividualLoginMobile
//
//  Created by Rajat Duggal on 22/08/17.
//  Copyright © 2017 Rajat Duggal. All rights reserved.
//

import UIKit

class MyPackagesScreen: UIViewController {

   
    @IBAction func btnActionOpenDrawer(_ sender: UIButton) {
       
        KAppDelegate.sideMenuVC.openLeft()

    }
    @IBOutlet weak var DatePickerOutLet: UIDatePicker!
    @IBAction func btnActionSortByDate(_ sender: UIButton) {
        DatePickerOutLet.isHidden=false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        DatePickerOutLet.isHidden=true
        self.navigationController?.navigationBar.isHidden=true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


   
}

extension MyPackagesScreen : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
}

