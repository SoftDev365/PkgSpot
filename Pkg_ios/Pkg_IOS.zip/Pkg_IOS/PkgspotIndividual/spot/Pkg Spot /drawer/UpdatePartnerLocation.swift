//
//  UpdatePartnerLocation.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 28/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation

class UpdatePartnerLocation {
    
    var address = String()
    var business_name = String()
    var city = String()
    var country = String()
    var lat = String()
    var long = String()
    var id = Int()
    var days_of_service  = NSArray()
    let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    var dayOfServiceArray = [DaysAndService]()

    
        func setUpdatePartnerLocation(dictDetail:NSMutableDictionary){
            
        if let address  = dictDetail["address"] as? String{
            self.address = address
        }
        if let business_name = dictDetail["business_name"] as? String{
            self.business_name =  business_name
        }
         if let city = dictDetail["city"] as? String {
            self.city = city
            
        }
        if let country = dictDetail["country"] as? String {
            self.country = country
            
        }
            if let lat = dictDetail["latitude"] as? String {
                self.lat = lat
                
            }
            if let long = dictDetail["longitude"] as? String {
                self.long = long
                
            }
            if let id = dictDetail["id"] as? Int {
                self.id = id
                
            }
            
            
            
            if let dayOfService = dictDetail["days_of_service"] as? String{
                // Code used to remove \n and '\'
                let strDaysOfServices = dayOfService.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil)
                let  strdayOfService =  strDaysOfServices.replacingOccurrences(of: "'\'", with: "", options: .literal, range: nil)
                
                if strdayOfService != ""{
                    let data: Data? = strdayOfService.data(using: String.Encoding.utf8)
                    let values:NSArray = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSArray
                    
                    for index in 0..<values.count{
                        let serviceVal = DaysAndService()
                        serviceVal.userData(dictDetail: values[index] as! NSDictionary, index: index)
                        dayOfServiceArray.append(serviceVal)
                    }
                }
            }
       }
  }
