//
//  PackageImagesViewController.swift
//  drawer
//
//  Created by Jaspreet Bhatia on 26/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import SDWebImage
import Alamofire

class PackageImagesViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var CollectionVwImage: UICollectionView!
    
    var packageImages = NSArray()
    var comeFrom = String()
    var packageId = Int()
    var strURL = ""
    
    @IBOutlet weak var webViewBillingPdf: UIWebView!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        CollectionVwImage.delegate = self
        CollectionVwImage.dataSource = self
        CollectionVwImage.reloadData()
        if comeFrom == "PackageImages"{
            webViewBillingPdf.isHidden = true
        }else{
           KAppDelegate.showActivityIndicator()
            CollectionVwImage.isHidden = true
            strURL =  "\(KServerUrl)" + "\(packageImageBilling)" + "\(packageId)"
            var documentsURL : URL!
            let destination: DownloadRequest.DownloadFileDestination = { _, _ in
                 documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                documentsURL.appendPathComponent("invoice(\(Date().timeIntervalSinceNow)).pdf")
                return (documentsURL, [.removePreviousFile])
            }
            Alamofire.download(strURL, to: destination).responseData { response in
                if response.result.isSuccess{
                    KAppDelegate.hideActivityIndicator()
                print("Download completed :",self.strURL)
                    self.webViewBillingPdf.loadRequest(URLRequest(url: documentsURL))
                }
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnCanncelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
  //MARK:- CollectionView Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if comeFrom == "PackageImages"{
        return packageImages.count
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath as IndexPath) as! PackageImagesCollectionViewCell
        if comeFrom == "PackageImages"{
       cell.imgVwPackages.sd_setImage(with: URL(string: packageImages[indexPath.row] as! String), placeholderImage : #imageLiteral(resourceName: "package_Image"))
        }else{
        
        }
        return cell

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CollectionVwImage.bounds.size
       
    }
}
