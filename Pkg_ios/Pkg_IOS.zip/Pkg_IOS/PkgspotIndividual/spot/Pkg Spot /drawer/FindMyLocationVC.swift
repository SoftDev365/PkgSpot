//
//  FindMyLocationVC.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire

class FindMyLocationVC: UIViewController, UITableViewDataSource, UITableViewDelegate,MKMapViewDelegate ,CLLocationManagerDelegate, addressProtocol,LocationHourlyServiceDelegate, ZipCodeDelegate,PartnerLocationDelegate{
    
    //MARK:- Outlets
    @IBOutlet weak var btnLocationIntrecation: UIButton!
    @IBOutlet weak var btnSearchHidden: UIButton!
    @IBOutlet weak var lblStaticLocation: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tblvwLocationList: UITableView!
    @IBOutlet weak var mapvwMyLocation: MKMapView!
    @IBOutlet weak var lblZipCode: UILabel!
    @IBOutlet weak var lbllocationName: UILabel!
    @IBOutlet weak var btnSkip: UIButton!
    @IBOutlet weak var btnNextOutlet: SetCornerButton!
    @IBOutlet weak var btnZipCode: UIButton!
    @IBOutlet weak var lblSelectLocation: UILabel!
    @IBOutlet weak var UserNotFoundVw: UIView!
    @IBOutlet weak var btnHeightConst: NSLayoutConstraint!
    
    @IBOutlet weak var stkVwHidden: UIStackView!
    //MARK:- Varriables
  //  let locationManager = CLLocationManager()
    var location = CLLocationCoordinate2D()
    var keyStringCombine = String()
    var arrayLocationDetials = [LocationModel]()
    var arrayUserUpdateLocation = [UpdatePartnerLocation]()
    var userSelectedLocation = NSMutableArray()
    var currentSelectedModal = LocationModel()
    var arrLocation  = [LocationModel]()
    var arrayPartnerLocation = [PartnerDropeDownModel]()
    var updatingTimer = Timer()
    var comeFrom = String()
    var strURL = ""
    var isFocusAnnotation = Bool()
    var getId = Int()
    var totalAnnotationCount = Int()
    var ComeTo = String()
    var arrydayTime = [DaysAndService]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        keyStringCombine.append("\(profileModel.idLocation)")
        navigationController?.isNavigationBarHidden = true
        zipCodeDelegateObj = self
        partnerLocationDelegateObj = self
        self.mapvwMyLocation.delegate = self
        addressLocProtocol = self
        if comeFrom == "Drawer" {
            getMyUserLocation()
            btnSearchHidden.isUserInteractionEnabled = false
            btnZipCode.isUserInteractionEnabled = false
            btnSearchHidden.isHidden = true
            btnLocationIntrecation.isUserInteractionEnabled = false
            btnNextOutlet.isHidden = true
            btnZipCode.isHidden = true
            stkVwHidden.isHidden = true
            btnHeightConst.constant = 0
            self.navigationController?.isNavigationBarHidden = true
            btnBack.setImage(#imageLiteral(resourceName: "DrawerIcon"), for: .normal)
            lblStaticLocation.text = "My Locations"
            lblSelectLocation.text = "My Locations"
            btnSkip.isHidden = true
            let location = CLLocationCoordinate2D(latitude: 37.773972, longitude: -122.431297)
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            annotation.title = "SanFrancisco"
            lbllocationName.text = "San Francisco, CA, USA"
            let span = MKCoordinateSpanMake(0.05, 0.05)
            let region = MKCoordinateRegion(center: location, span: span)
            mapvwMyLocation.setRegion(region, animated: false)
            lblZipCode.text = "94130"
        }else if getId == 1 {
            btnBack.setImage(#imageLiteral(resourceName: "DrawerIcon"), for: .normal)
            lblStaticLocation.text = "Find My Location"
            lblSelectLocation.text = "Select my Location"
            btnNextOutlet.setTitle("Update", for: .normal)
            btnNextOutlet.setTitleColor(UIColor.white, for: .normal)
            btnSkip.isHidden = true
            btnHeightConst.constant = 50
            let location = CLLocationCoordinate2D(latitude: 37.773972, longitude: -122.431297)
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            annotation.title = "SanFrancisco"
            lbllocationName.text = "San Francisco, CA, USA"
            let span = MKCoordinateSpanMake(0.05, 0.05)
            let region = MKCoordinateRegion(center: location, span: span)
            mapvwMyLocation.setRegion(region, animated: true)
            lblZipCode.text = "94130"
            // nearbyLocations()
            self.setLoaction(lattitude: "37.773972", longitude: "-122.431297", isFocusMap: true, isSetZipCode: false, isShowAddress: false)
            }else{
            btnBack.setImage(#imageLiteral(resourceName: "backarrow"), for: .normal)
            lblStaticLocation.text = "Find My Location"
            lblSelectLocation.text = "Select my Location"
            btnSkip.isHidden = true
            btnNextOutlet.setTitle("Select My Location", for: .normal)
            let location = CLLocationCoordinate2D(latitude: 37.773972, longitude: -122.431297)
            let annotation = MKPointAnnotation()
            annotation.coordinate = location
            annotation.title = "SanFrancisco"
            btnHeightConst.constant = 50
            lbllocationName.text = "San Francisco, CA, USA"
            let span = MKCoordinateSpanMake(0.05, 0.05)
            let region = MKCoordinateRegion(center: location, span: span)
            mapvwMyLocation.setRegion(region, animated: true)
            lblZipCode.text = "94130"
            self.setLoaction(lattitude: "37.773972", longitude: "-122.431297", isFocusMap: true, isSetZipCode: false, isShowAddress: false)

        }
        
    }
    //Mark : - Delegate Function
    func getZipCode(zipcode: LocationModel) {
        lblZipCode.text = zipcode.zipCode
        lbllocationName.text = locationModel.city
        arrayLocationDetials = [zipcode]
        ZipLoaction(lattitude: zipcode.latitude, longitude: zipcode.longitude, isFocusMap: true, isSetZipCode: false, isShowAddress: true)
    }
    
    func getPartnerLocation(partnerAdress: PartnerDropeDownModel) {
        setLoaction(lattitude: partnerAdress.latitude , longitude: partnerAdress.longitude, isFocusMap: true, isSetZipCode: true, isShowAddress: false)
        lbllocationName.text = partnerAdress.city
        locationModel.city = partnerAdress.city
      }
    
    
    //Mark Action  Go to zip code vc
    @IBAction func btnZipCodeAction(_ sender: Any) {
        let  zipCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"ZipCodeVc") as!  ZipCodeVc
        self.present(zipCodeVc, animated: true, completion: nil)
    }
    //Mark Action  Go to Partner vc
    @IBAction func btnLocationDropeDownAction(_ sender: Any) {
        let  partnerLocation = self.storyboard?.instantiateViewController(withIdentifier:"PartnerLocationVc") as!PartnerLocationVc
        //partnerLocation.arrPartnerLocation = arrayPartnerLocation
        self.present(partnerLocation, animated: true, completion: nil)
     }
    
    func  nearBylocTimer ()
    {
        nearbyLocations()
    }
    
    func nearbyLocations() {
        KAppDelegate.hideActivityIndicator()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            setLoaction(lattitude: lat, longitude: long, isFocusMap: false, isSetZipCode: false, isShowAddress: true)
                 } else{
              }
          }
    
    //Mark: PartnerLocation Api
    
    
    func setLoaction(lattitude:String, longitude:String,isFocusMap:Bool,isSetZipCode:Bool,isShowAddress: Bool)  {
        arrLocation.removeAll()
        arrayLocationDetials.removeAll()
        
        let param = [
            "lat": lattitude ,
            "lng" : longitude,
            ] as [String:AnyObject]
        proxy.sharedProxy().postData("\(KServerUrl)\(KPartnerLocation)", params: param, showIndicator: true, completion: { (JSON) in
            if JSON["status"] as! Int == 200 {
                self.UserNotFoundVw.isHidden = true

                if  let data = JSON["data"] as? NSArray {
                    self.arrayLocationDetials.removeAll()
                    for i in 0..<data.count {
                        let dictData = data.object(at: i) as! NSDictionary
                        let locationData = LocationModel()
                        let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
                        mutatedDic.setValue(0, forKey: "isSelected")
                        locationData.setUserLocation(dictDetail: mutatedDic)
                        self.arrayLocationDetials.append(locationData)
                    }
                    
                    var arrGridAnnotationTemp = [MKAnnotation]()
                    for i in 0 ..< self.arrayLocationDetials.count {
                        let modalPartners = self.arrayLocationDetials[i]
                        if modalPartners.latitude != "" && modalPartners.longitude != "" {
                            let annotation = PartnersAnnotation.init(coordinate: CLLocationCoordinate2DMake( Double(modalPartners.latitude)! as CLLocationDegrees, Double(modalPartners.longitude)! as CLLocationDegrees), index: i, name: "", address: modalPartners.address, estimatedDestance: "")
                    
                            self.mapvwMyLocation.addAnnotation(annotation)
                            annotation.title = modalPartners.business_name
                            arrGridAnnotationTemp.append(annotation)
                        }
                    }
                    if isShowAddress{
                        if self.arrayLocationDetials.count > 0{
                            self.lbllocationName.text =  self.arrayLocationDetials[0].city

                            for i in 0 ..< self.arrayLocationDetials.count{
                            let modal = self.arrayLocationDetials[i]
                                if modal.zipCode == self.lblZipCode.text!{
                                    self.lbllocationName.text =  modal.city
                                }
                            }
                        }
                    }
                    
                    
                    if isSetZipCode{
                      
                         if self.arrayLocationDetials.count > 0{
                        self.lblZipCode.text = "\(self.arrayLocationDetials[0].zipCode)"
                        }

                    }
                    
                    self.mapvwMyLocation.showAnnotations(arrGridAnnotationTemp, animated: true)
                    
                }
            } else {
                //  self.UserNotFoundVw.isHidden = false
                if let error = JSON["error"] as? String {
                    let annotationsToRemove = self.mapvwMyLocation.annotations.filter { $0 !== self.mapvwMyLocation.userLocation }
                    self.mapvwMyLocation.removeAnnotations(annotationsToRemove)
                    proxy.sharedProxy().displayStatusCodeAlert(error)
                    self.arrayLocationDetials.removeAll()
                }
            }
            
            self.tblvwLocationList.dataSource = self
            self.tblvwLocationList.delegate = self
            self.tblvwLocationList.reloadData()
            KAppDelegate.hideActivityIndicator()
            
        })
  
    }
    
    
    func ZipLoaction(lattitude:String, longitude:String,isFocusMap:Bool,isSetZipCode:Bool,isShowAddress: Bool)  {
        arrLocation.removeAll()
        arrayLocationDetials.removeAll()
        
        let param = [
            "zipcode": lblZipCode.text,
            "lat": lattitude ,
            "lng" : longitude,
            ] as [String:AnyObject]
        proxy.sharedProxy().postData("\(KServerUrl)\(KPartnerLocation)", params: param, showIndicator: true, completion: { (JSON) in
            if JSON["status"] as! Int == 200 {
                self.UserNotFoundVw.isHidden = true
                
                if  let data = JSON["data"] as? NSArray {
                    self.arrayLocationDetials.removeAll()
                    for i in 0..<data.count {
                        let dictData = data.object(at: i) as! NSDictionary
                        let locationData = LocationModel()
                        let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
                        mutatedDic.setValue(0, forKey: "isSelected")
                        locationData.setUserLocation(dictDetail: mutatedDic)
                        self.arrayLocationDetials.append(locationData)
                    }
                    
                    var arrGridAnnotationTemp = [MKAnnotation]()
                    for i in 0 ..< self.arrayLocationDetials.count {
                        let modalPartners = self.arrayLocationDetials[i]
                        if modalPartners.latitude != "" && modalPartners.longitude != "" {
                            let annotation = PartnersAnnotation.init(coordinate: CLLocationCoordinate2DMake( Double(modalPartners.latitude)! as CLLocationDegrees, Double(modalPartners.longitude)! as CLLocationDegrees), index: i, name: "", address: modalPartners.address, estimatedDestance: "")
                            self.mapvwMyLocation.addAnnotation(annotation)
                            annotation.title = modalPartners.business_name
                            arrGridAnnotationTemp.append(annotation)
                        }
                    }
                    if isShowAddress{
                        if self.arrayLocationDetials.count > 0{
                            self.lbllocationName.text =  self.arrayLocationDetials[0].city
                            
                            for i in 0 ..< self.arrayLocationDetials.count{
                                let modal = self.arrayLocationDetials[i]
                                if modal.zipCode == self.lblZipCode.text!{
                                    self.lbllocationName.text =  modal.city
                                }
                            }
                        }
                    }
                    
                    
                    if isSetZipCode{
                        
                        if self.arrayLocationDetials.count > 0{
                            self.lblZipCode.text = "\(self.arrayLocationDetials[0].zipCode)"
                        }
                        
                    }
                    
                    self.mapvwMyLocation.showAnnotations(arrGridAnnotationTemp, animated: true)
                    
                }
            } else {
                //  self.UserNotFoundVw.isHidden = false
                if let error = JSON["error"] as? String {
                    let annotationsToRemove = self.mapvwMyLocation.annotations.filter { $0 !== self.mapvwMyLocation.userLocation }
                    self.mapvwMyLocation.removeAnnotations(annotationsToRemove)
                    proxy.sharedProxy().displayStatusCodeAlert(error)
                    self.arrayLocationDetials.removeAll()
                }
            }
            
            self.tblvwLocationList.dataSource = self
            self.tblvwLocationList.delegate = self
            self.tblvwLocationList.reloadData()
            KAppDelegate.hideActivityIndicator()
            
        })
        
    }
    
    //MARK:- btnAction
    @IBAction func btnSerachLocationAction(_ sender: Any) {
        let addressVc = storyboard?.instantiateViewController(withIdentifier:"addressVC") as! addressVC
        self.navigationController?.pushViewController(addressVc, animated: true)
    }
    
    // Mark :- SkipAction
    @IBAction func btnSkippAction(_ sender: Any) {
        
        let addressVc = storyboard?.instantiateViewController(withIdentifier:"CreateAccountVC") as!  CreateAccountVC
        self.navigationController?.pushViewController(addressVc, animated: true)
    }
    
    //Mark :- Delegate Method
    func addressLocation(locationModal:AutoCompleteModel) {
        
        if locationModal.locationCoordinate.latitude != 0 && locationModal.locationCoordinate.longitude != 0 {
            self.lbllocationName.text = locationModal.descriptionName
            self.lblZipCode.text = "\(locationModal.zipCode)"
            self.setLoaction(lattitude: "\(locationModal.locationCoordinate.latitude)", longitude: "\(locationModal.locationCoordinate.longitude)", isFocusMap: true, isSetZipCode: true, isShowAddress: false)
        }else{
            proxy.sharedProxy().displayStatusCodeAlert("No location found")
        }
        
    }
    //Mark: -
    @IBAction func btnBackAction(_ sender: Any) {
        if comeFrom == "Drawer" {
            KAppDelegate.sideMenuVC.openLeft()
        }else if getId == 1{
            KAppDelegate.sideMenuVC.openLeft()
            
        }else{
            self.navigationController?.popViewController(animated: true)
        }
    }
    // Mark APi PartnerLocation
    func partnerLocation() {
        //let locationStr = userSelectedLocation.componentsJoined(by: ",")
        let param = [
            "location"     : "\(currentSelectedModal.id)" ,
            "id" :       profileModel.id ] as [String : Any]
       
        let userLocationUrl = "\(KServerUrl)\(KUserLocation)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            request(userLocationUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                 
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                          
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(userLocationUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KUserLocation)  {
    
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        profileModel.setUserProfile(dictDetail: (dic ).mutableCopy() as! NSMutableDictionary)
                        
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
            let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"CreateAccountVC") as! CreateAccountVC
            self.navigationController?.pushViewController(otpCodeVc,animated: true)
            
            
        }
        
    }
    // MArk:- btn Action
    @IBAction func btnNextAction(_ sender: Any) {
        if comeFrom == "Drawer" {
            if currentSelectedModal.id == 0{
                KAppDelegate.gotoMyPackagesScreen()
            }
            
        }
        else if getId == 1 {
            if currentSelectedModal.id == 0{
                proxy.sharedProxy().displayStatusCodeAlert("Please select Partner")
            }else{
                if selectedID != "True"
                {
                selectedNewPartnerUpdate()
                proxy.sharedProxy().displayStatusCodeAlert("Your partner location submitted successfully!")
                }
                else
                {
                     proxy.sharedProxy().displayStatusCodeAlert("Partner location allready exsist")
                }
              }
        }else{
            //if currentSelectedModal.id != 0{
            partnerLocation()
            // }else{
            // proxy.sharedProxy().displayStatusCodeAlert("Please  select Partner")
            //  }
            
        }
    }
    
    //Mark : Update PartnerLocation Api
    func selectedNewPartnerUpdate() {
        
        let param = [
            "location"     : keyStringCombine ]
        let userLocationUrl = "\(KServerUrl)\(KupdateLocation)\(profileModel.id)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            request(userLocationUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
     
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                profileModel.idLocation = self.keyStringCombine
                                self.serviceResponseUpdateLocation(JSONDIC)
                           
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(userLocationUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    
    func serviceResponseUpdateLocation(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KupdateLocation)\(profileModel.id)") {
          
            if JSON["status"] as! Int == 200 {
                //IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        KAppDelegate.gotoMyPackagesScreen()
                    }
                    KAppDelegate.gotoMyPackagesScreen()
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
    }
    //Mark : - Api MyLocation
    func getMyUserLocation(){
        let contentUrl = "\(KServerUrl)\(KMylocation)" + "/\(profileModel.id)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            request(contentUrl, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    if response.data != nil && response.result.error == nil {
                        if response.response?.statusCode == 200 || response.response?.statusCode == 1000  {
                            if let JSON = response.result.value as? NSDictionary{
                                self.serviceResponseMyLocation(JSON .mutableCopy() as! NSMutableDictionary)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().stautsHandler(contentUrl, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                        }
                    } else {
                        KAppDelegate.hideActivityIndicator()
                        proxy.sharedProxy().openSettingApp()
                    }
            }
        } else {
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponseMyLocation(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
      
       // self.arrayUserUpdateLocation.removeAll()
        if JSON["status"] as! Int == 200 {
            if  let data = JSON["data"] as? NSArray {
                totalAnnotationCount = data.count
                if let dicDetail = data.firstObject as? NSDictionary {
                    if let address = dicDetail["address"] as? String {
                        lbllocationName.text = address
                    }
                    if let zipcode = dicDetail["zipcode"] as? String {
                        lblZipCode.text = zipcode
                    }
                }
                
                         for i in 0..<data.count {
                         let dictData = data.object(at: i) as! NSDictionary
                         let partnerLocation =  UpdatePartnerLocation()
                         let mutatedDic = dictData.mutableCopy() as! NSMutableDictionary
                         partnerLocation.setUpdatePartnerLocation(dictDetail: mutatedDic)
                         self.arrayUserUpdateLocation.append(partnerLocation)
                    
                }
                
                
                var arrGridAnnotationTemp = [MKAnnotation]()
                for i in 0 ..< self.arrayUserUpdateLocation.count {
                    let modalPartners = self.arrayUserUpdateLocation[i]
                    if modalPartners.lat != "" && modalPartners.long != "" {
                        let annotation = PartnersAnnotation.init(coordinate: CLLocationCoordinate2DMake( Double(modalPartners.lat)! as CLLocationDegrees, Double(modalPartners.long)! as CLLocationDegrees), index: i, name: "", address: modalPartners.address, estimatedDestance: "")
                        self.mapvwMyLocation.addAnnotation(annotation)
                        annotation.title = modalPartners.business_name
                        arrGridAnnotationTemp.append(annotation)
                    }
                   
                }
                
                tblvwLocationList.delegate = self
                tblvwLocationList.dataSource = self
                tblvwLocationList.reloadData()
                self.UserNotFoundVw.isHidden = true
                if arrGridAnnotationTemp.count > 0 {
                    self.mapvwMyLocation.showAnnotations([arrGridAnnotationTemp[0]], animated: true)

                }
            }
         
        }
        else
        {
            if let errorMessage = JSON["error"] {
                proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
            }
        }
    }
    
    
    //MARK:- Tableview datasource and delegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if comeFrom == "Drawer"{
                // MY Location Array
            return arrayUserUpdateLocation.count
        }else{       // find My Location Array
            return arrayLocationDetials.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FindMyLocationCell", for: indexPath) as! FindMyLocationCell
        
        if comeFrom == "Drawer"{
            cell.lblSelection.isHidden = true
            cell.btnSelect.isHidden = true
            
            let updateLocationObj = arrayUserUpdateLocation[indexPath.row]
            cell.lblLocationName.text = updateLocationObj .address
            cell.lblCompanyName.text = updateLocationObj.business_name
            
        }
        else {
            let locationModelObj = arrayLocationDetials[indexPath.row]
            cell.lblLocationName.text = locationModelObj.address
            cell.lblCompanyName.text = locationModelObj.business_name
            
            if locationModelObj.isSeleced == 0
            {
                cell.btnSelect.setImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
            }else{
                cell.btnSelect.setImage(#imageLiteral(resourceName: "ic_check"), for: .normal)
            }
        }
        cell.btnSelect.tag = indexPath.row
        cell.btnLocationDetail.tag = indexPath.row
        cell.btnSelect.addTarget(self, action: #selector(btnSelectAction(sender:)), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        if comeFrom == "Drawer"{
            let deleteAction = UITableViewRowAction(style: .destructive , title: "Delete") { (action, indexPath) in
            let customerModal = self.arrayUserUpdateLocation[indexPath.row]
                if self.keyStringCombine.contains(",\(customerModal.id)") && self.keyStringCombine.contains("\(customerModal.id),"){
                    
                     self.keyStringCombine =  self.keyStringCombine.replacingOccurrences(of: ",\(customerModal.id)", with: "")
                    
                }else if self.keyStringCombine.contains(",\(customerModal.id)"){
                 self.keyStringCombine =  self.keyStringCombine.replacingOccurrences(of: ",\(customerModal.id)", with: "")
                    
                }else if self.keyStringCombine.contains("\(customerModal.id),"){
                    self.keyStringCombine =  self.keyStringCombine.replacingOccurrences(of: "\(customerModal.id),", with: "")

                }else{
                    self.keyStringCombine =  self.keyStringCombine.replacingOccurrences(of: "\(customerModal.id)", with: "")
                }
                
            let alertController = UIAlertController(title: "", message: "Are you sure you want to remove this  Location ?", preferredStyle: .alert)
            let yesAction = UIAlertAction(title: "Yes", style: .default) { (action) in
               // self.selectedNewPartnerUpdate(strCardId: "\(customerModal.id)")
               self.removePartnerocation(PartnerId:"\(customerModal.id)")
            }
            
            let noAction = UIAlertAction(title: "No", style: .default) { (action) in
                self.dismiss(animated: true, completion: nil)
                
            }
            KAppDelegate.window?.currentViewController()?.present(alertController, animated: true, completion: nil)
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
            
        }
        deleteAction.backgroundColor = UIColor(red: 23/255, green: 153/255, blue: 243/255, alpha: 1)
        return[deleteAction]
        }
        else {
        return [UITableViewRowAction]()
        }
       
    }
    
        func removePartnerocation(PartnerId:String) {
            
                let param = [
                "location"     : keyStringCombine ]
            let userLocationUrl = "\(KServerUrl)\(KupdateLocation)\(profileModel.id)"
            
            if  reachability?.isReachable  == true {
                KAppDelegate.showActivityIndicator()
                request(userLocationUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                        
                        do
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                KAppDelegate.hideActivityIndicator()
                                if response.response?.statusCode == 200   {
                                    profileModel.idLocation = self.keyStringCombine
                                    self.serviceResponseUpdateLocation(JSONDIC)
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(userLocationUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding")
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
            }

      
    }
    
    
    // Mark: - btn Action
    @IBAction func btnLocationDetailAction(_ sender: Any) {
        if comeFrom == "Drawer"{
            let index = (sender as! UIButton).tag
            let updatelocationObj = arrayUserUpdateLocation[index]
            let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"LocationHourlyServiceVC") as! LocationHourlyServiceVC
            otpCodeVc.currentIndex = index
            protocolLocationHourly = self
            otpCodeVc.updateLocation = updatelocationObj
            otpCodeVc.comeIn = "1"
            otpCodeVc.dayOfServiceArray = arrydayTime
            present(otpCodeVc, animated: true, completion: nil)
            
            
        }else{
            let index = (sender as! UIButton).tag
            let locationModelObj = arrayLocationDetials[index]
            let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"LocationHourlyServiceVC") as! LocationHourlyServiceVC
            otpCodeVc.currentIndex = index
            protocolLocationHourly = self
            otpCodeVc.locationDetialGet = locationModelObj
            otpCodeVc.dayOfServiceArray = arrydayTime
            present(otpCodeVc, animated: true, completion: nil)
            
        }
    }
    var selectedID = String()
    func btnSelectAction(sender: UIButton) {
        selectPartner(indexPath: sender.tag)
    }
    
    func selectPartner(index: Int, isSelected:Bool){
        if isSelected {
            selectPartner(indexPath: index)
        }else{
            for i in 0 ..< arrayLocationDetials.count{
                let modalLocation = arrayLocationDetials[i]
                modalLocation.isSeleced = 0
                arrayLocationDetials[i] = modalLocation
            }
            tblvwLocationList.reloadData()
        }
    }
    
   
    func selectPartner(indexPath: Int){
        let locationModelObj = arrayLocationDetials[indexPath]
        if keyStringCombine.characters.count > 0 {
            if !(keyStringCombine.contains("\(locationModelObj.id)"))
            {
                 keyStringCombine.append(",\(locationModelObj.id)")
                selectedID =   "False"
            }
            else
            {
                selectedID =   "True"
            }
        }else{
            if !(keyStringCombine.contains("\(locationModelObj.id)"))
            {
            keyStringCombine.append("\(locationModelObj.id)")
                selectedID =   "False"
            }
            else
            {
                selectedID =   "True"
            }
        }
        if locationModelObj.isSeleced == 0 {
            locationModelObj.isSeleced = 1
            currentSelectedModal = locationModelObj
            arrayLocationDetials[indexPath] = locationModelObj
        }else{
            locationModelObj.isSeleced = 0
            currentSelectedModal = LocationModel()
            arrayLocationDetials[indexPath] = locationModelObj
        }
        
        for i in 0 ..< arrayLocationDetials.count{
            let modalLocation = arrayLocationDetials[i]
            if i != indexPath {
                modalLocation.isSeleced = 0
                arrayLocationDetials[i] = modalLocation
            }
        }
        tblvwLocationList.reloadData()
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//        if annotation is MKUserLocation {
//            return nil
//        }
        if annotation.isKind(of: PartnersAnnotation.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "")
            _ = annotation as! PartnersAnnotation
            let imgAnno = UIImageView()
            imgAnno.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            imgAnno.image = #imageLiteral(resourceName: "DrawerLocation")
            anView.canShowCallout = true
            anView.addSubview(imgAnno)
            anView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            return anView
        }
        
        return nil
    }
    
}

extension FindMyLocationVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
          print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
          print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
          print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
          print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
          print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
          print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
          print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
          print("SlideMenuControllerDelegate: rightDidClose")
    }
    
}
