
//
//  CreateAccountVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 28/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift
import Stripe

class CreateAccountVC: UIViewController,UITextFieldDelegate ,MonthYearPickerViewDelegate{
    
 //MARK : - Variable
    var locationModal = LocationModel()
    var strYear = String()
    var strMonth = String()
    var monthYearDatePicker = MonthYearPickerView()
    var strURL = ""
    var amountPackage = String()
    var packageFree   = String()
    var feeAmount = String()
    var pickUpDay = String()
    var timeDuration = String()

    //MARK  Outlet
    @IBOutlet weak var lblFirstPackages: UILabel!
    @IBOutlet weak var lblWeeklyFee: UILabel!
    @IBOutlet weak var lblPackageDays: UILabel!
    @IBOutlet weak var lblPerPackage: UILabel!
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldCardNumber: UITextField!
    @IBOutlet weak var txtFldExpiryCardDate: UITextField!
    
    @IBOutlet weak var imageViewCardType: UIImageView!
    // Mark Varriable
    let limitLength = 16
      override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true 
        protocolMonthYearPickerView = self
        strURL = "\(KServerUrl)\(createAccountDetial)"
        createAmountDetial(strURL: strURL, param: nil)
        
        txtFldName.attributedPlaceholder = NSAttributedString(string: "Name on Card", attributes: [NSForegroundColorAttributeName: UIColor.gray
            ])
        txtFldCardNumber.attributedPlaceholder = NSAttributedString(string: "Card Number ", attributes: [NSForegroundColorAttributeName: UIColor.gray])
        
        txtFldExpiryCardDate.attributedPlaceholder = NSAttributedString(string: "MM/YY ", attributes: [NSForegroundColorAttributeName: UIColor.gray])
        

        
          }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    // Mark Action TxtField
    
    @IBAction func txtfldDateAction(_ sender: UITextField) {
       
        sender.inputView = monthYearDatePicker

    }
    
    func datePickerValueChanged(sender:UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        
        dateFormatter.dateFormat =   "MM/yyyy"
        txtFldExpiryCardDate.text = dateFormatter.string(from: sender.date)
        
        let monthFormatter = DateFormatter()
        monthFormatter.dateFormat =   "MM"
        strMonth = monthFormatter.string(from: sender.date)
        
        monthFormatter.dateFormat =   "yyyy"
        let calendar = Calendar.current
        let year = calendar.component(.year, from: sender.date)
        strYear = "\(year)"
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
         if textField == txtFldCardNumber {
            let length = txtFldCardNumber.text!.characters.count + string.characters.count - range.length
            if length >= 16 {
                if length == 16 {
                    let cardBrand = STPCardValidator.brand(forNumber: txtFldCardNumber.text!)
                    let cardImage = STPImageLibrary.brandImage(for: cardBrand)
                    
                    imageViewCardType.image = cardImage
                }
                if string != "" {
                    if length == 17 {
                        return false
                    }
                    else{
                        return true
                    }
                }
                else {
                    imageViewCardType.image = UIImage(named:  "")
                    return true
                }
            } else{
                imageViewCardType.image = #imageLiteral(resourceName: "icnCard")
                return true
            }
        
        }
              return true
    }
    

    
    @IBAction func btnCreateAccountAction(_ sender: Any) {
        IQKeyboardManager.sharedManager().resignFirstResponder()
        let whitespaceSet = NSCharacterSet.whitespaces
        if txtFldCardNumber.text!.isEmpty() {
           imageViewCardType.image = #imageLiteral(resourceName: "icnCard")
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Card Number")
        } else  if txtFldCardNumber.text!.characters.count != 16 {
                  imageViewCardType.image = #imageLiteral(resourceName: "icnCard")
            proxy.sharedProxy().displayStatusCodeAlert("incorrect card Number")
        } else if txtFldExpiryCardDate.text!.isEmpty() {
           proxy.sharedProxy().displayStatusCodeAlert("Please enter Exp. Date")
        } else if txtFldName.text!.isEmpty() {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
      }else {
            if txtFldCardNumber.text!.trimmingCharacters(in: whitespaceSet) != "" {
                
                
                
                
                let stripCard = STPCardParams()
                
                // Split the expiration date to extract Month & Year
                
                stripCard.number = self.txtFldCardNumber.text!.trimmingCharacters(in: whitespaceSet)
                //stripCard.cvc = self.txtFieldCVV.text!.trimmingCharacters(in: whitespaceSet)
                stripCard.expMonth = UInt(strMonth)!
                stripCard.expYear = UInt(strYear)!
                stripCard.name = String(txtFldName.text!.trimmingCharacters(in: whitespaceSet))!
                KAppDelegate.showActivityIndicator()
                
                STPAPIClient.shared().createToken(withCard: stripCard, completion: { (token, error) -> Void in
                    
                    if error != nil {
                        self.handleError(error! as NSError)
                        return
                    }else{
                        self.createAccount(strToken: token!)

                    }
                    
                    
                })
            } else {
                proxy.sharedProxy().displayStatusCodeAlert("Please enter valid card details")
            }
        }
    }
    
       
        // MARK : Method error Handler .
    func handleError(_ error: NSError) {
        KAppDelegate.hideActivityIndicator()
        UIAlertView(title: "In valid card number Please Try Again",
                    message: error.localizedDescription,
                    delegate: nil,
                    cancelButtonTitle: "OK").show()
    }

    
    
    //Mark: Create Account Api
    func createAccount(strToken:STPToken){
        let userId = profileModel.id
        let param = [
            
            "name"    : "\(txtFldName.text!)",
            "number" :   "\(strToken.tokenId)",
           
            ] as [String : Any]
 
        
        let creatAccount = "\(KServerUrl)\(KUserCard)\(userId)"
         
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)","auth_code": "\(proxy.sharedProxy().authNil())"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Error: Server not responding!")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(KUserCard)\(profileModel.id)") {
            if JSON["status"] as! Int == 200 {
                IQKeyboardManager.sharedManager().resignFirstResponder()
                
                            let congratulationVc = self.storyboard?.instantiateViewController(withIdentifier:"CongratulationsVC") as! CongratulationsVC
                            self.navigationController?.pushViewController(congratulationVc,animated: true)
                 }
            else
            {
               
            if let errorMessage =   JSON["error"] as? String{
                    if proxy.sharedProxy().checkStringIfNull(errorMessage).characters.count > 0{
                        proxy.sharedProxy().displayStatusCodeAlert(errorMessage )
                    }
                }
               
            }
        }
        
    }
    
    func selectedMonthYear( month: Int,  year: Int){
        txtFldExpiryCardDate.text = "\(month)/\(year)"
        strMonth = "\(month)"
        strYear = "\(year)"
    }
    
    
    
    @IBAction func btnTermsandConditionAction(_ sender: Any) {
        
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndCondition_PrivacyPolicyVc")as!TermsAndCondition_PrivacyPolicyVc
        signup.selectedValue = "2"
        self.navigationController?.pushViewController(signup, animated: true)

    }
    
    
    @IBAction func btnPrivacyPolicyAction(_ sender: Any) {
        
        
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndCondition_PrivacyPolicyVc")as!TermsAndCondition_PrivacyPolicyVc
        signup.selectedValue = "3"
        self.navigationController?.pushViewController(signup, animated: true)
     }
    
    
    
    
     // Mark:- Create Account Api 
    func createAmountDetial(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        proxy.sharedProxy().getDataHandler(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let arrayDes = responseDict["data"] as? NSDictionary{
                    
                  if let amountPerPackage = arrayDes["amountPerPackage"] as? String{
                        self.amountPackage = amountPerPackage
                    }
                    if let freePackage = arrayDes["freePackage"] as? String{
                        self.packageFree = freePackage
                    }
                    if let lateFeeAmount = arrayDes["lateFeeAmount"] as? String{
                        self.feeAmount = lateFeeAmount
                    }
                    if let validPickUpDay = arrayDes["validPickUpDay"] as? String{
                        self.pickUpDay = validPickUpDay
                    }
                    if let tmDuration = arrayDes["timeDuration"] as? String{
                        self.timeDuration = tmDuration
                    }
                    self.lblFirstPackages.text = "Your first \(self.packageFree) Packages are FREE"
                    self.lblPerPackage.text = " then $\(self.amountPackage) per Package."
                    self.lblPackageDays.text = "Packages held over \(self.pickUpDay) days will incure a $\(self.feeAmount).00"
                    if self.timeDuration == "0" {
                        self.lblWeeklyFee.text = "weekly fee."
                    }else{
                         self.lblWeeklyFee.text = "daily fee."
                    }
                }
            }
            else{
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.createAmountDetial(strURL: strURL, param: param)
            })
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
 }





