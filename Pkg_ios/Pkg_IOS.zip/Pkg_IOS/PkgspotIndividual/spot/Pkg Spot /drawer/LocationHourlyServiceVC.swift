//
//  LocationHourlyServiceVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 28/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
protocol LocationHourlyServiceDelegate {
    func selectPartner(index: Int,isSelected:Bool)
}

var protocolLocationHourly: LocationHourlyServiceDelegate?

class LocationHourlyServiceVC: UIViewController, UITableViewDataSource, UITableViewDelegate {

  @IBOutlet weak var tblvwServices: UITableView!
  @IBOutlet weak var btnSelect: UIButton!
  @IBOutlet weak var lblLocationName: UILabel!
    @IBOutlet weak var lblCompanyName: UILabel!
    @IBOutlet weak var lblSelectionLocation: UILabel!

     // Mark : - varriable
    var selectedDaysAndTime = NSMutableArray()
    var dictDaysOfServices : [String: String] = [:]
    var locationDetialGet = LocationModel()
    var  updateLocation = UpdatePartnerLocation()
    var  currentIndex = Int()
    var   comeIn = String()
    var dayOfServiceArray = [DaysAndService]()

  
  let arrDay = ["M","T","W","TH","F","S","S"]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
      tblvwServices.dataSource = self
      tblvwServices.delegate = self
      tblvwServices.reloadData()
        
        if comeIn == "1"{
            btnSelect.isHidden = true
            lblSelectionLocation.isHidden = true
            lblLocationName.text = updateLocation.address
            lblCompanyName.text = updateLocation.business_name
        }
        else{
     lblLocationName.text = locationDetialGet.address
     lblCompanyName.text = locationDetialGet.business_name
        
        if locationDetialGet.isSeleced == 1 {
            btnSelect.isSelected = true
        }else{
            btnSelect.isSelected = false
        }
    }
}

  
  //MARK:- btnaction
  
  @IBAction func btnCrossAction(_ sender: Any) {
    self.dismiss(animated: true, completion: nil)
  }
  
  
  @IBAction func btnSelectAction(_ sender: Any) {
    
    let btnSelectLocation = sender as! UIButton
    if  btnSelectLocation.isSelected{
        btnSelectLocation.isSelected = false
        protocolLocationHourly?.selectPartner(index: currentIndex, isSelected: false)
        
    }else{
        btnSelectLocation.isSelected = true
        protocolLocationHourly?.selectPartner(index: currentIndex, isSelected: true)
    }
    
  }
  
  //MARK:- tableview dataseource and delegate
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    if comeIn == "1"{
        return updateLocation.dayOfServiceArray.count
        
    }else{
       return locationDetialGet.dayOfServiceArray.count
    }
  //  debugPrint("locationDetialGet.days_of_service",locationDetialGet.dayOfServiceArray.count)
    return locationDetialGet.dayOfServiceArray.count
  }
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell  = tableView.dequeueReusableCell(withIdentifier: "LocationHourlyServiceTVC", for: indexPath) as! LocationHourlyServiceTVC
    
    if comeIn == "1"{
        cell.btnDay.setTitle(arrDay[indexPath.row], for: .normal)
        let start  =  updateLocation.dayOfServiceArray[indexPath.row]
        cell.lblStartTime.text = start.starttime
        cell.lblEndTime.text =   updateLocation.dayOfServiceArray[indexPath.row].endtime
        
    }else{
            cell.btnDay.setTitle(arrDay[indexPath.row], for: .normal)
        let start  =  locationDetialGet.dayOfServiceArray[indexPath.row]
        cell.lblStartTime.text = start.starttime
      cell.lblEndTime.text =   locationDetialGet.dayOfServiceArray[indexPath.row].endtime

    }
    
    return cell
  }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 }
