
import UIKit
import Alamofire

let KAppDelegate = UIApplication.shared.delegate as! AppDelegate
let  KMode = "development"
let  KAppName = "PkgSpot"
let usewrAgent = "\(KMode)" + "\(KAppName)"

enum AppInfo {
    static let Mode = "development"
    static let AppName = "PkgSpotPartner"
    static let Version =  "1.0"
    static let ZoomLevel =  Float(14.0)
    static let UserAgent = "\(Mode)/\(AppName)"
    static let AppColor = UIColor(red: 59/255, green: 89/255, blue: 152/255, alpha: 1)
    static let FemaleColor = UIColor(red: 1, green: 0, blue: 1, alpha: 1)
    static let MaleColor = UIColor(red: 0, green: 85/255, blue: 212/255, alpha: 1)
}

enum Apis {
    static let KServerUrl =  "http://34.230.87.240/"
    static let KUserCheck = "api/user/check"
    
    static let KSignUp = "api/partner/partner-signup"
    static let KSignUpStep2 = "api/partner/partner-step2/"
    static let KSignUpStep3 = "api/partner/email-verify/"
    static let KResendMail = "api/partner/resend-mail"
    static let KSignUpTermsStep3 = "api/partner/terms/"
    static let KSignUpPolicyStep3 = "api/partner/terms/"
    static let KSignUpComplete = "api/partner/complete-signup/"
    
    static let KLogin = "api/partner/login"
    static let KMyAccount = "api/partner/profile/"
    static let KPartnerUpdate = "api/partner/partner-update/"
    static let KMarketingMsg = "api/partner/info-update/"
    static let KHistoryInfo = "api/package/index/"
    static let KCalender = "api/package/filter/"
    static let KVeifyCustomer = "api/package/verify-code/"
    static let KImagesMail = "api/package/confirm-package/"
    static let KImgMail = "api/package/confirm-package-email"
    static let KImgUpload = "api/package/send-message/"
    
    static let KForgotPassword = "api/user/forgot-password"
    static let KChangePassword = "api/user/change-password"
    static let KChangeMailId = "api/user/upadte-email/"
    static let KHelpPage  = "api/partner/terms/"
    static let KLogout = "api/user/logout"
    static let googleBaseURL = "https://maps.googleapis.com/maps/api/"
    static let kgetPkgSpotId = "api/package/scane/"
    static let kUploadScannedData = "api/package/upload/"
    static let ForgotPassword = "api/user/forgot-password"
    static let kOtpVerify = "api/user/confirm-otp"
}//api/package/send-message/

enum UserDefaultsData {
    static let str_unique_id = "unique_id"
    static let str_userid = "userid"
    static let str_full_name = "business_name"
    static let str_address = "address"
    static let str_city = "city"
    static let str_state = "state"
    static let str_zipcode = "zipcode"
}

// MARK: - Protocol
@objc protocol WebServiceDelegate{
    func retryMethod(_ paramsDic:Dictionary<String,AnyObject>, withServiceUrl:NSString, error:NSError?)
}

var delegateObject: WebServiceDelegate?

class Proxy: NSObject {
    
    static var sharedProxy: Proxy {
        return Proxy()
    }
    private override init(){
    }

    func checkStringIfNull(_ content: String) -> String {
        if ((content == "null")) || ((content == "(null)")) || ((content == "<null>")) || ((content == "nil")) || ((content == "")) || ((content == "<nil>")) || (content.characters.count == 0){
            return ""
        }
        else {
            return content
        }
    }
    
    func authNil () -> String
    {
        if(UserDefaults.standard.object(forKey: "auth_code") == nil){
            return ""
        }
        else{
            return String(describing: UserDefaults.standard.object(forKey: "auth_code") as AnyObject)
        }
    }
    
    func expiryDateCheckMethod(_ expiryDate: String)->Bool  {
        let DateInFormat = DateFormatter()
        DateInFormat.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        DateInFormat.dateFormat = "yyyy-MM-dd"
        let expiryDate = DateInFormat.date(from: expiryDate)
        
        let f:DateFormatter = DateFormatter()
        f.timeZone = NSTimeZone.local
        f.dateFormat = "yyyy-MM-dd"
        
        let now = f.string(from: NSDate() as Date)
        let currentDate = f.date(from: now)
        let offsetTime = NSTimeZone.local.secondsFromGMT()
        let finalTime = currentDate!.addingTimeInterval(TimeInterval(offsetTime))
        
        if finalTime.compare(expiryDate!) == ComparisonResult.orderedDescending {
            return false
        } else if currentDate!.compare(expiryDate!) == ComparisonResult.orderedAscending  {
            return true
        } else{
            return true
        }
    }
    
    //Mark:- Check Email
    func isValidEmail(_ testStr:String) -> Bool{
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let range = testStr.range(of: emailRegEx, options:.regularExpression)
        let result = range != nil ? true : false
        return result
    }
    
    func getDateFormat(_ dateStr: String) -> String {
        let formattr = DateFormatter()
        formattr.dateFormat = "YYYY-MM-dd HH:mm:ss"
        let dt = formattr.date(from: dateStr)
        formattr.dateFormat = "hh:mm a"
        if dt != nil {
            return formattr.string(from: dt!)
        }else {
            Proxy.sharedProxy.displayStatusCodeAlert("Date format is wrong")
            return ""
        }
    }
    
    //MARK: - check password
    
    func isValidPassword(_ testStr:String) -> Bool
        
    {
        let alphaBaticLetterRegEx = ".*[A-Z]+.*"
        let texttest4 = NSPredicate(format:"SELF MATCHES %@", alphaBaticLetterRegEx)
        let capitalResult = texttest4.evaluate(with: testStr)
        
        let capitalLetterRegEx  = ".*[A-Za-z]+.*"
        let texttest = NSPredicate(format:"SELF MATCHES %@", capitalLetterRegEx)
        let capitalresult = texttest.evaluate(with: testStr)
        
        let numberRegEx  = ".*[0-9]+.*"
        let texttest1 = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        let numberresult = texttest1.evaluate(with: testStr)
       
        let eightRegEx  = ".{6,}"
        let texttest3 = NSPredicate(format:"SELF MATCHES %@", eightRegEx)
        let eightresult = texttest3.evaluate(with: testStr)
        return  capitalResult && capitalresult && numberresult && eightresult
        
    }
    
    
    // MARK: - Error Handling
    
    func stautsHandler(_ url:String, parameter:Dictionary<String,AnyObject>? = nil, response:HTTPURLResponse?, data:Data?, error:NSError?)
    {
        if response != nil  {
            if  response?.statusCode == 400
            {
                displayStatusCodeAlert("bad url")
            }
            else if response?.statusCode == 401
            {
                displayStatusCodeAlert("unauthorized")
            }
            else if response?.statusCode == 403
            {
                UserDefaults.standard.set("", forKey: "auth_code")
                UserDefaults.standard.synchronize()
                displayStatusCodeAlert("session not found")
             //   KAppDelegate.gotoInitialVC()
            }
            else if response?.statusCode == 404
            {
                displayStatusCodeAlert("file not found")
            }
            else if response?.statusCode ==  500
            {
                //proxy.sharedProxy().displayStatusCodeAlert("Server Error")
                
                Proxy.sharedProxy.displayStatusCodeAlert(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String)
            }
                
            else if response?.statusCode == 408
            {
                RequestTimeOutAlertMessage("\(String(describing: error?.localizedDescription))" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            else if error?.code == -1001
            {
                RequestTimeOutAlertMessage("\(String(describing: error?.localizedDescription))" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            else if error?.code == -1009
            {
                RequestTimeOutAlertMessage("\(String(describing: error?.localizedDescription))" as NSString, Url:url, Parameter:parameter!, Response:response, data:data, Error:error)
            }
            
        }else {
            Proxy.sharedProxy.displayStatusCodeAlert("Network Error")
        }
    }
    
    func displayStatusCodeAlert(_ userMessage: String){
      UIView.hr_setToastThemeColor(appColor)
     // UIView.hr_setToastFontColor(UIColor.white)
      KAppDelegate.window!.makeToast(message: userMessage)
    }
    
    func openSettingApp(){
        var settingAlert = UIAlertController()
        DispatchQueue.main.async
            {
                settingAlert = UIAlertController(title: "Connection Problem", message: "Please check your internet connection", preferredStyle: UIAlertControllerStyle.alert)
                
                let okAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
                settingAlert.addAction(okAction)
                
                let openSetting = UIAlertAction(title:"Setting", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                    UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
                })
                
                settingAlert.addAction(openSetting)
                
                UIApplication.shared.keyWindow?.rootViewController?.present(settingAlert, animated: true, completion: nil)
        }
    }
    
    
    func RequestTimeOutAlertMessage(_ alrtMessage:NSString, Url:String, Parameter:Dictionary<String, AnyObject>? = nil, Response: HTTPURLResponse? , data: Data? , Error:NSError?)
    {
        if (Parameter!.count) > 0
       
        {
            var timeOutAlert = UIAlertController()
            
            timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
            
            let okAction = UIAlertAction(title:"Cancel", style:UIAlertActionStyle.default, handler: nil)
            timeOutAlert.addAction(okAction)
            
            let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                
                delegateObject!.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
            })
            
            timeOutAlert.addAction(retryAction)
            
            UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
        }
        else
        {
            DispatchQueue.main.async
                {
                    var timeOutAlert = UIAlertController()
                    
                    timeOutAlert = UIAlertController(title:"", message:alrtMessage as String, preferredStyle: UIAlertControllerStyle.alert)
                    
                    let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: nil)
                    timeOutAlert.addAction(okAction)
                    
                    let retryAction = UIAlertAction(title:"Retry", style:UIAlertActionStyle.default, handler:{ (action: UIAlertAction!) in
                        delegateObject?.retryMethod(Parameter!, withServiceUrl:Url as NSString, error:Error)
                    })
                    
                    timeOutAlert.addAction(retryAction)
                    
                    UIApplication.shared.keyWindow?.rootViewController?.present(timeOutAlert, animated: true, completion: nil)
            }
        }
    }
  
    //MARKK:- API Interaction
    func postData(_ urlStr: String, params: Dictionary<String, AnyObject>? = nil, showIndicator: Bool, completion: @escaping (_ response: NSMutableDictionary) -> Void,failure: @escaping (_ error: NSError) -> Void) {
      
        debugPrint("URL RESPONSE:", urlStr)
        debugPrint("PARAMETERS: ", params)
       
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
           
            request(urlStr, method: .post, parameters: params, encoding: URLEncoding.httpBody, headers:["auth_code": "\(Proxy.sharedProxy.authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                if let JSON = response.result.value as? NSDictionary {
                                    debugPrint("JSON RESPONSE:", JSON)
                                    KAppDelegate.hideActivityIndicator()
                                    completion(JSON .mutableCopy() as! NSMutableDictionary)
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                              } else {
                              KAppDelegate.hideActivityIndicator()
                                Proxy.sharedProxy.statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        }else {
                            KAppDelegate.hideActivityIndicator()
                            if let json = response.data {
                                debugPrint("JSON RESPONSE:", NSString(data: (response.data)!, encoding: String.Encoding.utf8.rawValue) ?? "")
                            }
                            Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to get response from server")
                            failure(response.result.error! as NSError)
                        }
                    } catch {
                        debugPrint(error.localizedDescription)
                        failure(error as NSError)
                    }
            }
        } else {
            Proxy.sharedProxy.openSettingApp()
        }
    }
    
    func getData(_ urlStr: String, showIndicator: Bool, completion: @escaping (_ responseDict: NSMutableDictionary) -> Void,failure: @escaping (_ error: NSError) -> Void){
       
        if  Reachability()!.isReachable {
            if showIndicator {
                KAppDelegate.showActivityIndicator()
            }
          
            debugPrint("URL: ",urlStr)
            request(urlStr, method: .get, parameters: nil, encoding: JSONEncoding.default, headers:["auth_code": "\(Proxy.sharedProxy.authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do {
                        if response.data != nil && response.result.error == nil {
                            if response.response?.statusCode == 200 {
                                KAppDelegate.hideActivityIndicator()
                                if let JSON = response.result.value as? NSDictionary {
                                    print("Response: ",JSON)

                                    completion(JSON.mutableCopy() as! NSMutableDictionary)
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to get response from server")
                                }
                            }
                            else {
                                KAppDelegate.hideActivityIndicator()
                        Proxy.sharedProxy.statusHandler(response.response, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to get response from server")
                            failure(response.result.error! as NSError)
                        }
                    }catch {
                        debugPrint(error.localizedDescription)
                        failure(error as NSError)
                    }
            }
        } else {
            Proxy.sharedProxy.openSettingApp()
        }
    }
    
    // MARK: - Error Handling
     func statusHandler(_ response:HTTPURLResponse?, error:NSError?) {
        if let code = response?.statusCode {
            switch code {
            case 400:
                displayStatusCodeAlert("Please heck the URL : 400")
            case 401:
                displayStatusCodeAlert("Unauthorized to perform this action : 401")
            case 403:
                UserDefaults.standard.set("",forKey:"auth_code")
                UserDefaults.standard.synchronize()
                KAppDelegate.gotoLoginSignUpVC()
            case 404:
                displayStatusCodeAlert("URL does not exists : 404")
            case 500:
                displayStatusCodeAlert("Status code 500 : Server error")
            case 408:
                displayStatusCodeAlert("Server error, Please try again..")
            default:
                displayStatusCodeAlert("Server error, Please try again..")
            }
        } else {
            displayStatusCodeAlert("Server error, Please try again..")
        }
        
        if let errorCode = error?.code {
            switch errorCode {
            default:
                displayStatusCodeAlert("Server error, Please try again..")
            }
        }
    }
    
    func isValidInput(_ Input:String) -> Bool {
        let characterset = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ ")
        // string contains non-whitespace characters
        
        if Input.rangeOfCharacter(from: characterset.inverted) != nil {
            Proxy.sharedProxy.displayStatusCodeAlert("Please enter valid Name ")
            return false
            
        }
        else {
            return true
        }
    }
}

extension String {
    
    func isEmpty() -> Bool{
        if self.trimmingCharacters(in: .whitespacesAndNewlines).characters.count > 0 {
            return false
        }
        return true
    }

}
