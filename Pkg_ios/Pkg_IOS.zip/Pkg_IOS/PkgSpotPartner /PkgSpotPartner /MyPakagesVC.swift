//
//  MyPakagesVC.swift
//  drawer
//
//  Created by Shivam Kheterpal on 28/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class MyPakagesVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      self.navigationController?.isNavigationBarHidden = true
    }

  @IBAction func btnDrawerAction(_ sender: Any) {
    KAppDelegate.sideMenuVC.openLeft()
  }
  
  @IBAction func btnCalenderAction(_ sender: Any) {
    let calenderVC = storyboard?.instantiateViewController(withIdentifier: "CalenderVC") as! CalenderVC
    self.navigationController?.pushViewController(calenderVC, animated: false)
  }
  
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
  extension MyPakagesVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
      print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
      print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
      print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
      print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
      print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
      print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
      print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
      print("SlideMenuControllerDelegate: rightDidClose")
    }

}
