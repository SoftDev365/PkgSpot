//
//  CongratulationsVC.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class CongratulationsVC: UIViewController {

  
  @IBOutlet weak var btnNext: SetCornerButton!
  @IBOutlet weak var lblPkgSpotNumber: UILabel!
  
  @IBOutlet weak var lblAddress: UILabel!
  
  
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchProfile()
    
    }
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController!.popViewController(animated: true)
    }
    
  @IBAction func btnNextAction(_ sender: Any) {
     completeSingUp()     }
    
    // MARK Complete SignUp  Api
    func completeSingUp() {
        let userId = profileModel.id
        let creatAccount = "\(KServerUrl)\(completSignUp)\(userId)"
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .post, parameters: nil, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    print(JSONDIC as Any)
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                                print("Response:",JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(completSignUp)\(profileModel.id)") {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
            if JSON["status"] as! Int == 200 {
               // IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSDictionary {
                    if let dic = data[0] as? NSArray {
                        profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                        
                       // lblPkgSpotNumber.text = profileModel.
                        
                        let ThanksVC = self.storyboard?.instantiateViewController(withIdentifier:"ThanksVC") as! ThanksVC
                        self.navigationController?.pushViewController(ThanksVC,animated: true)
                        
                                          }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
     
}
    
    
    
  //MARK Fetch Profile Api
    
       func fetchProfile() {
        let userId = profileModel.id
        let creatAccount = "\(KServerUrl)\(userInfo)\(userId)"
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(creatAccount, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    print(JSONDIC as Any)
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serResponse(JSONDIC)
                                print("Response:",JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(creatAccount, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual ("\(userInfo)\(profileModel.id)") {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
            if JSON["status"] as! Int == 200 {
                // IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSDictionary {
                    let location = data["location"] as? NSArray
                    if let dic = location?[0] as? NSDictionary {
                        print(dic)
                        profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                        print(profileModel)
                         lblPkgSpotNumber.text = ("\(profileModel.unique_id)")
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
        
    
    }
    
  
}






