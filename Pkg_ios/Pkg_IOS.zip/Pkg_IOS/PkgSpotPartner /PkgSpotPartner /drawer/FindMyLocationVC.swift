//
//  FindMyLocationVC.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Alamofire

class FindMyLocationVC: UIViewController, UITableViewDataSource, UITableViewDelegate,MKMapViewDelegate, addressProtocol{
    
    //MARK:- Outlets
    @IBOutlet weak var lblStaticLocation: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tblvwLocationList: UITableView!
    @IBOutlet weak var mapvwMyLocation: MKMapView!
    @IBOutlet weak var lblZipCode: UILabel!
    @IBOutlet weak var lbllocationName: UILabel!
    
    //MARK:- Variables
    let locationManager = CLLocationManager()
    var location = CLLocationCoordinate2D()
    
    var arrayLocationDetials = [LocationModel]()
    var userSelectedLocation = NSMutableArray()
    
    var updatingTimer = Timer()
    var comeFrom = String()
    var locationData = LocationModel()
    var addressLat = ""
    var addressLong = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.mapvwMyLocation.delegate = self
        
        if comeFrom == "Drawer" {
            self.navigationController?.isNavigationBarHidden = true
            btnBack.setImage(#imageLiteral(resourceName: "DrawerIcon"), for: .normal)
            lblStaticLocation.text = "My Location"
        }else{
            btnBack.setImage(#imageLiteral(resourceName: "backarrow"), for: .normal)
            lblStaticLocation.text = "Find My Location"
            
        }
        
           addressLocProtocol = self
        
        updatingTimer = Timer.scheduledTimer(timeInterval:0.5, target: self, selector: #selector(FindMyLocationVC.nearBylocTimer), userInfo: nil, repeats: false)
        
    }
    
    
    func  nearBylocTimer ()
    {
        nearbyLocations()
    }
    func nearbyLocations() {
        KAppDelegate.hideActivityIndicator()
        if UserDefaults.standard.object(forKey: "lat") != nil {
            let lat =  UserDefaults.standard.object(forKey: "lat") as! String
            let long = UserDefaults.standard.object(forKey: "long") as! String
            debugPrint("LATITUDE:", lat)
            debugPrint("LONGITUDE:", long)
            setLoaction(lattitude: lat, longitude: long)
            
        } else
        {
            proxy.sharedProxy().displayStatusCodeAlert("Unable fetching locations")
        }
    }
    
    func setLoaction(lattitude:String, longitude:String)  {
        let param = [
            "lat":"\(lattitude)" ,
            "lng" : "\(longitude)",
            ] as [String:AnyObject]
        
        proxy.sharedProxy().postData("\(KServerUrl)\(KPartnerLocation)", params: param, showIndicator: true, completion: { (JSON) in
            if JSON["status"] as! Int == 200 {
                if  let data = JSON["data"] as? NSArray {
                    self.arrayLocationDetials = [LocationModel]()
                    for i in 0..<data.count {
                        if let dic = data[i] as? NSDictionary {
                            let mutatedDic = dic.mutableCopy() as! NSMutableDictionary
                            let locationData = LocationModel()
                            mutatedDic.setValue(0, forKey: "isSelected")
                            locationData.setUserLocation(dictDetail: mutatedDic)
                            self.arrayLocationDetials.append(locationData)//add(locationData)
                        }
                    }
                    
                    self.mapvwMyLocation.removeAnnotations(self.mapvwMyLocation.annotations)
                    
                    for i in 0 ..< self.arrayLocationDetials.count {
                        let modalPartners = self.arrayLocationDetials[i]
                        if modalPartners.latitude != "" && modalPartners.longitude != "" {
                            let annotation = PartnersAnnotation.init(coordinate: CLLocationCoordinate2DMake( Double(modalPartners.latitude)! as CLLocationDegrees, Double(modalPartners.longitude)! as CLLocationDegrees), index: i, name: "", address: modalPartners.address, estimatedDestance: "")
                            self.mapvwMyLocation.addAnnotation(annotation)
                        }
                    }
   
                    
                }
            } else {
                if let error = JSON["error"] as? String {
                    self.arrayLocationDetials = [LocationModel]()
                    proxy.sharedProxy().displayStatusCodeAlert(error)
                }
            }
            
            self.tblvwLocationList.dataSource = self
            self.tblvwLocationList.delegate = self
            self.tblvwLocationList.reloadData()
            KAppDelegate.hideActivityIndicator()
        })
    }
    
    //MARK:- btnAction
    @IBAction func btnSerachLocationAction(_ sender: Any) {
        let addressVc = storyboard?.instantiateViewController(withIdentifier: "addressVC") as! addressVC
        self.navigationController?.pushViewController(addressVc, animated: true)
    }
    
    func addressLocation(_ address: String, location: NSDictionary) {
        lbllocationName.text = address
        
        if location.count>0
        {
            addressLat = String(describing: location["lat"]!)
            addressLong = String(describing: location["lng"]!)
            setLoaction(lattitude: addressLat, longitude: addressLong)
        }else{
           proxy.sharedProxy().displayStatusCodeAlert("No location found")
        }
        
    }
    @IBAction func btnBackAction(_ sender: Any) {
        if comeFrom == "Drawer" {
            KAppDelegate.sideMenuVC.openLeft()
        }else{
            self.navigationController!.popViewController(animated: true)
        }
    }
    
    @IBAction func btnLocationDetailAction(_ sender: Any) {
        let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"LocationHourlyServiceVC") as! LocationHourlyServiceVC
        present(otpCodeVc, animated: true, completion: nil)
        }
    
    // Mark APi PartnerLocation
    func partnerLocation() {
        let locationStr = userSelectedLocation.componentsJoined(by: ",")
        let param = [
            "location"     : locationStr ,
            "id" :       profileModel.id            ] as [String : Any]
        print(param)
        
        let userLocationUrl = "\(KServerUrl)\(KUserLocation)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            request(userLocationUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    print(JSONDIC as Any)
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                                print("Response:",JSONDIC)
                                } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(userLocationUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KUserLocation)  {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
            if JSON["status"] as! Int == 200 {
                //IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        print(dic)
                        //profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
            let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"CreateAccountVC") as! CreateAccountVC
            self.navigationController?.pushViewController(otpCodeVc,animated: true)
            
            
        }
        
    }
    
    @IBAction func btnNextAction(_ sender: Any) {
        if comeFrom == "Drawer" {
            //pending
        }else{
            partnerLocation()
        }
    }
    
    //MARK:- tableview datasource and delegte
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayLocationDetials.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FindMyLocationCell", for: indexPath) as! FindMyLocationCell
        let locationModelObj = arrayLocationDetials[indexPath.row]
        cell.lblLocationName.text = locationModelObj.address
        cell.lblCompanyName.text = locationModelObj.business_name
        
        if locationModelObj.isSeleced == 0
        {
            cell.btnSelect.setImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
        }else{
            cell.btnSelect.setImage(#imageLiteral(resourceName: "ic_check"), for: .normal)
        }
        
        cell.btnSelect.tag = indexPath.row
        cell.btnSelect.addTarget(self, action: #selector(btnSelectAction(sender:)), for: .touchUpInside)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    func btnSelectAction(sender: UIButton) {
        let position: CGPoint = sender.convert(.zero, to: tblvwLocationList)
        if let indexPath = tblvwLocationList.indexPathForRow(at: position)
        {
            let locationModelObj = arrayLocationDetials[indexPath.row]
            let getId = locationModelObj.id
            if userSelectedLocation.count>0
            {
                if userSelectedLocation.contains(getId)
                {
                    locationModelObj.isSeleced = 0
                    userSelectedLocation.remove(getId)
                }else{
                    locationModelObj.isSeleced = 1
                    userSelectedLocation.add(getId)
                }
            }else{
                locationModelObj.isSeleced = 1
                userSelectedLocation.add(getId)
            }
            tblvwLocationList.reloadData()
            debugPrint("UserSelected Location",userSelectedLocation)
        }
    }
    
    //Mark:- MapVIEW  METHODS
       func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        let location = locations.last as! CLLocation
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        var region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        region.center = mapvwMyLocation.userLocation.coordinate
        mapvwMyLocation.setRegion(region, animated: true)
        }
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
            if annotation.isKind(of: PartnersAnnotation.self) {
            let anView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
            let annotationCustomer = annotation as! PartnersAnnotation
            let imgAnno = UIImageView()
            imgAnno.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            imgAnno.image = #imageLiteral(resourceName: "gpsimage")
            anView.canShowCallout = false
            anView.addSubview(imgAnno)
            anView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            return anView
        }
        return nil
    }
    
}
extension FindMyLocationVC : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
    
}
