
import UIKit
import Alamofire

class DrawerVC: UIViewController,UITableViewDelegate,UITableViewDataSource{
    // MARK:- IB OUTLETS
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtfldName: UITextField!
    @IBOutlet weak var txtfldAddress: UITextField!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var txtfldState: UITextField!
    @IBOutlet weak var txtfldZip: UITextField!

    // MARK:- VARIABLES
    let arrayimages = ["ic_truck", "ic_packg", "ic_list", "DrawerMyAccount", "DrawerHelp", "DrawerLogout"]
    
    let array1 = ["Receive Packages", "Package Pick Up", "History", "Profile","Help","Log Out"]
    let arrRows = [[],[],[],["- Edit Partner Info","- Edit Days/Hrs of Service","- Edit Marketing Message"],[], []]
    
    var totalArrray = NSMutableArray()
    
    // MARK:- View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
      
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KMyAccount)\(userid)"
        Update(strURL: strURL, param: nil)
        self.navigationController?.navigationBar.isHidden = true
        let nibName = UINib(nibName: "DrawerTableViewCell", bundle: nil)
        tblView.register(nibName, forCellReuseIdentifier: "drawerCell")
    }
    
    
    func Update(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray {
                    if let dict = arr[0] as? NSDictionary {
                        
                    partnerInfoModel.setUserInfo(dictDetail: dict.mutableCopy() as! NSMutableDictionary)
                        
                      self.txtfldName.text = partnerInfoModel.bzname
                      self.txtfldAddress.text = partnerInfoModel.strtadd
                      self.lblCity.text = partnerInfoModel.cty
                      self.txtfldState.text = partnerInfoModel.stat
                      self.txtfldZip.text = partnerInfoModel.zpp
                    }
                }
                self.tblView.reloadData()
            }
            else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.Update(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    //MARK:- TABLE VIEW METHODS
    func numberOfSections(in tableView: UITableView) -> Int {
            return array1.count
        }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if totalArrray.contains(section) {
            return (arrRows[section] as NSArray).count
        }
        return 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "drawerCell", for: indexPath) as! DrawerTableViewCell

        let arr = arrRows[indexPath.section] as NSArray
        cell.lblContent.text = arr[indexPath.row] as? String
        cell.lblContent.adjustsFontSizeToFitWidth = true
        return cell
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view1 = UIView.init()
        let label = UILabel()
        label.frame = CGRect(x: 58, y: 5, width: 200, height: 50)
        label.text = array1[section]
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(clickedSection(_:)))
        tapGesture.accessibilityHint = String(section)
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 20, y: 20, width: 20, height: 20)
        image.image = UIImage(named: arrayimages[section])
        view1.addSubview(image)
        view1.addSubview(label)
        view1.addGestureRecognizer(tapGesture)
        return view1
    }
    
    func clickedSection(_ sender: UITapGestureRecognizer) -> Void {
        let section : Int = Int(sender.accessibilityHint!)!
        switch section {
        case 0:
            KAppDelegate.popToDrawerViewcontroller(identifier:"ImagePackVC")
            break
        case 1:
            KAppDelegate.popToDrawerViewcontroller(identifier:"PkgPickUpScanInfo")
            break
        case 2:
            KAppDelegate.popToDrawerViewcontroller(identifier:"MyStorePackagesVC")
            break
        case 3:
            if totalArrray.contains(section) {
               totalArrray.remove(section)
            } else {
               totalArrray.add(section)
            }
            tblView.reloadData()
            break
        case 4:
            KAppDelegate.popToDrawerViewcontroller(identifier:"HelpViewController")
            break
        case 5:
            logOut()
            break
            
        default:
            break
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            KAppDelegate.popToDrawerViewcontroller(identifier:"MyAccountInfoVC")
            
        }   else if indexPath.row==1{
            KAppDelegate.popToDrawerViewcontroller(identifier:"MyAccountSecondVC")
        }
        else{
            KAppDelegate.popToDrawerViewcontroller(identifier:"MyAccountMsgVC")
        }
    }
    
    //MARK:- API REQUEST
    func logOut() {
        let logoutURL = "\(Apis.KServerUrl)\(Apis.KLogout)"
        let reachability = Reachability()
        if  reachability!.isReachable {
            KAppDelegate.showActivityIndicator()
            request(logoutURL, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers: ["auth_code": "\(Proxy.sharedProxy.authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do  {
                        KAppDelegate.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary {
                            if (JSON["status"]! as AnyObject).isEqual(200) {
                                
                                UserDefaults.standard.set("", forKey: "auth_code")
                                UserDefaults.standard.synchronize()
                                KAppDelegate.gotoLoginSignUpVC()
                                Proxy.sharedProxy.displayStatusCodeAlert("You are Logged Out Successfully")
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                Proxy.sharedProxy.stautsHandler(logoutURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                    }
            }
        }
    }
}
