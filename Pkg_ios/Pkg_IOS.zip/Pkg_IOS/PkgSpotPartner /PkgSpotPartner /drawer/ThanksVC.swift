//
//  ThanksVC.swift
//  tableView
//
//  Created by Tajinder Singh on 24/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class ThanksVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnLoginYourAccountAction(_ sender: Any) {
      let loginVc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVc") as! LoginVc
      self.navigationController?.pushViewController(loginVc , animated: true)
    }
  
    @IBAction func btnOpenWithFacebookAction(_ sender: Any) {
    }
    
    
    @IBAction func btnOpenWithTwiter(_ sender: Any) {
    }
    
}



