//
//  CollectionViewCell.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 13/09/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var vwContainer: UIView!
    @IBOutlet weak var lblImageNumber: UILabel!
    @IBOutlet weak var btnDeleteImageOutlet: UIButton!
    
}
