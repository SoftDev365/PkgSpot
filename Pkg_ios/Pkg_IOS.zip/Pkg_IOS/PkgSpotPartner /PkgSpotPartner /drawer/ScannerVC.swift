
import UIKit
import AVFoundation

protocol OCRViewControllerDelegate {
    func ocrSendImage(imgCaptured:UIImage)
}

var protocolOCR: OCRViewControllerDelegate?

protocol ScannerDelegate {
    func sendImage(imgDetected: UIImage?,strDetectedText:String)
}

var protocolScannedImage: ScannerDelegate?

class ScannerVC: UIViewController ,AVCaptureMetadataOutputObjectsDelegate,AVCaptureVideoDataOutputSampleBufferDelegate{
    
    //MARK: - VARIABLES
    var captureSession:AVCaptureSession?
    var videoPreviewLayer:AVCaptureVideoPreviewLayer?
    var qrCodeFrameView:UIView?
    private let context = CIContext()
    var imageCaptured : UIImage?
    var isDetectQRorBarCode = Bool()
    
    //MARK: - IBOUTLET
    @IBOutlet weak var vwCameraContainer: UIView!
    @IBOutlet weak var btnCaptureCamera: UIButton!
    
    //Added to support different barcodes
    let supportedBarCodes = [
            AVMetadataObjectTypeUPCECode,
            AVMetadataObjectTypeCode39Code,
            AVMetadataObjectTypeCode39Mod43Code,
            AVMetadataObjectTypeEAN13Code,
            AVMetadataObjectTypeEAN8Code,
            AVMetadataObjectTypeCode93Code,
            AVMetadataObjectTypeCode128Code,
            AVMetadataObjectTypePDF417Code,
            AVMetadataObjectTypeAztecCode,
            AVMetadataObjectTypeQRCode
        ]
    
    //MARK: - VIEW CONTROLLER
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // isDetectQRorBarCode = true
        
        // Get an instance of the AVCaptureDevice class to initialize a device object and provide the video
        // as the media type parameter.
        let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        do {
            // Get an instance of the AVCaptureDeviceInput class using the previous device object.
            let input = try AVCaptureDeviceInput(device: captureDevice)
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            
            // Set the input device on the capture session.
            captureSession?.addInput(input)
            
            if isDetectQRorBarCode {
                self.btnCaptureCamera.isHidden = true
                // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
                let captureMetadataOutput = AVCaptureMetadataOutput()
                captureSession?.addOutput(captureMetadataOutput)
                
                // Set delegate and use the default dispatch queue to execute the call back
                captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                
                // Detect all the supported bar code
                captureMetadataOutput.metadataObjectTypes = supportedBarCodes
            }
            
            let videoOutput = AVCaptureVideoDataOutput()
            videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "sample buffer"))
            captureSession?.addOutput(videoOutput)
            
            guard let connection = videoOutput.connection(withMediaType: AVFoundation.AVMediaTypeVideo) else { return }
            guard connection.isVideoOrientationSupported else { return }
            //guard connection.isVideoMirroringSupported else { return }
            connection.videoOrientation = .portrait
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
            videoPreviewLayer?.frame = view.layer.bounds
            //videoPreviewLayer?.frame.size.height = 300.0
            //videoPreviewLayer?.frame.size.width = 300.0
            vwCameraContainer.layer.addSublayer(videoPreviewLayer!)
            
            // Start video capture
            captureSession?.startRunning()
            
            if isDetectQRorBarCode {
                // Initialize QR Code Frame to highlight the QR code
                qrCodeFrameView = UIView()
                if let qrCodeFrameView = qrCodeFrameView {
                    qrCodeFrameView.layer.borderColor = UIColor.green.cgColor
                    qrCodeFrameView.layer.borderWidth = 2
                    view.addSubview(qrCodeFrameView)
                    view.bringSubview(toFront: qrCodeFrameView)
                }
            }
        } catch {
            // If any error occurs, simply print it out and don't continue any more.
            print(error)
            return
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.captureSession?.stopRunning()
        self.captureSession = nil
    }
    
    // MARK:- Sample buffer to UIImage conversion
    private func imageFromSampleBuffer(sampleBuffer: CMSampleBuffer) -> UIImage? {
        guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return nil }
        let ciImage = CIImage(cvPixelBuffer: imageBuffer)
        guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
    
    // MARK:- AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputSampleBuffer sampleBuffer: CMSampleBuffer!, from connection: AVCaptureConnection!) {
        guard let uiImage = imageFromSampleBuffer(sampleBuffer: sampleBuffer) else { return }
        DispatchQueue.main.async { [unowned self] in
            self.imageCaptured = uiImage
            print("didOutputSampleBuffer: ",self.imageCaptured!)
        }
    }
    
    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0 {
            qrCodeFrameView?.frame = CGRect.zero
            //messageLabel.text = "No barcode/QR code is detected"
            return
        }
        // Get the metadata object.
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        let metaData =  metadataObjects.first
        if let barcode = metaData as? AVMetadataMachineReadableCodeObject {
            if  let strDetectedText = metadataObj.stringValue{
                // CONVERT META DATA INTO USER READABLE FORM
                let decodeBounds = videoPreviewLayer?.transformedMetadataObject(for: barcode).bounds
                qrCodeFrameView?.layer.borderWidth = 4
                qrCodeFrameView?.layer.borderColor = UIColor.green.cgColor
                qrCodeFrameView?.frame = decodeBounds!
                self.view.bringSubview(toFront: qrCodeFrameView!)
                
                let dispatchTime = DispatchTime.now() + 0.5
                DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                    self.dismiss(animated: true, completion: {
                        guard self.imageCaptured != nil else { return }
                        protocolScannedImage?.sendImage(imgDetected: self.imageCaptured!, strDetectedText: strDetectedText)
                        self.captureSession?.stopRunning()
                        self.captureSession?.stopRunning()
                    })
                })
            }
        }
        
        // Here we use filter method to check if the type of metadataObj is supported
        // Instead of hardcoding the AVMetadataObjectTypeQRCode, we check if the type
        // can be found in the array of supported bar codes.
        
        if supportedBarCodes.contains(metadataObj.type) {
            //If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            qrCodeFrameView?.frame = barCodeObject!.bounds
            if metadataObj.stringValue != nil {
                let dispatchTime = DispatchTime.now() + 0.5
                DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                    self.dismiss(animated: true, completion: {
                        guard self.imageCaptured != nil else { return }
                        protocolScannedImage?.sendImage(imgDetected: self.imageCaptured!, strDetectedText: metadataObj.stringValue)
                    })
                })
            }
        }
    }
    
    @IBAction func btnActionCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- Button Action For OCR
    @IBAction func btnActionCaptureImage(_ sender: Any) {
        self.dismiss(animated: true) {
            protocolOCR?.ocrSendImage(imgCaptured: self.imageCaptured!)
        }
    }
}




