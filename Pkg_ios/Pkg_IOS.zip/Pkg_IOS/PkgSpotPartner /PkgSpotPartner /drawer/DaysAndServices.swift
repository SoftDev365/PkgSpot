
import Foundation

var DaysAndServices = DaysAndService()

class DaysAndService {
    
    var day = String()
    var starttime = Int()
    var endtime = Int()
    
    var dayOfService = NSArray()
    
    func userData(dictDetail: NSDictionary){
        if let starttime = dictDetail["start_time"] as? integer_t{
                self.starttime = Int(starttime)
        }
        if let day = dictDetail["day"] as? String{
                self.day = day
        }
        if let endtime = dictDetail["end_time"] as? integer_t{
            self.endtime = Int(endtime)
        }
    }
}
