
import UIKit

var signUpUserObj = SignUpUserInfoModel()

class SignUpTimeDaysVC: UIViewController,UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate {
    
    //MARK: - IBOUTLETS
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnrefMon: SetCornerButton!
    @IBOutlet weak var btnrefTue: SetCornerButton!
    @IBOutlet weak var btnrefWed: SetCornerButton!
    @IBOutlet weak var btnrefThrs: SetCornerButton!
    @IBOutlet weak var btnrefFri: SetCornerButton!
    @IBOutlet weak var btnrefSat: SetCornerButton!
    @IBOutlet weak var btnrefSun: SetCornerButton!
    
    @IBOutlet weak var btnCheck: SetCornerButton!
    @IBOutlet weak var refbtnSelectAll: SetCornerButton!
    
    @IBOutlet weak var btnCheckSatSun: SetCornerButton!
    @IBOutlet weak var refbtnSelSunSat: SetCornerButton!
    
    //MARK: - VARIABLE
    let daysArray = ["M","T","W","T","F","S","S"]
    var isSelected = ["0","0","0","0","0","0","0"]
    var selectedDaysAndTime = NSMutableArray()
    var dictDaysOfServices :[String: String] = [:]
    
    let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    let arrMon = ["monday", "tuesday", "wednesday", "thursday", "friday"]
    let arrSat = ["saturday", "sunday"]
    var colorSat = 0
    var selectSat = 0
    var color = 0
    var selectAll = 0
    
    //MARK:-View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.dataSource = self
        tblView.delegate = self
        tblView.reloadData()
        
        btnCheck.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
        
        for i in 0..<arrDay.count{
            let selectedHrDic = NSMutableDictionary()
            selectedHrDic["start_time"] = ""
            selectedHrDic["end_time"] = ""
            selectedHrDic["day"] = "\(arrDay[i])"
            selectedHrDic["isSelected"] = "0"
            selectedDaysAndTime.add(selectedHrDic)
            let startIndex = (i + 1)*100
            let endIndex = ((i + 1)*100) + 1
            dictDaysOfServices["\(startIndex)"] = ""
            dictDaysOfServices["\(endIndex)"] = ""
        }
        debugPrint("selectedDaysAndTime",selectedDaysAndTime)
    }

    @IBAction func btnActionSetFIxedValue(_ sender: Any) {
        let selectedHrDic = selectedDaysAndTime.object(at: 0) as! NSMutableDictionary
        if selectedHrDic["start_time"] as! String == "" || selectedHrDic["end_time"] as! String == "" {
            Proxy.sharedProxy.displayStatusCodeAlert("Please set monday time")
        }
        else{
            if selectAll == 0 {
                refbtnSelectAll.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                refbtnSelectAll.setTitleColor(UIColor.white, for: UIControlState.normal)
                selectAll = 1
                let startTime = selectedHrDic["start_time"] as! String
                let endTime = selectedHrDic["end_time"] as! String
                for i in 0..<arrMon.count {
                    let startIndex = (i + 1)*100
                    let endIndex = ((i + 1)*100) + 1
                    dictDaysOfServices["\(startIndex)"] = startTime
                    dictDaysOfServices["\(endIndex)"] = endTime
                    
                    let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                    selectedHrDic["start_time"] = startTime
                    selectedHrDic["end_time"] = endTime
                    //selectedHrDic["isSelected"] = "1"
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
            }
            else {
                refbtnSelectAll.backgroundColor = UIColor.white
                refbtnSelectAll.setTitleColor(UIColor.gray, for: UIControlState.normal)
                for i in 0..<arrMon.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                    selectedHrDic["start_time"] = ""
                    selectedHrDic["end_time"] = ""
                    let startIndex = (i + 1)*100
                    let endIndex = ((i + 1)*100) + 1
                    dictDaysOfServices["\(startIndex)"] = ""
                    dictDaysOfServices["\(endIndex)"] = ""
                    //selectedHrDic["isSelected"] = "0"
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
                selectAll = 0
            }
        }
        tblView.reloadData()
    }
    
    @IBAction func btnActionSelectAll(_sender: Any) {
        if color == 0  {
            btnrefMon.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnrefMon.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnrefTue.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnrefTue.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnrefWed.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnrefWed.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnrefThrs.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnrefThrs.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnrefFri.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnrefFri.setTitleColor(UIColor.white, for: UIControlState.normal)
            color = color + 1
            btnCheck.setBackgroundImage( #imageLiteral(resourceName: "ic_check"), for: .normal)
            debugPrint("selectedDaysAndTime", selectedDaysAndTime)
            
            for i in 0..<arrMon.count{
                let getDictData = selectedDaysAndTime[i] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "1"
                }else {
                    getDictData["isSelected"] = "1"
                }
                tblView.reloadData()
            }
            debugPrint("selectedDaysAndTime", selectedDaysAndTime)
        } else {
            btnrefMon.backgroundColor = UIColor.white
            btnrefMon.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnrefTue.backgroundColor = UIColor.white
            btnrefTue.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnrefWed.backgroundColor = UIColor.white
            btnrefWed.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnrefThrs.backgroundColor = UIColor.white
            btnrefThrs.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnrefFri.backgroundColor = UIColor.white
            btnrefFri.setTitleColor(UIColor.gray, for: UIControlState.normal)
            color = color - 1
            btnCheck.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
            for i in 0..<arrMon.count{
                let getDictData = selectedDaysAndTime[i] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "0"
                } else{
                    getDictData["isSelected"] = "0"
                }
            }
            tblView.reloadData()
        }
    }
    
    
    //MARK:- Set Time
    @IBAction func btnActionSetTimeSatSun(_ sender: Any) {
        let selectedHrDic = selectedDaysAndTime.object(at: 5) as! NSMutableDictionary
        if colorSat == 0{
            Proxy.sharedProxy.displayStatusCodeAlert("Please select hour services")
        }else if selectedHrDic["start_time"] as! String == "" || selectedHrDic["end_time"] as! String == "" {
            Proxy.sharedProxy.displayStatusCodeAlert("Please set Saturday time")
        } else{
            if selectSat == 0 {
                refbtnSelSunSat.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                refbtnSelSunSat.setTitleColor(UIColor.white, for: UIControlState.normal)
                
                selectSat = 1
                
                let startTime = selectedHrDic["start_time"] as! String
                let endTime = selectedHrDic["end_time"] as! String
                
                for i in 0..<arrSat.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i+5) as! NSMutableDictionary
                    selectedHrDic["start_time"] = startTime
                    selectedHrDic["end_time"] = endTime
                    //selectedHrDic["isSelected"] = "1"
                    selectedDaysAndTime.replaceObject(at: i+5, with: selectedHrDic)
                }
            } else{
                refbtnSelSunSat.backgroundColor = UIColor.white
                refbtnSelSunSat.setTitleColor(UIColor.gray, for: UIControlState.normal)
                
                for i in 0..<arrSat.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i+5) as! NSMutableDictionary
                    selectedHrDic["start_time"] = ""
                    selectedHrDic["end_time"] = ""
                    //selectedHrDic["isSelected"] = "0"
                    selectedDaysAndTime.replaceObject(at: i+5, with: selectedHrDic)
                }
                selectSat = 0
            }
        }
        tblView.reloadData()
    }
    
    @IBAction func btnCheckSat(_ sender: Any) {
        if colorSat == 0 {
            self.btnrefSat.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            self.btnrefSat.setTitleColor(UIColor.white, for: UIControlState.normal)
            self.btnrefSun.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            self.btnrefSun.setTitleColor(UIColor.white, for: UIControlState.normal)
           
            colorSat = colorSat + 1
           
            btnCheckSatSun.setBackgroundImage( #imageLiteral(resourceName: "ic_check"), for: .normal)
           
            for i in 0..<arrSat.count{
                let getDictData = selectedDaysAndTime[i+5] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "1"
                } else{
                    getDictData["isSelected"] = "1"
                }
                tblView.reloadData()
            }
        } else{
            self.btnrefSat.backgroundColor = UIColor.white
            self.btnrefSat.setTitleColor(UIColor.gray, for: UIControlState.normal)
            self.btnrefSun.backgroundColor = UIColor.white
            self.btnrefSun.setTitleColor(UIColor.gray, for: UIControlState.normal)
          
            colorSat = colorSat - 1
           
            btnCheckSatSun.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
            
            for i in 0..<arrSat.count{
                let getDictData = selectedDaysAndTime[i+5] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "0"
                }else{
                    getDictData["isSelected"] = "0"
                }
            }
            tblView.reloadData()
        }
    }
    
    //MARK:- TABLE VIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedDaysAndTime.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tblView.dequeueReusableCell(withIdentifier: "TableViewCellMA") as! TableViewCellMA
        let getDictData = selectedDaysAndTime[indexPath.row] as! NSMutableDictionary
        cell.btnRefMM.setTitle(daysArray[indexPath.row] , for: .normal)
        if getDictData["isSelected"] as! String == "0"{
            cell.btnRefMM.backgroundColor = UIColor.white
            cell.btnRefMM.titleLabel?.textColor = UIColor.gray
            cell.textfldStart.isUserInteractionEnabled = false
            cell.textfldEnd.isUserInteractionEnabled = false
        }else{
            cell.btnRefMM.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            cell.btnRefMM.titleLabel?.textColor = UIColor.white
            cell.textfldStart.isUserInteractionEnabled = true
            cell.textfldEnd.isUserInteractionEnabled = true
            cell.textfldStart.text = getDictData["start_time"] as? String
            cell.textfldEnd.text = getDictData["end_time"] as? String
        }
        cell.startTimePicker.datePickerMode = .time
        cell.endTimePicker.datePickerMode = .time
        cell.startTimePicker.tag = ((indexPath.row+1) * 100)
        cell.endTimePicker.tag = ((indexPath.row+1)*100)+1
        cell.textfldStart.tintColor = UIColor.clear
        cell.textfldEnd.tintColor = UIColor.clear
        cell.textfldStart.tag = ((indexPath.row+1)*100)
        cell.textfldEnd.tag = ((indexPath.row+1)*100)+1
        return cell
    }
    
    //MARK: - ACTIONS
    @IBAction func btnActSrvcDz(_ sender: UIButton) {
        //isSelectType = chooseType(rawValue:sender.tag)!
        if selectAll == 0 {
            let getDictData = selectedDaysAndTime[sender.tag] as! NSMutableDictionary
            if  getDictData["isSelected"] as! String == "0"{
                getDictData["isSelected"] = "1"
                sender.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                sender.setTitleColor(UIColor.white, for: UIControlState.normal)
            } else{
                getDictData["isSelected"] = "0"
                sender.backgroundColor = UIColor.white
                sender.setTitleColor(UIColor.gray, for: UIControlState.normal)
            }
            tblView.reloadData()
        }
    }
    
    @IBAction func startTimeAction(_ sender: UITextField) {
        debugPrint("Start TextField", sender.tag)
        dictDaysOfServices["\(sender.tag)"] = "\(sender.text!)"
        if selectAll == 1{
            for i in 0..<arrMon.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 1)*100
                let endIndex = ((0 + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }else{
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        if selectSat == 1 {
            for i in 5..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 6)*100
                let endIndex = ((0 + 6)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        else{
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
    }
    
    @IBAction func endTimeAction(_ sender: UITextField) {
        debugPrint("End TextField", sender.tag)
        dictDaysOfServices["\(sender.tag)"] = "\(sender.text!)"
        if selectAll == 1{
            for i in 0..<arrMon.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 1)*100
                let endIndex = ((0 + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        } else {
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        if selectSat == 1 {
            for i in 5..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 6)*100
                let endIndex = ((0 + 6)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        } else {
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
    }
    
    var resultedArray = NSMutableArray()
    
    @IBAction func btnActionNxt(_ sender: Any) {
        debugPrint("selectedDaysAndTime", selectedDaysAndTime)
        //This case is ruunig when single-2 selection for hrs & time
        if selectAll != 1 && selectSat != 1{
            for i in 0..<arrDay.count{
                let selectedHrDic = NSMutableDictionary()
                selectedHrDic["day"] = "\(arrDay[i])"
                let selectDict = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                isSelected[i] = selectDict["isSelected"] as! String
                selectedHrDic["isSelected"] = selectDict["isSelected"]
                let startIndex = (i + 1) * 100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
        }
        
        resultedArray = []
        var isEmpty = 0
        for i in 0..<isSelected.count{
            if isSelected[i] != "0"{
                let getStartDict = selectedDaysAndTime[i] as! NSMutableDictionary
                
                if getStartDict["start_time"] as! String == "" || getStartDict["end_time"] as! String == ""{
                    isEmpty = 0
                    Proxy.sharedProxy.displayStatusCodeAlert("Please select time")
                    break
                }else{
                    isEmpty += 1
                }
            }else{
                debugPrint("resultedArray", selectedDaysAndTime)
                isEmpty += 1
            }
        }
        
        if isEmpty == 0{
            debugPrint("resultedArray", resultedArray)
            Proxy.sharedProxy.displayStatusCodeAlert("Please select any services")
        }
        else{
            for index in 0..<selectedDaysAndTime.count{
                let getDictData = selectedDaysAndTime[index] as! NSMutableDictionary
                let dictData = NSMutableDictionary()
                let dictStartEnd = NSMutableDictionary()
                if  getDictData["isSelected"] as! String != "0"{
                    dictStartEnd.setValue( getDictData["start_time"], forKey: "start_time")
                    dictStartEnd.setValue(getDictData["end_time"], forKey: "end_time")
                    dictData.setValue(dictStartEnd, forKey: "\(arrDay[index])")
                    resultedArray.add(dictData)
                } else{
                    dictStartEnd.setValue("", forKey: "start_time")
                    dictStartEnd.setValue("", forKey: "end_time")
                    dictData.setValue(dictStartEnd, forKey: "\(arrDay[index])")
                    resultedArray.add(dictData)
                }
            }
            
            var isSelectCount = 0
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                if  selectedHrDic["isSelected"] as! String == "0"{
                    isSelectCount = isSelectCount + 1
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
            }
            if isSelectCount == selectedDaysAndTime.count {
                Proxy.sharedProxy.displayStatusCodeAlert("Please select any services")
                return
            }
            debugPrint("resultedArray", resultedArray)
            SignUP()
        }
    }
    
    // MARK:- SignUp API
    func SignUP() {
        var jsonString : NSString = ""
        do{
            let arrJson = try JSONSerialization.data(withJSONObject: resultedArray, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
        }
        catch let error as NSError{
            print(error.description)
            jsonString = "[]"
        }
        debugPrint("hoursService:", jsonString)
        
        //Other Parameters
        let param = [
            "business_name":"\(signUpObj.bzname)",
            "operating_as": "\(signUpObj.opras)",
            "address":"\(signUpObj.strtadd)",
            "city": "\(signUpObj.cty)",
            "state":"\(signUpObj.stat)",
            "zipcode":"\(signUpObj.zpp)" ,
            "full_name":"\(signUpObj.nam)",
            "position":"\(signUpObj.postn)",
            "website":"\(signUpObj.site)",
            "email":"\(signUpObj.email)",
            "contact_no":"\(signUpObj.phn)",
            "password":"\(signUpObj.psswrd)",
            "days_of_service":"\(jsonString)",
            "latitude" : "\(signUpObj.lat)" ,
            "longitude": "\(signUpObj.long)"
        ]
        let strURL = "\(Apis.KServerUrl)\(Apis.KSignUp)"
        signUp(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }
    
    func signUp(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let userIdVal = responseDict["userId"] as? Int{
                    signUpUserObj.userId = userIdVal
                }
                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpMarketingMsgVC") as! SignUpMarketingMsgVC
                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
            }else{
                if let errorMessage = responseDict["error"] {
                    
                    if let userid = responseDict["userId"] as? Int{
                        signUpUserObj.userId = userid
                    } else{
                    if Proxy.sharedProxy.checkStringIfNull(responseDict["userId"] as! String).characters.count > 0 {
                            signUpUserObj.userId = Int(responseDict["userId"] as! String)!
                        }
                    }
                    if signUpUserObj.userId == 0 {
                        Proxy.sharedProxy.displayStatusCodeAlert("Error: User not found!")
                    }
                    else{
                        if  let steps = responseDict.object(forKey: "step") as? Int{
                            switch steps{
                            case 0:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "ThanksSignUpVC") as! ThanksSignUpVC
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 1:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpMarketingMsgVC") as! SignUpMarketingMsgVC
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 2:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpMailVerificationVC") as! SignUpMailVerificationVC
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            case 3:
                                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpInfoVC") as! SignUpInfoVC
                                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                                break
                            default:
                                break
                            }
                        }
                    }
                    Proxy.sharedProxy.displayStatusCodeAlert(errorMessage as! String)
                }
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.signUp(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    enum chooseType: Int{
        case Mon,Tue, Wed, Thu, Fri, Sat, Sun
    }
    
    @IBAction func btnActionBck(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}


