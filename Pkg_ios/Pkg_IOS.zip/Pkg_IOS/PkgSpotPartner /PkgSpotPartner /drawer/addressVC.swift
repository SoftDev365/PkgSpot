import UIKit
import Alamofire
import CoreLocation


@objc protocol addressProtocol
{
     func getAddress(addressModal: AutoCompleteModel)
}
var addressLocProtocol:addressProtocol?

class addressVC: UIViewController, UISearchBarDelegate, UISearchDisplayDelegate, UISearchControllerDelegate, UITableViewDelegate, UITableViewDataSource , UISearchResultsUpdating   {
    
    //MARK:- Outlets
    @IBOutlet weak var searchTableVw: UITableView!
    
    //MARK:- Variables
    var searchController = UISearchController()
    var jsonResult = NSMutableDictionary()
    var resultsArray = NSArray()
    var locationArray = NSMutableArray()
    var arySavedDropOffs = NSMutableArray()
    var checkString = String()
    
    override func viewDidLoad() {
        if self.responds(to: #selector(getter: UIViewController.edgesForExtendedLayout)) {
            self.edgesForExtendedLayout = UIRectEdge()
        }
        searchTableVw.dataSource = self
        searchTableVw.delegate = self
        let searchResultsController: UITableViewController = UITableViewController(style: .plain)
        searchResultsController.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        searchResultsController.tableView.dataSource = self;
        searchResultsController.tableView.delegate = self;
        
        self.searchController = UISearchController(searchResultsController: searchResultsController)
        self.definesPresentationContext = true;
        self.searchController.searchBar.tintColor = UIColor.white;
        self.searchController.searchResultsUpdater = self;
        self.searchController.searchBar.delegate = self;
        
        self.searchController.hidesNavigationBarDuringPresentation = false
        self.navigationItem.titleView = self.searchController.searchBar;
        
        searchController.searchBar.setShowsCancelButton(true, animated: true)
        searchTableVw.tableHeaderView = self.searchController.searchBar;
    }
    
    override func viewWillAppear(_ animated: Bool){
        self.navigationController?.isNavigationBarHidden = true
        searchController.searchBar.canResignFirstResponder
        self.view.endEditing(true)
        searchTableVw.delegate = self
        searchTableVw.dataSource = self
        searchTableVw.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        (self.searchController.searchResultsController as! UITableViewController).tableView.reloadData()
    }
    
    //MARK:- Back Tab
    @IBAction func btnBackNavAction(_ sender: AnyObject) {
        self.navigationController!.popViewController(animated: true)
    }

    //MARK:-  Search Delegate Method
    
    //func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        searchBar.tintColor = UIColor.blue
        
        let rect = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 64)
        let topView = UIView(frame: rect)
        topView.backgroundColor = UIColor.white
        let lblVC = UILabel(frame: CGRect(x: 29, y: 29, width: 210, height: 21))
        lblVC.text = "Select Address"
        lblVC.font = UIFont(name: lblVC.font.fontName, size: 20)
        
        lblVC.textColor = UIColor.white
        lblVC.textAlignment = .center
        let btnBack = UIButton(frame: CGRect(x: 0, y: 8, width: 59, height: 63))
        btnBack.addTarget(self, action: #selector(addressVC.btnBackAction(_:)), for: .touchUpInside)
        btnBack.setImage(UIImage(named: "back_arrow_grey"), for: UIControlState())
        topView.addSubview(btnBack)
        topView.addSubview(lblVC)
        self.searchController.view.addSubview(topView)
        print("Searched text: ",self.searchController.searchBar.text )
        if self.searchController.searchBar.text!.trimmingCharacters(in: CharacterSet.whitespaces).characters.count > 0{
            let delay = 1.0 * Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay)) / Double(NSEC_PER_SEC)) { () -> Void in
                self.search_API( self.searchController.searchBar.text!)
            }
        }
    }

    func updateSearchResults(for searchController: UISearchController) {
    }
    
    //MARK:- Search API
    func search_API( _ searchText:String){
        var currentLat : String!
        var currentLong : String!
        let trimmedText = searchText.replacingOccurrences(of: " ", with: "%20")
        if UserDefaults.standard.object(forKey: "lat") != nil {
            currentLat = UserDefaults.standard.object(forKey: "lat") as? String
            currentLong = UserDefaults.standard.object(forKey: "long") as? String
        }else{
            currentLat = ""
            currentLong = ""
        }
        
        //client id= AIzaSyARbc_W9MBsfo1qypNRSAi_hhm0eZaPW08
        let apiAddress = "\(Apis.googleBaseURL)" + "place/textsearch/json?query="
        let searchAddress = apiAddress + trimmedText + "&key=AIzaSyARbc_W9MBsfo1qypNRSAi_hhm0eZaPW08&sensor=false"
        //AIzaSyCrlmhJO9FWVGaX5wZiZ9Fw9D9SmkXjbJU
        //AIzaSyDiP60Sy3ZCOlqLIYWdEZFCvTZIhydpeus
        //AIzaSyBA9y38IDYytKT0WuyMawIgu1_7dkTojJI
        request(searchAddress, method: .get, parameters: nil, encoding: JSONEncoding.default , headers: nil)
            .responseJSON { response in
                do
                { if(response.response?.statusCode == 200) {
                        if let JSON = response.result.value as? NSDictionary{
                            self.serviceResponsePlace(JSON .mutableCopy() as! NSMutableDictionary)
                        }else{
                            Proxy.sharedProxy.displayStatusCodeAlert("Error Unable to response from server")
                        }
                }else {
                    Proxy.sharedProxy.stautsHandler(searchAddress, parameter: nil, response: response.response, data:response.data, error: response.result.error as NSError?)
                    }
                }
            }
        }
    
    func serviceResponsePlace(_ JSON:NSMutableDictionary) {
        if (JSON["status"]! as AnyObject).isEqual("OK"){
            let resultsArray = JSON["results"] as! NSArray
            self.locationArray.removeAllObjects()
            for i in 0 ..< resultsArray.count {
                var dict = NSMutableDictionary()
                dict = (resultsArray[i] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                let strlat = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lat") as! NSNumber
                let strlong = ((dict.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary).object(forKey: "lng") as! NSNumber
                
                let autoCompleteModel = AutoCompleteModel()
                autoCompleteModel.descriptionName = "\(dict["formatted_address"]!)"
                autoCompleteModel.locationCoordinate = CLLocationCoordinate2D.init(latitude: Double(strlat), longitude: Double(strlong))
                
                self.locationArray.add(autoCompleteModel)
                (self.searchController.searchResultsController as! UITableViewController).tableView.reloadData()
            }
        }
        else{
            let errorMessage = JSON["status"] as! String
            Proxy.sharedProxy.displayStatusCodeAlert(errorMessage)
        }
    }
    
    //MARK:- TableView Delegate methods
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return locationArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
       var cell = UITableViewCell()
        if  locationArray.count > 0{
            let cellID = "cell"
            cell = (self.searchController.searchResultsController as! UITableViewController).tableView.dequeueReusableCell(withIdentifier: cellID)!
            cell = UITableViewCell(style: .default, reuseIdentifier: cellID)
            let autoCompleteModel = locationArray[(indexPath as NSIndexPath).row] as? AutoCompleteModel
            cell.textLabel?.text =  autoCompleteModel?.descriptionName
            cell.textLabel?.numberOfLines = 20
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (tableView == (self.searchController.searchResultsController as! UITableViewController).tableView)
        { if locationArray.count > 0 {
                if (tableView == (self.searchController.searchResultsController as! UITableViewController).tableView){
                    let autoCompleteModel = locationArray[(indexPath as NSIndexPath).row] as! AutoCompleteModel
                    let geoCode = "https://maps.googleapis.com/maps/api/geocode/json?address=\(autoCompleteModel.descriptionName)&key=AIzaSyARbc_W9MBsfo1qypNRSAi_hhm0eZaPW08&sensor=false"
                    let formattedString = geoCode.replacingOccurrences(of: " ", with: "%20")
                    
                    Proxy.sharedProxy.getData(formattedString, showIndicator: false, completion: { (responseDict) in
                        debugPrint("response ",responseDict)
                        if  let arrResult = responseDict.object(forKey: "results") as? NSArray{
                            if  arrResult.count > 0{
                                let dictComponent = arrResult.object(at: 0) as! NSDictionary
                                if let arrComponents = dictComponent.object(forKey: "address_components") as? NSArray{
                                    for i in 0 ..< arrComponents.count{
                                        if let dictData = arrComponents.object(at: i) as? NSDictionary{
                                            if let arrType = dictData.object(forKey: "types") as? NSArray{
                                                for j in 0 ..< arrType.count {
                                                    let someType = arrType.object(at: j) as! String
                                                    if someType == "postal_code"{
                                                        if let zipCode = dictData.object(forKey: "long_name") as? String{j
                                                            autoCompleteModel.zipCode = zipCode
                                                        }
                                                    }
                                                    if someType == "street_number"{
                                                        if let strStreetNumber = dictData.object(forKey: "long_name") as? String{
                                                            autoCompleteModel.strStreetNumber = strStreetNumber
                                                        }
                                                    }
                                                    if someType == "route"{
                                                        if let route = dictData.object(forKey: "long_name") as? String{
                                                            autoCompleteModel.route = route
                                                        }
                                                    }
                                                    if someType == "administrative_area_level_1"{
                                                        if let strState = dictData.object(forKey:"long_name") as? String{
                                                            autoCompleteModel.strState = strState
                                                        }
                                                    }
                                                    if someType == "locality"{
                                                        if let strCity = dictData.object(forKey:"long_name") as? String{
                                                            autoCompleteModel.strCity = strCity
                                                        }
                                                    }
                                                    if someType == "country"{
                                                        if let strCou = dictData.object(forKey:"short_name") as? String{
                                                            autoCompleteModel.strCountry = strCou
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        addressLocProtocol?.getAddress(addressModal: autoCompleteModel )
                        self.navigationController?.popViewController(animated: false)
                    })
                    { (error) in
                    }
                }
            }
        }
    }
   
    //MARK:- Back Tab
    @IBAction func btnBackAction(_ sender: AnyObject) {
        self.navigationController!.popViewController(animated: true)
    }
    
    //MARK:- get Location Api
    func getloc(_ id: String, place : String){
        let getlocUrl = "https://maps.googleapis.com/maps/api/place/details/json?placeid=\(id)&key=AIzaSyARbc_W9MBsfo1qypNRSAi_hhm0eZaPW08&sensor=false"
        request(getlocUrl, method: .get, parameters: nil, encoding: JSONEncoding.default , headers: nil)
            .responseJSON { response in
                do
                {
                    if(response.response?.statusCode == 200)
                    {
                        KAppDelegate.hideActivityIndicator()
                        self.locationArray.removeAllObjects()
                        NSLog("LOCATION ARRAY: %@", self.locationArray)
                        NSLog("RESULT ARRAY: %@", self.resultsArray)
                        var JSONDIC = NSMutableDictionary()
                        JSONDIC = (response.result.value as! NSDictionary).mutableCopy() as! NSMutableDictionary
                        if JSONDIC.allKeys.count > 0{
                            if JSONDIC["result"] != nil{
                                let JSONDIC1 = (JSONDIC["result"] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                                if JSONDIC1.allKeys.count > 0{
                                    _ = (JSONDIC1["formatted_address"]as? String)!
                                    let geomatery = JSONDIC1["geometry"] as! NSDictionary
                                    let location = geomatery["location"] as! NSDictionary!
                                    let placeName1 = place
                                    //addressLocProtocol?.addressLocation(placeName1, location: location!)
                                }
                                _ =    self.navigationController?.popViewController(animated: true)
                            }
                            else{
                                Proxy.sharedProxy.displayStatusCodeAlert("Address not found")
                            }
                        }
                    }
                }
            }
        }
}
