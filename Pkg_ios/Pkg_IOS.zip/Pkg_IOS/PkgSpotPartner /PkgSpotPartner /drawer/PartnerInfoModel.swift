

import Foundation

var partnerInfoModel = PartnerInfoModel()

class PartnerInfoModel {
    
    var bzname = String()
    var opras = String()
    var strtadd = String()
    var cty = String()
    var stat = String()
    var zpp = String()
    var nam = String()
    var postn = String()
    var site = String()
    var email = String()
    var phn = String()
    var psswrd = String()
    var marketMsg = String()
    var dn = String()
    var starttime = String()
    var day = String()
    var str_unique_id = String()
  
    var dayOfServiceArray = [DaysAndService]()
    
    func setUserInfo(dictDetail: NSMutableDictionary){
        if let bzname = dictDetail["business_name"] as? String {
            self.bzname = bzname
        }
        if let opras = dictDetail["operating_as"] as? String{
            self.opras = opras
        }
        if let strtadd = dictDetail["address"] as? String{
            self.strtadd = strtadd
        }
        if let cty = dictDetail["city"] as? String{
            self.cty = cty
        }
        if let stat = dictDetail["state"] as? String {
            self.stat = stat
        }
        if let zpp = dictDetail["zipcode"] as? String{
            self.zpp = zpp
        }
        if let nam = dictDetail["full_name"] as? String{
            self.nam = nam
        }
        if let site = dictDetail["website"] as? String{
            self.site = site
        }
        if let postn = dictDetail["position"] as? String{
            self.postn = postn
        }
        if let email = dictDetail["email"] as? String {
            self.email = email
        }
        if let phn = dictDetail["contact_no"] as? String{
            self.phn = phn
        }
        if let marketMsg = dictDetail["marketing_message"] as? String{
            self.marketMsg = marketMsg
        }
        
        if let unique_id = dictDetail["unique_id"] as? String {
            str_unique_id = unique_id
        }
        if let dayOfService = dictDetail["days_of_service"] as? String{
        // Code used to remove \n and '\'
let strDaysOfServices = dayOfService.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil)
let  strdayOfService =  strDaysOfServices.replacingOccurrences(of: "'\'", with: "", options: .literal, range: nil)
            
            if strdayOfService != ""{
                let data: Data? = strdayOfService.data(using: String.Encoding.utf8)
        let values:NSArray = try! JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! NSArray
               
                for index in 0..<values.count{
                    let serviceVal = DaysAndService()
                    serviceVal.userData(dictDetail: values[index] as! NSDictionary)
                    dayOfServiceArray.append(serviceVal)
                }
            }
        }
    }
}
