
import UIKit
import  Alamofire

    // MARK:- VARIABLES
    var signUpObj = SignUpModel()
    
class SignUpInfoVC: UIViewController,UITableViewDelegate,UITableViewDataSource,addressProtocol {

    //MARK: - IBOUTLETS
    @IBOutlet weak var txtfldOperating: UITextField!
    @IBOutlet weak var txtfldStreetAddrs: UITextField!
    @IBOutlet weak var txtfldCity: UITextField!
    @IBOutlet weak var txtfldState: UITextField!
    @IBOutlet weak var txtfldZip: UITextField!
    @IBOutlet weak var txtfldBuisnessName: UITextField!
    @IBOutlet weak var txtfldName: UITextField!
    @IBOutlet weak var txtfldPosition: UITextField!
    @IBOutlet weak var txtfldWeb: UITextField!
    @IBOutlet weak var txtfldMail: UITextField!
    @IBOutlet weak var txtfldPhn: UITextField!
    @IBOutlet weak var txtfldPasswrd: UITextField!
    @IBOutlet weak var tblView: UITableView!
    
    //MARK:- VARIABLES
    var locationNsDict = NSDictionary()
    var mailId = NSString()
    let content = ["  Individual/Sole proprietor or single-member LLC", "  C Corporation", "  S Corporation", "  Partnership", "  Limited Liability Company", "  Other"]

    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.dataSource = self
        tblView.delegate = self
        tblView.isHidden = true
        addressLocProtocol = self
    }
    
    //MARK: - UITABLEVIEW METHOD
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return content.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.adjustsFontSizeToFitWidth = true
        cell.textLabel?.minimumScaleFactor = 0.1
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
        cell.textLabel?.text = content[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        txtfldOperating.text = content[indexPath.row]
        self.tblView.isHidden = true
    }

    //MARK: - ACTION PERFORMED
    @IBAction func btnActionNxt(_ sender: Any){
        if txtfldBuisnessName.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Buissness Name")
        }else if Proxy.sharedProxy.isValidInput(txtfldBuisnessName.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Buissness Name ")
            return
        }
        
        else if txtfldOperating.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Operating As")
        }
        
        else if txtfldName.text!.isEmpty(){
            txtfldName.autocapitalizationType = .words
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Name")
        }else if Proxy.sharedProxy.isValidInput(txtfldName.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Name ")
            return
        }
        
        else if txtfldZip.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Zip Code")
            return
        }
        
        else if txtfldStreetAddrs.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Street address ")
            return
        }
            
        else if txtfldCity.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid city ")
            return
        }
            
        else if txtfldPosition.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Position")
        }
        else if Proxy.sharedProxy.isValidEmail(txtfldMail.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please enter valid email")
        }
       
        else if txtfldPhn.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Phone Number")
        }else if txtfldPhn.text?.characters.count != 10 {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Valid Phone Number")
        }
      
        else if Proxy.sharedProxy.isValidPassword(txtfldPasswrd.text!) == false{
            Proxy.sharedProxy.displayStatusCodeAlert("Minimum of 6 characters,at least one Upper Case")
        } else{
            signUpObj.bzname = txtfldBuisnessName.text!
            signUpObj.opras = txtfldOperating.text!
            signUpObj.strtadd = txtfldStreetAddrs.text!
            signUpObj.cty = txtfldCity.text!
            signUpObj.stat = txtfldState.text!
            signUpObj.zpp = txtfldZip.text!
            signUpObj.nam = txtfldName.text!
            signUpObj.postn = txtfldPosition.text!
            signUpObj.site = txtfldWeb.text!
            signUpObj.email = txtfldMail.text!
            signUpObj.phn = txtfldPhn.text!
            signUpObj.psswrd = txtfldPasswrd.text!
           
            UserDefaults.standard.set(signUpObj.email, forKey: "userEmail")
            let timeDays = storyboard?.instantiateViewController(withIdentifier:"SignUpTimeDaysVC") as! SignUpTimeDaysVC
            self.navigationController?.pushViewController(timeDays, animated: true)
        }
    }
    
    func setLoaction(lattitude:String, longitude:String,isFocusMap:Bool)  {
        signUpObj.lat = lattitude
        signUpObj.long = longitude
    }
    
    func getAddress(addressModal: AutoCompleteModel){
        if addressModal.locationCoordinate.latitude != 0 && addressModal.locationCoordinate.longitude != 0 {
                if(addressModal.strStreetNumber == "" && addressModal.route == ""){
                    self.txtfldStreetAddrs.text = ""
                }
                else if(addressModal.strStreetNumber == ""){
                    self.txtfldStreetAddrs.text = "\(addressModal.route)"
                }
                else{
                    self.txtfldStreetAddrs.text = "\(addressModal.strStreetNumber)\(" , ")\(addressModal.route)"
                }
                
                if addressModal.strState == ""{
                    self.txtfldState.text = "\(addressModal.strCountry)"
                }
                else if(addressModal.strState == "" && addressModal.strCountry == ""){
                    self.txtfldState.text = ""
                }
                else{
                    self.txtfldState.text = "\(addressModal.strState)\(" , ")\(addressModal.strCountry)"
                }
                
                if addressModal.strCity == "" {
                    self.txtfldCity.text = ""
                }
                else{
                    self.txtfldCity.text = "\(addressModal.strCity)"
                }
                
                if addressModal.zipCode == ""{
                    self.txtfldZip.text = ""
                }
                else{
                    self.txtfldZip.text = "\(addressModal.zipCode)"
                }
                self.setLoaction(lattitude: "\(addressModal.locationCoordinate.latitude)", longitude: "\(addressModal.locationCoordinate.longitude)", isFocusMap: true)
            }else{
                Proxy.sharedProxy.displayStatusCodeAlert("No location found")
            }
    }
    
    @IBAction func btnStreetAddSearchAction(_ sender: Any) {
        let addressVc = storyboard?.instantiateViewController(withIdentifier:"addressVC") as! addressVC
        self.navigationController?.pushViewController(addressVc, animated: true)
    }
    
    @IBAction func btnDropDown(_ sender: Any) {
        UIView.animate(withDuration: 10.0, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
        }) { (finished:Bool) -> Void in
            if(self.tblView.isHidden == true){
                self.tblView?.isHidden = false
            }else{
                self.tblView.isHidden = true
            }
        }
    }
    
    @IBAction func btnActionPop(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
