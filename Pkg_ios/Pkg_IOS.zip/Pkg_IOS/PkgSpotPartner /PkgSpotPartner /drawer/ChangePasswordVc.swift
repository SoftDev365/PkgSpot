  //
//  ChangePasswordVc.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 17/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire
class ChangePasswordVc: UIViewController {
    //MARK:- Variable
    var changePassword = String()
    var strUserId = String()
    var changeController = Int()
    
    //Mark:- Outlets
    @IBOutlet weak var txtFldNewPassWord: UITextField!
    @IBOutlet weak var txtFldConfirmPassword: UITextField!
    
    //Mark:- View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden=true
        txtFldNewPassWord.attributedPlaceholder = NSAttributedString(string: "Your new password", attributes: [NSForegroundColorAttributeName: UIColor.lightGray])
        txtFldConfirmPassword.attributedPlaceholder = NSAttributedString(string: "confirm new password", attributes: [NSForegroundColorAttributeName: UIColor.lightGray])
    }
    
    //Mark:- Button Action
    @IBAction func actionBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionDone(_ sender: Any) {
        changePasswordApi()
    }
    
    //Mark:- Api Response
    func changePasswordApi(){
        if txtFldNewPassWord.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter New Password")
            return
        } else if txtFldConfirmPassword.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Confirm Password")
            return
        } else if Proxy.sharedProxy.isValidPassword(txtFldNewPassWord.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Minimum of 6 characters,at least one Upper Case")
        } else if txtFldNewPassWord.text! != txtFldConfirmPassword.text! {
            Proxy.sharedProxy.displayStatusCodeAlert("Confirm Password does not match")
            return
        }else {
            let param = [
                "id": strUserId,
                "password": txtFldNewPassWord.text!
                    ] as [String : Any]
            let strURL = "\(Apis.KServerUrl)\(Apis.KChangePassword)"
            changePassword(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }
    }
    
    func changePassword(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                Proxy.sharedProxy.displayStatusCodeAlert("Password changed successfully")
                 KAppDelegate.gotoLoginSignUpVC()
                self.logOut()
            }else{
            }
        })
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.changePassword(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    //MARK:- API REQUEST
    func logOut() {
        let logoutURL = "\(Apis.KServerUrl)\(Apis.KLogout)"
        let reachability = Reachability()
        if  reachability!.isReachable {
            KAppDelegate.showActivityIndicator()
            request(logoutURL, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers: ["auth_code": "\(Proxy.sharedProxy.authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do  {
                        KAppDelegate.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary {
                            if (JSON["status"]! as AnyObject).isEqual(200) {
                                
                                UserDefaults.standard.set("", forKey: "auth_code")
                                UserDefaults.standard.synchronize()
                                KAppDelegate.gotoLoginSignUpVC()
                                //Proxy.sharedProxy.displayStatusCodeAlert("You are Logged Out Successfully")
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                Proxy.sharedProxy.stautsHandler(logoutURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                    }
            }
        }
    }
}

