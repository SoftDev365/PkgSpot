
import UIKit

class PartnerLogInVC: UIViewController {
    // MARK:- OUTLETS
    @IBOutlet weak var txtfldCustomerID: UITextField!
    @IBOutlet weak var txtfldPswrd: UITextField!
    
    var buisnessname = String()
    var address = String()
    var city = String()
    var state = String()
    var zipcode = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    // MARK:- BUTTON ACTIONS
    @IBAction func btnActionBack(_ sender: Any) {
         _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnActionNxt(_ sender: Any) {
         if txtfldCustomerID.text!.isEmpty {
        
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Customer ID")
         }else if txtfldPswrd.text!.isEmpty {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Password")
         }
         else{
            var deviceTokken =  ""
         
            if UserDefaults.standard.object(forKey: "device_token") == nil {
deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
            }
        else {
                deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
            }
         
            let param = [
                "email":"\(txtfldCustomerID.text!)",
                "password": "\(txtfldPswrd.text!)",
                "device_token": "\(deviceTokken)",
                "type":"2"
                ]
            let strURL = "\(Apis.KServerUrl)\(Apis.KLogin)"
            Login(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }
    }
    
    //MARK:- API REQUEST
    func Login(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
            
                let authcode = ((responseDict.value(forKey: "auth_code")!)) as! String
                UserDefaults.standard.set(authcode, forKey: "auth_code")
                UserDefaults.standard.synchronize()

                if let arrData = responseDict["data"] as? NSArray{
                    if arrData.count > 0{
                        if let dictData = arrData[0] as? NSDictionary{
                           
                            partnerInfoModel.setUserInfo(dictDetail: dictData .mutableCopy() as! NSMutableDictionary)
                            
                            if let unique_id = dictData["unique_id"] as? String {
                                UserDefaults.standard.set(unique_id, forKey: UserDefaultsData.str_unique_id)
                                UserDefaults.standard.synchronize()
                            }
                        }
                    }
                }
                if let userid = responseDict["userId"] as? Int {
                    UserDefaults.standard.set(userid, forKey: "userid")
                    UserDefaults.standard.synchronize()
                }
            KAppDelegate.popToDrawerViewcontroller(identifier: "Home")
                
    let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpMarketingMsgVC") as! SignUpMarketingMsgVC
            self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
            }
            else{
                if let data1 = responseDict["error"] as? String {
                    if data1 != "" {
                        Proxy.sharedProxy.displayStatusCodeAlert("\(data1)")
                    }else{
                    }
                }
            }
        }){ (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.Login(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

    @IBAction func btnActionPswrdHlp(_ sender: Any) {
        let gotoForgotPasswordVc = self.storyboard?.instantiateViewController(withIdentifier:"ForgotPasswordVc") as! ForgotPasswordVc
        self.navigationController?.pushViewController(gotoForgotPasswordVc,animated: true)
    }
}
