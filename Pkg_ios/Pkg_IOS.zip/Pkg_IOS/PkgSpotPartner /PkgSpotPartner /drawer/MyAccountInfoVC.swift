
import UIKit

class MyAccountInfoVC: UIViewController,UITableViewDelegate,UITableViewDataSource,addressProtocol {
    
    // MARK:- OUTLETS
    @IBOutlet weak var txtfldOperating: UITextField!
    @IBOutlet weak var txtfldStreetAddrs: UITextField!
    @IBOutlet weak var txtfldCity: UITextField!
    @IBOutlet weak var txtfldState: UITextField!
    @IBOutlet weak var txtfldZip: UITextField!
    @IBOutlet weak var txtfldBuisnessName: UITextField!
    @IBOutlet weak var txtfldName: UITextField!
    @IBOutlet weak var txtfldPosition: UITextField!
    @IBOutlet weak var txtfldWeb: UITextField!
    @IBOutlet weak var txtfldMail: UITextField!
    @IBOutlet weak var txtfldPhn: UITextField!
    @IBOutlet weak var txtfldPasswrd: UITextField!
    @IBOutlet weak var tblView: UITableView!
    
    //MARK: - VARIABLE
    var isLogin = Bool()
    var locationNsDict = NSDictionary()
    
    let content = ["  Individual/Sole proprietor or single-member LLC", "  C Corporation", "  S Corporation", "  Partnership", "  Limited Liability Company", "  Other"]
    
    //MARK: - Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.dataSource = self
        tblView.delegate = self
        tblView.isHidden = true
        addressLocProtocol = self
        
        txtfldBuisnessName.isUserInteractionEnabled = true
        txtfldOperating.isUserInteractionEnabled = true
        txtfldName.isUserInteractionEnabled = true
        txtfldWeb.isUserInteractionEnabled = true
        txtfldPosition.isUserInteractionEnabled = true
        txtfldPhn.isUserInteractionEnabled = true
        
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KMyAccount)\(userid)"
        Update(strURL: strURL, param: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    //MARK: - UITABLEVIEW METHOD
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return content.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.adjustsFontSizeToFitWidth = true
        cell.textLabel?.minimumScaleFactor = 0.1
        cell.textLabel?.font = UIFont.systemFont(ofSize: 14.0)
        cell.textLabel?.text = content[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        txtfldOperating.text = content[indexPath.row]
        self.tblView.isHidden = true
    }
    func setLoaction(lattitude:String, longitude:String,isFocusMap:Bool)  {
        signUpObj.lat = lattitude
        signUpObj.long = longitude
    }
    
    func getAddress(addressModal: AutoCompleteModel){
        if addressModal.locationCoordinate.latitude != 0 && addressModal.locationCoordinate.longitude != 0 {
            if(addressModal.strStreetNumber == "" && addressModal.route == ""){
                 self.txtfldStreetAddrs.text = ""
            }
            else if(addressModal.strStreetNumber == ""){
                self.txtfldStreetAddrs.text = "\(addressModal.route)"
            }
            else{
                self.txtfldStreetAddrs.text = "\(addressModal.strStreetNumber)\(" , ")\(addressModal.route)"
            }
            
            if addressModal.strState == ""{
                 self.txtfldState.text = "\(addressModal.strCountry)"
            }
            else if(addressModal.strState == "" && addressModal.strCountry == ""){
                self.txtfldState.text = ""
            }
            else{
                self.txtfldState.text = "\(addressModal.strState)\(" , ")\(addressModal.strCountry)"
            }
            
            if addressModal.strCity == "" {
                self.txtfldCity.text = ""
            }
            else{
                 self.txtfldCity.text = "\(addressModal.strCity)"
            }
           
            if addressModal.zipCode == ""{
                self.txtfldZip.text = ""
                }
            else{
                self.txtfldZip.text = "\(addressModal.zipCode)"
                }
            self.setLoaction(lattitude: "\(addressModal.locationCoordinate.latitude)", longitude: "\(addressModal.locationCoordinate.longitude)", isFocusMap: true)
        }else{
            Proxy.sharedProxy.displayStatusCodeAlert("No location found")
        }
    }
    
    //MARK:-BUTTON ACTION
    @IBAction func btnActionSearchStreetAddress(_ sender: Any) {
        let addressVc = storyboard?.instantiateViewController(withIdentifier:"addressVC") as! addressVC
        self.navigationController?.pushViewController(addressVc, animated: true)
    }
    
    @IBAction func btnActionDropDown(_ sender: Any) {
        UIView.animate(withDuration: 10.0, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: { () -> Void in
        }) { (finished:Bool) -> Void in
            if(self.tblView.isHidden == true){
                self.tblView?.isHidden = false
            }
            else{
                self.tblView.isHidden = true
            }
        }
    }
    
    @IBAction func btnActionDraw(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()
    }
    
    @IBAction func btnActionPasswordChange(_ sender: Any){
        let gotoForgotPasswordVc = self.storyboard?.instantiateViewController(withIdentifier:"ForgotPasswordVc") as! ForgotPasswordVc
        self.navigationController?.pushViewController(gotoForgotPasswordVc,animated: true)
    }
    
    @IBAction func btnActionChangeEmail(_ sender: Any) {
        let param = [
                "email":"\(txtfldMail.text!)"
                    ]
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KChangeMailId)\(userid)"
        partnerInfoUpdate(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }
    
    @IBAction func btnActionEditInformation(_ sender: AnyObject) {

    }
  
    //MARK: - GET Webservice response
    func Update(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray {
                    if let dict = arr[0] as? NSDictionary {
                        partnerInfoModel.setUserInfo(dictDetail: dict.mutableCopy() as! NSMutableDictionary)
                        self.txtfldBuisnessName.text = partnerInfoModel.bzname
                        self.txtfldOperating.text = partnerInfoModel.opras
                        self.txtfldStreetAddrs.text = partnerInfoModel.strtadd
                        self.txtfldCity.text = partnerInfoModel.cty
                        self.txtfldState.text = partnerInfoModel.stat
                        self.txtfldZip.text = partnerInfoModel.zpp
                        self.txtfldName.text = partnerInfoModel.nam
                        self.txtfldWeb.text = partnerInfoModel.site
                        self.txtfldPosition.text = partnerInfoModel.postn
                        self.txtfldMail.text = partnerInfoModel.email
                        self.txtfldPhn.text = partnerInfoModel.phn
                    }
                }
            }
            else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.Update(strURL: strURL, param: param)
            })
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

    //MARK:- Partner Update Profile
    @IBAction func btnActionDone(_ sender: Any) {
        
        if txtfldBuisnessName.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Buissness Name")
        }else if Proxy.sharedProxy.isValidInput(txtfldBuisnessName.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Buissness Name ")
            return
        }
            
        else if txtfldOperating.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Operating As")
        }
            
        else if txtfldName.text!.isEmpty(){
            txtfldName.autocapitalizationType = .words
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Name")
        }else if Proxy.sharedProxy.isValidInput(txtfldName.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Name ")
            return
        }
            
        else if txtfldZip.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Zip Code")
            return
        }
            
        else if txtfldStreetAddrs.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid Street address ")
            return
        }
            
        else if txtfldCity.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter valid city ")
            return
        }
            
        else if txtfldPosition.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Position")
        }
        
        else if txtfldPhn.text!.isEmpty(){
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Phone Number")
        }
        else{
                let param = [
                        "business_name":"\(txtfldBuisnessName.text!)",
                        "operating_as": "\(txtfldOperating.text!)",
                        "address":"\(txtfldStreetAddrs.text!)",
                        "city": "\(txtfldCity.text!)",
                        "state":"\(txtfldState.text!)",
                        "zipcode":"\(txtfldZip.text!)" ,
                        "full_name":"\(txtfldName.text!)",
                        "position":"\(txtfldPosition.text!)",
                        "website":"\(txtfldWeb.text!)",
                        "contact_no":"\(txtfldPhn.text!)"
                            ]
            
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KPartnerUpdate)\(userid)"
        partnerInfoUpdate(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }
    }

    //MARK:- API Response
    func partnerInfoUpdate(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                Proxy.sharedProxy.displayStatusCodeAlert("My Account Information updated !")
            }
        }){ (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.partnerInfoUpdate(strURL: strURL, param: param)
            })
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    //MARK:- Api Response Change Email ID
    func KChangeMailId(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                //Proxy.sharedProxy.displayStatusCodeAlert("Email sent successfully.")
            }
            else{
            }
        }){ (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.partnerInfoUpdate(strURL: strURL, param: param)
            })
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}
