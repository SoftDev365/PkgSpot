
import UIKit
import Alamofire
import IQKeyboardManagerSwift

class LoginVc: UIViewController {

    @IBOutlet weak var txt_Fld_Email: UITextField!
    @IBOutlet weak var txt_Fld_Password: UITextField!
    @IBOutlet weak var ScrollViewOutlet: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()

ScrollViewOutlet.bounces = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    

    @IBAction func btnBack(_ sender: Any) {
        
          _ = self.navigationController?.popViewController(animated: true)
        
    }
   
    
    @IBAction func btnActionNextorLogin(_ sender: UIButton) {
        signIn()
    }
    
    
    func signIn() {
        
        if txt_Fld_Email.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email Address")
            return
        } else if proxy.sharedProxy().isValidEmail(txt_Fld_Email.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email")
            return
        } else if txt_Fld_Password.text!.isEmpty {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Phone Number")
            return
        }
        else {
            var deviceTokken =  ""
            if UserDefaults.standard.object(forKey: "device_token") == nil {
                deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
            } else {
                deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
            }
            let param = [
                "email": "\(txt_Fld_Email.text!)" ,
                "password": "\(txt_Fld_Password.text!)" ,
                "device_token": "\(deviceTokken)",
                "type":"2"
            ]
            
            let loginInUrl = "\(KServerUrl)" + "\(KLogin)"
            let reachability = Reachability()
            if  reachability?.isReachable  == true {
                KAppDelegate.showActivityIndicator()
                // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(loginInUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                        print(JSONDIC as Any)
                        do
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                KAppDelegate.hideActivityIndicator()
                                if response.response?.statusCode == 200 {
                                    self.serviceResponse(JSONDIC)
                                    print("Response:",JSONDIC)
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(loginInUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Problema de conexión a Internet")
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
            }
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KLogin) {
            
            KAppDelegate.debugPrint(Text: "Sign In Details", Object: JSON)
            if (JSON["status"]! as AnyObject).isEqual(200) {
                IQKeyboardManager.sharedManager().resignFirstResponder()
                
                let authcode = ((JSON.value(forKey: "auth_code")!)) as! String
                UserDefaults.standard.set(authcode, forKey: "auth_code")
                UserDefaults.standard.synchronize()
                
                let detail = JSON.value(forKey: "data")! as? NSDictionary
                let id = detail?.value(forKey: "id")! as? Int32
                let email = detail?.value(forKey: "email") as? String
                let password = detail?.value(forKey: "password") as? String
                
                
                
                UserDefaults.standard.set(id, forKey: "id")
                UserDefaults.standard.set(email, forKey: "email")
                UserDefaults.standard.set(password, forKey: "password")
                UserDefaults.standard.synchronize()
                
                
                KAppDelegate.gotoMyAccountScreen()
                
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
     
}
}


extension LoginVc : SlideMenuControllerDelegate {
    
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
    
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
}



