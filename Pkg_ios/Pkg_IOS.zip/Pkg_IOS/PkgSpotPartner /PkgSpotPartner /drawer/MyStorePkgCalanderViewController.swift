import UIKit
import FSCalendar

protocol CalanderDateSelectedDelegate {
        func calanderDateSelected(arrReceived: [HistoryDataModel])
    }

var protocolCalender: CalanderDateSelectedDelegate?

class MyStorePkgCalanderViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate {
   
    //MARK:- OUTLETS
    @IBOutlet weak var calender: FSCalendar!
    var arrayPackages = [HistoryDataModel]()
    
    //MARK:- View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        calender.dataSource = self
        calender.delegate = self
    }
   
    //MARK:- Calender delegate
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            let result = formatter.string(from: date)
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KCalender)\(userid)/\(result)"
        filterCalendar(strURL: strURL, param: nil)
    }
    
    //MARK:- Hide Calender On Tap Any Where
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK: - Get Webservice Response
    func filterCalendar(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200){
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray{
                    for i in 0..<arr.count{
                        if let dict = arr[i] as? NSDictionary {
                            let packageDetials = HistoryDataModel()
                            let mutatedDic = dict.mutableCopy() as! NSDictionary
                            packageDetials.userData(dict: mutatedDic)
                            self.arrayPackages.append(packageDetials)
                        }
                    }
                    self.dismiss(animated: true, completion: {
                        protocolCalender?.calanderDateSelected(arrReceived: self.arrayPackages)
                    })
                }
            }else{
                
                if let error = responseDict.object(forKey: "error")as? String{
                    Proxy.sharedProxy.displayStatusCodeAlert(error)
                    self.dismiss(animated: true, completion: {
                        //protocolCalender?.calanderDateSelected()
                    })
                }
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.filterCalendar(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}
