
import UIKit

class CreateAccountVC: UIViewController {
    // MARK:- OUTLETS
    @IBOutlet weak var lblConfirmationText: UILabel!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        lblConfirmationText.text = "By creating a\nPkg.Spot account\nyou agree to our"
    }
    
    // MARK:BUTTON ACTION
    
    //TermsOfService()
    @IBAction func btnActionTerms(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyMsgVC")as! TermsAndPolicyMsgVC
        signup.selectedStr = "4"
        self.navigationController?.pushViewController(signup, animated: true)
    }
    
    // PrivacyPolicy
    @IBAction func btnActionPolicy(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "TermsAndPolicyMsgVC")as!TermsAndPolicyMsgVC
        signup.selectedStr = "5"
        self.navigationController?.pushViewController(signup, animated: true)
    }

    @IBAction func btnActionBck(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnNxt(_ sender: Any) {
        let strURL = "\(Apis.KServerUrl)\(Apis.KSignUpComplete)\(signUpUserObj.userId)"
        KSignUpComplete(strURL: strURL, param: nil)
    }
    
    // MARK:- API REQUEST
    func KSignUpComplete(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                
                let signup = self.storyboard?.instantiateViewController(withIdentifier: "ThanksSignUpVC")
                self.navigationController?.pushViewController(signup!, animated: true)
                
            }   else{
            }
        })
            
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KSignUpComplete(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in})
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

}
