
import UIKit

class TableViewCellMA: UITableViewCell,UITextFieldDelegate {
    // MARK:- OUTLETS
    @IBOutlet weak var textfldStart: UITextField!
    @IBOutlet weak var textfldEnd: UITextField!
    @IBOutlet weak var btnRefMM: SetCornerButton!
    
    let startTimePicker = UIDatePicker()
    let endTimePicker = UIDatePicker()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        startTimePicker.datePickerMode = .time
        //MARK:- For 24 hour format
        //startTimePicker.locale = Locale(identifier:"en_GB")
        textfldStart.inputView = startTimePicker
        textfldEnd.inputView = endTimePicker
        //endTimePicker.locale = Locale(identifier:"en_GB")
        
        textfldStart.tintColor = UIColor.clear
        textfldEnd.tintColor = UIColor.clear
        textfldStart.delegate = self
        textfldEnd.delegate = self
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "hh:mm a"
      startTimePicker.addTarget(self, action: #selector(TableViewCellMA.timePickerValueCahnge), for: .valueChanged)
      endTimePicker.addTarget(self, action: #selector(TableViewCellMA.endTimerPickerValueChange), for: .valueChanged)
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
              return true
    }
    
    //MARK: - Picker Value Change Action
    func timePickerValueCahnge(){
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "hh:mm a"
      //dateformatter.dateFormat = "HH:mm"
        textfldStart.text = dateformatter.string(from: startTimePicker.date)
        debugPrint("[\(startTimePicker.tag)] Time:",textfldStart.text!)
    }
    
    func endTimerPickerValueChange(){
        let dateformatter = DateFormatter()
        //dateformatter.dateFormat = "HH:mm"
        dateformatter.dateFormat = "hh:mm a"
        textfldEnd.text = dateformatter.string(from: endTimePicker.date)
        debugPrint("[\(endTimePicker.tag)] Time:",textfldEnd.text!)
    }
}
