import UIKit

class MyAccountSecondVC: UIViewController ,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    let daysArray = ["M","T","W","T","F","S","S"]
    var isSelected = ["0","0","0","0","0","0","0"]
    
    //MARK:-IBOutlet
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnMon: SetCornerButton!
    @IBOutlet weak var btnTue: SetCornerButton!
    @IBOutlet weak var btnWed: SetCornerButton!
    @IBOutlet weak var btnThr: SetCornerButton!
    @IBOutlet weak var btnFri: SetCornerButton!
    @IBOutlet weak var btnSat: SetCornerButton!
    @IBOutlet weak var btnSun: SetCornerButton!

    @IBOutlet weak var btnCheck: SetCornerButton!
    @IBOutlet weak var refbtnSelectAll: SetCornerButton!

    @IBOutlet weak var refbtnCheck: SetCornerButton!
    @IBOutlet weak var refBtnSelectSat: SetCornerButton!

    //MARK:- VARIABLES
    var selectedDaysAndTime = NSMutableArray()
    var dictDaysOfServices : [String: String] = [:]
    var resultedArray = NSMutableArray()
    
    let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    let arrMon = ["monday", "tuesday", "wednesday", "thursday", "friday"]
    let arrSat = ["saturday", "sunday"]
    
    var colorSat = 0
    var selectSat = 0
    
    var color = 0
    var selectAll = 0
    
    //MARK:- VIEW CONTROLLER LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.dataSource = self
        tblView.delegate = self
        tblView.reloadData()
        btnCheck.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
        
        for i in 0..<arrDay.count{
            let selectedHrDic = NSMutableDictionary()
            selectedHrDic["start_time"] = ""
            selectedHrDic["end_time"] = ""
            selectedHrDic["day"] = "\(arrDay[i])"
            selectedHrDic["isSelected"] = "0"
            selectedDaysAndTime.add(selectedHrDic)
            let startIndex = (i + 1) * 100
            let endIndex = ((i + 1) * 100) + 1
            dictDaysOfServices["\(startIndex)"] = ""
            dictDaysOfServices["\(endIndex)"] = ""
        }
        debugPrint("selectedDaysAndTime",selectedDaysAndTime)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KMyAccount)\(userid)"
        getData(strURL: strURL, param: nil)
    }
    
    //MARK:- Set Fixed Value For All Days
    @IBAction func btnActionSetFIxedValue(_ sender: Any) {
        let selectedHrDic = selectedDaysAndTime.object(at: 0) as! NSMutableDictionary
        if selectedHrDic["start_time"] as! String == "" || selectedHrDic["end_time"] as! String == "" {
            Proxy.sharedProxy.displayStatusCodeAlert("Please set monday time")
        }
        else{
            if selectAll == 0 {
                refbtnSelectAll.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                refbtnSelectAll.setTitleColor(UIColor.white, for: UIControlState.normal)
                selectAll = 1
                let startTime = selectedHrDic["start_time"] as! String
                let endTime = selectedHrDic["end_time"] as! String
                
                for i in 0..<arrMon.count {
                    let startIndex = (i + 1)*100
                    let endIndex = ((i + 1)*100) + 1
                    dictDaysOfServices["\(startIndex)"] = startTime
                    dictDaysOfServices["\(endIndex)"] = endTime
                    
                    let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                    selectedHrDic["start_time"] = startTime
                    selectedHrDic["end_time"] = endTime
                    //selectedHrDic["isSelected"] = "1"
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
            }
            else {
                refbtnSelectAll.backgroundColor = UIColor.white
                refbtnSelectAll.setTitleColor(UIColor.gray, for: UIControlState.normal)
                for i in 0..<arrMon.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                    selectedHrDic["start_time"] = ""
                    selectedHrDic["end_time"] = ""
                    let startIndex = (i + 1)*100
                    let endIndex = ((i + 1)*100) + 1
                    dictDaysOfServices["\(startIndex)"] = ""
                    dictDaysOfServices["\(endIndex)"] = ""
                    //selectedHrDic["isSelected"] = "0"
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
                selectAll = 0
            }
        }
        tblView.reloadData()
    }
    
    //MARK: - Select All Button And Set Background Color
    @IBAction func btnActionSelectAll(_sender: Any) {
        if color == 0  {
            btnMon.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnMon.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnTue.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnTue.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnWed.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnWed.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnThr.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnThr.setTitleColor(UIColor.white, for: UIControlState.normal)
            btnFri.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            btnFri.setTitleColor(UIColor.white, for: UIControlState.normal)
            color = color + 1
            btnCheck.setBackgroundImage( #imageLiteral(resourceName: "ic_check"), for: .normal)
            debugPrint("selectedDaysAndTime", selectedDaysAndTime)
            for i in 0..<arrMon.count{
                let getDictData = selectedDaysAndTime[i] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "1"
                }
                else{
                    getDictData["isSelected"] = "1"
                }
                tblView.reloadData()
            }
                debugPrint("selectedDaysAndTime", selectedDaysAndTime)
            } else {
            btnMon.backgroundColor = UIColor.white
            btnMon.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnTue.backgroundColor = UIColor.white
            btnTue.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnWed.backgroundColor = UIColor.white
            btnWed.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnThr.backgroundColor = UIColor.white
            btnThr.setTitleColor(UIColor.gray, for: UIControlState.normal)
            btnFri.backgroundColor = UIColor.white
            btnFri.setTitleColor(UIColor.gray, for: UIControlState.normal)
            color = color - 1
            btnCheck.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
            for i in 0..<arrMon.count{
                let getDictData = selectedDaysAndTime[i] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "0"
                }
                else{
                    getDictData["isSelected"] = "0"
                }
            }
            tblView.reloadData()
        }
    }
    
    //MARK:- Button Select Sat Sun
    @IBAction func btnCheckSat(_ sender: Any) {
        if colorSat == 0 {
            self.btnSat.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            self.btnSat.setTitleColor(UIColor.white, for: UIControlState.normal)
            self.btnSun.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            self.btnSun.setTitleColor(UIColor.white, for: UIControlState.normal)
            colorSat = colorSat + 1
            refbtnCheck.setBackgroundImage( #imageLiteral(resourceName: "ic_check"), for: .normal)
            for i in 0..<arrSat.count{
                let getDictData = selectedDaysAndTime[i+5] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "1"
                } else{
                    getDictData["isSelected"] = "1"
                }
                tblView.reloadData()
            }
            
        } else{
            self.btnSat.backgroundColor = UIColor.white
            self.btnSat.setTitleColor(UIColor.gray, for: UIControlState.normal)
            self.btnSun.backgroundColor = UIColor.white
            self.btnSun.setTitleColor(UIColor.gray, for: UIControlState.normal)
            colorSat = colorSat - 1
            refbtnCheck.setBackgroundImage(#imageLiteral(resourceName: "ic_uncheck"), for: .normal)
            for i in 0..<arrSat.count{
                let getDictData = selectedDaysAndTime[i+5] as! NSMutableDictionary
                if  getDictData["isSelected"] as! String == "0"{
                    getDictData["isSelected"] = "0"
                }else{
                    getDictData["isSelected"] = "0"
                }
            }
            tblView.reloadData()
        }
    }
    
    //MARK:- Set Time
    @IBAction func btnActionSetTimeSatSun(_ sender: Any) {
        let selectedHrDic = selectedDaysAndTime.object(at: 5) as! NSMutableDictionary
        if colorSat == 0{
            Proxy.sharedProxy.displayStatusCodeAlert("Please select hour services")
        }else if selectedHrDic["start_time"] as! String == "" || selectedHrDic["end_time"] as! String == "" {
            Proxy.sharedProxy.displayStatusCodeAlert("Please set Saturday time")
        }else {
            if selectSat == 0 {
                refBtnSelectSat.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                refBtnSelectSat.setTitleColor(UIColor.white, for: UIControlState.normal)
                selectSat = 1
                let startTime = selectedHrDic["start_time"] as! String
                let endTime = selectedHrDic["end_time"] as! String
                for i in 0..<arrSat.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i+5) as! NSMutableDictionary
                    selectedHrDic["start_time"] = startTime
                    selectedHrDic["end_time"] = endTime
                    selectedDaysAndTime.replaceObject(at: i+5, with: selectedHrDic)
                }
            }
            else{
                refBtnSelectSat.backgroundColor = UIColor.white
                refBtnSelectSat.setTitleColor(UIColor.gray, for: UIControlState.normal)
                for i in 0..<arrSat.count{
                    let selectedHrDic = selectedDaysAndTime.object(at: i+5) as! NSMutableDictionary
                    selectedHrDic["start_time"] = ""
                    selectedHrDic["end_time"] = ""
                    selectedDaysAndTime.replaceObject(at: i+5, with: selectedHrDic)
                }
                selectSat = 0
            }
        }
        tblView.reloadData()
    }
    
    //MARK:- Table View Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedDaysAndTime.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCellMA
        let getDictData = selectedDaysAndTime[indexPath.row] as! NSMutableDictionary
        cell.btnRefMM.setTitle(daysArray[indexPath.row] , for: .normal)
        if getDictData["isSelected"] as! String == "0"{
            cell.btnRefMM.backgroundColor = UIColor.white
            cell.btnRefMM.titleLabel?.textColor = UIColor.gray
            cell.textfldStart.isUserInteractionEnabled = false
            cell.textfldEnd.isUserInteractionEnabled = false
        }
        else{
            cell.btnRefMM.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
            cell.btnRefMM.titleLabel?.textColor = UIColor.white
            cell.textfldStart.isUserInteractionEnabled = true
            cell.textfldEnd.isUserInteractionEnabled = true
            cell.textfldStart.text = getDictData["start_time"] as? String
            cell.textfldEnd.text = getDictData["end_time"] as? String
        }
        cell.startTimePicker.datePickerMode = .time
        cell.endTimePicker.datePickerMode = .time
        cell.startTimePicker.tag = ((indexPath.row+1) * 100)
        cell.endTimePicker.tag = ((indexPath.row+1) * 100) + 1
        cell.textfldStart.tintColor = UIColor.clear
        cell.textfldEnd.tintColor = UIColor.clear
        cell.textfldStart.tag = ((indexPath.row+1) * 100)
        cell.textfldEnd.tag = ((indexPath.row+1) * 100) + 1
        return cell
    }
    
    //MARK: - Select Start & EndTime  Action
    @IBAction func startTimeAction(_ sender: UITextField) {
        debugPrint("Start TextField", sender.tag)
        dictDaysOfServices["\(sender.tag)"] = "\(sender.text!)"
        if selectAll == 1{
            for i in 0..<arrMon.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }else {
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        if selectSat == 1 {
            for i in 5..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 6)*100
                let endIndex = ((0 + 6)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        else{
            
            for i in 0..<arrDay.count{
                
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
    }
    
    @IBAction func endTimeAction(_ sender: UITextField) {
        debugPrint("End TextField", sender.tag)
        dictDaysOfServices["\(sender.tag)"] = "\(sender.text!)"
        if selectAll == 1{
            for i in 0..<arrMon.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        } else {
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
        if selectSat == 1 {
            for i in 5..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (0 + 6)*100
                let endIndex = ((0 + 6)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        } else {
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                let startIndex = (i + 1)*100
                let endIndex = ((i + 1)*100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
            }
            tblView.reloadData()
        }
    }
    
    @IBAction func btnActionNxt(_ sender: Any) {
        debugPrint("selectedDaysAndTime", selectedDaysAndTime)
        if selectAll != 1 && selectSat != 1{
            for i in 0..<arrDay.count{
                let selectedHrDic = NSMutableDictionary()
                selectedHrDic["day"] = "\(arrDay[i])"
                let selectDict = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                isSelected[i] = selectDict["isSelected"] as! String
                selectedHrDic["isSelected"] = selectDict["isSelected"]
                let startIndex = (i + 1) * 100
                let endIndex = ((i + 1) * 100) + 1
                selectedHrDic["start_time"] = dictDaysOfServices["\(startIndex)"]
                selectedHrDic["end_time"] = dictDaysOfServices["\(endIndex)"]
                selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
           }
    
        resultedArray = []
        
        var isEmpty = 0
        
        for i in 0..<isSelected.count{
                if isSelected[i] != "0"{
                    let getStartDict = selectedDaysAndTime[i] as! NSMutableDictionary

                    if getStartDict["start_time"] as! String == "" || getStartDict["end_time"] as! String == ""{
                        isEmpty = 0
                        Proxy.sharedProxy.displayStatusCodeAlert("Please select time")
                        break
                    }else{
                         isEmpty += 1
                    }
                }else{
                    debugPrint("resultedArray", selectedDaysAndTime)
                    isEmpty += 1
                }
        }
        if isEmpty == 0{
            Proxy.sharedProxy.displayStatusCodeAlert("Please select any services")
        }else{
            for index in 0..<selectedDaysAndTime.count{
                let getDictData = selectedDaysAndTime[index] as! NSMutableDictionary
                let dictData = NSMutableDictionary()
                let dictStartEnd = NSMutableDictionary()
                if  getDictData["isSelected"] as! String != "0"{
                    dictStartEnd.setValue( getDictData["start_time"], forKey: "start_time")
                    dictStartEnd.setValue(getDictData["end_time"], forKey: "end_time")
                    dictData.setValue(dictStartEnd, forKey: "\(arrDay[index])")
                    resultedArray.add(dictData)
                }else
                {   dictStartEnd.setValue("", forKey: "start_time")
                    dictStartEnd.setValue("", forKey: "end_time")
                    dictData.setValue(dictStartEnd, forKey: "\(arrDay[index])")
                    resultedArray.add(dictData)
                }
            }
            
            var isSelectCount = 0
            for i in 0..<arrDay.count{
                let selectedHrDic = selectedDaysAndTime.object(at: i) as! NSMutableDictionary
                if  selectedHrDic["isSelected"] as! String == "0"{
                    isSelectCount = isSelectCount + 1
                    selectedDaysAndTime.replaceObject(at: i, with: selectedHrDic)
                }
            }
            if isSelectCount == selectedDaysAndTime.count{
                Proxy.sharedProxy.displayStatusCodeAlert("Please select any services")
                return
            }
            let myAccountMsgVC = self.storyboard?.instantiateViewController(withIdentifier:"MyAccountMsgVC") as! MyAccountMsgVC
            myAccountMsgVC.selectedDays = resultedArray
            myAccountMsgVC.isFromDrawer = true
            debugPrint("resultedArray:" , resultedArray)
            self.navigationController?.pushViewController(myAccountMsgVC, animated: true)
        }
    }
    
    //MARK:- BUTTON DAYS
    @IBAction func btnActSrvcDz(_ sender: UIButton) {
        // isSelectType = chooseType(rawValue:sender.tag)!
        let startIndex = (sender.tag + 1)*100
        let endIndex = ((sender.tag + 1)*100) + 1
        if selectAll == 0 {
            let getDictData = selectedDaysAndTime[sender.tag] as! NSMutableDictionary
            if  getDictData["isSelected"] as! String == "0"{
                getDictData["isSelected"] = "1"
                sender.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                sender.setTitleColor(UIColor.white, for: UIControlState.normal)
            }
            else{
                getDictData["isSelected"] = "0"
                sender.backgroundColor = UIColor.white
                getDictData.setValue("", forKey: "start_time")
                getDictData.setValue("", forKey: "end_time")
                dictDaysOfServices["\(startIndex)"] = ""
                dictDaysOfServices["\(endIndex)"] = ""
                selectedDaysAndTime.replaceObject(at: sender.tag, with: getDictData)
                sender.setTitleColor(UIColor.gray, for: UIControlState.normal)
            }
            tblView.reloadData()
        }
    }
    
    //MARK: - GET Webservice response
    func getData(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray {
                    let dayOfServiceDict = arr[0] as! NSDictionary
                    
                    if let dayOfService = dayOfServiceDict["days_of_service"] as? String{
                        if dayOfService != ""{
                            let strDaysOfServices = dayOfService.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil)
                            let  strdayOfService =  strDaysOfServices.replacingOccurrences(of: "'\'", with: "", options: .literal, range: nil)
                            let data: Data = strdayOfService.data(using: String.Encoding.utf8)!
                            do{
                                var values = NSArray()
                                values = try  JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                                // print("array zones: ",JSONArray)
                                for index in 0..<values.count{
                                    let getDataDict  = (values[index] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                                    
                                    let selectedDaysAndTimeDic  = self.selectedDaysAndTime[index] as! NSMutableDictionary
                                    
                                    let dictStartEndTime = getDataDict.object(forKey: "\(self.arrDay[index])") as! NSDictionary
                                    selectedDaysAndTimeDic["start_time"] = dictStartEndTime["start_time"] as! String
                                    selectedDaysAndTimeDic["end_time"] = dictStartEndTime["end_time"] as! String
                                    
                                    if dictStartEndTime["start_time"] as! String == "" && dictStartEndTime["end_time"] as! String == ""{
                                        selectedDaysAndTimeDic["isSelected"] = "0"
                                        switch index {
                                        case 0:
                                            self.btnMon.backgroundColor = UIColor.white
                                            self.btnMon.titleLabel?.textColor = UIColor.black
                                            break
                                        case 1:
                                            self.btnTue.backgroundColor = UIColor.white
                                            self.btnTue.titleLabel?.textColor=UIColor.black
                                            break
                                        case 2:
                                            self.btnWed.backgroundColor=UIColor.white
                                            self.btnWed.titleLabel?.textColor=UIColor.black
                                            break
                                        case 3:
                                            self.btnThr.backgroundColor=UIColor.white
                                            self.btnThr.titleLabel?.textColor=UIColor.black
                                            break
                                        case 4:
                                            self.btnFri.backgroundColor=UIColor.white
                                            self.btnFri.titleLabel?.textColor=UIColor.black
                                            break
                                        case 5:
                                            self.btnSat.backgroundColor=UIColor.white
                                            self.btnSat.titleLabel?.textColor=UIColor.black
                                            break
                                        case 6:
                                            self.btnSun.backgroundColor=UIColor.white
                                            self.btnSun.titleLabel?.textColor=UIColor.black
                                            break
                                        default:
                                            break
                                        }
                                    }
                                    else{
                                        selectedDaysAndTimeDic["isSelected"] = "1"
                                        switch index {
                                        case 0:
                                            self.btnMon.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnMon.titleLabel?.textColor = UIColor.white
                                            break
                                        case 1:
                                            self.btnTue.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnTue.titleLabel?.textColor = UIColor.white
                                            break
                                        case 2:
                                            self.btnWed.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnWed.titleLabel?.textColor = UIColor.white
                                            break
                                        case 3:
                                            self.btnThr.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnThr.titleLabel?.textColor = UIColor.white
                                            break
                                        case 4:
                                            self.btnFri.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnFri.titleLabel?.textColor = UIColor.white
                                            break
                                        case 5:
                                            self.btnSat.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnSat.titleLabel?.textColor = UIColor.white
                                            break
                                        case 6:
                                            self.btnSun.backgroundColor = UIColor.init(red: 2/255, green: 156/255, blue: 237/255, alpha: 1)
                                            self.btnSun.titleLabel?.textColor = UIColor.white
                                            break
                                            
                                        default:
                                            break
                                        }
                                    }
                                    self.selectedDaysAndTime[index] = selectedDaysAndTimeDic
                                    let startIndex = (index + 1)*100
                                    let endIndex = ((index + 1)*100) + 1
                                    self.dictDaysOfServices["\(startIndex)"] = dictStartEndTime["start_time"] as? String
                                    self.dictDaysOfServices["\(endIndex)"] = dictStartEndTime["end_time"] as? String
                                }
                            }
                            catch let error as NSError{
                                NSLog("EXCEPTION : %@", error.description)
                            }
                        }
                    }
                    debugPrint("SelectedDaysAndTime" , self.selectedDaysAndTime)
                    self.tblView.reloadData()
                }
            }
            else{
            }
        }){ (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getData(strURL: strURL, param: param)
            })
            let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnActDraw(_ sender: UIButton){
        KAppDelegate.sideMenuVC.openLeft()
    }
    
    
}
