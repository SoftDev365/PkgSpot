
import UIKit

class MyStorePkgVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
