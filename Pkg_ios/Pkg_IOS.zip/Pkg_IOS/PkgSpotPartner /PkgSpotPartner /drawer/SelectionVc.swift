//
//  SelectionVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 21/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit

class SelectionVc: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }

    
    @IBAction func btnLogin(_ sender: UIButton) {
        let loginVc = self.storyboard?.instantiateViewController(withIdentifier: "LoginVc") as! LoginVc
        self.navigationController?.pushViewController(loginVc , animated: true)
        
    }
    
    
    @IBAction func BtnSignUp(_ sender: UIButton) {
    
    let signUp = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVc") as! SignUpVc
    self.navigationController?.pushViewController(signUp , animated: true)
    
    }
    @IBAction func btnGoToPartner(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "PartnerStoryboard", bundle: nil)
        let login = storyBoard.instantiateViewController(withIdentifier: "PartnerLogInViewController") as! PartnerLogInViewController
        self.navigationController?.pushViewController(login , animated: true)
    }
    
}
