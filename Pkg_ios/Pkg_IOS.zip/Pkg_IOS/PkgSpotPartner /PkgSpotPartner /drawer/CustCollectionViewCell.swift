//
//  CustCollectionViewCell.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 08/11/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class CustCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgVieww: UIImageView!
}
