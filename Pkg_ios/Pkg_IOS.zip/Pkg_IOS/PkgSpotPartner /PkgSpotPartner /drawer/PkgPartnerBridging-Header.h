//
//  PkgPartnerBridging-Header.h
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 11/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

#import <TesseractOCR/TesseractOCR.h>

#ifdef __cplusplus

#endif

