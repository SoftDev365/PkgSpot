
import UIKit

class PkgPickUpScanInfo: UIViewController,ScannerDelegate,UITextFieldDelegate {
    
    //MARK:- Variables
    var arrImageCaptured = [ImageCapturedModal]()
    var scannerVC = ScannerVC()
    var strPkGID = String()
    var countFalse = 0
    var countTrue = 0
    // MARK:- OUTLETS
    @IBOutlet weak var lblrefName: UILabel!
    @IBOutlet weak var txtfldBarDisplay: UITextField!
    @IBOutlet weak var vwScannerContainer: UIView!
    @IBOutlet weak var imgViewStar: UIImageView!
    @IBOutlet weak var lblErrorMsg: UILabel!
    @IBOutlet weak var btnVerifyCust: UIButton!
    @IBOutlet weak var refBtnNxt: SetCornerButton!
    
    //MARK:- View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        imgViewStar.isHidden = true
        txtfldBarDisplay.delegate = self
        lblErrorMsg.text = ""
        //ERROR:-\nPlease contact Customer Service
        lblErrorMsg.isHidden = true
        lblrefName.isHidden = true
        btnVerifyCust.isHidden = false
        refBtnNxt.isHidden = false
    }
    
    //MARK: - PROTOCOL FUNCTION
    func sendImage(imgDetected: UIImage?,strDetectedText:String){
            print("Detected text: ",strDetectedText)
            self.imgViewStar.isHidden = false
            txtfldBarDisplay.isHidden = true
        let param = [
                "qr_code":strDetectedText
                    ]
            let userid = UserDefaults.standard.object(forKey: "userid") as! Int
            let strURL = "\(Apis.KServerUrl)\(Apis.KVeifyCustomer)\(userid)"
            
            VerifyCustomerName(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }
    
    public func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        strPkGID = txtfldBarDisplay.text!
//        lblCustmrName.text = strPkGID
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        strPkGID = txtfldBarDisplay.text!
//        lblCustmrName.text = strPkGID
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnActionBck(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()
    }

    @IBAction func btnActionBtnScanBarCode(_ sender: Any) {
        let scannerVC = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
        protocolScannedImage = self
        scannerVC.isDetectQRorBarCode = true
        self.present(scannerVC, animated: true, completion: nil)
    }
    
    @IBAction func btnActionScan(_ sender: Any) {
        let scannerVC = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
        protocolScannedImage = self
        scannerVC.isDetectQRorBarCode = true
        self.present(scannerVC, animated: true, completion: nil)
    }
    
    @IBAction func btnActionNxt(_ sender: Any) {
        if strPkGID.trimmingCharacters(in: CharacterSet.whitespaces).characters.count == 7 {
            let param = [
                "qr_code":strPkGID
                    ]
            let userid = UserDefaults.standard.object(forKey: "userid") as! Int
            let strURL = "\(Apis.KServerUrl)\(Apis.KVeifyCustomer)\(userid)"
            VerifyCustomerName(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }else{
            Proxy.sharedProxy.displayStatusCodeAlert("Please enter seven digit")
        }
    }
    
    // MARK:- API POST REQUEST
    func VerifyCustomerName(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if self.countTrue == 0{
                if let arr = responseDict["data"] as? NSArray {
                   if let dict = arr[0] as? NSDictionary {
                   PackagePickModel.userData(dict: dict.mutableCopy() as! NSDictionary)
                }
                  self.countTrue = self.countTrue + 1
                  self.refBtnNxt.isHidden = true
                  self.btnVerifyCust.isHidden = true
                  self.lblErrorMsg.isHidden = false
                  self.lblrefName.isHidden = false
                self.imgViewStar.isHidden = false
             self.lblrefName.text = "\(PackagePickModel.names)\n\(PackagePickModel.address)\n\(PackagePickModel.city)\nPkg.Spot - \(PackagePickModel.cuid)\n\(PackagePickModel.zipcode)" as String
                        //\nNumber of packages to Pick Up:\(PackagePickModel.package_count)
                }
                self.lblErrorMsg.text = "Ok to give package(s) to customer.\nPlease verify customer name \nNumber of packages to Pick Up:\(PackagePickModel.package_count)"
                }
                else{
                    self.lblErrorMsg.text = "Package(s) have already been picked up. Please verify number is correct."
                }
            }
            else{
                self.btnVerifyCust.isHidden = true
                if let data1 = responseDict["exists"] as? String {
                    if data1 == "1" {
                        Proxy.sharedProxy.displayStatusCodeAlert("Package is already picked up.")
                    }
                    else{
                        if(self.countFalse == 0){
                            self.lblrefName.isHidden = true
                            self.lblErrorMsg.isHidden = false
                            self.lblErrorMsg.text = "ERROR:-\nPlease verify number and try again"
                            self.countFalse = self.countFalse + 1
                        }else{
                            self.lblrefName.isHidden = true
                            self.lblErrorMsg.isHidden = false
                            self.lblErrorMsg.text = "ERROR:-\nPlease contact Customer Service"
                        }
                    }
                }else{
                    if let data1 = responseDict["exists"] as? Int {
                        if data1 == 1 {
                            Proxy.sharedProxy.displayStatusCodeAlert("Package(s) have already been picked up. Please verify number is correct.")
                        }
                        else{
                            if(self.countFalse == 0){
                                self.lblrefName.isHidden = true
                                self.lblErrorMsg.isHidden = false
                                self.lblErrorMsg.text = "ERROR:-\nPlease verify number and try again"
                                self.countFalse = self.countFalse+1
                            }else{
                                self.lblrefName.isHidden = true
                                self.lblErrorMsg.isHidden = false
                                self.lblErrorMsg.text = "ERROR:-\nPlease contact Customer Service"
                            }
                        }
                    }
                }
            }
        }){ (error) in
            KAppDelegate.hideActivityIndicator()
            
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.VerifyCustomerName(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

}
