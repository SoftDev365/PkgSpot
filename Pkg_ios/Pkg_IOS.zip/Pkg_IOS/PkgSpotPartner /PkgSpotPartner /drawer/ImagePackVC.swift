
import UIKit
import Alamofire

class ImagePackVC: UIViewController, OCRViewControllerDelegate{
    
    //MARK: - VARIABLE
    var arrImageCaptured = [ImageCapturedModal]()
    
    var strPkgSpotID = String() //txt cont
    
    var activityIndicator:UIActivityIndicatorView!
    var scannerVC = ScannerVC()
    var imgCurrent = UIImage()
    
    var pkgid = String()
    var barcodenumber = String()
    var barImg = UIImage()
    var capturedModal = ImageCapturedModal()
    var pkgidno = NSMutableArray()
    
    //MARK:- OUTLETS
    @IBOutlet weak var vwScannerContainer: UIView!
    
    //MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        for _ in 0 ..< 8 {
            let captureModal = ImageCapturedModal()
            captureModal.isCaptured = false
            arrImageCaptured.append(captureModal)
        }
    }

    //MARK:- Frame of Picture Captured
    func scaleImage(image: UIImage, maxDimension: CGFloat) -> UIImage {
        
        var scaledSize = CGSize(width:maxDimension, height:maxDimension)
        var scaleFactor:CGFloat
        
        if image.size.width > image.size.height {
            scaleFactor = image.size.height / image.size.width
            scaledSize.width = maxDimension
            scaledSize.height = scaledSize.width * scaleFactor
        } else {
            scaleFactor = image.size.width / image.size.height
            scaledSize.height = maxDimension
            scaledSize.width = scaledSize.height * scaleFactor
        }
        
        UIGraphicsBeginImageContext(scaledSize)
        image.draw(in: CGRect(x:0, y:0, width:scaledSize.width, height:scaledSize.height))
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return scaledImage!
    }
    
    //MARK: - IMAGE PROCESSING
    func ocrSendImage(imgCaptured:UIImage){
        DispatchQueue.main.async {
            self.addActivityIndicator()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let scaledImage = self.scaleImage(image: imgCaptured, maxDimension: 640)
            // 1
            let tesseract = G8Tesseract()
            // 2
            tesseract.language = "eng+fra"
            // 3
            tesseract.engineMode = .tesseractCubeCombined
            // 4
            tesseract.pageSegmentationMode = .auto
            // 5
            tesseract.maximumRecognitionTime = 60.0
            // 6
            tesseract.image = scaledImage.g8_blackAndWhite()
            tesseract.recognize()
            // 7
            self.strPkgSpotID = tesseract.recognizedText
            DispatchQueue.main.async {
                self.removeActivityIndicator()
                let userid = UserDefaults.standard.object(forKey: "userid") as! Int
                let strURL = "\(Apis.KServerUrl)\(Apis.kgetPkgSpotId)\(userid)"
                self.capturedModal.imgCaptured = imgCaptured
                let param = [
                    "text":self.strPkgSpotID,
                    ]
                self.getPkgSpotID(strURL: strURL, param: param as Dictionary<String, AnyObject>,image: imgCaptured)
            }
        }
    }
    
    //MARK:- API Response
    func getPkgSpotID(strURL:String,param: Dictionary<String, AnyObject>? = nil,image: UIImage) {
        Proxy.sharedProxy.postData(strURL, params: param, showIndicator: true
            , completion: { (responseDict) in
                print("Response data: ",responseDict)
                let modal = ImageCapturedModal()
                if (responseDict["status"]! as AnyObject).isEqual(200){
                    if let arr = responseDict["data"] as? NSArray {
                        if let dict = arr[0] as? NSDictionary {
                            if let strPkgid = dict["pkgid"] as? String{
                                self.pkgid = strPkgid
                                modal.isCaptured = true
                                modal.imgCaptured = image
                                modal.strPkgId = strPkgid
                          
                                Proxy.sharedProxy.displayStatusCodeAlert("Pkg ID Confirmed!")
                                
                                let customerVC = self.storyboard?.instantiateViewController(withIdentifier:"CustomerVC") as? CustomerVC
                                customerVC?.objModel = modal
                                customerVC?.arrImage = self.imgCurrent
                                customerVC?.pkgid = strPkgid
                                self.navigationController?.pushViewController(customerVC!, animated: true)
                            }
                        }
                    }
                    
                }else{
                    if let errorMessages = responseDict.object(forKey: "error") as? String{
                        Proxy.sharedProxy.displayStatusCodeAlert(errorMessages)
                        let signup = self.storyboard?.instantiateViewController(withIdentifier:"ValidateCustomerVC") as? ValidateCustomerVC
                       
                        modal.isCaptured = true
                        modal.imgCaptured = image
                        signup?.objModal = modal
                        signup?.fromImageCapture = "1"
                       
                        self.navigationController?.pushViewController(signup!, animated: true)
                    }else{
                        Proxy.sharedProxy.displayStatusCodeAlert("Error: Data not found!")
                    }
                }
        }) { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                //self.getPkgSpotID(strURL: strURL, param: param!,image: arrImageCaptured)
            })
            let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
                
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    // Activity Indicator methods for ORC Only
    func addActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(frame: view.bounds)
        activityIndicator.activityIndicatorViewStyle = .gray
        activityIndicator.backgroundColor = UIColor(white: 0, alpha: 0.25)
        activityIndicator.startAnimating()
        view.addSubview(activityIndicator)
    }
    
    func removeActivityIndicator() {
        activityIndicator.removeFromSuperview()
        activityIndicator = nil
    }

    // MARK:- Action Button
    
    @IBAction func btnActionDrwr(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()
    }
    
    @IBAction func btnActionOpenScannOptions(_ sender: Any) {
        //openScanningOptions()
        let scannerVC = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
        protocolOCR = self
        scannerVC.isDetectQRorBarCode = false
        self.present(scannerVC, animated: true, completion: nil)
    }
    
    @IBAction func btnActionCaptureImage(_ sender: Any) {
        //openScanningOptions()
        let scannerVC = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
        protocolOCR = self
        scannerVC.isDetectQRorBarCode = false
        self.present(scannerVC, animated: true, completion: nil)
    }
}
