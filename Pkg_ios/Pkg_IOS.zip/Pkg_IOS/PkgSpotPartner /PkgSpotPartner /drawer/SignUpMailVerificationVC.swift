
import UIKit

class SignUpMailVerificationVC: UIViewController {
   
    // MARK:- OUTLETS
    @IBOutlet weak var lblMailId: UILabel!
    @IBOutlet weak var lblMail: UILabel!
    @IBOutlet weak var lblSend: UILabel!
    
    var mail = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblSend.text = "We just sent you an email\nverification to"
        lblMail.text = "Please verify your email\naddress to continue."
        lblMailId.text = signUpUserObj.userEmail
    }
    
    // MARK:- NEXT BUTTON ACTIONS
    @IBAction func btnActionNxt(_ sender: Any) {
            let strURL = "\(Apis.KServerUrl)\(Apis.KSignUpStep3)\(signUpUserObj.userId)"
            KSignUpStep3(strURL: strURL, param: nil)
        }
    
    // MARK:- API REQUEST
    func KSignUpStep3(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
        if (responseDict["status"]! as AnyObject).isEqual(200) {
    let signup = self.storyboard?.instantiateViewController(withIdentifier: "CreateAccountVC")as!CreateAccountVC
        self.navigationController?.pushViewController(signup, animated: true)
            }
            else{
                Proxy.sharedProxy.displayStatusCodeAlert("Verify Your Email ID")
            }
       })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KSignUpStep3(strURL: strURL, param: param)
            })
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

    // MARK:- DID NOT RECIEVE EMAIL BUTTON ACTIONS
    @IBAction func btnActionMailNotRec(_ sender: Any) {
        let userEmail = UserDefaults.standard.object(forKey: "userEmail") as! String
        let param = [
                    "email":"\(userEmail)"
                    ]
        let strURL = "\(Apis.KServerUrl)\(Apis.KResendMail)"
        KResendMail(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }
   
    // MARK:- API REQUEST
    
    func KResendMail(strURL:String,param: Dictionary<String, AnyObject>? = nil){
    Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
        if (responseDict["status"]! as AnyObject).isEqual(200) {
            }
            else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KResendMail(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }

    @IBAction func btnActionBck(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }

}
