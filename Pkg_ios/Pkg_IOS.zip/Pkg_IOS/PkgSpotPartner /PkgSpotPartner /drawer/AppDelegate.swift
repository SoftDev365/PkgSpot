import UIKit
import SWRevealViewController
import IQKeyboardManagerSwift
import Alamofire
//import SwiftSpinner
import UserNotifications
import Kingfisher
import Firebase
import SwiftSpinner

var appColor = UIColor(colorLiteralRed: 23/255, green: 153/255, blue: 243/255, alpha: 1.0)

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate,UNUserNotificationCenterDelegate,SWRevealViewControllerDelegate {
    var didStartFromNotification = Bool()
    
    var window: UIWindow?
    var viewController: SWRevealViewController!
    var firstNavController = UINavigationController()
    var visibleNavController : SWRevealViewController!
    var mainStoryBoard = UIStoryboard()
    var sideMenuVC = SlideMenuController()
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    //let storyBoard1 = UIStoryboard(name: "PartnerStoryboard", bundle: nil)
    var window2: UIWindow?
    var splashView:UIImageView = UIImageView()
    var DrawerNavController = UINavigationController()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        application.applicationIconBadgeNumber = 0
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().removeAllDeliveredNotifications()
        } else {
            application.cancelAllLocalNotifications()
        }
        registerForPushNotifications(application: application)
        
        FirebaseApp.configure()
        
        IQKeyboardManager.sharedManager().enable = true
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true
        
        let locationManager = locationManagerClass.sharedLocationManager()
        locationManager.startStandardUpdates()
        self.window = UIWindow(frame: UIScreen.main.bounds)
        let blankController:UIViewController = UIViewController()
        firstNavController = UINavigationController.init(rootViewController: blankController)
        self.window!.rootViewController = firstNavController
        
        self.window!.makeKeyAndVisible()
        splashView.frame = CGRect(x: 0, y: 0, width: (self.window?.frame.width)!, height: (self.window?.frame.height)!)
        splashView.image = #imageLiteral(resourceName: "Splash")
        blankController.view.addSubview(splashView)
        self.window?.addSubview(splashView)
        
        var deviceTokken =  ""
        if UserDefaults.standard.object(forKey: "device_token") == nil {
            deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
        } else {
            deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
        }
                gotoLoginSignUpVC()
        
        if let options = launchOptions {
            if let notification = options[UIApplicationLaunchOptionsKey.remoteNotification] as? NSDictionary {
            // checkApiWithNotification(userInfo: notification)
            } else {
            // checkApiMethodWithoutNotification()
            }
        } else {
            // checkApiMethodWithoutNotification()
        }
        if Proxy.sharedProxy.expiryDateCheckMethod("2017-12-31") {
            
            if ((UserDefaults.standard.object(forKey: "First")) != nil) {
                let authCode: String = Proxy.sharedProxy.authNil()
                if((authCode == "" )) {
                    gotoLoginSignUpVC()
                }
                else {
                    let contentUrl = "\(Apis.KServerUrl)\(Apis.KUserCheck)"
                    
                    let reachability = Reachability()
                    if  reachability?.isReachable  == true {
                        self.showActivityIndicator()
                        request("\(contentUrl)", method: .get, parameters: nil, encoding: URLEncoding.default,headers: ["device_token":"\(deviceTokken)","auth_code":"\(authCode)"] )
                            .responseJSON  { response in
                                if response.response != nil {
                                    self.hideActivityIndicator()
                                    if let JSON = response.result.value as? NSDictionary {
                                        if (JSON["status"]! as AnyObject).isEqual(200) {
                                            Swift.debugPrint(JSON)
                                            if let arrData = JSON ["data"] as? NSArray{
                                                if arrData.count > 0{
//if let dictData = arrData[0] as? NSDictionary{partnerInfoModel.setUserInfo(dictDetail: dictData .mutableCopy() as! NSMutableDictionary)}
                                                }
                                            }
                                         locationManagerClass.sharedLocationManager().startStandardUpdates()
                                            self.popToDrawerViewcontroller(identifier:"Home")
                                            self.window!.makeKeyAndVisible()
                                            
                                        } else if (JSON["status"]! as AnyObject).isEqual(1000) {
                                            self.gotoLoginSignUpVC()
                                            
                                            self.window!.makeKeyAndVisible()
                                            
                                        } else {
                                            self.hideActivityIndicator()
                                            Proxy.sharedProxy.stautsHandler("\(contentUrl)"+"\(authCode)", parameter: nil, response: response.response, data: response.data, error: response.result.error as NSError?)
                                        }
                                    }
                                }
                            }
                        }
                    }
            } else {
                UserDefaults.standard.set("Yes", forKey:"First")
                UserDefaults.standard.synchronize()
                gotoLoginSignUpVC()
            }
        } else {
            displayDateCheckAlert()
        }
        return true
    }
    
    func gotoLoginSignUpVC() {
let viewControllerVC = storyBoard.instantiateViewController(withIdentifier: "PartnerLogInViewController") as! PartnerLogInViewController     
        firstNavController  = UINavigationController(rootViewController: viewControllerVC)
        firstNavController.isNavigationBarHidden = true
        self.window!.rootViewController = firstNavController
        self.window!.makeKeyAndVisible()
    }
    
    func gotoLoginCustomerVC() {
        let viewControllerVC = storyBoard.instantiateViewController(withIdentifier: "CustomerVC") as! CustomerVC
        firstNavController  = UINavigationController(rootViewController: viewControllerVC)
        firstNavController.isNavigationBarHidden = true
        self.window!.rootViewController = firstNavController
        self.window!.makeKeyAndVisible()
    }
    
    func popToDrawerViewcontroller(identifier:String) {
        let mainViewController = storyBoard.instantiateViewController(withIdentifier: identifier)
        let sideViewController = storyBoard.instantiateViewController(withIdentifier: "DrawerVC") as! DrawerVC
        let mainNav: UINavigationController = UINavigationController(rootViewController: mainViewController)
        let sideNav: UINavigationController = UINavigationController(rootViewController: sideViewController)
        let slideMenuController = SlideMenuController.init(mainViewController: mainNav, leftMenuViewController: sideNav)
        slideMenuController.automaticallyAdjustsScrollViewInsets = true
        slideMenuController.delegate = mainViewController as? SlideMenuControllerDelegate
        sideMenuVC = slideMenuController
        mainNav.isNavigationBarHidden = true
        sideNav.isNavigationBarHidden = true
        self.window?.rootViewController = slideMenuController
        self.window?.makeKeyAndVisible()
    }

    //MARK:- Activity Indicator Method
    func showActivityIndicator() {
        SwiftSpinner.show("Loading", animated: true)
    }
    
    func hideActivityIndicator() {
        SwiftSpinner.hide()
    }
    
    // MARK:- Global Print Function
    func debugPrint(Text: String,Object: Any?){
        print("\(Text) :",Object!)
    }
    
    //MARK: - NOTIFICATION METHODS
    func registerForPushNotifications(application: UIApplication) {
        if #available(iOS 10.0, *){
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: {(granted, error) in
                if (granted) {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            })
        } else {
            let notificationSettings = UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil)
            application.registerUserNotificationSettings(notificationSettings)
        }
    }
    
    func registerForPushNotifications(_ application: UIApplication) {
        let notificationSettings = UIUserNotificationSettings(
            types: [.badge, .sound, .alert], categories: nil)
        application.registerUserNotificationSettings(notificationSettings)
    }
    
    func application(_ application: UIApplication, didRegister notificationSettings: UIUserNotificationSettings) {
        UIApplication.shared.registerForRemoteNotifications()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let tokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        // Auth.auth().setAPNSToken(deviceToken, type: AuthAPNSTokenType)
        UserDefaults.standard.set(tokenString, forKey: "device_token")
        UserDefaults.standard.synchronize()
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        //    var deviceTokken =  ""
        //    if UserDefaults.standard.object(forKey: "device_token") == nil {
        //        deviceTokken = "22221152133594131721231122222225858585252559110209CDBA0B489DF9619815ADB9A3DE0DBCD7B6674994E9DDFCA4955AD5C6F49855558899"
        //    } else {
        //        deviceTokken = UserDefaults.standard.object(forKey: "device_token")! as! String
        //    }
        
        //    UserDefaults.standard.set("000000000000000000000000000000000000000000000000000000000000055", forKey: "device_token")
        //    UserDefaults.standard.synchronize()
    }
    
    private func application(_ application: UIApplication,
                             didReceiveRemoteNotification notification: [AnyHashable : Any],
                             fetchCompletionHandler completionHandler: @escaping () -> Void) {
        if Auth.auth().canHandleNotification(notification) {
            completionHandler()
            return
        }
        // This notification is not auth related, developer should handle it.
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (_ options: UNNotificationPresentationOptions) -> Void) {
        var userInfo = NSDictionary()
        userInfo = notification.request.content.userInfo as NSDictionary
        completionHandler([.sound, .alert])

    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        var userInfo = NSDictionary()
        userInfo = response.notification.request.content.userInfo as NSDictionary
    }
    
    //MARK: - displayDateChaeckAlert
    func displayDateCheckAlert()
    {
        let alert: UIAlertView = UIAlertView(title: "Demo Expired", message: "Please contact the team", delegate: nil, cancelButtonTitle: "Ok")
        alert.show()
    }
    
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}
