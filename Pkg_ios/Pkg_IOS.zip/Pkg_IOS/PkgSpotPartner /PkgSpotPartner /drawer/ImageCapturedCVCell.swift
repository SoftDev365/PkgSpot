//
//  ImageCapturedCVCell.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 11/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class ImageCapturedCVCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
