
import UIKit

class PartnerHomeVC: UIViewController {
    
    //MARK:-View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    // MARK:- Button Action
    @IBAction func btnActionRecPkg(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "ImagePackVC")
        self.navigationController?.pushViewController(signup!, animated: true)
    }

    @IBAction func btnActionPkgPckUp(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"PkgPickUpScanInfo")
        self.navigationController?.pushViewController(signup!, animated: true)
    }
   
    @IBAction func btnActionDrw(_ sender: Any) {
           KAppDelegate.sideMenuVC.openLeft()
    }
}
