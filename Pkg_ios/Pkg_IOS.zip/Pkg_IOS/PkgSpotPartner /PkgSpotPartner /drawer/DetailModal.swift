//
//  DetailModal.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 18/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit

class DetailModal: NSObject {

    var str_unique_id = String()
    var str_full_name = String()
    var str_address = String()
    var str_city = String()
    var str_state = String()
    var str_zipcode = String()
 
 init(str_unique_id:String,str_full_name:String,str_address:String,str_city:String,str_state:String,str_zipcode:String){
        self.str_unique_id = str_unique_id
        self.str_full_name = str_full_name
        self.str_address = str_address
        self.str_city = str_city
        self.str_state = str_state
        self.str_zipcode = str_zipcode

    }
    //https://stackoverflow.com/questions/29986957/save-custom-objects-into-nsuserdefaults
    //required convenience init(coder aDecoder: NSCoder) {
       //let id = aDecoder.decodeInteger(forKey: "id")
       //let name = aDecoder.decodeObject(forKey: "name") as! String
       //let shortname = aDecoder.decodeObject(forKey: "shortname") as! String
       //self.init(id: id, name: name, shortname: shortname)
    //}
    
    func encode(with aCoder: NSCoder) {
     //   aCoder.encode(id, forKey: "id")
     //   aCoder.encode(name, forKey: "name")
       // aCoder.encode(shortname, forKey: "shortname")
    }
    
}
