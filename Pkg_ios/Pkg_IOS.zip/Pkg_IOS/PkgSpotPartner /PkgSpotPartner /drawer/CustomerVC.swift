//
//  CustomerVC.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 08/11/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class CustomerVC: UIViewController,OCRViewControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,InvalidImageCapture {
    
    //MARK:- Variable
    var arrImage = UIImage()
    var arrImageCaptured = [ImageCapturedModal]()
    var scannerVC = ScannerVC()
    var strPkgSpotID = String()//txt cont
    var imgCurrent = UIImage()
    var pkgid = String()
    var strDetectedText = String()
    var objModel = ImageCapturedModal()
    var activityIndicator:UIActivityIndicatorView!
    var comeFromValidCustomerVC = ""
    //MARK:- IBOUTLETS
    @IBOutlet weak var colView: UICollectionView!
    
    //MARK:- View Controller Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        //if comeFromValidCustomerVC != "1"{
        strPkgSpotID.append(pkgid)
        
        arrImageCaptured.append(objModel)
        for _ in 1 ..< 8 {
            let captureModal = ImageCapturedModal()
            captureModal.isCaptured = false
            arrImageCaptured.append(captureModal)
            colView.delegate = self
            colView.dataSource = self
            colView.reloadData()
        }
    }
    
    //MARK:- COLLECTION VIEW DELEGATE
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return (arrImageCaptured.count)
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath as IndexPath) as! CollectionViewCell  // get a reference to our storyboard cell
        let capturedModal = arrImageCaptured[indexPath.row]
        if capturedModal.isCaptured {
            cell.btnDeleteImageOutlet.isHidden = false
            cell.imgView.isHidden = false
            cell.imgView.image = capturedModal.imgCaptured
            cell.vwContainer.isHidden = true
        }else{
            cell.btnDeleteImageOutlet.isHidden = true
            cell.vwContainer.isHidden = false
            cell.lblImageNumber.text = "Package\n#\(indexPath.row + 1)"
            cell.imgView.isHidden = true
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 96, height: 94)
    }
    
    //MARK:- Image Upload
    func uploadScannerData(){
        KAppDelegate.showActivityIndicator()
        let arrData = NSMutableArray()
        for modal in arrImageCaptured {
        if modal.isCaptured {
                //let resultdic = NSMutableDictionary()
                //resultdic["customer_id"] = modal.strPkgId
                arrData.add(modal.strPkgId)
            }
        }
        debugPrint("arrData:",arrData )
        
        var jsonString : NSString = ""
        do{
            let Json = try JSONSerialization.data(withJSONObject:arrData, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: Json, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
            debugPrint("Response:",jsonString)
        }catch let error as NSError{
            debugPrint(error.description)
        }
        
        let userid = UserDefaults.standard.object(forKey: UserDefaultsData.str_userid) as! Int
        let strUniqueId = UserDefaults.standard.object(forKey: UserDefaultsData.str_unique_id) as! String
        let strURL = "\(Apis.KServerUrl)\(Apis.kUploadScannedData)\(userid)"
            let param = [
                "partner":strUniqueId,
                "customer_pkg_id":(jsonString as String)
            ]
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                for (key,value) in param {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                }
                var index = 0
                for i in 0 ..< self.arrImageCaptured.count{
                    let captureModal = self.arrImageCaptured[i]
                    if captureModal.isCaptured{
                        guard let imageData = UIImageJPEGRepresentation(captureModal.imgCaptured, 0.5)
                            else {return
                        }
                        let timeStamp = Date().timeIntervalSince1970 * 1000
                        let fileName = "image\(timeStamp).png"
                        print("image_data: image[\(index)]")
                        multipartFormData.append(imageData, withName: "image[\(index)]", fileName: fileName, mimeType: "image/jpeg")
                        index = index + 1
                    }
                }
        },to:strURL,
          headers:["auth_code":"\(Proxy.sharedProxy.authNil())"],
          encodingCompletion: { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    KAppDelegate.hideActivityIndicator()
                    if response.response?.statusCode == 200 {
                        if let responseDict = response.result.value as? NSDictionary {
                            if (responseDict["status"]! as AnyObject).isEqual(200) {
                                //Proxy.sharedProxy.displayStatusCodeAlert("Scanned data uploaded")
                                let userid = UserDefaults.standard.object(forKey: UserDefaultsData.str_userid) as! Int
                                var feedbackResponse = NSString()
                                if let arrayDes = responseDict["data"] as? NSArray{
                                    do {
                            let jsonData = try JSONSerialization.data(withJSONObject: arrayDes, options: JSONSerialization.WritingOptions.prettyPrinted)
                            let strDaysOfServices = NSString(data: jsonData, encoding: String.Encoding.utf8.rawValue)! as String
                                        
                        feedbackResponse = strDaysOfServices.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil) as NSString
                                        
                                    }catch let error as NSError{
                                        print(error.description)
                                    }
                                    
                            let param = [
                                    "data":"\(feedbackResponse)"
                                    ]
                                self.KImgUpload(strURL: "\(Apis.KServerUrl)\(Apis.KImgUpload)\(userid)", param: param as Dictionary<String, AnyObject>)
                                }
                                KAppDelegate.hideActivityIndicator()
                            } else {
                                Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to upload data!")
                            }
                        }else{
                            Proxy.sharedProxy.displayStatusCodeAlert("Error: Unable to get response from server!")
                        }
                    }
                }case .failure(let encodingError):
                    debugPrint(encodingError)
                    KAppDelegate.hideActivityIndicator()
                break
            }
        })
    }
    
    //MARK: - IMAGE PROCESSING
    func ocrSendImage(imgCaptured:UIImage){
        DispatchQueue.main.async {
            self.addActivityIndicator()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let scaledImage = self.scaleImage(image: imgCaptured, maxDimension: 640)
            // 1
            let tesseract = G8Tesseract()
            // 2
            tesseract.language = "eng+fra"
            // 3
            tesseract.engineMode = .tesseractCubeCombined
            // 4
            tesseract.pageSegmentationMode = .auto
            // 5
            tesseract.maximumRecognitionTime = 60.0
            // 6
            tesseract.image = scaledImage.g8_blackAndWhite()
            tesseract.recognize()
            // 7
            self.strPkgSpotID = tesseract.recognizedText
            DispatchQueue.main.async{
                    self.removeActivityIndicator()
                    let userid = UserDefaults.standard.object(forKey: "userid") as! Int
                    let strURL = "\(Apis.KServerUrl)\(Apis.kgetPkgSpotId)\(userid)"
                    let param = [
                        "text":self.strPkgSpotID,
                        ]
                    self.getPkgSpotID(strURL: strURL, param: param as Dictionary<String, AnyObject>,image: imgCaptured)
            }
        }
    }
    
    //MARK:- API Response
    func getPkgSpotID(strURL:String,param: Dictionary<String, AnyObject>? = nil, image: UIImage) {
        Proxy.sharedProxy.postData(strURL, params: param, showIndicator: true
            , completion: { (responseDict) in
                print("Response data: ",responseDict)
                
                if (responseDict["status"]! as AnyObject).isEqual(200){
                    
                    if let arr = responseDict["data"] as? NSArray {
                        if let dict = arr[0] as? NSDictionary {
                            
                            if let strPkgid = dict["pkgid"] as? String{
                                self.pkgid = strPkgid
                                for i in 0 ..< self.arrImageCaptured.count {
                                    let obj = self.arrImageCaptured[i]
                                    if obj.isCaptured != true {
                                        obj.imgCaptured = image
                                        obj.strPkgId = self.pkgid
                                        obj.isCaptured = true
                                        break
                                    }
                                }
                                Proxy.sharedProxy.displayStatusCodeAlert("Pkg ID Confirmed!")
                            }
                        }
                    }
                    self.colView.reloadData()
                }else{
                    if let errorMessages = responseDict.object(forKey: "error") as? String{
                        Proxy.sharedProxy.displayStatusCodeAlert(errorMessages)
            let signup = self.storyboard?.instantiateViewController(withIdentifier:"ValidateCustomerVC") as? ValidateCustomerVC
                        let modal = ImageCapturedModal()
                        modal.isCaptured = true
                        modal.imgCaptured = image
                        signup?.objModal = modal
                        invalidCaptureImgProtocol = self
                        signup?.fromImageCapture = "2"
                        self.navigationController?.pushViewController(signup!, animated: true)
                    }else{
                        Proxy.sharedProxy.displayStatusCodeAlert("Error: Data not found!")
                    }
                }
        }) { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unable to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                //self.getPkgSpotID(strURL: strURL, param: param, index:index, modal:modal
            })
            let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
                
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    func sendImage(imgDetected: UIImage?, strDetectedText: String) {
        for i in 0 ..< self.arrImageCaptured.count {
            let obj = self.arrImageCaptured[i]
            if obj.isCaptured != true{
                obj.imgCaptured = imgDetected!
                obj.strPkgId = strDetectedText
                obj.isCaptured = true
                break
            }
        }
        colView.delegate = self
        colView.dataSource = self
        colView.reloadData()
    }
    
    //MARK:- Button Action
    @IBAction func btnActionFinish(_ sender: Any) {
           uploadScannerData()
    }
    
    //MARK:- Button Delete Action
    @IBAction func actionDeleteImage(_ sender: UIButton) {
        let alertControllerVC = UIAlertController.init(title: "Alert", message: "Are you sure you want to delete !", preferredStyle: .alert)
        let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
            self.arrImageCaptured.remove(at: sender.tag)
            let captureModal = ImageCapturedModal()
            captureModal.isCaptured = false
            self.arrImageCaptured.append(captureModal)
            self.colView.delegate = self
            self.colView.dataSource = self
            self.colView.reloadData()
        })
        let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            
        })
        alertControllerVC.addAction(alertActionOK)
        alertControllerVC.addAction(alertActionCancel)
        self.present(alertControllerVC, animated: true, completion: nil)
    }
    
    @IBAction func btnActionImagePackages(_ sender: Any) {
        let scannerVC = self.storyboard?.instantiateViewController(withIdentifier: "ScannerVC") as! ScannerVC
        protocolOCR = self
        scannerVC.isDetectQRorBarCode = false
        self.present(scannerVC, animated: true, completion: nil)
    }
    
    //MARK:- Frame of Picture Captured
    func scaleImage(image: UIImage, maxDimension: CGFloat) -> UIImage {
        var scaledSize = CGSize(width:maxDimension, height:maxDimension)
        var scaleFactor:CGFloat
        if image.size.width > image.size.height {
            scaleFactor = image.size.height / image.size.width
            scaledSize.width = maxDimension
            scaledSize.height = scaledSize.width * scaleFactor
        } else {
            scaleFactor = image.size.width / image.size.height
            scaledSize.height = maxDimension
            scaledSize.width = scaledSize.height * scaleFactor
        }
        UIGraphicsBeginImageContext(scaledSize)
        image.draw(in: CGRect(x:0, y:0, width:scaledSize.width, height:scaledSize.height))
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return scaledImage!
    }
    
    // Activity Indicator methods for ORC Only
    func addActivityIndicator() {
        activityIndicator = UIActivityIndicatorView(frame: view.bounds)
        activityIndicator.activityIndicatorViewStyle = .gray
        activityIndicator.backgroundColor = UIColor(white: 0, alpha: 0.25)
        activityIndicator.startAnimating()
        view.addSubview(activityIndicator)
    }
    
    func removeActivityIndicator() {
        activityIndicator.removeFromSuperview()
        activityIndicator = nil
    }
    
    @IBAction func btnDrawer(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()
    }
    
    //MARK:- API REQUEST
    func KImgUpload(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                KAppDelegate.hideActivityIndicator()
               Proxy.sharedProxy.displayStatusCodeAlert("Scanned data uploaded !")
                
                let signup = self.storyboard?.instantiateViewController(withIdentifier:"Home")
                self.navigationController?.pushViewController(signup!, animated: true)
            }else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KImgUpload(strURL: strURL, param: nil)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}
