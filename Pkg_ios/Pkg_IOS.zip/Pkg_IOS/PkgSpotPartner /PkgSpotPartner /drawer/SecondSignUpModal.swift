

import UIKit

class SecondSignUpModal: NSObject {
    
    var strBussinessName = String()
    var strOperatingAs = String()
}
