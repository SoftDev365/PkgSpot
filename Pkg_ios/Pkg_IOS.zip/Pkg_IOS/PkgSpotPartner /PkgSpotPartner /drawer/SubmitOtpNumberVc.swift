//
//  SubmitOtpNumberVc.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 17/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//
import UIKit
import Alamofire

class SubmitOtpNumberVc: UIViewController {
    
    //MARK:- Variables
    var userVerifyEmail = String()
    
    //MARK:- IBOUTLETS
    @IBOutlet weak var lblEmailVerify: UILabel!
    @IBOutlet weak var txtFldOtpCode: UITextField!
   
    //MARK:- View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        lblEmailVerify.text = userVerifyEmail
    }
    
    //MARK:- Button Action
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnOtpResendAction(_ sender: Any) {
        let param = [
            "email":"\(userVerifyEmail)"
                ]
        let strURL = "\(Apis.KServerUrl)\(Apis.KForgotPassword)"
        forgotPassword(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }

    @IBAction func btnNextAction(_ sender: Any) {
        let param = [
            "otp":"\(txtFldOtpCode.text!)",
            "email": "\(userVerifyEmail)"
                    ]
        let strURL = "\(Apis.KServerUrl)\(Apis.kOtpVerify)"
        getOtp(strURL: strURL, param: param as Dictionary<String, AnyObject>)
    }
    
    //MARK:- Api Response
    func forgotPassword(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if  let data = responseDict["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        if let email = dic ["email"] as? String{
                            let userEmail = email
                            self.dismiss(animated: true, completion: nil)
                        }
                    }
                }
            }else{
            }
        })
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.forgotPassword(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    func getOtp(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                let submitOtpVc = self.storyboard?.instantiateViewController(withIdentifier:"ChangePasswordVc") as! ChangePasswordVc
                if let strUserId = responseDict.object(forKey: "userId") as? String{
                    submitOtpVc.strUserId = strUserId
                    self.navigationController?.pushViewController(submitOtpVc,animated: true)
                }else{
                    if let userId = responseDict.object(forKey: "userId") as? Int{
                        submitOtpVc.strUserId = "\(userId)"
                        self.navigationController?.pushViewController(submitOtpVc,animated: true)
                    }else{
                        Proxy.sharedProxy.displayStatusCodeAlert("Error: User not found!")
                    }
                }
            }else{
            }
        })
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getOtp(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}

