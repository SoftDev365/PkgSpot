//
//  AddressTVC.swift
//  EZFood
//
//  Created by Sukhpreet Kaur on 04/01/17.
//  Copyright © 2017 Sukhpreet Kaur. All rights reserved.
//

import UIKit

class AddressTVC: UITableViewCell {
    @IBOutlet var lblAddress1: UILabel!

    @IBOutlet var heightLblConstAddres1: NSLayoutConstraint!
    @IBOutlet var lblCountry: UILabel!
    @IBOutlet var btnSetting: UIButton!
    @IBOutlet var btnTick: UIButton!
    @IBOutlet var lblAddress: UILabel!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblCityState: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
