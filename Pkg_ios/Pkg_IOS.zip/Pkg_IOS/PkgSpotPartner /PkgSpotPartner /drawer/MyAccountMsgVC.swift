

import UIKit

class MyAccountMsgVC: UIViewController {
    
    //MARK:- OUTLETS
    @IBOutlet weak var txtViewMsg: UITextView!
    
    //MARK:- VIEW METHODS
    var selectedDays = NSMutableArray()
    var selectedDaysAndTime = NSMutableArray()
    var dictDaysOfServices :[String: String] = [:]
    var resultedArray = NSMutableArray()
    let arrDay = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    var isFromDrawer = Bool()

    //MARK:- CONTROLLER METHOD
    override func viewDidLoad() {
        super.viewDidLoad()
        txtViewMsg.layer.borderColor = UIColor(red: 0.0, green: 156/255, blue: 237/255, alpha: 1.0).cgColor
        txtViewMsg.layer.borderWidth = 1.0
        txtViewMsg.layer.cornerRadius = 5
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int //get from user default
        
        let strURL = "\(Apis.KServerUrl)\(Apis.KMyAccount)\(userid)"
            getData(strURL: strURL, param: nil)
    }
  
    //MARK:- TEXTVIEW METHOD
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text.characters.count == 0 {
            textView.text = "    " + textView.text
        }
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnActionSave(_ sender: Any) {
            if txtViewMsg.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Message")
        }
        else{
           
        var jsonString : NSString = ""
        
        do{
            let arrJson = try JSONSerialization.data(withJSONObject: selectedDays, options: JSONSerialization.WritingOptions.prettyPrinted)
            let string = NSString(data: arrJson, encoding: String.Encoding.utf8.rawValue)
            jsonString = string! as NSString
            }
        
        catch let error as NSError{
            
            print(error.description)
            jsonString = "[]"
        }
        
        debugPrint("hoursService:", jsonString)
        let param = [
        "marketing_message":"\(txtViewMsg.text!)",
        "days_of_service": "\(jsonString)"
                ]
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KMarketingMsg)\(userid)"
        marketingMessage(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }
    }

    //MARK: - GET Webservice response
    func getData(strURL:String,param: Dictionary<String, AnyObject>? = nil){
    Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200){
                debugPrint(responseDict)
                if let arr = responseDict["data"] as? NSArray {
                    let dayOfServiceDict = arr[0] as! NSDictionary
                    if let dict = arr[0] as? NSDictionary {
                        partnerInfoModel.setUserInfo(dictDetail: dict.mutableCopy() as! NSMutableDictionary)
                    }
                    self.txtViewMsg.text = partnerInfoModel.marketMsg
                    
                    if self.isFromDrawer == false{   //By default it will be false when we come through drawer and will the code below else only upper part as we have assigned true to next button
                    if let dayOfService = dayOfServiceDict["days_of_service"] as? String{
                    if dayOfService != ""{
    let strDaysOfServices = dayOfService.replacingOccurrences(of: "\n", with: "", options: .literal, range: nil)
    let strdayOfService = strDaysOfServices.replacingOccurrences(of: "'\'", with: "", options: .literal, range: nil)
                            let data: Data = strdayOfService.data(using: String.Encoding.utf8)!
                            do{
                                var values = NSArray()
                                values = try  JSONSerialization.jsonObject(with: data, options: []) as! NSArray
                                
                             for index in 0..<values.count{
                                  let getDataDict  = (values[index] as! NSDictionary).mutableCopy() as! NSMutableDictionary
                                 self.selectedDays.add(getDataDict)
                                        }
                                    }
                            catch let error as NSError{
                                NSLog("EXCEPTION : %@", error.description)
                            }
                        }
                    }
                }
                debugPrint("SelectedDaysAndTime" , self.selectedDaysAndTime)
            }
        }
        else{}
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getData(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
   
    //MARK: - POST Webservice Response
    func marketingMessage(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                debugPrint(responseDict)
                let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "Home") as! PartnerHomeVC
                self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.marketingMessage(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnActionDrawer(_ sender: Any) {
         KAppDelegate.sideMenuVC.openLeft()
    }

}
