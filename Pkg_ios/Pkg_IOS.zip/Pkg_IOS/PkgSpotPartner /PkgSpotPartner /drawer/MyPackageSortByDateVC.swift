
import UIKit

class MyPackageSortByDateVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    // MARK:- OUTLETS
    @IBOutlet weak var tblView: UITableView!
   
    // MARK:- Life Cycle View Controller
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.dataSource = self
        tblView.delegate = self
        tblView.reloadData()
    }
    
    // MARK:- TABLE VIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell", for: indexPath) as! TableViewCellSortDate
        return cell
    }
    
    //MARK:- BUTTON ACTION
    @IBAction func btnActionSortDate(_ sender: Any) {
    }
   
    @IBAction func btnActionDrop(_ sender: Any) {
         KAppDelegate.sideMenuVC.openLeft()
    }
}




