
import Foundation
import UIKit
import CoreLocation

class AutoCompleteModel: NSObject
{
    
    var descriptionName = String()
    var placeId = String()
    var zipCode  = String()
    var locationCoordinate = CLLocationCoordinate2D()
    var strStreetNumber = String()
    var strCity = String()
    var strState = String()
    var route = String()
    var strCountry = String()
    
}

