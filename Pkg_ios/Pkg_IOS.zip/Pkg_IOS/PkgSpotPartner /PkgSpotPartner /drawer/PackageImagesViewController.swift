import UIKit
import SDWebImage

class PackageImagesViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    //MARK:- IBOUTLETS
    @IBOutlet weak var CollectionVwImage: UICollectionView!
    
    //MARK:- Variables
    var packageImages = NSArray()
    
    //MARK:- View Controller Functions
    override func viewDidLoad() {
        super.viewDidLoad()
        CollectionVwImage.delegate = self
        CollectionVwImage.dataSource = self
        CollectionVwImage.reloadData()
    }
    
    //MARK:- Button Action
    @IBAction func btnCanncelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- Collection View Functions
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return packageImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CollectionVwImage.bounds.size
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! PackageImagesCollectionViewCell
        cell.imgVwPackages.sd_setImage(with: URL(string: packageImages[indexPath.row] as! String), placeholderImage : #imageLiteral(resourceName: "SplashImage"))
        
        return cell
    }
}

