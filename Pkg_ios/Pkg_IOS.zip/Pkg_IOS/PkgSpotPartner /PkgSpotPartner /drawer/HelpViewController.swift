
import UIKit

class HelpViewController: UIViewController,UIWebViewDelegate {
   
    //MARK:-IBOutlets
    @IBOutlet weak var webVw: UIWebView!
    @IBOutlet weak var lblTitle: UILabel!
    //MARK:- Variables
    var value = 6
    
 //MARK:-VIEW CONTROLLER LIFE CYCLE
  override func viewDidLoad() {
        super.viewDidLoad()
        webVw.delegate = self
    }
    
  override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let strURL = "\(Apis.KServerUrl)\(Apis.KHelpPage)\(value)"
        Help(strURL: strURL, param: nil)
    }

  //MARK: - GET Webservice response
  func Help(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                //debugPrint(responseDict)
                if  let data = responseDict["data"] as? NSArray {
                    if let arrayDes = responseDict["data"] as? NSArray {
                        debugPrint(arrayDes)
                        let getDic = arrayDes[0] as! NSDictionary
                        self.lblTitle.text = getDic["title"] as? String
                        if let descript = getDic["description"] as? String {
                        self.webVw.loadHTMLString(descript , baseURL: nil)
                        }
                    }
                }
            }
            else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.Help(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
            }
        }
    }


  extension HelpViewController : SlideMenuControllerDelegate {
  
    func leftWillOpen() {
        print("SlideMenuControllerDelegate: leftWillOpen")
    }
  
    func leftDidOpen() {
        print("SlideMenuControllerDelegate: leftDidOpen")
    }
    
    func leftWillClose() {
        print("SlideMenuControllerDelegate: leftWillClose")
    }
    
    func leftDidClose() {
        print("SlideMenuControllerDelegate: leftDidClose")
    }
    
    func rightWillOpen() {
        print("SlideMenuControllerDelegate: rightWillOpen")
    }
    
    func rightDidOpen() {
        print("SlideMenuControllerDelegate: rightDidOpen")
    }
    
    func rightWillClose() {
        print("SlideMenuControllerDelegate: rightWillClose")
    }
    
    func rightDidClose() {
        print("SlideMenuControllerDelegate: rightDidClose")
    }
    
    @IBAction func btnActionOpenDrawer(_ sender: UIButton) {
        KAppDelegate.sideMenuVC.openLeft()
    }

}


