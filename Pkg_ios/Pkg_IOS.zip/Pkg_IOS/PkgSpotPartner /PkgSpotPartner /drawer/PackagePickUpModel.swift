//
//  File.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 28/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation

var PackagePickModel = PackagePickUp()

class PackagePickUp {
    
    var names = String()
    var address = String()
    var cuid = String()
    var city = String()
    var country = String()
    var zipcode = String()
    var package_count = String()
    
    var PackagePicked = NSArray()
    
    func userData(dict: NSDictionary){
        
        if let names = dict["name"] {
                self.names = names as! String
            }
            if let address = dict["address"] {
                self.address = address as! String
            }
            if let cuid = dict["cuid"] {
                self.cuid = cuid as! String
            }
            if let city = dict["city"] {
                self.city = (city as! NSString) as String
            }
            if let country = dict["country"] as? String {
                self.country = country
            }
            if let zipcode = dict["zipcode"] as? String {
                self.zipcode = zipcode
            }
            if let package_count = dict["package_count"] as? String {
                self.package_count = package_count
            }
    }
}

