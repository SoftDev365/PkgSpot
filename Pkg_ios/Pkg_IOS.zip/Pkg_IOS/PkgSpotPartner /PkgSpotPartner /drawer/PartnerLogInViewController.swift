
import UIKit

class PartnerLogInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    //MARK:- BUTTON ACTION
    @IBAction func btnActionLogin(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "PartnerLogIn")
        self.navigationController?.pushViewController(signup!, animated: true)
    }
    
    @IBAction func btnActionSignUp(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "SignUpInfoVC")
        self.navigationController?.pushViewController(signup!, animated: true)
    }
}







