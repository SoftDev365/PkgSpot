
import Foundation

class SignUpModel {
    
    var bzname = String()
    var opras = String()
    var strtadd = String()
    var cty = String()
    var stat = String()
    var zpp = String()
    var nam = String()
    var postn = String()
    var site = String()
    var email = String()
    var phn = String()
    var psswrd = String()
    var lat = String()
    var long = String()
}

