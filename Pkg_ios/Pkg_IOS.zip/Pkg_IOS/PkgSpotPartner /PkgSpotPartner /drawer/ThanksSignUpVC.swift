
import UIKit

class ThanksSignUpVC: UIViewController {
    
    // MARK:- OUTLETS
    @IBOutlet weak var lblThnx: UILabel!
    @IBOutlet weak var lblAccount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
     lblThnx.text = "Thanks for signing up\nto be a PkgSpot partner."
     lblAccount.text = "Your account is under\nreview. We will be in touch\nwith you soon."
    }
   
    // MARK:- BUTTON ACTION
    @IBAction func btnActionBck(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnActionLogin(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier: "PartnerLogInViewController") 
        self.navigationController?.pushViewController(signup!, animated: true)
    }
}
