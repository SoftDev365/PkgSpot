//
//  ForgotPasswordVc.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 17/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class ForgotPasswordVc: UIViewController {
   
    //MARK: - Variables
    var userModel = SignUpUserInfoModel()
   
    //MARK: - Outlets
    @IBOutlet weak var txtFldEmail: UITextField!
    
    //MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
  
    //MARK: - Button Action
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnForgotPaaswordSubmitAction(_ sender: Any) {
        if txtFldEmail.text!.isEmpty{
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Email")
            return
        }
        else if Proxy.sharedProxy.isValidEmail(txtFldEmail.text!) == false {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Valid Email")
            return
        }
        else{
            let param = [
                "email":"\(txtFldEmail.text!)"]
            let strURL = "\(Apis.KServerUrl)\(Apis.ForgotPassword)"
            forgotPassword(strURL: strURL, param: param as Dictionary<String, AnyObject>)
        }
    }
    
    // MARK:- API Response
    func forgotPassword(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if  let data = responseDict["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        if let email = dic ["email"] as? String{
                            let userEmail = email
                            print(userEmail)
                            
                            let submitOtpVc = self.storyboard?.instantiateViewController(withIdentifier:"SubmitOtpNumberVc") as! SubmitOtpNumberVc
                            submitOtpVc.userVerifyEmail = userEmail
                            self.navigationController?.pushViewController(submitOtpVc,animated: true)
                        }
                    }
                }
            }else{
            }
        })
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.forgotPassword(strURL: strURL, param: param)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}
