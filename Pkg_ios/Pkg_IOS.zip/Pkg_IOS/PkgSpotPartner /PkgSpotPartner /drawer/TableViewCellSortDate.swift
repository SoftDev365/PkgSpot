

import UIKit

class TableViewCellSortDate: UITableViewCell {
    //MARK:- OUTLETS
    @IBOutlet weak var lblDateRcv: UILabel!
    @IBOutlet weak var lblCustNm: UILabel!
    @IBOutlet weak var lblCustNum: UILabel!
    @IBOutlet weak var lblPckUpTime: UILabel!
    @IBOutlet weak var lblPkgNo: UILabel!
   
    @IBOutlet weak var btnPackageImages: UIButton!
    //MARK:- ACTION
    @IBAction func btnActionVIew(_ sender: Any) {
        
    }
}
