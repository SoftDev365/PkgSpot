
import UIKit

class DrawerTableViewCell: UITableViewCell {
    
    //MARK:- OUTLETS
    @IBOutlet weak var lblContent: UILabel!
}
