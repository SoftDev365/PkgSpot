//
//  HistoryDataModel.swift
//  PkgSpotPartner
//  Created by Desh Raj Thakur on 16/10/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import Foundation

class HistoryDataModel {
  
    var dateRecived = String()
    var custName = String()
    var custNum = String()
    var pickUpTime = NSString()
    var package = Int()
    var image = NSArray()
    
    var history = NSArray()
    
    func userData(dict: NSDictionary){
        if let dateRecived = dict["recived_date"] {
            self.dateRecived = dateRecived as! String
        }
        if let custName = dict["customer_name"] {
            self.custName = custName as! String
        }
        if let custNum = dict["cuid"] {
            self.custNum = custNum as! String
        }
        if let pickUpTime = dict["pickedup_time"] as? NSString {
            if pickUpTime == "" {
                self.pickUpTime = "Pending"
            }else{
                self.pickUpTime = pickUpTime
            }
        }
        if let package = dict["package_count"] as? Int {
            self.package = package
        }
        if let  images  = dict["images"] as? NSArray {
            self.image = images
        }
        
    }
}
