//
//  ViewController.swift
//  drawer
//
//  Created by Tajinder Singh on 23/08/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    let arrayimages = ["DrawerMyPackage", "ic_map_location_b", "DrawerMyAccount", "DrawerHelp", "DrawerLogout"]
    let arraycellimages = ["MyLocation", "ic_add"]
    let array1 = ["My Packages", "Locations", "My Account", "Help", "Log Out"]
    let arrRows = [[],["My Location","Add New Location"],[], [],[]]
    var totalArrray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        let nibName = UINib(nibName: "TableViewCell", bundle: nil)
        tableView.register(nibName, forCellReuseIdentifier: "cell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return array1.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if totalArrray.contains(section) {
            return (arrRows[section] as NSArray).count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
       // cell.imageView1.image = self.array[indexPath.item]
        cell.imageView1.image = UIImage(named: arraycellimages[indexPath.row])
      cell.imageView1.contentMode = .scaleAspectFit
      cell.imageView1.clipsToBounds = true
        let arr = arrRows[indexPath.section] as NSArray
        cell.label.text = arr[indexPath.row] as? String
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view1 = UIView.init()
        let label = UILabel()
        label.frame = CGRect(x: 58, y: 5, width: 200, height: 50)
        label.text = array1[section]
        let tapGesture : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(clickedSection(_:)))
        tapGesture.accessibilityHint = String(section)
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 20, y: 20, width: 20, height: 20)
        image.image = UIImage(named: arrayimages[section])
        view1.addSubview(image)
        view1.addSubview(label)
        view1.addGestureRecognizer(tapGesture)
        return view1
    }
    func clickedSection(_ sender: UITapGestureRecognizer) -> Void {
        let section : Int = Int(sender.accessibilityHint!)!
        switch section {
        case 0:
            KAppDelegate.MyPackagesScreen()
            break
        case 1:
            if totalArrray.contains(section) {
                totalArrray.remove(section)
            } else {
                totalArrray.add(section)
            }
            tableView.reloadData()
            break
        case 2:
            KAppDelegate.gotoMyAccountScreen()
            break
        case 3:
          KAppDelegate.gotoHelpViewController()
          break
        case 4:
            logOut()
            break
        default:
            break
        }
    }
    
    
    
    func logOut() {
        // let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
        let logoutURL = "\(KServerUrl)\(KLogout)"
        let reachability = Reachability()
        if  reachability!.isReachable {
            KAppDelegate.showActivityIndicator()
            request(logoutURL, method: .post, parameters: nil, encoding: URLEncoding.httpBody,headers: ["auth_code": "\(proxy.sharedProxy().authNil())","User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    do  {
                        KAppDelegate.hideActivityIndicator()
                        if let JSON = response.result.value as? NSDictionary {
                            if (JSON["status"]! as AnyObject).isEqual(200) {
                                UserDefaults.standard.set("", forKey: "auth_code")
                                UserDefaults.standard.synchronize()
                                KAppDelegate.gotoSelectionVC()
                                proxy.sharedProxy().displayStatusCodeAlert("You are Logged Out Successfully")
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(logoutURL, parameter: nil, response: response.response, data: response.data as Data?, error: response.result.error as NSError?)
                            }
                        }
                    }
            }
        }
    }
    
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      if indexPath.row == 0 {
        KAppDelegate.FindMyLocation()
      }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

