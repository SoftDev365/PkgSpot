//
//  OtpCodeVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 22/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import FirebaseAuth
import Alamofire


class OtpCodeVc: UIViewController {

  @IBOutlet weak var txtfldEnterOTP: UITextField!
  @IBOutlet weak var lblNumber: UILabel!
  var userNumber = String()
  var locationData = LocationModel()
  var locationArray = [LocationModel]()
  let verificationID = UserDefaults.standard.string(forKey: "authVerificationID")

    override func viewDidLoad() {
        super.viewDidLoad()
     lblNumber.text = userNumber
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
  @IBAction func btnResendCodeAction(_ sender: Any) {
    
  }
    
    @IBAction func btnBack(_ sender: Any) {
     _ = self.navigationController?.popViewController(animated: true)
    }
    
  @IBAction func btnNextAction(_ sender: Any) {
    if (txtfldEnterOTP.text?.isEmpty)! {
      proxy.sharedProxy().displayStatusCodeAlert("Enter OTP first")
    }else{
      KAppDelegate.showActivityIndicator()
      let credential = PhoneAuthProvider.provider().credential(
        withVerificationID: verificationID!,
        verificationCode: txtfldEnterOTP.text!)
      Auth.auth().signIn(with: credential) { (user, error) in
        if let error = error {
          KAppDelegate.hideActivityIndicator()
          proxy.sharedProxy().displayStatusCodeAlert("\(error.localizedDescription)")
          return
        }
        KAppDelegate.hideActivityIndicator()
        proxy.sharedProxy().displayStatusCodeAlert("\(user?.displayName ?? "") verification successfully")
       
        
        if self.userNumber.contains(" ") {
            self.userNumber = self.userNumber.replacingOccurrences(of:  " ", with: "")
        }
        
        let param = [
            "contact_no": "\(self.userNumber)" ,
            "id" :       profileModel.id
        ] as [String : Any]
        print(param)
        
        let verifyNumber = "\(KServerUrl)\(KVerifyOtp)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(verifyNumber, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    print(JSONDIC as Any)
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                                self.serviceResponse(JSONDIC)
                                print("Response:",JSONDIC)
                                
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(verifyNumber, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
        }
        
        let firebaseAuth = Auth.auth()
        do {
          try firebaseAuth.signOut()
        } catch let signOutError as NSError {
          KAppDelegate.hideActivityIndicator()
          proxy.sharedProxy().displayStatusCodeAlert("Error signing out: \(signOutError.localizedDescription)")
        }
    
          }
    
    }
    
    func getPartnerslocations(dictData:NSDictionary){
        let verifyNumber = "\(KServerUrl)\(KPartnerLocation)"
        
        let reachability = Reachability()
        if  reachability?.isReachable  == true {
            KAppDelegate.showActivityIndicator()
            let usewrAgent = "\(KMode)\(KAppName)"
            request(verifyNumber, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["User-Agent":"\(usewrAgent)"])
                .responseJSON { response in
                    let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                    print(JSONDIC as Any)
                    do
                    {
                        if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                            KAppDelegate.hideActivityIndicator()
                            if response.response?.statusCode == 200   {
                               self.serviceResponse(JSONDIC)
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().stautsHandler(verifyNumber, parameter: nil as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                            }
                        } else {
                            KAppDelegate.hideActivityIndicator()
                            proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                        }
                    }
            }
        } else {
            KAppDelegate.hideActivityIndicator()
            proxy.sharedProxy().openSettingApp()
        }
    }
    
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KVerifyOtp)  {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
            if JSON["status"] as! Int == 200 {
                //IQKeyboardManager.sharedManager().resignFirstResponder()
                if  let data = JSON["data"] as? NSArray {
                    if let dic = data.firstObject as? NSDictionary {
                        print(dic)
                        profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
//                        self.getPartnerslocations(dictData: dic)
                    }
                }
                
                let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"FindMyLocationVC") as! FindMyLocationVC
                self.navigationController?.pushViewController(otpCodeVc,animated: true)
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }else  if (JSON["url"]! as AnyObject).isEqual(KPartnerLocation)  {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
            if JSON["status"] as! Int == 200 {
                
                if  let data = JSON["data"] as? NSArray {
                    for i in 0..<data.count {
                    if let dic = data[i] as? NSDictionary {
                        let mutatedDic = dic.mutableCopy() as! NSMutableDictionary
                        let locationData = LocationModel()
                        mutatedDic.setValue(0, forKey: "isSelected")
                        locationData.setUserLocation(dictDetail: mutatedDic)
                        self.locationArray.append(locationData)//add(locationData)
                    }
                }
                }
                
                let otpCodeVc = self.storyboard?.instantiateViewController(withIdentifier:"FindMyLocationVC") as! FindMyLocationVC
                otpCodeVc.arrayLocationDetials = locationArray
                self.navigationController?.pushViewController(otpCodeVc,animated: true)
                print(locationArray)
                
                
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
    }
    
}



    
    
    

    

    


