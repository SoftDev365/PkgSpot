

import UIKit

class ImageCapturedModal: NSObject {

    var imgCaptured = UIImage()
    var strPkgSpotId = String() //text:""
    var strPkgId = String()
    var isCaptured = Bool()
}
