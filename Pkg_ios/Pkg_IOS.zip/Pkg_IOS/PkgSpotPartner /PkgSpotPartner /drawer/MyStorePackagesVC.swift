
import UIKit


class MyStorePackagesVC: UIViewController,UITableViewDelegate,UITableViewDataSource ,CalanderDateSelectedDelegate{
   
    //MARK:- OUTLETS
    @IBOutlet weak var lblSortPkg: UILabel!
    @IBOutlet weak var lblSortbyDate: UILabel!
    @IBOutlet weak var tblView: UITableView!
   
    var arrayPackages = [HistoryDataModel]()
    var a = 0
    
    //MARK:- View Controller Life Cycle
    override func viewDidLoad() {
        tblView.dataSource = self
        tblView.delegate = self
        tblView.reloadData()
        protocolCalender = self
        if (a == 0) {
             lblSortPkg.text = "Sort by Packages not Picked Up"
        }
    
    }
    
    //MARK:- View Controller Life Cycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.KHistoryInfo)\(userid)"
        getData(strURL: strURL, param: nil)
    }
    
    func calanderDateSelected(arrReceived: [HistoryDataModel]){
        if arrReceived.count > 0 {
            self.arrayPackages = arrReceived
            a = 1
            if (a > 0){
                self.lblSortPkg.text = "Sort by Date"
            }
        }
        tblView.reloadData()
    }
    
    //MARK:- TABLE VIEW METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  arrayPackages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCellSortPkg
 
        cell.lblCustomerName.text = arrayPackages[indexPath.row].custName
        cell.lblCustomerNumb.text = arrayPackages[indexPath.row].custNum
        cell.lblDateRec.text = arrayPackages[indexPath.row].dateRecived
        cell.lblPickUp.text = arrayPackages[indexPath.row].pickUpTime as String
       
        let packageCounts = (arrayPackages[indexPath.row].package)
        cell.lblPacakages.text = "\(packageCounts)"
        cell.btnActionImage.tag = indexPath.row
   
        return cell
    }
    
    @IBAction func btnActionView(_ sender: Any) {
        let index = (sender as AnyObject).tag
        let modal = arrayPackages[index!]
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"PackageImagesViewController") as! PackageImagesViewController
        signup.packageImages = modal.image
        self.present(signup, animated: true)
    }
    
    //MARK:- Button Action
    @IBAction func btnActionDrop(_ sender: Any) {
         KAppDelegate.sideMenuVC.openLeft()
    }
    
    @IBAction func btnActionSortPkg(_ sender: Any) {
        let signup = self.storyboard?.instantiateViewController(withIdentifier:"MyStorePkgCalanderViewController")
        self.present(signup!, animated: true)
    }
 
    //MARK: - Get Webservice Response
    func getData(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200){
                debugPrint(responseDict)
                
                if  let data = responseDict["data"] as? NSArray {
                    for i in 0..<data.count {
                        let dict = data[i] as? NSDictionary
                        let packageDetials = HistoryDataModel()
                        let mutatedDic = dict?.mutableCopy() as! NSDictionary
                        packageDetials.userData(dict: mutatedDic)
                        self.arrayPackages.append(packageDetials)
                    }
                }
                self.tblView.reloadData()
            }else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getData(strURL: strURL, param: param)
            })
            
            let alertActionCancel=UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
   func calanderDateSelected(){
        tblView.reloadData()
    }
}

