

import UIKit

class TableViewCellSortPkg: UITableViewCell {
    
    // MARK:- OUTLETS
    @IBOutlet weak var lblDateRec: UILabel!
    @IBOutlet weak var lblCustomerName: UILabel!
    @IBOutlet weak var lblCustomerNumb: UILabel!
    @IBOutlet weak var lblPickUp: UILabel!
    @IBOutlet weak var lblPacakages: UILabel!
    @IBOutlet weak var btnActionImage: UIButton!
}
