

import Foundation

class SignUpUserInfoModel {
    
    var userId = Int()
    var userEmail = String()
}
