

import UIKit

class TermsAndPolicyMsgVC: UIViewController, UIWebViewDelegate {
    
    //MARK:- OUTLETS
    @IBOutlet weak var webVw: UIWebView!
    @IBOutlet weak var lblTile: UILabel!
    
    //MARK:- VARIABLES
    var descriptionStr = ""
    var selectedStr  = ""
    var strURL = ""
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK:- FOR PRIVACY POLICY
        strURL = "\(Apis.KServerUrl)\(Apis.KSignUpPolicyStep3)\(selectedStr)"
        TermsAndPolicy(strURL: strURL, param: nil)
        
        //MARK:- FOR TERMS CONDITION
        strURL = "\(Apis.KServerUrl)\(Apis.KSignUpTermsStep3)\(selectedStr)"
        TermsAndPolicy(strURL: strURL, param: nil)
    }
    
    //MARK:- API REQUEST
    
    func TermsAndPolicy(strURL:String,param: Dictionary<String, AnyObject>? = nil){
       
        Proxy.sharedProxy.getData(strURL, showIndicator: true, completion: { (responseDict) in
            
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                        if let arrayDes = responseDict["data"] as? NSArray {
                            debugPrint(arrayDes)
                            let getDic = arrayDes[0] as! NSDictionary
                            self.lblTile.text = getDic["title"] as? String
                            if let descript = getDic["description"] as? String {
                                debugPrint(descript)
                                self.webVw.loadHTMLString(descript as String, baseURL: nil)
                                self.webVw.delegate = self
                            }
                        }
            }
            else{
            }
        })
            { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.TermsAndPolicy(strURL: strURL, param: param)
            })
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnActionPop(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
