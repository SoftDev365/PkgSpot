//
//  SignUpVc.swift
//  PkgSpot
//
//  Created by Jaspreet Bhatia on 21/08/17.
//  Copyright © 2017 Jaspreet Bhatia. All rights reserved.
//

import UIKit
import Alamofire
import IQKeyboardManagerSwift




class SignUpVc: UIViewController {
      // Mark Outlet
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldZipCode: UITextField!
    // Mark Varriable
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
 
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }


    @IBAction func btnBack(_ sender: UIButton) {
     _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnNext(_ sender: Any) {
       signUp()
    }
    func signUp() {
        if txtFldName.isBlank {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Name")
            return
         } else if txtFldEmail.isBlank{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Email Address")
            return
        } else if proxy.sharedProxy().isValidEmail(txtFldEmail.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter valid Email")
            return
        }
        else if txtFldPassword.isBlank {
            proxy.sharedProxy().displayStatusCodeAlert("Please enter Password")
            return
        } else if proxy.sharedProxy().isValidPassword(txtFldPassword.text!) == false {
            proxy.sharedProxy().displayStatusCodeAlert("Password should have minimum 6 alphanumeric characters with atleast one special character")
        }else if txtFldZipCode.isBlank{
            proxy.sharedProxy().displayStatusCodeAlert("Please enter ZipCode")
            return
        }else{
            let param = [
                "full_name" : "\(txtFldName.text!)" ,
                "email" :  "\(txtFldEmail.text!)" ,
                "password" :  "\(txtFldPassword.text!)",
                "zipcode":  "\(txtFldZipCode.text!)",
            ]
           
            let signUpUrl = "\(KServerUrl)" + "\(KSignup)"
            let reachability = Reachability()
            if  reachability?.isReachable  == true {
                KAppDelegate.showActivityIndicator()
                let usewrAgent = "\(KMode)"+"/"+"\(KAppName)"
                request(signUpUrl, method: .post, parameters: param, encoding: URLEncoding.httpBody, headers: ["User-Agent":"\(usewrAgent)"])
                    .responseJSON { response in
                        let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary
                        print(JSONDIC as Any)
                        do
                        {
                            if let JSONDIC = (response.result.value as? NSDictionary)?.mutableCopy() as? NSMutableDictionary {
                                KAppDelegate.hideActivityIndicator()
                                if response.response?.statusCode == 200   {
                                    self.serviceResponse(JSONDIC)
                                    print("Response:",JSONDIC)
                                    
                                } else {
                                    KAppDelegate.hideActivityIndicator()
                                    proxy.sharedProxy().stautsHandler(signUpUrl, parameter: param as Dictionary<String, AnyObject>?, response: response.response, data: response.data, error: response.result.error as NSError?)
                                }
                            } else {
                                KAppDelegate.hideActivityIndicator()
                                proxy.sharedProxy().displayStatusCodeAlert("Problem connection of the Internet")
                            }
                        }
                }
            } else {
                KAppDelegate.hideActivityIndicator()
                proxy.sharedProxy().openSettingApp()
            }
        }
    }
    
     func serviceResponse(_ JSON:NSMutableDictionary) {
      KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual(KSignup)  {
            KAppDelegate.debugPrint(Text: "Sign Up Details", Object: JSON)
              if JSON["status"] as! Int == 200 {
                IQKeyboardManager.sharedManager().resignFirstResponder()
                    if  let data = JSON["data"] as? NSArray {
                    if let dic = data[0] as? NSDictionary {
                   profileModel.setUserProfile(dictDetail: dic.mutableCopy() as! NSMutableDictionary)
                        let PhoneNumberVc = self.storyboard?.instantiateViewController(withIdentifier: "AddYourphoneNumberVc") as! AddYourphoneNumberVc
                       self.navigationController?.pushViewController(PhoneNumberVc,animated: true)
                    }
                }
            }
            else
            {
                if let errorMessage = JSON["error"] {
                    proxy.sharedProxy().displayStatusCodeAlert(errorMessage as! String)
                }
            }
        }
     }
    
     }
//MARK:- TextFieldExtension
extension UITextField {
    var isBlank : Bool {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)!
    }
    var trimmedValue : String {
        return (self.text?.trimmingCharacters(in: .whitespacesAndNewlines))!
    }
    
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder! : "", attributes:[NSForegroundColorAttributeName: newValue!])
        }
    }
}
