
import UIKit

class SignUpMarketingMsgVC: UIViewController ,UITextViewDelegate{
    
    // MARK:- OUTLETS
    @IBOutlet weak var txtViewMsg: UITextView!
    var delete =  ""
    var info = ""
        
    //MARK:- VIEW CONTROLLER LIFE CYCLE
    override func viewDidLoad() {
        txtViewMsg.layer.borderColor = UIColor(red: 0.0, green: 156/255, blue: 237/255, alpha: 1.0).cgColor
        txtViewMsg.layer.borderWidth = 1.0
        txtViewMsg.layer.cornerRadius = 5
    }
    
    // MARK:- TEXTFIELD METHOD
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text.characters.count == 0 {
            textView.text = "    " + textView.text
        }
    }
    
    // MARK:- BUTTON ACTION
    @IBAction func btnActionNxt(_ sender: Any) {
        if txtViewMsg.text!.isEmpty() {
            Proxy.sharedProxy.displayStatusCodeAlert("Please Enter Message")
        } else{
        let param = [
                "marketing_message":"\(txtViewMsg.text!)"
                ]
        signUpStep2(strURL: "\(Apis.KServerUrl)\(Apis.KSignUpStep2)\(signUpUserObj.userId)", param: param as Dictionary<String, AnyObject>)
        }
    }
    
    //MARK:- API REQUEST
    func signUpStep2(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
      
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                if let userData = responseDict["data"] as? NSArray{
                    let userDic = userData[0] as! NSDictionary
                    signUpUserObj.userEmail = userDic["email"] as! String
                }
            let signup = self.storyboard?.instantiateViewController(withIdentifier: "SignUpMailVerificationVC")as!SignUpMailVerificationVC
            self.navigationController?.pushViewController(signup, animated: true)

                }else{
            }
         })
        { (error) in
            
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.signUpStep2(strURL: strURL, param: nil)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnActionBck(_ sender: Any) {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
