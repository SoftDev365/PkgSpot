//
//  ValidateCustomerVC.swift
//  PkgSpotPartner
//
//  Created by Desh Raj Thakur on 08/11/17.
//  Copyright © 2017 Tajinder Singh. All rights reserved.
//

import UIKit
import Alamofire

var invalidCaptureImgProtocol: InvalidImageCapture?

protocol InvalidImageCapture {
    func sendImage(imgDetected: UIImage?,strDetectedText:String)
}
class ValidateCustomerVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    //MARK:- IBOUTLETS
    @IBOutlet weak var textfldEnterPkgID: UITextField!
    @IBOutlet weak var refcollectionView: UICollectionView!
    var fromImageCapture = ""
    //MARK:- Variables
    var detectedCode = String()
    var arrImageCaptured = [ImageCapturedModal]()
    var objModal = ImageCapturedModal()
    var strDetectedText = String()
    var pkgid = String()
    var userID = Int()
    
    //MARK:- View Controller Classes
    override func viewDidLoad() {
        super.viewDidLoad()
        arrImageCaptured.append(objModal)
        if UserDefaults.standard.object(forKey: "userid") as?  Int != nil {
            userID = UserDefaults.standard.object(forKey: "userid") as! Int
        }
         textfldEnterPkgID.attributedPlaceholder = NSAttributedString(string: "Enter Customer Number", attributes: [NSForegroundColorAttributeName: UIColor.init(red: 76/255, green: 76/255, blue: 76/255, alpha: 1.0)])
//        textfldEnterPkgID.text = "Enter Customer Number"
        textfldEnterPkgID.textColor = UIColor.darkGray
        textfldEnterPkgID.borderRect(forBounds: )
        refcollectionView.delegate = self
        refcollectionView.dataSource = self
        refcollectionView.reloadData()
    }
    
    //MARK:- COLLECTION VIEW DELEGATE
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return arrImageCaptured.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell{
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath as IndexPath) as! CollectionViewCell  // get a reference to our storyboard cell
       
        let capturedModal = arrImageCaptured[indexPath.row]
//        if capturedModal.isCaptured {
//            cell.btnDeleteImageOutlet.isHidden = false
//            cell.imgView.isHidden = false
//            cell.imgView.image = capturedModal.imgCaptured
//            cell.vwContainer.isHidden = true
//        }else{
//            cell.btnDeleteImageOutlet.isHidden = true
//            cell.vwContainer.isHidden = false
//            cell.lblImageNumber.text = "Package\n#\(indexPath.row + 1)"
//        }
        
            cell.imgView.isHidden = false
            cell.vwContainer.isHidden = true
            cell.imgView.image = capturedModal.imgCaptured
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 96, height: 94)
    }
    
    //MARK:- Button Actions
    @IBAction func btnSendImages(_ sender: UIButton) {
        let capturedModal = arrImageCaptured[sender.tag]
        let image = capturedModal.imgCaptured
        if image != nil {
            apiAddImage(imgPost: image)
        }
    }
    
    @IBAction func btnActionDrawer(_ sender: Any) {
        KAppDelegate.sideMenuVC.openLeft()
    }
    
    @IBAction func btnSubmit(_ sender: Any) {
        let param = [
            "text":"\(textfldEnterPkgID.text!)",
                ]
        let userid = UserDefaults.standard.object(forKey: "userid") as! Int
        let strURL = "\(Apis.KServerUrl)\(Apis.kgetPkgSpotId)\(userid)"
        getPkgSpotID (strURL: strURL, param: param as Dictionary<String, AnyObject>)
        
    }
    
    //MARK:- Button Delete Action
    @IBAction func actionDeleteImage(_ sender: UIButton) {
        
        let alertControllerVC = UIAlertController.init(title: "Alert", message: "Are you sure you want to delete !", preferredStyle: .alert)
        let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
//            self.arrImageCaptured.remove(at: sender.tag)
//            let captureModal = ImageCapturedModal()
//            captureModal.isCaptured = false
//            self.arrImageCaptured.append(captureModal)
//            self.refcollectionView.delegate = self
//            self.refcollectionView.dataSource = self
//            self.refcollectionView.reloadData()
            _ = self.navigationController?.popViewController(animated: true)
        })
        let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
        
        })
        alertControllerVC.addAction(alertActionOK)
        alertControllerVC.addAction(alertActionCancel)
        self.present(alertControllerVC, animated: true, completion: nil)
    }
    
    //MARK:- API Response
    func getPkgSpotID(strURL:String,param: Dictionary<String, AnyObject>? = nil) {
        Proxy.sharedProxy.postData(strURL, params: param, showIndicator: true
            , completion: { (responseDict) in
                print("Response data: ",responseDict)
                if (responseDict["status"]! as AnyObject).isEqual(200){
                    if let arr = responseDict["data"] as? NSArray {
                        if let dict = arr[0] as? NSDictionary {
                            if let strPkgid = dict["pkgid"] as? String{
                                Proxy.sharedProxy.displayStatusCodeAlert("Pkg ID Confirmed!")
                                if self.fromImageCapture == "1"{
                        let customerVC = self.storyboard?.instantiateViewController(withIdentifier:"CustomerVC") as? CustomerVC
                                    self.objModal.strPkgId = strPkgid
                                    customerVC?.objModel = self.objModal
                                    customerVC?.pkgid = strPkgid
                                    customerVC?.comeFromValidCustomerVC = "1"
                                    self.navigationController?.pushViewController(customerVC!, animated: true)
                                }else{
                                    invalidCaptureImgProtocol?.sendImage(imgDetected: self.objModal.imgCaptured, strDetectedText: strPkgid)
                                    self.navigationController?.popViewController(animated:true)
                                }
                            }
                        }
                    }
                    self.refcollectionView.reloadData()
                    
                }else{
                    Proxy.sharedProxy.displayStatusCodeAlert("Error: Pkg ID not matched !")
                }
                
        }) { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getPkgSpotID(strURL: strURL, param: param)
            })
            let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
                
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    //MARK:- API Response
    func KImagesMail (strURL:String,param: Dictionary<String, AnyObject>? = nil) {
        Proxy.sharedProxy.postData(strURL, params: param, showIndicator: true
            , completion: { (responseDict) in
                print("Response data: ",responseDict)
                if (responseDict["status"]! as AnyObject).isEqual(200){
                }else{
                    Proxy.sharedProxy.displayStatusCodeAlert("Error: Pkg ID not matched !")
                }
                
        }) { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unable to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.getPkgSpotID(strURL: strURL, param: param)
            })
            let alertActionCancel = UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
                
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
    
    //MARK: - Api add post images
    func apiAddImage(imgPost: UIImage){
        let reachability = Reachability()
        if  (reachability?.isReachable)! {
            uploadImages(imgPost)
        }else{
            Proxy.sharedProxy.openSettingApp()
        }
    }
    
    func uploadImages( _ imageInsaurance: UIImage){
        uploadImage (
            imageInsaurance ,
            progress: { percent in
        }, completion: { completed in
            if(completed == true) {
            }else {
            }
        })
    }
    
    func uploadImage(_ imageInsaurance: UIImage, progress: (_ percent: Float) -> Void, completion: @escaping (_ completed: Bool) -> Void){
        let timeStamp = NSDate().timeIntervalSince1970 * 1000
        let fileName = "image\(timeStamp).png"
        let addVideoUrl = "\(Apis.KServerUrl)"+"\(Apis.KImagesMail)"+"\(userID)"
        //let addVideoUrl = "\(kLiveurl)"+"\(kAddImage)"+"\(post_id)"
        KAppDelegate.showActivityIndicator()
        guard let imgUser = UIImageJPEGRepresentation(imageInsaurance, 0.5)
            else{
                return
        }
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                multipartFormData.append(imgUser, withName: "image", fileName: fileName, mimeType: "image/png")
        },
            usingThreshold:UInt64.init(),
            to:addVideoUrl,
            method:.post,
            headers:["User-Agent":"\(usewrAgent)"],
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.validate()
                    upload.responseJSON
                        { response in
                            guard response.result.isSuccess else {
                                print(response)
                                _ = NSString(data: response.data!, encoding: String.Encoding.utf8.rawValue)
                                completion(true)
                                return
                            }
                            KAppDelegate.hideActivityIndicator()
                            let responseJSON = response.result.value as! NSDictionary
                            self.serviceResponse((responseJSON).mutableCopy() as! NSMutableDictionary)
                          }
                case .failure( _): break
                }
        })
        KAppDelegate.showActivityIndicator()
    }
    
    //MARK:- Webservice Method
    func serviceResponse(_ JSON:NSMutableDictionary) {
        KAppDelegate.hideActivityIndicator()
        if (JSON["url"]! as AnyObject).isEqual("/\(Apis.KImagesMail)\(userID)")  {
            if (JSON["status"]! as AnyObject).isEqual(200) {
                var img = String()
                    if let arrayDes = JSON["data"] as? NSArray {
                        let getDic = arrayDes[0] as! NSDictionary
                        if let file = getDic["filename"] as? String {
                                img = file
                        }
                    }
                let param = [
                    "filename":"\(img)"
                ]
       KImgMail(strURL: "\(Apis.KServerUrl)\(Apis.KImgMail)", param: param as Dictionary<String, AnyObject>)
            }else{
                if let errorMessage = JSON["error"] as? String {
                    Proxy.sharedProxy.displayStatusCodeAlert(errorMessage)
                }
            }
        }
    }
    
    //MARK:- API REQUEST
    func KImgMail(strURL:String,param: Dictionary<String, AnyObject>? = nil){
        Proxy.sharedProxy.postData(strURL, params: param ,showIndicator: true, completion:{ (responseDict) in
            if (responseDict["status"]! as AnyObject).isEqual(200) {
                Proxy.sharedProxy.displayStatusCodeAlert("Email sent successfully !")
                let ImagePack = self.storyboard?.instantiateViewController(withIdentifier:"ImagePackVC") as!ImagePackVC
                self.navigationController?.pushViewController(ImagePack, animated: true)
            }else{
            }
        })
        { (error) in
            KAppDelegate.hideActivityIndicator()
            let alertControllerVC = UIAlertController.init(title: "Error", message: "Unabel to get response from server!", preferredStyle: .alert)
            let alertActionOK = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.KImgMail(strURL: strURL, param: nil)
            })
            
            let alertActionCancel =  UIAlertAction.init(title: "Cancel", style: .default, handler: { (action) in
            })
            alertControllerVC.addAction(alertActionOK)
            alertControllerVC.addAction(alertActionCancel)
            self.present(alertControllerVC, animated: true, completion: nil)
        }
    }
}
