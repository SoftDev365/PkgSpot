/*	
	MobileCoreServices.h
	Copyright (c) 2009, Apple Inc. All rights reserved.
*/

#ifndef __MOBILECORESERVICES__

#include <MobileCoreServices/UTCoreTypes.h>
#include <MobileCoreServices/UTType.h>

#endif /* __MOBILECORESERVICES__ */
