exports.admin = function(req, res) {
	res.locals.partials.header = 'header';
	res.locals.partials.sidebar = 'sidebar';
	res.locals.partials.breadcrumbs = 'breadcrumbs';
	res.locals.partials.theme = 'js/theme';
	res.locals.partials.layout = 'js/layout';

	res.render('base', {
		user : req.session.user,
		// csrf: req.csrfToken(),

		csrf : 'pkg-spot_csrf',

		url : {
			home : '/'
		}
	});
}

exports.guestMain = function(req, res) {
	res.locals.partials.theme = 'js/theme';
	res.locals.partials.layout = 'js/layout';

	res.render('guest-main', {
		url : {
			home : '/'
		}
	});
}

exports.signupLayout = function(req, res) {
	res.locals.partials.theme = 'js/theme';
	res.locals.partials.layout = 'js/layout';

	res.render('signup-layout', {
		url : {
			home : '/'
		}
	});
}

var status = {};
status['status'] = '1000';
status['error'] = '';

exports.api = function(req, res) {
	res.json(status);
}