var ActiveRecord = require('../lib/db/activeRecord');
let constants = require('../lib/app/const');
var helpers = require('../lib/app/helper');

var Helper = require('../lib/components/helper');

var jsonData = require('../lib/app/jsonData');

exports.index = function(req, res, next) {
	var string = res.locals.string;

	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : "tbl_setting"
	});

	var helper = new Helper(req, res, next);

	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Settings"
		} ]
	};

	var where = {};

	activeRecord.FindAll(where, function(err, result) {
		if (err || (result.length <= 0)) {
			console.log(err);
			res.locals.view = {
				amount : helper.getDefaultAmoutDetail(),
				config : helper.getDefaultAdminConfig()
			}
		} else {
			console.log(jsonData.json.adminConfigSetting(result));
			res.locals.view = jsonData.json.adminConfigSetting(result);
		}

		res.locals.partials = {
			content : 'setting/index'
		};
		next();
	});
}

exports.add = function(req, res, next) {
	var response = {
		status : constants.API_ERROR
	};

	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : "tbl_setting"
	});

	console.log(req.body);

	if (req.body && req.body.settingType) {

		if (req.body.settingType == 1) {
			var where = {
				where : {
					data_key : constants.SETTING_KEY_BASIC_CONFIG
				}
			};

			var data = {
				data_key : constants.SETTING_KEY_BASIC_CONFIG,
				data_value : JSON.stringify(req.body)
			};

			var updateData = {
				load : data,
				where : {
					data_key : constants.SETTING_KEY_BASIC_CONFIG
				}
			};
		} else if (req.body.settingType == 2) {
			var where = {
				where : {
					data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
				}
			};

			var data = {
				data_key : constants.SETTING_KEY_PACKAGE_AMOUNT,
				data_value : JSON.stringify(req.body)
			};

			var updateData = {
				load : data,
				where : {
					data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
				}
			};
		}

		helpers.init.functions.setDefaultCreateTime(data);

		activeRecord.FindOne(where, function(err, result) {
			if (err) {
				response['status'] = constants.API_ERROR;
				response['error'] = err;
				res.json(response);
			} else if (typeof result['0'] == "undefined") {
				var params = {
					load : data
				};
				activeRecord.Save(params, function(err, result) {
					if (err) {
						response['status'] = constants.API_ERROR;
						response['error'] = err;
						res.json(response);
					} else {
						response['success'] = "Settings added successfully.";
						response['status'] = constants.API_SUCCESS;
						res.json(response);
					}
				});
			} else {
				activeRecord.Save(updateData, function(err, result) {
					if (err) {
						response['status'] = constants.API_ERROR;
						response['error'] = err;
						res.json(response);
					} else {
						response['success'] = "Settings updated successfully.";
						response['status'] = constants.API_SUCCESS;
						res.json(response);
					}
				});
			}
		});
	}
}
