exports.get = function(req, res, next) {

	if (req.session.user) {
		res.redirect(res.locals.root + '/');
	} else {
		res.locals.partials = {
			content : 'login'
		};

		next();
	}
}
