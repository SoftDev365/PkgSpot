var activeRecord = require('../lib/db/activeRecord');
var packageHistory = require('../lib/models/package-history');
let constants = require('../lib/app/const');
let jsonData = require('../lib/app/jsonData');

var async = require('async');

exports.get = function(req, res, next) {
	getJsonData(req, res, function(result) {
		res.json(result);
	});
}

function getJsonData(req, res, cb) {
	var conn = res.locals._admin.db.client;
	var tbl = req.params.table;
	var page = req.params.page;
	var r;
	var params = {
		limit : req.body.start + ", " + req.body.length,
		orderBy : {},
	};
	var wh = searchColumn(req.body.columns, req.body.search.value);

	params.orderBy[getColumn(req.body)] = req.body.order['0'].dir;

	var ActiveRecord = new activeRecord({
		conn : conn,
		table : tbl
	});

	switch (tbl) {
	case "tbl_user":
		if (page == "user-index") {

			var inArray = [ 'unique_id', 'full_name', 'email', 'state_id',
					'created_on' ];
			var query = "SELECT `id`,`unique_id`, `full_name`, `email`,`state_id`, `created_on` FROM `tbl_user` WHERE "
					+ createFiltering(req.body.search.value, inArray);
			query += " AND ( `role_id` != '0' )";

			query += "ORDER BY `" + getColumn(req.body) + "` "
					+ req.body.order['0'].dir + " LIMIT " + req.body.start
					+ ", " + req.body.length;

			ActiveRecord.Count({}, function(err, result) {
				if (err) {
					var data = {
						draw : req.body.draw,
						recordsTotal : 0,
						recordsFiltered : 0,
						data : []
					};
					return cb(data);
				} else {
					var length = result['0'].total;
					ActiveRecord.RawQuery(query, function(err, result) {
						var data = {
							draw : req.body.draw,
							recordsTotal : length,
							recordsFiltered : length,
						};
						if (err || result['0'] == undefined) {
							data.data = [];
						} else {
							var record = jsonData.json.userJsonDisplay(result);
							data.data = record;
						}
						return cb(data);
					});
				}
			});
		}
		break;

	case "tbl_media":
		break;

	case "tbl_partner":
		break;

	case "tbl_page":
		var inArray = [ 'id', 'title', 'type_id' ];
		var query = "SELECT id,title,type_id FROM `tbl_page` WHERE "
				+ createFiltering(req.body.search.value, inArray);
		query += "ORDER BY `" + getColumn(req.body) + "` "
				+ req.body.order['0'].dir + " LIMIT " + req.body.start + ", "
				+ req.body.length;

		ActiveRecord.Count({}, function(err, result) {
			if (err) {
				var data = {
					draw : req.body.draw,
					recordsTotal : 0,
					recordsFiltered : 0,
					data : []
				};
				return cb(data);
			} else {
				var length = result['0'].total;
				ActiveRecord.RawQuery(query, function(err, result) {
					var data = {
						draw : req.body.draw,
						recordsTotal : length,
						recordsFiltered : length,
					};
					if (err || result['0'] == undefined) {
						data.data = [];
					} else {
						var record = jsonData.json.pageJson(result);
						data.data = record;
					}
					return cb(data);
				});
			}
		});
		break;

	case "tbl_payment":
		break;

	case "tbl_package_history":
		if (page == "partner-total") {

			var inArray = [ 'ph.id', 'ph.puid', 'ph.business_name', 'l.address' ];

			var distinct = "SELECT DISTINCT puid FROM tbl_package_history ph INNER JOIN tbl_location l ON l.created_by_id = ph.partner_id WHERE ";
			distinct += " (`ph`.`created_on` >= '" + req.body.start_date;
			distinct += "' AND `ph`.`created_on` <= '" + req.body.end_date
					+ "') ";
			distinct += " OR "
					+ createFiltering(req.body.search.value, inArray);
			distinct += " LIMIT " + req.body.start + ", " + req.body.length;

			var count = "SELECT DISTINCT puid FROM tbl_package_history ph INNER JOIN tbl_location l ON l.created_by_id = ph.partner_id WHERE ";
			count += "(  CAST(ph.created_on as DATE) >= '"
					+ req.body.start_date;
			count += "' AND CAST(ph.created_on as DATE) <= '"
					+ req.body.end_date + "' )";

			var pkgdata = {
				location : [],
				pkg : [],
				sum : []
			};

			ActiveRecord.RawQuery(distinct, function(err, result) {
				if (err || (typeof result['0'] == "undefined")) {
					console.log(err);
					var data = {
						draw : req.body.draw,
						recordsTotal : 0,
						recordsFiltered : 0,
						data : []
					};
					return cb(data);
				} else {
					var dis = result;
					ActiveRecord.RawQuery(count, function(err, result) {
						if (err) {
							console.log(err);
							var data = {
								draw : req.body.draw,
								recordsTotal : 0,
								recordsFiltered : 0,
								data : []
							};
							return cb(data);
						} else {
							var length = result.length;

							getpartnetTotalData(dis, pkgdata, function(err,
									result) {
								var data = {
									draw : req.body.draw,
									recordsTotal : length,
									recordsFiltered : length,
								};
								if (err) {
									data.data = [];
								} else {
									var record = sendPartnerDataJson(pkgdata);
									data.data = record;
								}
								return cb(data);
							});
						}
					});
				}
			});

			function getpartnetTotalData(distnict, pkgdata, done) {
				async
						.each(
								distnict,
								function(key, done) {
									var sum = "SELECT count(puid) as total, SUM(total_price) as total_price FROM tbl_package_history Where `puid` = '"
											+ key.puid
											+ "' GROUP BY total_price, puid";
									ActiveRecord
											.RawQuery(
													sum,
													function(err, result) {
														if (err) {
															return done(err,
																	null);
														} else {
															var sumCount = result['0'];

															var packageHistory = {
																where : {
																	puid : key.puid
																},
																table : 'tbl_package_history'
															};
															ActiveRecord
																	.FindOne(
																			packageHistory,
																			function(
																					err,
																					result) {
																				if (err
																						|| (typeof result['0'] == "undefined")) {
																					console
																							.log(err);
																					return done(
																							err,
																							null);
																				} else {
																					var location = {
																						where : {
																							created_by_id : result['0'].partner_id
																						},
																						table : 'tbl_location'
																					};
																					var pkgd = result['0'];
																					ActiveRecord
																							.FindOne(
																									location,
																									function(
																											err,
																											result) {
																										if (err
																												|| typeof result['0'] == "undefined") {
																											console
																													.log(err);
																											return done(
																													err,
																													null);
																										} else {
																											pkgdata.location
																													.push(result['0']);
																											pkgdata.pkg
																													.push(pkgd);
																											pkgdata.sum
																													.push(sumCount);
																											done();
																										}
																									});
																				}
																			});
														}
													});
								}, done);
			}

		} else if (page == "customer") {

			var inArray = [ 'id', 'cuid', 'customer_name', 'package_count',
					'pickedup_date', 'recived_date', 'price_per_pkg',
					'late_per_pkg', 'pkg_price', 'extra_price', 'total_price' ];
			var query = "SELECT * FROM `tbl_package_history` WHERE "
					+ " ( DATE(`created_on`) BETWEEN '" + req.body.start_date
					+ "' AND '" + req.body.end_date + "') AND " + "( "
					+ createFiltering(req.body.search.value, inArray) + " ) ";
			query += "ORDER BY `" + getColumn(req.body) + "` "
					+ req.body.order['0'].dir + " LIMIT " + req.body.start
					+ ", " + req.body.length;

			var count = "SELECT COUNT(id) as total FROM `tbl_package_history` WHERE "
					+ "( DATE(`created_on`) BETWEEN '"
					+ req.body.start_date
					+ "' AND '"
					+ req.body.end_date
					+ "') AND "
					+ " ( "
					+ createFiltering(req.body.search.value, inArray) + " ) ";

			ActiveRecord.RawQuery(count, function(err, result) {
				if (err) {
					var data = {
						draw : req.body.draw,
						recordsTotal : 0,
						recordsFiltered : 0,
						data : []
					};
					return cb(data);
				} else {
					var length = result['0'].total;
					ActiveRecord.RawQuery(query, function(err, result) {
						var data = {
							draw : req.body.draw,
							recordsTotal : length,
							recordsFiltered : length,
						};
						if (err || result['0'] == undefined) {
							data.data = [];
						} else {
							var record = jsonData.json.packageDetails(result);
							data.data = record;
						}
						return cb(data);
					});
				}
			});
		} else {
			var inArray = [ 'id', 'puid', 'business_name', 'recived_date',
					'pickedup_date', 'package_count' ];
			var query = "SELECT * FROM `tbl_package_history` WHERE "
					+ "( DATE(`created_on`) BETWEEN '" + req.body.start_date
					+ "' AND '" + req.body.end_date + "' ) AND " + "( "
					+ createFiltering(req.body.search.value, inArray) + " ) ";
			query += "ORDER BY `" + getColumn(req.body) + "` "
					+ req.body.order['0'].dir + " LIMIT " + req.body.start
					+ ", " + req.body.length;

			var count = "SELECT COUNT(id) as total FROM `tbl_package_history` WHERE "
					+ "( DATE(`created_on`) BETWEEN '"
					+ req.body.start_date
					+ "' AND '"
					+ req.body.end_date
					+ "') AND "
					+ "( "
					+ createFiltering(req.body.search.value, inArray) + " ) ";

			ActiveRecord.RawQuery(count, function(err, result) {
				if (err) {
					var data = {
						draw : req.body.draw,
						recordsTotal : 0,
						recordsFiltered : 0,
						data : []
					};
					return cb(data);
				} else {
					var length = result['0'].total;
					ActiveRecord.RawQuery(query, function(err, result) {
						var data = {
							draw : req.body.draw,
							recordsTotal : length,
							recordsFiltered : length,
						};
						if (err || result['0'] == undefined) {
							data.data = [];
						} else {
							var record = jsonData.json.packageDetails(result);
							data.data = record;
						}
						return cb(data);
					});
				}
			});
		}
		break;

	case "tbl_notification":
		var inArray = [ 'id', 'message', ];
		var query = "SELECT * FROM `tbl_notification` WHERE ( (`id` LIKE '%"
				+ req.body.search.value + "%') OR (`message` LIKE '%"
				+ req.body.search.value + "%') )";

		query += "ORDER BY `" + getColumn(req.body) + "` "
				+ req.body.order['0'].dir + " LIMIT " + req.body.start + ", "
				+ req.body.length;
		ActiveRecord.Count({}, function(err, result) {
			if (err) {
				var data = {
					draw : req.body.draw,
					recordsTotal : 0,
					recordsFiltered : 0,
					data : []
				};
				return cb(data);
			} else {
				var length = result['0'].total;
				ActiveRecord.RawQuery(query, function(err, result) {
					var data = {
						draw : req.body.draw,
						recordsTotal : length,
						recordsFiltered : length,
					};
					if (err || result['0'] == undefined) {
						data.data = [];
					} else {
						var record = jsonData.json.notificationJson(result);
						data.data = record;
					}
					return cb(data);
				});
			}
		});
		break;
	}
	return r;
}

function sendPartnerDataJson(data) {
	var json = [];
	if (data.location.length > 0 && data.pkg.length) {
		for (var i = 0; i <= (data.pkg.length - 1); i++) {
			if (((typeof data.pkg[i] != "undefined") && (typeof data.location[i] != "undefined"))) {
				json.push({
					"id" : data.pkg[i].id,
					"puid" : data.pkg[i].puid,
					"business_name" : data.pkg[i].business_name,
					"address" : data.location[i].address,
					"total" : data.sum[i].total,
					"total_price" : data.sum[i].total_price
				});
			}
		}
	}
	return json;
}

function createFiltering(value, inArray) {

	var b = " ( ";

	b.or = {};
	if (inArray != null && inArray.length > 0) {
		for (i = 0; i <= (inArray.length - 1); i++) {
			b += " (" + inArray[i] + " LIKE '%" + value + "%')";

			if (i < (inArray.length - 1)) {
				b += " OR ";
			}
		}
	} else {
		return "";
	}
	b += " ) ";
	return b;
}

function searchColumn(body, value) {

	var b = {};

	/*
	 * b.like = { id : value, }; b.or = {}; if (body != null && body.length > 0) {
	 * b.or.like = {}; for (i = 0; i <= (body.length - 1); i++) {
	 * b.or.like[body[i].data] = value; } } else { return false; }
	 */

	b.id = {
		like : value,
	};
	b.or = {};
	if (body != null && body.length > 0) {
		for (i = 0; i <= (body.length - 1); i++) {
			b.or[body[i].data] = {
				like : value
			}
		}
	} else {
		return false;
	}

	return b;
}

function getColumn(column) {
	var c = column.order['0'].column;
	var q = column.columns[c].data;

	return q;
}