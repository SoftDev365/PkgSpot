var helpers = require('../../lib/app/helper');
var jsonData = require('../../lib/app/jsonData');
var DATABASE = require('../../lib/app/query');

exports.deleteLocation = function(req, res, next) {
	if (req.params && req.params.id != 'undefined') {
		DATABASE.connection.Location.deleteLocationById(
				res.locals._admin.db.client, req.params.id, function(err,
						result) {
					if (err) {
						console.log(err);
						res.redirect(res.locals.root + '/404');
					} else {
						res.redirect(res.locals.root + '/locations');
					}
				});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.get = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	if (req.params && req.params.id != 'undefined') {
		DATABASE.connection.Location.getLocationById(conn, req.params.id, function(err, result) {
					if (err) {
						console.log(err);
						res.redirect(res.locals.root + '/404');
					} else {
						res.locals.view = {
								Location : result[0]
						};
						if( typeof result[0] != "undefined" ) {
							DATABASE.connection.UserTable.getUserById(conn, result[0].created_by_id,
									function(err, result) {
										if (err) {
											console.log(err);
											res.redirect(res.locals.root + '/404');
										} else {
											res.locals.view.Partner = result;		
											
											res.locals.breadcrumbs = {
												links : [ {
													url : '/',
													text : res.locals.string.home
												}, {
													url : '/locations',
													text : "Locations"
												}, {
													active : true,
													text : req.params.id
												} ]
											};
	
											res.locals.partials = {
												content : 'locations/view',
											};
											next();
									}
								});
						} else {
							res.redirect(res.locals.root + '/404');
						}
					}
				});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}