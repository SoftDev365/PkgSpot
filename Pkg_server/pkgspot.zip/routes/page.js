var ActiveRecord = require('../lib/db/activeRecord');
let constants = require('../lib/app/const');
var jsonData = require('../lib/app/jsonData');
var Encoder = require('node-html-encoder').Encoder;
var helpers = require('../lib/app/helper');

exports.index = function(req, res, next) {
	var string = res.locals.string;

	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Pages"
		} ]
	};

	res.locals.partials = {
		content : 'page/index'
	};
	next();
}

exports.view = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var string = res.locals.string;
	var encoder = new Encoder('entity');
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_page'
	});

	if (req.params.id) {
		res.locals.breadcrumbs = {
			links : [ {
				url : '/',
				text : string.home
			}, {
				url : '/pages/index',
				text : "Pages"
			} ]
		};

		var params = {
			where : {
				id : req.params.id
			}
		};

		activeRecord.FindOne(params, function(err, result) {
			if (err || result['0'] == undefined) {
				res.redirect(res.locals.root + '/404');
			} else {
				res.locals.breadcrumbs.links.push({
					active : true,
					text : result['0'].title
				});

				var pageJson = jsonData.json.pageJson(result);

				res.locals.view = {
					page : pageJson['0']
				}

				res.locals.partials = {
					content : 'page/view'
				};
				next();
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.update = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_page'
	});
	var encoder = new Encoder('entity');

	var d = req.body.Page.description;

	var q = 'UPDATE tbl_page SET `title`="' + req.body.Page.title
			+ '",`description`="' + encoder.htmlEncode(d) + '" WHERE `id`='
			+ req.params.id;

	var one = {
		where : {
			'id' : req.params.id
		}
	}

	activeRecord.RawQuery(q, function(err, result) {
		activeRecord.FindOne(one, function(err, result) {
			var response = {};
			if (err || result.length <= 0) {
				response.status = 1000;
			} else {
				response.status = 200;
				response.data = result['0']
			}
			res.json(response);
		});
	});
}

exports.add = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	helpers.init.functions.setDefaultCreateTime(req.body);
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_page'
	});

	var params = {
		load : {
			'title' : req.body.Page.title,
			'description' : req.body.Page.description,
			'state_id' : constants.STATE_ACTIVE,
			'created_on' : req.body.created_on,
		}
	};

	console.log(req.body.Page);
	
	if (req.body.Page.type == "1") {
		params.load.type_id = constants.TYPE_PAGE_HELP;
	} else {
		params.load.type_id = constants.TYPE_PARTNER_PAGE_HELP;
	}

	activeRecord.Save(params, function(err, result) {
		var response = {};
		if (err || result.length <= 0) {
			response.status = 1000;
		} else {
			response.status = 200;
			response.data = result['0']
		}
		res.json(response);
	});
}

exports.deleteCustomerPage = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_page'
	});
	var response = {};

	if (req.params && (typeof req.params.id != 'undefined')) {
		var one = {
			where : {
				'id' : req.params.id
			}
		}
		activeRecord.Delete(one, function(err, result) {
			if (err) {
				console.log(err);
				response.status = constants.STATE_INACTIVE;
			} else {
				response.status = constants.STATE_ACTIVE;
				response.data = result['0']
			}
			res.json(response);
		});
	} else {
		res.json(response);
	}
}
