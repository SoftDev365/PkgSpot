var ActiveRecord = require('../lib/db/activeRecord');
let constants = require('../lib/app/const');

exports.get = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	if (req.params.key !== undefined) {
		var activeRecord = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		var where = {
			load : {
				verification_key : null,
				email_verified : constants.EMAIL_VERIFY
			},
			where : {
				verification_key : req.params.key
			}
		};

		var count = {
			count : 'id',
			where : {
				verification_key : req.params.key
			}
		};
		activeRecord.Count(count, function(err, result) {
			if (err || result['0'].id == 0) {
				res.locals.partials = {
					content : '404'
				};
				next();
			} else {
				activeRecord.Save(where, function(err, result) {
					if (err) {
						res.locals.partials = {
							content : '404'
						};
						next();
					} else {
						res.locals.partials = {
							content : 'success'
						};
						next();
					}
				});
			}
		});
	} else {
		res.locals.partials = {
			content : '404'
		};
		next();
	}
}
