exports.get = function(req, res, next) {

	console.log(req.params);

}
