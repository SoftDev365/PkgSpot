let constants = require('../lib/app/const');
var ActiveRecord = require('../lib/db/activeRecord');
var passwordHash = require('password-hash');
var helpers = require('../lib/app/helper');
var moment = require('moment');
var jsonData = require('../lib/app/jsonData');
var Stripe = require('../lib/components/stripe');
var Helper = require('../lib/components/helper');

exports.userSignup = function(req, res, next) {
	var string = res.locals.string;

	res.locals.partials = {
		content : 'frontend/user-signup'
	};
	next();
}

exports.saveUserSignup = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var params = {
		where : {
			'email' : req.body.userEmail
		}
	};
	var ActiveRecordObj = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	var p = {
		recursion : {
			'cUniqueId' : "unique_id"
		}
	};

	ActiveRecordObj
			.Recursion(
					p,
					function(err, value, result) {
						var uId = value;
						ActiveRecordObj
								.FindOne(
										params,
										function(err, result) {
											if (err) {
												var status = helpers.init.functions
														.errorResponse(err,
																req.originalUrl);
												res.json(status);
											} else if (typeof result[0] != 'undefined'
													&& (result[0].step == null || result[0].step == 0)) {
												var err = "Email '"
														+ req.body.userEmail
														+ "' has already been taken.";
												var error = err;
												var status = helpers.init.functions
														.errorResponse(error,
																req.originalUrl);
												res.json(status);
											} else if (typeof result['0'] != 'undefined'
													&& result[0].step != 0) {
												var error = "Please Complete you signup details.";
												var status = helpers.init.functions
														.errorResponse(error,
																req.originalUrl);
												status['step'] = result[0].step;
												status['userId'] = result[0].id;
												res.json(status);
											} else {
												req.body.role_id = constants.ROLE_CUSTOMER;
												req.body.step = constants.CUSTOMER_STEP_ONE;
												req.body.state_id = constants.STATE_INACTIVE;
												req.body.created_on = moment()
														.format(
																"YYYY-MM-DD HH:mm:ss");
												req.body.updated_on = moment()
														.format(
																"YYYY-MM-DD HH:mm:ss");
												req.body.unique_id = uId;
												req.body.userPassword = passwordHash
														.generate(req.body.userPassword);

												var saveUserData = {
													role_id : req.body.role_id,
													step : req.body.step,
													state_id : req.body.state_id,
													updated_on : req.body.updated_on,
													created_on : req.body.created_on,
													unique_id : req.body.unique_id,
													password : req.body.userPassword,
													email : req.body.userEmail,
													zipcode : req.body.zipcode,
													full_name : req.body.userFullName,
													contact_no : req.body.userContactNumber,
													otp : helpers.init.functions
															.gerateUniqueKey(7)
												};

												var save = {
													load : saveUserData,
													table : "tbl_user"
												};

												ActiveRecordObj
														.Save(
																save,
																function(err,
																		result) {
																	if (err) {
																		console
																				.log(err);
																		var status = helpers.init.functions
																				.errorResponse(
																						err,
																						req.originalUrl);
																		res
																				.json(status);
																	} else {
																		if (result.insertId != 0) {
																			var where = {
																				where : {
																					id : result.insertId
																				},
																				table : "tbl_user"
																			};
																			ActiveRecordObj
																					.FindOne(
																							where,
																							function(
																									err,
																									result) {
																								var HelperObj = new Helper(
																										req,
																										res,
																										next);

																								var msg = 'Your verification code is '
																										+ saveUserData.otp
																								HelperObj
																										.sendMessage(
																												req.body.userContactNumber,
																												msg,
																												function(
																														err,
																														result) {
																													console
																															.log(err);
																												});

																								var status = helpers.init.functions
																										.successResponse(
																												result,
																												req.originalUrl);
																								status['step'] = result['0'].step;
																								status['userId'] = result['0'].id;
																								res
																										.json(status);
																							});
																		} else {
																			var error = "Data not save";
																			var status = helpers.init.functions
																					.errorResponse(
																							error,
																							req.originalUrl);
																			res
																					.json(status);
																		}
																	}
																});
											}
										});
					});
}

exports.resendOtp = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var ActiveRecordObj = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	if ((typeof req.body.userId != "undefined")
			&& (typeof req.body.contactNo != "undefined")) {
		var saveUserData = {
			otp : helpers.init.functions.gerateUniqueKey(7)
		};

		var save = {
			load : saveUserData,
			where : {
				id : req.body.userId
			},
			table : "tbl_user"
		};

		ActiveRecordObj.Save(save, function(err, result) {
			if (err) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			} else {
				var HelperObj = new Helper(req, res, next);
				var msg = 'Otp is ' + saveUserData.otp
				HelperObj.sendMessage(req.body.contactNo, msg, function(err,
						result) {
					console.log(err);
				});
				var status = helpers.init.functions.successResponse(result,
						req.originalUrl);
				res.json(status);
			}
		});
	}
}

exports.verifyOtp = function(req, res, next) {
	var string = res.locals.string;

	if ((typeof req.body.otp != "undefined")
			&& (typeof req.body.userId != "undefined")
			&& (typeof req.body.save != "undefined") && (req.body.save == "1")) {
		var conn = res.locals._admin.db.client;

		var params = {
			where : {
				'id' : req.body.userId,
				'otp' : req.body.otp
			}
		};
		var ActiveRecordObj = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		ActiveRecordObj.FindOne(params, function(err, result) {
			if (err || (typeof result['0'] == "undefined")) {
				console.log(err);
				var error = "OTP not matched";
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				res.json(status);
			} else {
				var save = {
					load : {
						step : constants.CUSTOMER_STEP_TWO
					},
					where : {
						id : req.body.userId
					},
					table : 'tbl_user'
				};
				ActiveRecordObj.Save(save, function(err, result) {
					if (err) {
						console.log(err);
						var error = "Phone number verification fail.";
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					} else {
						var status = helpers.init.functions.successResponse([],
								req.originalUrl);
						status['step'] = constants.CUSTOMER_STEP_TWO;
						status['userId'] = req.body.userId;
						res.json(status);
					}
				});
			}
		});
	} else {
		res.locals.view = {
			userDetail : {
				userId : req.body.userId,
				contactNo : req.body.contactNo
			}
		};

		res.locals.partials = {
			content : 'frontend/verify'
		};
		next();
	}
}

exports.yourLocation = function(req, res, next) {
	var string = res.locals.string;

	res.locals.view = {
		userDetail : {
			userId : req.body.userId
		}
	};

	if ((typeof req.body.save != "undefined") && (req.body.save == 1)) {
		var conn = res.locals._admin.db.client;
		var params = {
			where : {
				'id' : req.body.userId
			}
		};
		var ActiveRecordObj = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		var save = {
			load : {
				step : constants.CUSTOMER_STEP_THREE,
				location : (typeof req.body.location != "undefined") ? req.body.location
						: ''
			},
			where : {
				id : req.body.userId
			},
			table : 'tbl_user'
		};
		ActiveRecordObj.Save(save, function(err, result) {
			if (err) {
				console.log(err);
				var error = "Location not save";
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				res.json(status);
			} else {
				var status = helpers.init.functions.successResponse([],
						req.originalUrl);
				status['step'] = constants.CUSTOMER_STEP_THREE;
				status['userId'] = req.body.userId;
				res.json(status);
			}
		});
	} else {
		res.locals.partials = {
			content : 'frontend/map'
		};
		next();
	}
}

exports.cardDetails = function(req, res, next) {
	var string = res.locals.string;
	var conn = res.locals._admin.db.client;

	var ActiveRecordObj = new ActiveRecord({
		conn : conn,
		table : 'tbl_setting'
	});
	var HelperObj = new Helper(req, res, next);

	if ((typeof req.body.save != "undefined") && (req.body.save == 1)
			&& (typeof req.body.token != "undefined")) {
		var stripe = new Stripe({
			token : req.body.token
		});

		stripe.saveCard({
			token : req.body.number
		}, function(err, result) {
			if (err || result == null) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				status['userId'] = req.body.userId;
				res.json(status);
			} else {
				var CardDetails = result;
				var saveSteps = {
					load : {
						'step' : constants.CUSTOMER_STEP_COMPLETE,
						'state_id' : constants.STATE_ACTIVE,
						'customer_id' : CardDetails.id
					},
					where : {
						'id' : req.body.userId
					},
					table : 'tbl_user'
				};

				ActiveRecordObj.Save(saveSteps, function(err, result) {
					if (err || result.affectedRows == 0) {
						console.log(err);
						var error = err;
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					} else {
						var status = helpers.init.functions.successResponse([],
								req.originalUrl);
						status['userId'] = req.body.userId;
						status['step'] = constants.CUSTOMER_STEP_COMPLETE;
						res.json(status);
					}
				});
			}
		});
	} else {
		var amount = {
			where : {
				data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
			},
			table : 'tbl_setting'
		};

		ActiveRecordObj.FindOne(amount, function(err, result) {
			if (err || (typeof result['0'] == "undefined")) {
				console.log(err);
				var calculateAmount = HelperObj.getDefaultAmoutDetail();
			} else {
				var calculateAmount = JSON.parse(result['0'].data_value);
			}
			res.locals.view = {
				amoutConfig : calculateAmount,
				userDetail : {
					userId : req.body.userId
				}
			};

			res.locals.partials = {
				content : 'frontend/card-details'
			};
			next();
		});
	}
}

exports.congratulation = function(req, res, next) {
	var string = res.locals.string;
	var conn = res.locals._admin.db.client;
	var ActiveRecordObj = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	var param = {
		where : {
			id : req.body.userId
		},
		table : 'tbl_user'
	};

	ActiveRecordObj
			.FindOne(
					param,
					function(err, result) {
						if (err || typeof result['0'] == 'undefined') {
							console.log(err);
							res.locals.partials = {
								content : 'frontend/congratulation'
							};
							next();
						} else {
							var UserUniqueId = {
								uId : result['0'].unique_id,
								uName : result['0'].full_name
							};
							var loc = result['0'].location;
							var param = {
								where : {
									id : loc
								},
								table : 'tbl_location'
							};
							ActiveRecordObj
									.FindOne(
											param,
											function(err, result) {
												if (err
														|| typeof result['0'] == 'undefined') {
													console.log(err);
													res.locals.partials = {
														content : 'frontend/congratulation'
													};
													next();
												} else {
													var userLocations = result;
													var sql = "SELECT unique_id from tbl_user where id IN ( SELECT created_by_id from tbl_location where id="
															+ loc + " )";
													ActiveRecordObj
															.RawQuery(
																	sql,
																	function(
																			err,
																			result) {
																		if (err
																				|| typeof result['0'] == 'undefined') {
																			console.log(err);
																			res.locals.partials = {
																				content : 'frontend/congratulation'
																			};
																			next();
																		} else {
																			var info = jsonData.json
																					.userLocationInfo(
																							userLocations,
																							result);
																			var userInfo = {
																				userName : UserUniqueId.uName,
																				userUniqueId : UserUniqueId.uId,
																				location : info['0']
																			};
																			res.locals.view = {
																				userDetail : userInfo
																			};
																			
																			console.log(res.locals.view.userDetail.location);

																			res.locals.partials = {
																				content : 'frontend/congratulation'
																			};
																			next();
																		}
																	});
												}
											});
						}
					});
}

exports.complete = function(req, res, next) {
	var string = res.locals.string;

	res.locals.partials = {
		content : 'frontend/complete'
	};
	next();
}

exports.termsService = function(req, res, next) {
	var string = res.locals.string;

	res.locals.partials = {
		content : 'frontend/service-page'
	};
	next();
}

exports.privacyPolicy = function(req, res, next) {
	var string = res.locals.string;

	res.locals.partials = {
		content : 'frontend/privacy-policy'
	};
	next();
}