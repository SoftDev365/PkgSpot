var ActiveRecord = require('../../lib/db/activeRecord');
let constants = require('../../lib/app/const');

var Notification = {
	deleteNotificationByUser : function(db, id, callback) {
		return db.query("delete from tbl_notification where created_by_id='"
				+ id + "'", callback);
	},
	deleteNotificationById : function(db, id, callback) {
		return db.query("delete from tbl_notification where id='" + id + "'",
				callback);
	},
};

exports.deleteNotification = function(req, res, next) {
	
	
	if (req.params && req.params.id != 'undefined') {
		Notification.deleteNotificationById(res.locals._admin.db.client,
				req.params.id, function(err, result) {
					console.log(err);
					if (err) {
						res.redirect(res.locals.root + '/404');
					} else {
						res.redirect(res.locals.root + '/notifications');
					}
				});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.index = function(req, res, next) {
	var string = res.locals.string;

	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Notifications"
		} ]
	};

	res.locals.partials = {
		content : 'notifications/index'
	};
	next();
}

exports.get = function(req, res, next) {
	if (req.params && req.params.id != 'undefined') {
		var conn = res.locals._admin.db.client;

		var activeRecord = new ActiveRecord({
			conn : conn,
			table : 'tbl_notification'
		});

		var params = {
			where : {
				id : req.params.id
			}
		};

		activeRecord.FindOne(params, function(err, result) {
			if (err || result == [] || result['0'] === undefined) {
				console.log(err);
				res.redirect(res.locals.root + '/404');
			} else {
				var is = result['0'].is_read;
				var Noti = result['0'];
				if (result[0].is_read == constants.NOT_READ) {
					params.load = {
						is_read : constants.IS_READ
					};
					activeRecord.Save(params, function(err, result) {
						if (err) {
							res.redirect(res.locals.root + '/404');
						} else {
							res.locals.view = {
								data : Noti,
								id : req.params.id
							};

							res.locals.breadcrumbs = {
								links : [ {
									url : '/',
									text : res.locals.string.home
								}, {
									url : '/notifications',
									text : "Notification"
								}, {
									active : true,
									text : req.params.id
								} ]
							};

							res.locals.partials = {
								content : 'notifications/view',
							};
							next();
						}
					});
				} else {
					res.locals.view = {
						data : Noti,
						id : req.params.id
					};

					res.locals.breadcrumbs = {
						links : [ {
							url : '/',
							text : res.locals.string.home
						}, {
							url : '/notifications',
							text : "Notification"
						}, {
							active : true,
							text : req.params.id
						} ]
					};

					res.locals.partials = {
						content : 'notifications/view',
					};
					next();
				}
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}