var ActiveRecord = require('../lib/db/activeRecord');
let constants = require('../lib/app/const');
const excel = require('node-excel-export');
var jsonData = require('../lib/app/jsonData');

exports.exportPartnerTotalData = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});
	// You can define styles as json object
	// More info: https://github.com/protobi/js-xlsx#cell-styles
	const styles = {
		headerDark : {
			fill : {
				fgColor : {
					rgb : 'FF000000'
				}
			},
			font : {
				color : {
					rgb : 'FFFFFFFF'
				},
				sz : 14,
				bold : true,
				underline : true
			}
		},
		cellPink : {
			fill : {
				fgColor : {
					rgb : 'FFFFCCFF'
				}
			}
		},
		cellGreen : {
			fill : {
				fgColor : {
					rgb : 'FF00FF00'
				}
			}
		}
	};

	// Array of objects representing heading rows (very top)
	const heading = [];
	switch (req.params.action) {
	case "customer":
		var query = "SELECT * FROM `tbl_package_history` WHERE "
				+ " ( DATE(`created_on`) BETWEEN '" + req.params.start
				+ "' AND '" + req.params.end + "')";

		// Here you specify the export structure
		var specification = {
			id : {
				displayName : 'Id',
				headerStyle : styles.headerDark,
				width : 120
			},
			cuid : {
				displayName : 'Customer Number',
				headerStyle : styles.headerDark,
				width : '10'
			},
			customer_name : {
				displayName : 'Customer Name',
				headerStyle : styles.headerDark,
				width : 220
			},
			package_count : {
				displayName : 'Picked Picked-Up',
				headerStyle : styles.headerDark,
				width : 220
			},
			pickedup_date : {
				displayName : 'Picked-Up(Date/Time)',
				headerStyle : styles.headerDark,
				width : 220
			},
			recived_date : {
				displayName : 'Recieved(Date/Time)',
				headerStyle : styles.headerDark,
				width : 220
			},
			price_per_pkg : {
				displayName : 'Bill/Rate Package',
				headerStyle : styles.headerDark,
				width : 220
			},
			late_per_pkg : {
				displayName : 'Bill Rate late Fee/Package',
				headerStyle : styles.headerDark,
				width : 220
			},
			pkg_price : {
				displayName : 'Package Fees',
				headerStyle : styles.headerDark,
				width : 220
			},
			extra_price : {
				displayName : 'Late Fees',
				headerStyle : styles.headerDark,
				width : 220
			},
			total_price : {
				displayName : 'Total Fees',
				headerStyle : styles.headerDark,
				width : 220
			}
		}
		break;
	case "partner":
		var query = "SELECT * FROM `tbl_package_history` WHERE "
				+ "( DATE(`created_on`) BETWEEN '" + req.params.start
				+ "' AND '" + req.params.end + "' )";
		// Here you specify the export structure
		var specification = {
			id : {
				displayName : 'Id',
				headerStyle : styles.headerDark,
				width : 120
			},
			puid : {
				displayName : 'Partner Number',
				headerStyle : styles.headerDark,
				width : '10'
			},
			business_name : {
				displayName : 'Business Name',
				headerStyle : styles.headerDark,
				width : 220
			},
			recived_date : {
				displayName : 'Recieved(Date/Time)',
				headerStyle : styles.headerDark,
				width : 220
			},
			pickedup_date : {
				displayName : 'Picked-Up(Date/Time)',
				headerStyle : styles.headerDark,
				width : 220
			},
			package_count : {
				displayName : 'Picked Picked-Up',
				headerStyle : styles.headerDark,
				width : 220
			}
		}
		break;
	case "partner-total":
		var query = "SELECT ph.id,ph.puid,ph.partner_id,ph.business_name,ph.created_on,count(ph.id) as total, count(ph.total_price) as total_price, l.address FROM tbl_package_history ph INNER JOIN tbl_location l ON l.created_by_id = ph.partner_id  WHERE puid IN (SELECT DISTINCT puid FROM tbl_package_history)";
		query += " AND ( DATE(`ph`.`created_on`) BETWEEN '" + req.params.start
				+ "' AND '" + req.params.end + "' )";

		// Here you specify the export structure
		var specification = {
			id : {
				displayName : 'Id',
				headerStyle : styles.headerDark,
				width : 10
			},
			puid : {
				displayName : 'Partner Number',
				headerStyle : styles.headerDark,
				width : 200
			},
			business_name : {
				displayName : 'Business Name',
				headerStyle : styles.headerDark,
				width : 220
			},
			address : {
				displayName : 'Address',
				headerStyle : styles.headerDark,
				width : 320
			},
			total : {
				displayName : 'Total Packages Received',
				headerStyle : styles.headerDark,
				width : 220
			},
			total_price : {
				displayName : 'Dollar Amount',
				headerStyle : styles.headerDark,
				width : 100
			}
		}
		break;
	}

	activeRecord.RawQuery(query, function(err, result) {

		switch (req.params.action) {
		case "customer":
			var record = jsonData.json.packageDetailsCustomerExport(result);
			break;
		case "partner":
			var record = jsonData.json.packageDetailsExport(result);
			break;
		case "partner-total":
			var record = jsonData.json.totalPartnerPachage(result);
			break;
		}
		const dataset = record;

		/*
		 * const merges = [ { start : { row : 1, column : 1 }, end : { row : 1,
		 * column : 10 } }, { start : { row : 2, column : 1 }, end : { row : 2,
		 * column : 5 } }, { start : { row : 2, column : 6 }, end : { row : 2,
		 * column : 10 } } ];
		 */

		const report = excel.buildExport([ {
			name : 'Report',
			heading : heading,
			// merges : merges,
			specification : specification,
			data : dataset
		} ]);

		res.attachment("report_" + req.params.start + "_" + req.params.end
				+ ".xlsx");
		return res.send(report);
	});
}

exports.customer = function(req, res, next) {
	var string = res.locals.string;

	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Customer"
		} ]
	};

	res.locals.partials = {
		content : 'package-history/customer'
	};
	next();
}

exports.images = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_parcel'
	});
	var response = {
		status : constants.STATE_INACTIVE
	};
	if (req.params && (typeof req.params.id != 'undefined')) {
		var all = {
			where : {
				'package_id' : req.params.id
			}
		}
		activeRecord.FindAll(all, function(err, result) {
			if (err || (typeof result['0'] == "undefined")) {
				console.log(err);
				response['status'] = constants.API_ERROR;
			} else {
				response['status'] = constants.API_SUCCESS;
				response.data = jsonData.json.packageImages(req, result);
			}
			res.json(response);
		});
	} else {
		res.json(response);
	}
}

exports.partner = function(req, res, next) {
	var string = res.locals.string;
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Partner"
		} ]
	};

	res.locals.partials = {
		content : 'package-history/partner'
	};
	next();
}

exports.partnerTotal = function(req, res, next) {
	var string = res.locals.string;
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : string.home
		}, {
			active : true,
			text : "Partner Total"
		} ]
	};

	res.locals.partials = {
		content : 'package-history/partner-total'
	};
	next();
}

exports.customerDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var string = res.locals.string;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});

	if (req.params.id) {
		var params = {
			where : {
				id : req.params.id
			}
		};

		activeRecord.FindOne(params, function(err, result) {
			if (err || result['0'] == undefined) {
				res.redirect(res.locals.root + '/404');
			} else {
				res.locals.view = {
					packageHistory : result['0']
				}

				res.locals.partials = {
					content : 'package-history/customer-detail'
				};
				next();
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}
