var pwd = require('pwd');
let constants = require('../lib/app/const');
var ActiveRecord = require('../lib/db/activeRecord');
var passwordHash = require('password-hash');

exports.status = function(req, res, next) {
	res.locals.show = {
		error : req.session.error,
		success : req.session.success
	};
	res.locals.username = req.session.username;
	delete req.session.error;
	delete req.session.success;
	delete req.session.username;
	next();
}

exports.restrict = function(req, res, next) {
	if (res.locals._admin.debug)
		return next();

	if (req.session.user)
		return next();
	req.session.error = res.locals.string['access-denied'];
	res.redirect(res.locals.root + '/login');
}

exports.apiRestrict = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var headers = req.headers;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	var id = req.params.id;
	if (id == undefined || id == null || id == "") {
		if (headers.auth_code != undefined || headers.auth_code == null
				|| headers.auth_code == "") {
			var auth = {
				where : {
					binary : {
						'auth_code' : headers.auth_code
					}
				},
				table : 'tbl_auth_session'
			};

			activeRecord.FindOne(auth, function(err, result) {
				if (err || result.length <= 0) {
					console.log("Hello");
					var status = {};
					status['name'] = "Forbidden";
					status['message'] = "Valid authcode required";
					status['code'] = 0;
					status['status'] = constants.API_403;
					res.json(status);
					return;
				} else {
					console.log("AUTH SUCCESS");
					return next();
				}
			});
		}
	} else {
		var params = {
			where : {
				id : id
			}
		};
		activeRecord.FindOne(params, function(err, result) {
			if (err || result.length <= 0) {
				var status = {};
				status['name'] = "Forbidden";
				status['message'] = "Valid authcode required";
				status['code'] = 0;
				status['status'] = constants.API_403;
				res.json(status);
				return;
			} else {
				console.log("AUTH SUCCESS");
				return next();
			}
		});
	}
}

exports.apiNotRestrict = function(req, res, next) {
	var status = [];
	// if ( req.session.user ) {
	// res.redirect(res.locals.root+'/api/auth/not-allowed');
	// } else {
	return next()
	// }
}

exports.login = function(req, res) {
	// query the db for the given username
	if (req.session.user) {
		res.redirect(res.locals.root + '/');
	} else {
		var conn = res.locals._admin.db.client;

		var activeRecord = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		var params = {
			where : {
				email : req.body.username,
				role_id : constants.ROLE_ADMIN
			}
		};

		activeRecord.FindOne(params, function(err, result) {
			if (err || result.length <= 0) {
				req.session.error = res.locals.string['find-user'];
				req.session.username = req.body.username;
				res.redirect(res.locals.root + '/login');
				return;
			}
			// apply the same algorithm to the POSTed password, applying
			// the hash against the pass / salt, if there is a match we
			// found the user
			if (passwordHash.verify(req.body.password, result['0'].password)) {
				// Regenerate session when signing in
				// to prevent fixation
				req.session.regenerate(function(err) {
					// Store the user's primary key
					// in the session store to be retrieved,
					// or in this case the entire user object
					req.session.user = result['0'];
					res.redirect(res.locals.root + '/');
				});
			} else {
				req.session.error = res.locals.string['invalid-password'];
				req.session.username = req.body.username;
				res.redirect(res.locals.root + '/login');
				return;
			}
		});
	}
}

exports.logout = function(req, res) {
	// destroy the user's session to log them out
	// will be re-created next request
	req.session.destroy(function() {
		// successfully logged out
		res.redirect(res.locals.root + '/login');
	});
}
