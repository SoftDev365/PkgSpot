//import ActiveRecord from '../../lib/db/activeRecord';
var moment = require('moment');
var helpers = require('../../lib/app/helper');
var jsonData = require('../../lib/app/jsonData');
var DATABASE = require('../../lib/app/query');

var auth = require('./auth');
let constants = require('../../lib/app/const');
var passwordHash = require('password-hash');
var _ = require('underscore');
var ActiveRecord = require('../../lib/db/activeRecord');
var Stripe = require('../../lib/components/stripe');

var Helper = require('../../lib/components/helper');

var Mailer = require('../../lib/app/mailer');
var fs = require('fs');
var path = require('path');
var async = require('async');

var EmailTemplates = require('swig-email-templates');
var templates = new EmailTemplates();
var status = {};
status['status'] = '1000';
status['error'] = '';
status['step'] = '';
status['userId'];
status['url'] = '';
status['datecheck'] = constants.DATECHECK;
status['maintainence'] = null;
status['data'] = [];

function notEmpty(str) {
	if ((typeof str !== 'undefined' && str)) {
		return true;
	}
	return false;
}

// req.originalUrl
// req.headers
exports.notAllowed = function(req, res, next) {
	status['status'] = constants.API_ERROR;
	status['data'] = [];
	status['auth_code'] = '';
	status['url'] = req.originalUrl;
	status['error'] = "You are not allowed to perform this action.";
	res.json(status);
}

exports.amountDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : "tbl_setting"
	});

	var param = {
		where : {
			data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
		}
	};

	var HelperObj = new Helper(req, res, next);

	activeRecord.FindOne(param, function(err, result) {
		if (err || (typeof result['0'] == "undefined")) {
			console.log(err);

			var data = HelperObj.getDefaultAmoutDetail();

			var status = helpers.init.functions.successResponse(data,
					req.originalUrl);
			res.json(status);
		} else {
			var status = helpers.init.functions.successResponse(JSON
					.parse(result['0'].data_value), req.originalUrl);
			res.json(status);
		}
	});
}

exports.changeNumber = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : "tbl_user"
	});

	if (typeof req.body.contact_no != 'undefined') {
		var params = {
			where : {
				contact_no : req.body.contact_no
			}
		};
		activeRecord.FindOne(params, function(err, result) {
			if (err) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			} else if (typeof result['0'] != 'undefined') {
				var err = "Contact number is allready exists.";
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			} else {
				var save = {
					load : {
						contact_no : req.body.contact_no
					},
					where : {
						id : req.params.id
					}
				};
				activeRecord.Save(save, function(err, result) {
					if (err) {
						console.log(err);
						var status = helpers.init.functions.errorResponse(err,
								req.originalUrl);
						res.json(status);
					} else {
						var status = helpers.init.functions.successResponse([],
								req.originalUrl);
						res.json(status);
					}
				});
			}
		});
	} else {
		var err = "Data not posted.";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.cityLocation = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : "tbl_location"
	});

	var params = {
		where : {
			type_id : constants.LOCATION_TYPE_PARTNER,
			state_id : constants.STATE_ACTIVE
		},
		select : "id, city, latitude, longitude"
	};

	activeRecord.FindAll(params, function(err, result) {
		if (err || (result.length <= 0)) {
			console.log(err);
			var err = "Cities not found.";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		} else {
			var data = jsonData.json.cityJson(result);
			var status = helpers.init.functions.successResponse(data,
					req.originalUrl);
			res.json(status);
		}
	});
}

exports.confirmOtp = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	try {
		if (req.body.email !== undefined && req.body.otp !== undefined) {
			var activeRecord = new ActiveRecord({
				conn : conn,
				table : 'tbl_user'
			});
			var params = {
				where : {
					'email' : req.body.email,
					'binary' : {
						'activation_key' : req.body.otp
					}
				}
			};

			activeRecord.FindOne(params, function(err, result) {
				if (err || (result['0'] === undefined)) {
					console.log(err);
					var err = "OTP not match.";
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					var uId = result['0'].id;
					var save = {
						load : {
							activation_key : null
						},
						where : {
							'email' : req.body.email
						}
					};
					activeRecord.Save(save, function(err, result) {
						if (err) {
							console.log(err);
							var status = helpers.init.functions.errorResponse(
									err, req.originalUrl);
							status['userId'] = uId;
							res.json(status);
						} else {
							var status = helpers.init.functions
									.successResponse([ {
										email : req.body.email
									} ], req.originalUrl);
							status['userId'] = uId;
							res.json(status);
						}
					});
				}
			});
		} else {
			var err = "OTP not send.";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is Missing.";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.forgotPassword = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var randomNo = helpers.init.functions.random(6);

	try {
		if (req.body.email !== undefined) {
			var activeRecord = new ActiveRecord({
				conn : conn,
				table : 'tbl_user'
			});
			var params = {
				load : {
					'activation_key' : randomNo
				},
				where : {
					'email' : req.body.email
				}
			};
			var MailerObj = new Mailer({
				res : res
			});
			var tp = path.join(__dirname,
					'/../../templates/forgot-password.html');

			// var
			var baseUrl = req.protocol + '://' + req.get('host');

			var img = baseUrl + "/img/template.jpg";

			var userInfo = {
				email : req.body.email,
				logoFile : img,
				randomNo : randomNo
			};
			activeRecord.Save(params, function(err, result) {
				if (err) {
					console.log(err);
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else if (result.affectedRows == 0) {
					var err = "Email not registered.";
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					templates.render(tp, userInfo, function(err, html, text,
							subject) {
						if (err) {
							console.log(err);
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(err);
						} else {
							var mailOptions = {
								to : req.body.email,
								subject : "Recover Password",
								html : html
							};
							MailerObj.send(mailOptions,
									function(err, response) {
										if (err) {
											var status = helpers.init.functions
													.errorResponse(err,
															req.originalUrl);
											res.json(status);
										} else {
											var status = helpers.init.functions
													.successResponse([ {
														email : req.body.email
													} ], req.originalUrl);
											res.json(status);
										}
									});
						}
					});
				}
			});
		} else {
			var err = "Data not Posted.";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is Missing.";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.upadteEmail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var params = {
		'count' : 'email',
		where : {
			'email' : req.body.email
		}
	};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	activeRecord.Count(params, function(err, result) {
		if (err) {
			console.log(err);
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			status['userId'] = req.params.id;
			res.json(status);
		} else {
			if (result['0'].email > 0) {
				var error = "Email already exists.";
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				status['userId'] = req.params.id;
				res.json(status);
			} else {
				var save = {
					save : {
						'email' : req.body.email
					},
					where : {
						'id' : req.params.id
					}
				};
				activeRecord.Save(save, function(err, result) {
					if (err) {
						var status = helpers.init.functions.errorResponse(err,
								req.originalUrl);
						status['userId'] = req.params.id;
						res.json(status);
					} else {
						var status = helpers.init.functions.successResponse(
								result, req.originalUrl);
						status['userId'] = req.params.id;
						res.json(status);
					}
				});
			}
		}
	});
}

exports.getCardDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var stripe = new Stripe();

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_card_detail'
	});

	stripe.retrieve(req.params.cId, function(err, result) {
		if (err || result == null) {
			console.log(err);
			var msg = (err.message !== undefined) ? err.message : err;
			var status = helpers.init.functions.errorResponse(msg,
					req.originalUrl);
			status['userId'] = req.params.uId;
			res.json(status);
		} else {
			var $json = jsonData.json.cardDetail(result["sources"]["data"]);
			var status = helpers.init.functions.successResponse($json,
					req.originalUrl);
			status['userId'] = req.params.uId;
			res.json(status);
		}
	});
}

exports.removeCard = function(req, res, next) {
	var stripe = new Stripe();
	if (req.body.customer_id && req.body.card_id) {
		var params = {
			cId : req.body.customer_id,
			cardId : req.body.card_id
		};
		stripe.removeCard(params, function(err, result) {
			if (err || result == null) {
				console.log(err);
				var msg = (err.message !== undefined) ? err.message : err;
				var status = helpers.init.functions.errorResponse(msg,
						req.originalUrl);
				res.json(status);
			} else {

				stripe.retrieve(req.body.customer_id, function(err, result) {
					if (err || result == null) {
						console.log(err);
						var msg = (err.message !== undefined) ? err.message
								: err;
						var status = helpers.init.functions.errorResponse(msg,
								req.originalUrl);
						res.json(status);
					} else {
						var $json = jsonData.json
								.cardDetail(result["sources"]["data"]);
						var status = helpers.init.functions.successResponse(
								$json, req.originalUrl);
						res.json(status);
					}
				});
			}
		});
	} else {
		var err = "Data not posted";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		status['userId'] = req.params.uId;
		res.json(status);
	}
}

exports.updateCardDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var stripe = new Stripe({
		token : req.body.number
	});

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_card_detail'
	});

	stripe.cardUpdate({
		token : req.body.number,
		name : req.body.name,
		cId : req.body.customer_id
	}, function(err, result) {
		if (err || result == null) {
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			status['userId'] = req.params.id;
			res.json(status);
		} else {
			var status = helpers.init.functions.successResponse([],
					req.originalUrl);
			status['userId'] = req.params.id;
			res.json(status);
		}
	});
}

exports.cardDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	helpers.init.functions.setDefaultCreateTime(req.body);
	req.body.created_by_id = req.params.id;
	req.body.token = req.body.number;

	var stripe = new Stripe({
		token : req.body.number
	});

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	if (typeof req.body.customer_id == "undefined") {
		stripe.saveCard({
			token : req.body.number
		}, function(err, result) {
			if (err || result == null) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				status['userId'] = req.params.id;
				res.json(status);
			} else {
				var params = {
					load : {
						customer_id : result.id,
						name : req.body.name
					},
					where : {
						id : req.params.id
					}
				};
				activeRecord.Save(params, function(err, result) {
					if (err || result == null) {
						console.log(err);
						var msg = (err.message !== undefined) ? err.message
								: err;
						var status = helpers.init.functions.errorResponse(msg,
								req.originalUrl);
						status['userId'] = req.params.id;
						res.json(status);
					} else {
						var status = helpers.init.functions.successResponse([],
								req.originalUrl);
						status['userId'] = req.params.id;
						res.json(status);
					}
				});
			}
		});
	} else {
		stripe.saveMultipleCard({
			token : req.body.number,
			cId : req.body.customer_id
		}, function(err, result) {
			console.log(err);
			if (err || result == null) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				status['userId'] = req.params.id;
				res.json(status);
			} else {
				var status = helpers.init.functions.successResponse([],
						req.originalUrl);
				status['userId'] = req.params.id;
				res.json(status);
			}
		});
	}
}

exports.login = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	if (req.body) {
		if (req.body.email) {
			if (req.body.password) {
				var params = {
					where : {
						'email' : req.body.email
					}
				};
				var activeRecord = new ActiveRecord({
					conn : conn,
					table : 'tbl_user'
				});
				activeRecord
						.FindOne(
								params,
								function(err, result) {
									if (err) {
										status = error(err);
										res.json(status);
									} else if (typeof result['0'] != 'undefined'
											&& result[0].step != 0) {
										var error = "Please Complete you signup details.";
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										status['userId'] = result['0'].id;
										status['step'] = result['0'].step;
										res.json(status);
									} else {
										DATABASE.connection.UserTable
												.getUserByEmail(
														conn,
														req.body.email,
														function(err, result) {

															if (err
																	|| result == []) {
																console
																		.log(err);
																var error = "Incorrect Email.";
																var status = helpers.init.functions
																		.errorResponse(
																				error,
																				req.originalUrl);
																res
																		.json(status);
															} else if (typeof result['0'] != 'undefined') {

																var obj = req.body;
																var userData = result;
																if (passwordHash
																		.verify(
																				obj.password,
																				userData['0'].password)) {

																	var auth = helpers.init.functions
																			.random(35);

																	var ob = {
																		auth_code : auth,
																		device_token : obj.device_token,
																		create_user_id : userData['0'].id,
																		type_id : obj.type
																	};
																	var authData = helpers.init.database
																			.setData(helpers.init.functions
																					.setDefaultCreateUpdateTime(ob));

																	DATABASE.connection.AuthSession
																			.newSession(
																					conn,
																					authData,
																					function(
																							err,
																							result) {
																						if (err) {
																							console
																									.log(err);
																							var error = "Session not create.";
																							var status = helpers.init.functions
																									.errorResponse(
																											error,
																											req.originalUrl);
																							res
																									.json(status);
																						} else {
																							req.session
																									.regenerate(function(
																											err) {
																										req.session.user = jsonData.json
																												.user(userData);
																										req.session.user['0'].auth_code = auth;
																										var data = jsonData.json
																												.user(userData);

																										var status = helpers.init.functions
																												.successResponse(
																														data,
																														req.originalUrl);

																										status['userId'] = data['0'].id;
																										status['auth_code'] = auth;
																										res
																												.json(status);
																									});
																						}
																					});
																} else {
																	var error = "Incorrect Password.";
																	var status = helpers.init.functions
																			.errorResponse(
																					error,
																					req.originalUrl);
																	res
																			.json(status);
																}
															} else {
																var error = "Incorrect Email/Password.";
																var status = helpers.init.functions
																		.errorResponse(
																				error,
																				req.originalUrl);
																res
																		.json(status);
															}
														});
									}
								});
			} else {
				var error = "Password cannot be blank.";
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				res.json(status);
			}
		} else {
			var error = "Email cannot be blank.";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		}
	} else {
		var error = "Email/Password cannot be blank.";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.logout = function(req, res, next) {
	var headers = req.headers;
	var conn = res.locals._admin.db.client;

	if ((headers) && ((typeof headers.auth_code !== 'undefined'))) {

		DATABASE.connection.AuthSession.getSession(conn, headers.auth_code,
				function(err, result) {
					if (err || result == []
							|| typeof result['0'] == 'undefined') {
						console.log(err)

						var error = "Something wrong.";
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					} else {
						var params = {
							where : {
								'create_user_id' : result['0'].create_user_id
							},
						};
						var activeRecord = new ActiveRecord({
							conn : conn,
							table : 'tbl_auth_session'
						});

						activeRecord.Delete(params, function(err, result) {
							if (err) {
								var status = helpers.init.functions
										.errorResponse(err, req.originalUrl);
								res.json(status);
							} else {
								var status = helpers.init.functions
										.successResponse([], req.originalUrl);
								res.json(status);
							}
						});
					}
				});
	} else {
		var error = "Auth code not found.";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.get = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	if (req.params.id) {
		DATABASE.connection.UserTable.getUserById(conn, req.params.id,
				function(err, result) {
					if (err || result == []
							|| typeof result['0'] == 'undefined') {

						var error = "Data not found.";
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					} else {
						var userData = result['0'];
						if (userData.role_id == constants.ROLE_PARTNER) {
							var status = helpers.init.functions
									.successResponse(
											jsonData.json.user(result),
											req.originalUrl);
							res.json(status);
						} else {
							var status = helpers.init.functions
									.successResponse(
											jsonData.json.user(result),
											req.originalUrl);
							res.json(status);
						}
					}
				});
	} else {
		var error = "User not found.";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.checkUser = function(req, res, next) {

	var conn = res.locals._admin.db.client;
	var headers = req.headers;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	try {
		if (req.session && req.session.user) {
			var status = helpers.init.functions.successResponse(jsonData.json
					.user(req.session.user), req.originalUrl);
			status['userId'] = req.session.user['0'].id;
			status['auth_code'] = headers.auth_code;
			res.json(status);
		} else {
			if (typeof headers.auth_code == 'undefined') {
				var error = 'Auth code not found';
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				res.json(status);
			} else {
				DATABASE.connection.AuthSession
						.getSession(
								conn,
								headers.auth_code,
								function(err, result) {
									// console.log(result);
									if (err || result == []) {
										var error = 'Session not found';
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										res.json(status);
									} else {
										if ( typeof headers.device_token == "undefined" ) {
											var error = 'Device Token not found.';
											var status = helpers.init.functions
													.errorResponse(error,
															req.originalUrl);
											res.json(status);
										} else {
											var ob = {
												device_token : headers.device_token,
											};
											var authData = helpers.init.database
													.setData(helpers.init.functions
															.setDefaultCreateUpdateTime(ob));

											DATABASE.connection.AuthSession
													.updateSession(
															conn,
															authData,
															headers.auth_code,
															function(err,
																	result) {
																if (err
																		|| result.affectedRows <= 0) {
																	var error = 'Session Expired';
																	var status = helpers.init.functions
																			.errorResponse(
																					error,
																					req.originalUrl);
																	res
																			.json(status);
																} else {
																	var query = "SELECT create_user_id from tbl_auth_session where BINARY auth_code='"
																			+ headers.auth_code
																			+ "' LIMIT 1";
																	DATABASE.connection
																			.RawQuery(
																					conn,
																					query,
																					function(
																							err,
																							result) {
																						if (err
																								|| result == []) {
																							console
																									.log(err);
																							var error = 'Auth Code not match.';
																							var status = helpers.init.functions
																									.errorResponse(
																											error,
																											req.originalUrl);
																							res
																									.json(status);
																						} else {

																							var params = {
																								where : {
																									'id' : result['0'].create_user_id
																								}
																							};

																							activeRecord
																									.FindOne(
																											params,
																											function(
																													err,
																													result) {

																												if (err
																														|| result == []
																														|| typeof result['0'] == 'undefined') {
																													console
																															.log(err);

																													var error = 'User not found.';
																													var status = helpers.init.functions
																															.errorResponse(
																																	error,
																																	req.originalUrl);
																													res
																															.json(status);
																												} else {
																													var status = helpers.init.functions
																															.successResponse(
																																	jsonData.json
																																			.user(result),
																																	req.originalUrl);
																													var userId = result['0'].id;
																													status['userId'] = userId;
																													status['auth_code'] = headers.auth_code;
																													res
																															.json(status);
																												}
																											});
																						}
																					});
																}
															});
										}
									}
								});
			}
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.helpPage = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var query = "Select * from tbl_page where type_id = '"
			+ constants.TYPE_PAGE_HELP + "' AND state_id = '"
			+ constants.STATE_COMPLETE + "'";

	DATABASE.connection.RawQuery(conn, query, function(err, result) {
		if (err || result.length <= 0) {
			console.log(err);
			var error = "Page not found";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		} else {
			var status = helpers.init.functions.successResponse(jsonData.json
					.pageDetails(result), req.originalUrl);
			// status['auth_code'] = headers.auth_code;
			res.json(status);
		}
	});
}

exports.myLocation = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var id = req.params.id;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	var params = {
		where : {
			id : id
		}
	};

	activeRecord
			.FindOne(
					params,
					function(err, result) {

						if (err || result.length <= 0) {
							console.log(err);
							var error = "User not found.";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else if ( (typeof result['0'].location != "undefined")
								&& ((result['0'].location == '') || (result['0'].location == null))) {
							var error = "Location not found.";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else {
							var locations = (result['0'].location).split(",");
							var arr = {
								location : [],
								partner : []
							};

							locationPartner(locations, arr, function(err,
									result) {
								if (err) {
									var error = "Data not found";
									var status = helpers.init.functions
											.errorResponse(error,
													req.originalUrl);
									res.json(status);
								} else {
									var status = helpers.init.functions
											.successResponse(jsonData.json
													.partnerLocation(arr),
													req.originalUrl);
									res.json(status);
								}
							});
						}
					});

	function locationPartner(location, data, done) {
		async.each(location, function(key, done) {
			var p = {
				where : {
					id : key
				},
				table : 'tbl_location'
			};

			activeRecord.FindOne(p, function(err, result) {
				if (err || typeof result['0'] == "undefined") {
					done(err, null);
					return;
				} else {
					var partner = {
						where : {
							created_by_id : result['0'].created_by_id
						},
						table : 'tbl_partner'
					};
					var ln = result['0'];
					activeRecord.FindOne(partner, function(err, result) {
						if (err || typeof result['0'] == "undefined") {
							console.log(err);
							done(err, null);
							return;
						} else {
							data.location.push(ln);
							data.partner.push(result['0']);
						}
						done();
					});
				}
			});
		}, done);
	}
}

exports.del = function(req, res, next) {
	DATABASE.connection.UserTable.deleteUser(res.locals._admin.db.client,
			req.params.id, function(err, count) {
				if (err) {
					res.json(err);
				} else {
					res.json(count);
				}
			});
}

exports.customerUpdateInfo = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var User = (typeof req.body.User === "undefined") ? req.body
			: req.body.User;
	var updatedata = helpers.init.functions.setDefaultUpdateTime(User);
	var data = helpers.init.database.setData(updatedata);

	DATABASE.connection.UserTable.updateUser(conn, req.params.id, data,
			function(err, result) {
				if (err) {
					var error = "Data not save";
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					if (result.affectedRows > 0) {
						DATABASE.connection.UserTable.getUserById(conn,
								req.params.id, function(err, result) {
									if (err) {
										var error = "User not found";
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										res.json(status);
									} else {
										var status = helpers.init.functions
												.successResponse(jsonData.json
														.user(result),
														req.originalUrl);
										res.json(status);
									}
								});
					} else {
						var error = "User not found";
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					}
				}
			});
}

exports.partnerUpdateInfo = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var userData = helpers.init.functions.setDefaultUpdateTime(req.body.User);
	var partnerData = helpers.init.functions
			.setDefaultUpdateTime(req.body.Partner);
	var User = helpers.init.database.setData(userData);
	var Partner = helpers.init.database.setData(partnerData);

	DATABASE.connection.UserTable
			.updateUser(
					conn,
					req.params.id,
					User,
					function(err, result) {
						if (err) {
							var error = "Data not save";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else {
							if (result.affectedRows > 0) {
								DATABASE.connection.Partner
										.updatePartner(
												conn,
												req.params.id,
												Partner,
												function(err, result) {
													if (err) {
														console.log(err);
														var error = "User not found";
														var status = helpers.init.functions
																.errorResponse(
																		error,
																		req.originalUrl);
														res.json(status);
													} else {
														DATABASE.connection.UserTable
																.getUserById(
																		conn,
																		req.params.id,
																		function(
																				err,
																				result) {
																			if (err) {
																				console
																						.log(err);
																				var error = "User not found";
																				var status = helpers.init.functions
																						.errorResponse(
																								error,
																								req.originalUrl);
																				res
																						.json(status);
																			} else {

																				var allData = {};
																				allData.customer = jsonData.json
																						.user(result);

																				DATABASE.connection.Partner
																						.getPartnerByUserId(
																								conn,
																								req.params.id,
																								function(
																										err,
																										result) {
																									if (err) {
																										console
																												.log(err);
																										var error = "User not found";
																										var status = helpers.init.functions
																												.errorResponse(
																														error,
																														req.originalUrl);
																										res
																												.json(status);
																									} else {
																										var status = helpers.init.functions
																												.successResponse(
																														allData,
																														req.originalUrl);
																										res
																												.json(status);
																									}
																								});
																			}
																		});
													}
												});
							} else {
								console.log(err);
								var error = "User not found";
								var status = helpers.init.functions
										.errorResponse(error, req.originalUrl);
								res.json(status);
							}
						}
					});
}

exports.customerStep2 = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var data = 'contact_no = ' + req.body.contact_no;
	data += ", step = " + constants.CUSTOMER_STEP_TWO;

	var params = {
		count : 'contact_no',
		where : {
			'contact_no' : req.body.contact_no
		}
	};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	activeRecord
			.Count(
					params,
					function(err, result) {
						if (err != null) {
							console.log(err);
							var status = helpers.init.functions.errorResponse(
									err, req.originalUrl);
							res.json(status);
						} else if (result['0'].contact_no >= 1) {
							console.log(err);
							var error = "Contact number already exists.";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else {
							DATABASE.connection.UserTable
									.updateUser(
											res.locals._admin.db.client,
											req.body.id,
											data,
											function(err, result) {
												if (err) {
													console.log(err);
													var error = "Data not save";
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													res.json(status);
												} else {
													if (result.affectedRows > 0) {
														DATABASE.connection.UserTable
																.getUserById(
																		res.locals._admin.db.client,
																		req.body.id,
																		function(
																				err,
																				result) {
																			if (err) {
																				console
																						.log(err);
																				var error = "User not found";
																				var status = helpers.init.functions
																						.errorResponse(
																								error,
																								req.originalUrl);
																				res
																						.json(status);
																			} else {
																				var status = helpers.init.functions
																						.successResponse(
																								jsonData.json
																										.user(result),
																								req.originalUrl);
																				res
																						.json(status);
																			}
																		});
													} else {
														console.log(err);
														var error = "User not found";
														var status = helpers.init.functions
																.errorResponse(
																		error,
																		req.originalUrl);
														res.json(status);
													}
												}
											});
						}
					});
}

exports.customerStep3 = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	if (typeof req.body.id != "undefined") {
		var data = "location = '" + req.body.location + "'";
		data += ", step = " + constants.CUSTOMER_STEP_THREE;
		DATABASE.connection.UserTable
				.updateUser(
						res.locals._admin.db.client,
						req.body.id,
						data,
						function(err, result) {
							if (err) {
								console.log(err);
								var error = "Data not save";
								var status = helpers.init.functions
										.errorResponse(error, req.originalUrl);
								res.json(status);
							} else {
								if (result.affectedRows > 0) {
									DATABASE.connection.UserTable
											.getUserById(
													res.locals._admin.db.client,
													req.body.id,
													function(err, result) {
														if (err) {
															var error = "User not found";
															var status = helpers.init.functions
																	.errorResponse(
																			error,
																			req.originalUrl);
															res.json(status);
														} else {
															var status = helpers.init.functions
																	.successResponse(
																			jsonData.json
																					.user(result),
																			req.originalUrl);
															res.json(status);
														}
													});
								} else {
									var error = "User not found";
									var status = helpers.init.functions
											.errorResponse(error,
													req.originalUrl);
									res.json(status);
								}
							}
						});
	} else {
		var error = "User not found";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.changePassword = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	if (typeof req.body != "undefined"
			&& typeof req.body.password != "undefined"
			&& typeof req.body.id != "undefined") {
		req.body.password = passwordHash.generate(req.body.password);

		var data = "password = '" + req.body.password + "'";

		DATABASE.connection.UserTable.updateUser(conn, req.body.id, data,
				function(err, result) {
					if (err || result.affectedRows == 0) {
						var status = helpers.init.functions.errorResponse(err,
								req.originalUrl);
						res.json(status);
					} else {
						var obj = {
							success : "Password changed successfully."
						};
						var status = helpers.init.functions.successResponse([],
								req.originalUrl, obj);
						res.json(status);
					}
				});
	} else {
		var error = "Data not posted";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.partnerMapLocation = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	console.log(req.body);

	var data = {
		lat : req.body.lat,
		lng : req.body.lng,
		zipcode : req.body.zipcode,
	};

	var loc = {
		partner : [],
		location : []
	};

	DATABASE.connection.Location.nearMeLocation(conn, data, function(err,
			result) {
		var location = result;
		var results;
		if (result.length > 0) {
			locationPartner(location, loc, function(err, result) {
				if (err) {
					var error = "Data not found";
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					var status = helpers.init.functions
							.successResponse(
									jsonData.json.partnerLocation(loc),
									req.originalUrl);
					res.json(status);
				}
			});
		} else {
			var error = "Data not found";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		}
	});

	function locationPartner(location, data, done) {
		var results = {};

		async.each(location, function(key, done) {
			var sql = "SELECT * from tbl_partner where created_by_id="
					+ key.created_by_id;
			DATABASE.connection.RawQuery(conn, sql, function(err, result) {
				if (err || result['0'] == "undefined") {
					done(err, null);
					return;
				} else {
					data.partner.push(result['0']);
					data.location.push(key);
				}
				done();
			});
		}, done);
	}
}

exports.partnerZipCode = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var data = {
		lat : req.body.lat,
		lng : req.body.lng,
		zipcode : req.body.zipcode,
	};

	DATABASE.connection.Location.nearMeLocation(conn, data, function(err,
			result) {
		if (err || result == []) {
			var error = "Data not found";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		} else {
			var status = helpers.init.functions.successResponse(jsonData.json
					.partnerZipCode(result), req.originalUrl);
			res.json(status);
		}
	});
}

exports.addCard = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	req.body.created_by_id = req.params.id;
	helpers.init.functions.setDefaultCreateTime(req.body);

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	var stripe = new Stripe({
		token : req.body.number
	});

	stripe.saveCard({
		token : req.body.number
	}, function(err, result) {
		if (err || result == null) {
			console.log(err);
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			status['userId'] = req.params.id;
			res.json(status);
		} else {
			var CardDetails = result;
			var saveSteps = {
				load : {
					'step' : constants.CUSTOMER_STEP_COMPLETE,
					'state_id' : constants.STATE_ACTIVE,
					'customer_id' : CardDetails.id
				},
				where : {
					'id' : req.params.id
				},
				table : 'tbl_user'
			};

			activeRecord.Save(saveSteps, function(err, result) {
				if (err || result.affectedRows == 0) {
					console.log(err);
					var error = err;
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					var status = helpers.init.functions.successResponse([],
							req.originalUrl);
					status['userId'] = req.params.id;
					status['step'] = constants.CUSTOMER_STEP_COMPLETE;
					res.json(status);
				}
			});
		}
	});
}

exports.signupComplete = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var data = "step = '" + constants.CUSTOMER_STEP_COMPLETE + "', state_id ="
			+ constants.STATE_ACTIVE;

	DATABASE.connection.UserTable.updateUser(conn, req.params.id, data,
			function(err, result) {
				if (err) {
					console.log(err);
					var error = err;
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					DATABASE.connection.UserTable.getUserById(conn,
							req.params.id, function(err, result) {
								if (err) {
									console.log(err);
									var error = err;
									var status = helpers.init.functions
											.errorResponse(error,
													req.originalUrl);
									res.json(status);
								} else {
									var status = helpers.init.functions
											.successResponse(jsonData.json
													.user(result),
													req.originalUrl);
									status['userId'] = req.params.id;
									res.json(status);
								}
							});
				}
			});
}

exports.customer = function(req, res, next) {
	if (notEmpty(req.body) && notEmpty(req.body.email)) {
		var conn = res.locals._admin.db.client;

		var params = {
			where : {
				'email' : req.body.email
			}
		};
		var activeRecord = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		var p = {
			recursion : {
				'cUniqueId' : "unique_id"
			}
		};

		activeRecord
				.Recursion(
						p,
						function(err, value, result) {
							var uId = value;
							activeRecord
									.FindOne(
											params,
											function(err, result) {
												if (err) {
													var status = helpers.init.functions
															.errorResponse(
																	err,
																	req.originalUrl);
													res.json(status);
												} else if (typeof result[0] != 'undefined'
														&& (result[0].step == null || result[0].step == 0)) {
													var err = "Email '"
															+ req.body.email
															+ "' has already been taken.";
													var error = err;
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													res.json(status);
												} else if (typeof result['0'] != 'undefined'
														&& result[0].step != 0) {
													var error = "Please Complete you signup details.";
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													status['step'] = result[0].step;
													status['userId'] = result[0].id;
													res.json(status);
												} else {
													// var uId = "C"
													// + helpers.init.functions
													// .gerateUniqueKey(6);
													req.body.role_id = constants.ROLE_CUSTOMER;
													req.body.step = constants.CUSTOMER_STEP_ONE;
													req.body.state_id = constants.STATE_INACTIVE;
													req.body.created_on = moment()
															.format(
																	"YYYY-MM-DD HH:mm:ss");
													req.body.updated_on = moment()
															.format(
																	"YYYY-MM-DD HH:mm:ss");
													req.body.unique_id = uId;
													req.body.password = passwordHash
															.generate(req.body.password);

													DATABASE.connection.UserTable
															.customerSignup(
																	res.locals._admin.db.client,
																	helpers.init.database
																			.keyValues(req.body),
																	function(
																			err,
																			result) {
																		if (err) {
																			console
																					.log(err);
																			var status = helpers.init.functions
																					.errorResponse(
																							err,
																							req.originalUrl);
																			res
																					.json(status);
																		} else {
																			if (notEmpty(result.insertId)) {
																				DATABASE.connection.UserTable
																						.getUserById(
																								res.locals._admin.db.client,
																								result.insertId,
																								function(
																										err,
																										result) {
																									var status = helpers.init.functions
																											.successResponse(
																													result,
																													req.originalUrl);
																									status['userId'] = result['0'].id;
																									res
																											.json(status);
																								});
																			} else {
																				var error = "Data not save";
																				var status = helpers.init.functions
																						.errorResponse(
																								error,
																								req.originalUrl);
																				res
																						.json(status);
																			}
																		}
																	});
												}
											});
						});
	} else {
		var error = "No data Posted";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.location = function(req, res, next) {

	var activeRecord = new ActiveRecord({
		conn : res.locals._admin.db.client,
		table : 'tbl_user'
	});

	if (req.body.location !== undefined && req.body.location != '') {
		var locationarray = (req.body.location).split(",");
		var arr = [];

		if (locationarray) {
			for (var i = 0; i <= (locationarray.length - 1); i++) {
				if (arr.indexOf(locationarray[i]) == -1
						&& (locationarray[i] != null || locationarray[i] != "")) {
					arr.push(locationarray[i]);
				}
			}
		}

		var loc = arr.toString();
	} else {
		var loc = req.body.location;
	}

	var params = {
		load : {
			location : loc
		},
		where : {
			id : req.params.id
		}
	};

	activeRecord
			.Save(
					params,
					function(err, result) {
						if (err) {
							console.log(err);
							var error = "Data not save";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else {
							if ((typeof req.body.location != "undefined")
									&& req.body.location == '') {

								var status = helpers.init.functions
										.successResponse([], req.originalUrl);
								res.json(status);

							} else {
								var u = {
									where : {
										id : req.params.id
									}
								};
								activeRecord
										.FindOne(
												u,
												function(err, result) {
													if (err
															|| result.length <= 0) {
														var error = "Locations not found.";
														var status = helpers.init.functions
																.errorResponse(
																		error,
																		req.originalUrl);
														res.json(status);
													} else {
														if (result['0'].location != null
																|| result['0'].location != '') {
															var locations = result['0'].location;

															var sql = "SELECT * from tbl_location where id IN ("
																	+ locations
																	+ ") ";

															activeRecord
																	.RawQuery(
																			sql,
																			function(
																					err,
																					result) {
																				if (err
																						|| result.length <= 0) {
																					console
																							.log(err);
																					var error = "Locations not found.";
																					var status = helpers.init.functions
																							.errorResponse(
																									error,
																									req.originalUrl);
																					res
																							.json(status);
																				} else {
																					var location = result;
																					var sql = "SELECT * from tbl_partner where created_by_id IN  ( SELECT created_by_id from tbl_location where id IN  ("
																							+ locations
																							+ ") ) ";
																					activeRecord
																							.RawQuery(
																									sql,
																									function(
																											err,
																											result) {
																										var loc = {
																											partner : result,
																											location : location
																										};

																										if (err
																												|| result.length <= 0) {
																											var error = "Locations not found.";
																											var status = helpers.init.functions
																													.errorResponse(
																															error,
																															req.originalUrl);
																											res
																													.json(status);
																										} else {
																											var status = helpers.init.functions
																													.successResponse(
																															jsonData.json
																																	.partnerLocation(loc),
																															req.originalUrl);
																											res
																													.json(status);
																										}

																									});
																				}
																			});
														} else {
															var error = "Locations not found.";
															var status = helpers.init.functions
																	.errorResponse(
																			error,
																			req.originalUrl);
															res.json(status);
														}
													}
												});
							}

						}
					});

}

exports.userInfo = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	if (req.params.id) {
		var q = " SELECT unique_id, location, full_name from tbl_user where id = "
				+ req.params.id;
		DATABASE.connection
				.RawQuery(
						conn,
						q,
						function(err, result) {
							//result['1'].unique_id;
							if (err || result == []
									|| typeof result['0'] == 'undefined') {
								console.log(err);
								var error = "User not found.";
								var status = helpers.init.functions
										.errorResponse(error, req.originalUrl);
								res.json(status);
							} else {
								var UserUniqueId = {
									uId : result['0'].unique_id,
									uName : result['0'].full_name
								};
								var loc = result['0'].location;

								var sql = "SELECT address,latitude,longitude,city,state,country,zipcode from tbl_location where id="
										+ loc;
								console.log(sql);
								DATABASE.connection
										.RawQuery(
												conn,
												sql,
												function(err, result) {
													if (err || result == []) {
														console.log(err);
														var error = "Location not found.";
														var status = helpers.init.functions
																.errorResponse(
																		error,
																		req.originalUrl);
														res.json(status);
													} else {
														var userLocations = result;
														var sql = "SELECT unique_id from tbl_user where id IN ( SELECT created_by_id from tbl_location where id="
																+ loc + " )";
														console.log(sql);
														DATABASE.connection
																.RawQuery(
																		conn,
																		sql,
																		function(
																				err,
																				result) {
																			if (err
																					|| result == []) {
																				console
																						.log(err);
																				var error = "User not found.";
																				var status = helpers.init.functions
																						.errorResponse(
																								error,
																								req.originalUrl);
																				res
																						.json(status);
																			} else {
																				var info = jsonData.json
																						.userLocationInfo(
																								userLocations,
																								result);
																				var userInfo = {
																					userName : UserUniqueId.uName,
																					userUniqueId : UserUniqueId.uId,
																					location : info
																				};
																				var status = helpers.init.functions
																						.successResponse(
																								userInfo,
																								req.originalUrl);
																				res
																						.json(status);
																			}
																		});
													}
												});
							}
						});
	} else {
		var error = "Missing required parameter id";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.getlocation = function(req, res, next) {
	if (notEmpty(req.params.uid) == true) {
		DATABASE.connection.Location.getLocationByUserId(
				res.locals._admin.db.client, req.params.uid, function(err,
						result) {
					if (notEmpty(result) == true) {
						var status = helpers.init.functions.successResponse(
								result, req.originalUrl);
						res.json(status);
					} else {
						var error = "No data found.";
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(status);
					}
				});
	} else {
		var error = "Missing required parameter uid";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.partnerLocation = function(req, res, next) {
	DATABASE.connection.UserTable.getPartnerLocation(
			res.locals._admin.db.client, function(err, result) {
				if (notEmpty(result) == true) {
					var status = helpers.init.functions.successResponse(result,
							req.originalUrl);
					res.json(status);
				} else {
					var error = "No data found.";
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				}
			});
}

exports.getMonthlyData = function(req, res, next) {
	var lastYear = moment().subtract(12, 'months').format("YYYY-MM"), i;
	var data = [];

	var activeRecord = new ActiveRecord({
		conn : res.locals._admin.db.client,
		table : 'tbl_user'
	});

	var params = {
		where : {
			created_on : {
				like : lastYear
			}
		}
	};

	activeRecord
			.Count(
					params,
					function(err, result) {
						data.push({
							"key" : "Jan",
							"value" : result['0'].total
						});
						lastYear = moment(lastYear).add(1, 'M').format(
								"YYYY-MM");

						params.where.created_on.like = lastYear;
						activeRecord
								.Count(
										params,
										function(err, result) {
											data.push({
												"key" : "Fab",
												"value" : result['0'].total
											});
											lastYear = moment(lastYear).add(1,
													'M').format("YYYY-MM");
											params.where.created_on.like = lastYear;
											activeRecord
													.Count(
															params,
															function(err,
																	result) {
																data
																		.push({
																			"key" : "Mar",
																			"value" : result['0'].total
																		});
																lastYear = moment(
																		lastYear)
																		.add(1,
																				'M')
																		.format(
																				"YYYY-MM");
																params.where.created_on.like = lastYear;
																activeRecord
																		.Count(
																				params,
																				function(
																						err,
																						result) {
																					data
																							.push({
																								"key" : "Apr",
																								"value" : result['0'].total
																							});
																					lastYear = moment(
																							lastYear)
																							.add(
																									1,
																									'M')
																							.format(
																									"YYYY-MM");
																					params.where.created_on.like = lastYear;
																					activeRecord
																							.Count(
																									params,
																									function(
																											err,
																											result) {
																										data
																												.push({
																													"key" : "May",
																													"value" : result['0'].total
																												});
																										lastYear = moment(
																												lastYear)
																												.add(
																														1,
																														'M')
																												.format(
																														"YYYY-MM");
																										params.where.created_on.like = lastYear;
																										activeRecord
																												.Count(
																														params,
																														function(
																																err,
																																result) {
																															data
																																	.push({
																																		"key" : "Jun",
																																		"value" : result['0'].total
																																	});
																															lastYear = moment(
																																	lastYear)
																																	.add(
																																			1,
																																			'M')
																																	.format(
																																			"YYYY-MM");
																															params.where.created_on.like = lastYear;
																															activeRecord
																																	.Count(
																																			params,
																																			function(
																																					err,
																																					result) {
																																				data
																																						.push({
																																							"key" : "July",
																																							"value" : result['0'].total
																																						});
																																				lastYear = moment(
																																						lastYear)
																																						.add(
																																								1,
																																								'M')
																																						.format(
																																								"YYYY-MM");
																																				params.where.created_on.like = lastYear;
																																				activeRecord
																																						.Count(
																																								params,
																																								function(
																																										err,
																																										result) {
																																									data
																																											.push({
																																												"key" : "Aug",
																																												"value" : result['0'].total
																																											});
																																									lastYear = moment(
																																											lastYear)
																																											.add(
																																													1,
																																													'M')
																																											.format(
																																													"YYYY-MM");
																																									params.where.created_on.like = lastYear;
																																									activeRecord
																																											.Count(
																																													params,
																																													function(
																																															err,
																																															result) {
																																														data
																																																.push({
																																																	"key" : "Sep",
																																																	"value" : result['0'].total
																																																});
																																														lastYear = moment(
																																																lastYear)
																																																.add(
																																																		1,
																																																		'M')
																																																.format(
																																																		"YYYY-MM");
																																														params.where.created_on.like = lastYear;
																																														activeRecord
																																																.Count(
																																																		params,
																																																		function(
																																																				err,
																																																				result) {
																																																			data
																																																					.push({
																																																						"key" : "Oct",
																																																						"value" : result['0'].total
																																																					});
																																																			lastYear = moment(
																																																					lastYear)
																																																					.add(
																																																							1,
																																																							'M')
																																																					.format(
																																																							"YYYY-MM");
																																																			params.where.created_on.like = lastYear;
																																																			activeRecord
																																																					.Count(
																																																							params,
																																																							function(
																																																									err,
																																																									result) {
																																																								data
																																																										.push({
																																																											"key" : "Nov",
																																																											"value" : result['0'].total
																																																										});
																																																								lastYear = moment(
																																																										lastYear)
																																																										.add(
																																																												1,
																																																												'M')
																																																										.format(
																																																												"YYYY-MM");
																																																								params.where.created_on.like = lastYear;
																																																								activeRecord
																																																										.Count(
																																																												params,
																																																												function(
																																																														err,
																																																														result) {
																																																													data
																																																															.push({
																																																																"key" : "Dec",
																																																																"value" : result['0'].total
																																																															});
																																																													status['status'] = constants.API_SUCCESS;
																																																													status['error'] = "";
																																																													status['data'] = data;
																																																													status['url'] = req.originalUrl;
																																																													res
																																																															.json(status);
																																																												});
																																																							});
																																																		});
																																													});
																																								});
																																			});
																														});
																									});
																				});
															});
										});
					});
}

// module.exports = router;
