var moment = require('moment');

var auth = require('./auth');
let constants = require('../../lib/app/const');
var passwordHash = require('password-hash');
var _ = require('underscore');

//
var ActiveRecord = require('../../lib/db/activeRecord');
var helpers = require('../../lib/app/helper');
var jsonData = require('../../lib/app/jsonData');
var DATABASE = require('../../lib/app/query');
//

exports.notification = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_notification'
	});
	
	var params = {
		where : {
			'is_read' : constants.NOT_READ
		}
	};

	activeRecord.FindAll(params, function (err, result) {
		var status = {
				success : "",
				error : "",
				date : []
		};
		
		if( err || result == [] || typeof result['0'] == 'undefined' || result['0'] == null  ) {
			status['error'] = constants.API_ERROR;
			status['count'] = '0';
		} else {
			status['success'] = constants.API_SUCCESS;
			status['data'] = jsonData.json.adminNotification(result);
			status['count'] = Object.keys(result).length;
		}
		
		res.json(status);
	} );
}