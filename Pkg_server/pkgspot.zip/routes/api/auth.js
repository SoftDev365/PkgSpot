var helpers = require('../../lib/app/helper');
var moment = require('moment');
var _ = require('underscore');

var auth = {
		auth_code : helpers.init.functions.random(25),
		created_on : moment().format("YYYY-MM-DD HH:mm:ss"),
		updated_on : moment().format("YYYY-MM-DD HH:mm:ss")
};

exports.newSession = function (req, res, next) {
	
	/*var newdata = _.extend(auth, req.body);
	
	var data = helpers.init.database.keyValues(newdata);
	
	res.locals._admin.db.client.query("Insert into tbl_auth_session " + data.keys + " VALUES "
			+ data.values + "", function (err, result) {
		if( err ) return err;
		next();
	});*/
}