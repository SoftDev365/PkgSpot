var DATABASE = require('../../lib/app/query');
let constants = require('../../lib/app/const');
var Mailer = require('../../lib/app/mailer');
var ActiveRecord = require('../../lib/db/activeRecord');
var helpers = require('../../lib/app/helper');
var Helper = require('../../lib/components/helper');
var jsonData = require('../../lib/app/jsonData');
var Stripe = require('../../lib/components/stripe');
var MySql = require('sync-mysql');

var databaseConfig = require('../../config.json');

var notification = require('../../lib/components/notification');
var path = require('path');

var moment = require('moment');
var async = require('async');

var fs = require('fs')
var pdf = require('html-pdf');
var http = require('http');

var EmailTemplates = require('swig-email-templates');
var templates = new EmailTemplates();

exports.pkgConfirmPackageEmail = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_setting'
	});
	console.log("body ==> " + JSON.stringify(req.body));
	var HelperObj = new Helper(req, res, next);
	try {
		if (req.body.filename) {
			var fileName = req.body.filename;
			var MailerObj = new Mailer({
				res : res
			});

			var tp = path.join(__dirname,
					'/../../templates/verify-package.html');
			var baseUrl = req.protocol + '://' + req.get('host');

			var img = baseUrl + "/upload/" + fileName;
			var logo = baseUrl + "/img/pkglogo.png";

			var where = {
				where : {
					data_key : constants.SETTING_KEY_BASIC_CONFIG
				},
				table : 'tbl_setting'
			};

			activeRecord
					.FindOne(
							where,
							function(err, result) {
								if (err) {
									console.log(err);
									var status = helpers.init.functions
											.errorResponse(err, req.originalUrl);
									res.json(status);
								} else {
									if ((typeof result['0'] == 'undefined')) {
										var adminConfig = HelperObj
												.getDefaultAdminConfig();
									} else {
										var adminConfig = JSON
												.parse(result['0'].data_value);
									}

									var userInfo = {
										email : adminConfig.customerServiceEmail,
										image : img,
										logo : logo
									};

									console.log("userInfo => " + userInfo);

									templates
											.render(
													tp,
													userInfo,
													function(err, htmld, text,
															subject) {

														console.log("err => "
																+ err);

														if (err) {
															console.log(err);
															var status = helpers.init.functions
																	.errorResponse(
																			err,
																			req.originalUrl);
															res.json(err);
														} else {
															var mailOptions = {
																to : adminConfig.customerServiceEmail,
																subject : "Verify Package",
																html : htmld
															};
															MailerObj
																	.send(
																			mailOptions,
																			function(
																					err,
																					response) {
																				console
																						.log("err => "
																								+ err);
																				if (err) {
																					var status = helpers.init.functions
																							.errorResponse(
																									err,
																									req.originalUrl);
																					res
																							.json(status);
																				} else {
																					var status = helpers.init.functions
																							.successResponse(
																									[ {
																										email : adminConfig.customerServiceEmail
																									} ],
																									req.originalUrl);
																					res
																							.json(status);
																				}
																			});
														}
													});
								}
							});
		} else {
			var err = "File name missing";
			console.log(err);
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		console.log(err);
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.pkgConfirmEmail = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_setting'
	});

	var HelperObj = new Helper(req, res, next);
	try {
		if (((typeof req.files != "undefined")
				&& (typeof req.files.image != "undefined") && req.files.image != null)) {
			HelperObj.upload(req.files.image, function(err, fileName) {
				if (err) {
					console.log("UPLOAD ERROR");
					console.log(err);
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					var status = helpers.init.functions.successResponse([ {
						filename : fileName
					} ], req.originalUrl);
					res.json(status);
				}
			});
		}
	} catch (err) {
		console.log(err);
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.packageDownload = function(req, res, next) {
	var id = req.params.id;
	var tp = path.join(__dirname, '/../../templates/billing.html');
	var name = "output_" + req.params.id + ".pdf";
	var completeUrl = '/../../templates/' + name;
	var filePath = path.join(__dirname, completeUrl);
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});

	if (fs.existsSync(filePath)) {
		fs.unlinkSync(filePath);
	}

	var options = {
		format : 'Letter'
	};

	var find = {
		where : {
			id : id
		}
	};

	var baseUrl = req.protocol + '://' + req.get('host');

	activeRecord
			.FindOne(
					find,
					function(err, result) {
						if (err || (typeof result['0']) == "undefined") {
							console.log(err);
							var status = helpers.init.functions.errorResponse(
									err, req.originalUrl);
							res.json(err);
						} else {
							var img = baseUrl + "/img/pkglogo.png";
							var opt = result['0'];
							opt.img = img;

							opt.recived_date = moment(opt.recived_date).format(
									"YYYY-MM-DD HH:mm:ss");
							opt.pickedup_date = (opt.pickedup_date) ? moment(
									opt.pickedup_date).format(
									"YYYY-MM-DD HH:mm:ss") : "Pending";
							opt.late_per_pkg = (opt.late_per_pkg) ? opt.late_per_pkg
									: 0;
							opt.pkg_price = (opt.pkg_price) ? opt.pkg_price : 0;
							opt.extra_price = (opt.extra_price) ? opt.extra_price
									: 0;

							templates
									.render(
											tp,
											opt,
											function(err, html, text, subject) {
												if (err) {
													console.log(err);
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													res.json(err);
												} else {
													pdf
															.create(html,
																	options)
															.toFile(
																	filePath,
																	function(
																			err,
																			result) {
																		if (err)
																			return console
																					.log(err);
																		if (fs
																				.existsSync(filePath)) {
																			var donneRecu = req.body;

																			var file = fs
																					.createReadStream(filePath);
																			var stat = fs
																					.statSync(filePath);
																			res
																					.setHeader(
																							'Content-Length',
																							stat.size);
																			res
																					.setHeader(
																							'Content-Type',
																							'application/pdf');
																			res
																					.setHeader(
																							'Content-Disposition',
																							'attachment; filename=invoice.pdf');
																			file
																					.pipe(res);
																		}
																	});
												}
											});
						}
					});
}

exports.packageIndex = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var id = req.params.id;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});

	var query = "SELECT * FROM `tbl_package_history` WHERE `customer_id` = '"
			+ id + "' OR `partner_id` = '" + id + "'  ORDER BY id DESC";

	var packageData = {
		packageHistory : [],
		location : [],
		images : []
	};

	activeRecord.RawQuery(query, function(err, result) {
		if (err || result.length <= 0) {
			var error = "Data not found.";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		} else {
			getLocations(result, packageData, function(err, response) {
				if (err) {
					var error = "Data not found.";
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					var data = jsonData.json.packageHistoryDetails(packageData,
							req);
					var status = helpers.init.functions.successResponse(data,
							req.originalUrl);
					res.json(status);
				}
			});
		}
	});

	function getLocations(packageHistory, packageData, done) {
		async.each(packageHistory, function(history, done) {
			var location = {
				where : {
					created_by_id : history.partner_id
				},
				table : 'tbl_location'
			};

			activeRecord.FindOne(location, function(err, result) {
				if (err || typeof result['0'] == "undefined") {
					done(err, null);
					return;
				} else {
					var parcel = {
						where : {
							package_id : history.id
						},
						table : 'tbl_parcel'
					};
					var ln = result['0'];

					activeRecord.FindAll(parcel, function(err, result) {
						if (err || typeof result['0'] == "undefined") {
							console.log(err);
							done(err, null);
							return;
						} else {
							packageData.location.push(ln);
							packageData.images.push(result);
							packageData.packageHistory.push(history);
						}
						done();
					});
				}
			});
		}, done);
	}
}

exports.packageFilter = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var id = req.params.id;
	if (typeof req.params.date != "undefined") {
		var date = req.params.date;
	} else {
		var date = moment().format("YYYY-MM-DD");
	}

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});

	var query = "SELECT * FROM `tbl_package_history` WHERE ( (`customer_id` = '"
			+ id
			+ "') AND (( CAST(pickedup_date as DATE) = '"
			+ date
			+ "') OR (CAST(recived_date as DATE) = '"
			+ date
			+ "') ) ) OR ( ((CAST(recived_date as DATE) = '"
			+ date
			+ "') OR ( CAST(pickedup_date as DATE) = '"
			+ date
			+ "') ) AND (`partner_id` = '" + id + "') ) ORDER BY id DESC";

	var packageData = {
		packageHistory : [],
		location : [],
		images : []
	};

	activeRecord.RawQuery(query, function(err, result) {
		if (err || result.length <= 0) {
			var error = "Data not found.";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		} else {
			getLocations(result, packageData, function(err, response) {
				if (err) {
					var error = "Data not found.";
					var status = helpers.init.functions.errorResponse(error,
							req.originalUrl);
					res.json(status);
				} else {
					var data = jsonData.json.packageHistoryDetails(packageData,
							req);
					var status = helpers.init.functions.successResponse(data,
							req.originalUrl);
					res.json(status);
				}
			});
		}
	});

	function getLocations(packageHistory, packageData, done) {
		async.each(packageHistory, function(history, done) {
			var location = {
				where : {
					created_by_id : history.partner_id
				},
				table : 'tbl_location'
			};

			activeRecord.FindOne(location, function(err, result) {
				if (err || typeof result['0'] == "undefined") {
					done(err, null);
					return;
				} else {
					var parcel = {
						where : {
							package_id : history.id
						},
						table : 'tbl_parcel'
					};
					var ln = result['0'];

					activeRecord.FindAll(parcel, function(err, result) {
						if (err || typeof result['0'] == "undefined") {
							console.log(err);
							done(err, null);
							return;
						} else {
							packageData.location.push(ln);
							packageData.images.push(result);
							packageData.packageHistory.push(history);
						}
						done();
					});
				}
			});
		}, done);
	}
}

exports.packageMessageDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});
	try {
		if (req.body.qr_code) {
			var params = {
				where : {
					qr_code : req.body.qr_code
				}
			};
			activeRecord
					.FindOne(
							params,
							function(err, result) {
								if (err || (typeof result['0'] == "undefined")) {
									console.log(err);
									var err = 'No data found.';
									var status = helpers.init.functions
											.errorResponse(err, req.originalUrl);
									res.json(status);
								} else {
									var packageData = result;
									var params = {
										where : {
											created_by_id : packageData['0'].partner_id
										},
										table : 'tbl_partner'
									};

									activeRecord
											.FindOne(
													params,
													function(err, result) {
														if (err
																|| (typeof result['0'] == "undefined")) {
															console.log(err);
															var err = 'No Location found.';
															var status = helpers.init.functions
																	.errorResponse(
																			err,
																			req.originalUrl);
															res.json(status);
														} else {
															var partnerData = result;
															var params = {
																where : {
																	created_by_id : packageData['0'].partner_id
																},
																table : 'tbl_location'
															};
															activeRecord
																	.FindOne(
																			params,
																			function(
																					err,
																					result) {
																				if (err
																						|| (typeof result['0'] == "undefined")) {
																					console
																							.log(err);
																					var err = 'No Location found.';
																					var status = helpers.init.functions
																							.errorResponse(
																									err,
																									req.originalUrl);
																					res
																							.json(status);
																				} else {
																					var arr = {
																						partner : partnerData,
																						location : result
																					};
																					var status = helpers.init.functions
																							.successResponse(
																									jsonData.json
																											.partnerLocation(arr),
																									req.originalUrl);
																					res
																							.json(status);
																				}
																			});
														}
													});
								}
							});
		} else {
			var err = 'Data not posted';
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.scaneImage = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	console.log(req.params);
	console.log(req.body);
	try {
		if (req.params.id && (req.body.text != "")) {
			var data = [];
			var s = req.body.text;
			var str = (s).replace(/(?:\r\n|\r|\n)/g, ",");
			var txtArray = str.split(/[ ,.'"]+/);
			console.log(txtArray);
			checkPkgId(txtArray, data, function(err, result) {
				if (data.length > 0 && typeof data['0'] != "undefined") {
					var opt = {
						success : "Success"
					};
					var pkgId = [ {
						pkgid : data['0'].unique_id
					} ];
					var status = helpers.init.functions.successResponse(pkgId,
							req.originalUrl, opt);
					res.json(status);
				} else {
					var err = "Pkg customer not match.";
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				}
			});
		} else {
			var err = "Required parameter id is missing";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		console.log(err);
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}

	function checkPkgId(array, response, cb) {
		async.each(array, function(key, cb) {
			if (key) {
				var strN = key.trim();
				var params = {
					where : {
						unique_id : strN
					},
					table : 'tbl_user'
				};
				activeRecord.FindOne(params, function(err, result) {
					if (err || typeof result['0'] == 'undefined') {
						console.log(err);
						cb(err, null);
						return;
					} else {
						response.push(result['0']);
						cb();
					}
				});
			} else {
				cb();
			}
		}, cb);
	}
}

exports.upload = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var syncConn = new MySql({
		host : 'localhost',
		user : "pkg_spot@pkgspot",
		pass : "",
		database : databaseConfig.mysql.database
	});

	var activeRecord = new ActiveRecord({
		conn : syncConn,
		type : 'sync'
	});

	var activeRecordAsync = new ActiveRecord({
		conn : conn,
		type : 'async'
	});

	console.log("BODY");
	console.log(req.body);

	console.log("FILES");
	console.log(req.files);
	var HelperObj = new Helper(req, res, next);
	var packageCount = [];
	var packageId = 0;
	var uploadedPackage = {};
	var uploadedPackageData = [];
	var countLnth = 0;
	var allData = {};

	req.body.customer_pkg_id = JSON.parse(req.body.customer_pkg_id);

	var customerPkgIds = req.body.customer_pkg_id;
	// var customerPkgIds = [ 'C339551', 'C339551' ];

	if (req.params
			&& ((typeof req.files != "undefined")
					&& (typeof req.files.image != "undefined") && req.files.image != null)
			&& (typeof req.body.customer_pkg_id != "undefined")
			&& (typeof req.body.partner != "undefined")) {

		var amount = {
			where : {
				data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
			},
			table : 'tbl_setting'
		};

		var amountSetting = activeRecord.FindOne(amount);

		if (amountSetting.length > 0) {
			var calculateAmount = JSON.parse(amountSetting['0'].data_value);
		} else {
			var calculateAmount = HelperObj.getDefaultAmoutDetail();
		}

		var partner = syncConn
				.query("SELECT * FROM `tbl_partner` WHERE `created_by_id` = '"
						+ req.params.id + "' LIMIT 1");

		if (partner.length > 0) {
			partner = partner['0'];
			for (key in Object.keys(customerPkgIds)) {
				var args = HelperObj.getArgs();
				args.files = args.upload ? args.upload : null;
				if (packageCount.includes(customerPkgIds[key])) {
					console.log("IF includes");
					var params = {
						where : {
							id : uploadedPackage[customerPkgIds[key]].pkgId
						},
						table : 'tbl_package_history'
					};

					var result = activeRecord.FindOne(params);
					if (result.length > 0) {
						var count = parseInt(1)
								+ parseInt(result['0'].package_count);
						var params = {
							load : {
								package_count : count
							},
							where : {
								id : uploadedPackage[customerPkgIds[key]].pkgId
							},
							table : 'tbl_package_history'
						};
						var updatePackage = activeRecord.Save(params);
						packageId = (uploadedPackage[customerPkgIds[key]].pkgId);
					}
				} else {
					console.log("ELSE includes");
					var customer = syncConn
							.query("SELECT * FROM `tbl_user` WHERE `unique_id` = '"
									+ customerPkgIds[key] + "' LIMIT 1");
					if (customer.length > 0) {
						customer = customer['0'];
						var qrCode = checkQrCode();

						var pkg = {
							cuid : customer.unique_id,
							qr_code : qrCode,
							customer_name : customer.full_name,
							customer_id : customer.id,
							puid : req.body.partner,
							business_name : partner.business_name,
							partner_id : req.params.id,
							package_count : 1,
							recived_date : moment().format(
									"YYYY-MM-DD HH:mm:ss"),
							price_per_pkg : calculateAmount.amountPerPackage,
							late_per_pkg : calculateAmount.lateFeeAmount,
							currency : "USD",
							total_price : 0,
							created_by_id : req.params.id
						};

						helpers.init.functions.setDefaultCreateTime(pkg);

						var params = {
							load : pkg,
							table : 'tbl_package_history'
						};

						var packageData = activeRecord.Save(params);
						if (packageData && (packageData.insertId > 0)) {
							packageCount.push(customer.unique_id);
							uploadedPackage[customerPkgIds[key]] = {
								pkgId : packageData.insertId,
								customer : customer
							};
							uploadedPackageData.push({
								pkgId : packageData.insertId,
								contact_no : customer.contact_no,
								unique_id : customer.unique_id,
								id : customer.id
							});
							packageId = packageData.insertId;
						}
					}
				}
				var obj = {
					package_id : packageId,
					cuid : customer.unique_id,
					puid : req.body.partner,
					state_id : constants.STATE_ACTIVE,
					qr_code : null,
					created_user_id : req.params.id,
				};
				uploadFile(
						args.files.image[key],
						obj,
						function(err, result) {
							if (err) {
								var err = 'Image.';
								var status = helpers.init.functions
										.errorResponse(err, req.originalUrl);
								res.json(status);
							} else {
								var response;
								var sendData = {
									customer : customer,
									// pakData : pakData,
									packageId : packageId
								};
								console
										.log("countLnth == (Object.keys(customerPkgIds).length) => "
												+ countLnth
												+ "=="
												+ (Object.keys(customerPkgIds).length));

								if (++countLnth == (Object.keys(customerPkgIds).length)) {
									console
											.log("uploadPackageData ==> "
													+ JSON
															.stringify(uploadedPackageData));
									var status = helpers.init.functions
											.successResponse(
													uploadedPackageData,
													req.originalUrl);
									res.json(status);
								} else {
									console.log("count ELSE=>");
								}
							}
						});
			}
		} else {
			var err = 'Partner not found';
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} else {
		var err = 'Data not posted';
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}

	function uploadFile(file, obj, cb) {
		HelperObj.upload(file, function(err, fileName) {
			if (err) {
				console.log("UPLOAD ERROR");
				console.log(err);
				cb(err, null);
				return;
			} else {
				obj.title = fileName;
				obj.file = fileName;
				helpers.init.functions.setDefaultCreateTime(obj);
				var params = {
					load : obj,
					table : 'tbl_parcel'
				};
				var saveImage = activeRecord.Save(params);
				cb(null, saveImage);
			}
		});
	}

	function checkQrCode() {
		var qrCode = helpers.init.functions.gerateUniqueKey(7);
		var find = syncConn
				.query("SELECT count(*) as total FROM `tbl_package_history` WHERE `qr_code` = '"
						+ qrCode + "'");
		if (find.total > 0) {
			checkQrCode();
		}
		return qrCode
	}
}

exports.sendMessage = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var syncConn = new MySql({
		host : 'localhost',
		user : "pkg_spot@pkgspot",
		pass : "",
		database : databaseConfig.mysql.database
	});

	var activeRecord = new ActiveRecord({
		conn : syncConn,
		type : 'sync',
		table : 'tbl_package_history'
	});

	var HelperObj = new Helper(req, res, next);

	var countLnth = 0;
	console.log("BODY ==> " + JSON.stringify(req.body));
	if (req.params && (typeof req.body.data != "undefined")) {
		var data = JSON.parse(req.body.data);
		console.log("data JSON OBJECT ==>" + JSON.stringify(data));
		for ( var key in data) {
			console.log("data ==> " + JSON.stringify(data[key]));

			var findOne = {
				where : {
					id : data[key].pkgId
				},
				table : 'tbl_package_history'
			};
			var pakData = activeRecord.FindOne(findOne);
			if ((typeof pakData != "undefined") && pakData.length > 0) {
				var packageHistory = pakData['0'];
				var msg = 'Hi '
						+ packageHistory.customer_name
						+ '. Your '
						+ packageHistory.package_count
						+ ' package has arrived! The following QR code will be required to pick up your package. '
						+ " For Android "
						+ constants.PACKAGE_ANDROID_MOBILE_LINK
						+ packageHistory.qr_code + " For IOS "
						+ constants.PACKAGE_IOS_MOBILE_LINK
						+ packageHistory.qr_code;

				console.log(msg);

				HelperObj.sendMessage(data[key].contact_no, msg, function(err,
						result) {
					console.log(err);
					console.log("SEND MESSAGE");
					if (++countLnth == (Object.keys(data).length)) {
						var status = helpers.init.functions.successResponse([],
								req.originalUrl);
						res.json(status);
					}
				});
			} else {
				var err = 'Package not found.';
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			}
		}
	} else {
		var err = 'Data not posted';
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.varifyQrCode = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_package_history'
	});
	var HelperObj = new Helper(req, res, next);

	console.log("QR_CODE" + req.body);

	try {
		if (req.body.qr_code) {
			var params = {
				where : {
					binary : {
						qr_code : req.body.qr_code
					}
				},
				table : 'tbl_package_history'
			};
			activeRecord
					.FindOne(
							params,
							function(err, result) {
								if (err) {
									var status = helpers.init.functions
											.errorResponse(err, req.originalUrl);
									res.json(status);
								} else if (typeof result['0'] == 'undefined') {
									var err = "Valid QR code required";
									var status = helpers.init.functions
											.errorResponse(err, req.originalUrl);
									res.json(status);
								} else {
									var parcel = result['0'];
									if (result['0'].state_id == constants.STATE_DELIVERED) {
										var err = "Package is already picked up.";
										var status = helpers.init.functions
												.errorResponse(err,
														req.originalUrl);
										status.exists = "1";
										res.json(status);
									} else {
										var packageData = result['0'];

										var userInfo = {
											where : {
												id : packageData.customer_id
											},
											table : "tbl_user"
										};
										activeRecord
												.FindOne(
														userInfo,
														function(err, result) {
															if (err
																	|| (typeof result['0'] == "undefined")) {
																var err = "User not found.";
																var status = helpers.init.functions
																		.errorResponse(
																				err,
																				req.originalUrl);
																res
																		.json(status);
															} else {
																var userData = result['0'];

																var amount = {
																	where : {
																		data_key : constants.SETTING_KEY_PACKAGE_AMOUNT
																	},
																	table : 'tbl_setting'
																};

																activeRecord
																		.FindOne(
																				amount,
																				function(
																						err,
																						result) {
																					if (err
																							|| (typeof result['0'] == "undefined")) {
																						var calculateAmount = HelperObj
																								.getDefaultAmoutDetail();
																					} else {
																						var calculateAmount = JSON
																								.parse(result['0'].data_value);
																					}
																					var delayDay = calculateDate(
																							parcel,
																							calculateAmount);

																					if (packageData.package_count > calculateAmount.freePackage) {
																						var w = {
																							load : {
																								price_per_pkg : calculateAmount.amountPerPackage,
																								late_per_pkg : constants.LATE_FREE,
																								extra_price : constants.EXTRA_AMOUNT,
																								pkg_price : (packageData.package_count * calculateAmount.amountPerPackage),
																								extra_days : delayDay
																							},
																							where : {
																								id : parcel.id
																							}
																						};
																					} else {
																						// free
																						// packages
																						var w = {
																							load : {
																								price_per_pkg : calculateAmount.amountPerPackage,
																								late_per_pkg : constants.LATE_FREE,
																								pkg_price : constants.FREE_PACKAGE,
																								extra_price : constants.EXTRA_AMOUNT,
																								extra_days : delayDay
																							},
																							where : {
																								id : parcel.id
																							}
																						};
																					}

																					if (parseInt(delayDay) > 0) {

																						if (calculateAmount.timeDuration == constants.TIME_DURATION_DAILY) {
																							w.load["extra_price"] = ((parseInt(delayDay)) * parseFloat(calculateAmount.lateFeeAmount));
																						} else {
																							var getWeek = (parseInt(delayDay) / 7);
																							var week = getWeek;

																							if (HelperObj
																									.isFloat(getWeek)) {
																								getWeek = "'"
																										+ getWeek
																										+ "'";
																								var array = getWeek
																										.split(".");
																								array['1'] = array['1']
																										.replace(
																												"'",
																												"");
																								array['0'] = array['0']
																										.replace(
																												"'",
																												"");

																								if (array['1'] > 0) {
																									week = (parseInt(array['0']) + parseInt(1));
																								}
																							}
																							w.load["extra_price"] = ((week) * parseFloat(calculateAmount.lateFeeAmount));
																						}
																						w.load["late_per_pkg"] = calculateAmount.lateFeeAmount;
																					}
																					w.load.total_price = (parseFloat(w.load.pkg_price) + parseFloat(w.load.extra_price));
																					w.load.pickedup_date = moment()
																							.format(
																									"YYYY-MM-DD HH:mm:ss");

																					w.load.state_id = constants.STATE_DELIVERED;

																					w.table = 'tbl_package_history';

																					activeRecord
																							.Save(
																									w,
																									function(
																											err,
																											result) {
																										if (err) {
																											var status = helpers.init.functions
																													.errorResponse(
																															err,
																															req.originalUrl);
																											res
																													.json(status);
																										} else {
																											var vrifyInfo = {
																												where : {
																													created_by_id : packageData.partner_id
																												},
																												table : "tbl_location"
																											};
																											activeRecord
																													.FindOne(
																															vrifyInfo,
																															function(
																																	err,
																																	result) {
																																var vryPkgData = [];
																																if (((result != null) && result.length > 0)) {
																																	for (var i = 0; i <= (result.length - 1); i++) {
																																		if (typeof result[i] != "undefined") {
																																			vryPkgData
																																					.push({
																																						"address" : result[i].address,
																																						"latitude" : result[i].latitude,
																																						"longitude" : result[i].longitude,
																																						"city" : result[i].city,
																																						"country" : result[i].country,
																																						"zipcode" : result[i].zipcode,
																																					});
																																			vryPkgData[i].name = packageData.customer_name;
																																			vryPkgData[i].package_count = packageData.package_count;
																																			vryPkgData[i].cuid = packageData.cuid;
																																		}
																																	}
																																}

																																console
																																		.log("vryPkgData Price ==>"
																																				+ vryPkgData);

																																if (w.load.total_price <= 0) {
																																	var status = helpers.init.functions
																																			.successResponse(
																																					vryPkgData,
																																					req.originalUrl);
																																	res
																																			.json(status);
																																} else {
																																	var stripe = new Stripe();
																																	var opt = {
																																		amount : w.load.total_price,
																																		cId : userData.customer_id,
																																		email : userData.email
																																	};

																																	stripe
																																			.charge(
																																					opt,
																																					function(
																																							err,
																																							result) {
																																						if (err
																																								|| result == null) {
																																							console
																																									.log(err);
																																							var msg = (err.message !== undefined) ? err.message
																																									: err;
																																							var status = helpers.init.functions
																																									.errorResponse(
																																											msg,
																																											req.originalUrl);
																																							res
																																									.json(status);
																																						} else {
																																							var updatePkgData = {
																																								load : {
																																									stripe_detail : JSON
																																											.stringify(result),
																																									is_pay : constants.IS_PAY
																																								},
																																								where : {
																																									id : parcel.id
																																								},
																																								table : "tbl_package_history"
																																							};
																																							activeRecord
																																									.Save(
																																											updatePkgData,
																																											function(
																																													err,
																																													result) {
																																												if (err) {
																																													var status = helpers.init.functions
																																															.errorResponse(
																																																	msg,
																																																	req.originalUrl);
																																													res
																																															.json(status);
																																												} else {

																																													console
																																															.log("vryPkgData  ==>"
																																																	+ vryPkgData);

																																													var status = helpers.init.functions
																																															.successResponse(
																																																	vryPkgData,
																																																	req.originalUrl);
																																													res
																																															.json(status);
																																												}
																																											});

																																						}
																																					});
																																}
																															});
																										}
																									});

																				});
															}
														});

									}
								}
							});
		} else {
			var err = "QR code is missing";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}

	function calculateDate(packageData, amountData) {
		var cDate = moment();
		cDate = cDate.format("YYYY-MM-DD HH:mm:ss");
		csData = new Date(cDate).getTime();
		var rData = new Date(packageData.recived_date).getTime();
		var deff = Math.abs(csData - rData);
		var diffDays = Math.ceil(deff / (1000 * 3600 * 24));

		if (parseInt(diffDays) > parseInt(amountData.validPickUpDay)) {
			return (parseInt(diffDays) - parseInt(amountData.validPickUpDay));
		}

		return constants.NO_EXTRA_DAYS;
	}
}
