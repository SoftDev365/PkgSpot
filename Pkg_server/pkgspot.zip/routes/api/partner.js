var moment = require('moment');

var auth = require('./auth');
let constants = require('../../lib/app/const');
var passwordHash = require('password-hash');
var _ = require('underscore');
var handlebars = require('handlebars');
//
var ActiveRecord = require('../../lib/db/activeRecord');
var helpers = require('../../lib/app/helper');

var jsonData = require('../../lib/app/jsonData');
var DATABASE = require('../../lib/app/query');
var fs = require('fs');
var path = require('path');
var Mailer = require('../../lib/app/mailer');
var Helper = require('../../lib/components/helper');
var Partner = require('../../lib/models/partner');
//

var EmailTemplates = require('swig-email-templates');
var templates = new EmailTemplates();

exports.updatePartnerInfo = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_partner'
	});

	try {
		if (req.body && req.params) {
			var updatedata = helpers.init.functions
					.setDefaultUpdateTime(req.body);

			var params = {
				load : updatedata,
				where : {
					created_by_id : req.params.id
				}
			};

			activeRecord.Save(params, function(err, result) {
				if (err || result.affectedRow == 0) {
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					var status = helpers.init.functions.successResponse([],
							req.originalUrl);
					res.json(status);
				}
			});
		} else {
			var err = "Data not post";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.resendMail = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	if (req.body.email !== undefined) {
		var email = req.body.email;
		var activationKey = helpers.init.functions.random(60);

		var MailerObj = new Mailer({
			res : res
		});

		var tp = path.join(__dirname, '/../../templates/verification.html');
		var email = req.body.email;
		var baseUrl = req.protocol + '://' + req.get('host');

		var img = baseUrl + "/img/template.jpg";

		var where = {
			where : {
				email : email
			}
		};

		activeRecord.FindOne(where, function(err, result) {
			if (err || (typeof result['0'] == 'undefined')) {
				console.log(err);
				err = "Email Not sent.";
				console.log("EMAIL NOT SEND");
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			} else {
				var activationKeyUrl = baseUrl + "/success/"
						+ result['0'].verification_key;
				var userInfo = {
					email : email,
					logoFile : img,
					keyUrl : activationKeyUrl
				};

				templates.render(tp, userInfo, function(err, html, text,
						subject) {
					if (err) {
						console.log(err);
						var status = helpers.init.functions.errorResponse(
								error, req.originalUrl);
						res.json(err);
					} else {
						var mailOptions = {
							to : email,
							subject : "Account Verification",
							html : html
						};
						MailerObj.send(mailOptions, function(err, response) {
							if (err) {
								var status = helpers.init.functions
										.errorResponse(err, req.originalUrl);
								res.json(status);
							} else {
								var status = helpers.init.functions
										.successResponse([ {
											email : req.body.email
										} ], req.originalUrl);
								res.json(status);
							}
						});
					}
				});
			}
		});
	}
}

exports.profile = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	try {
		if (req.params.id !== undefined) {
			var params = {
				where : {
					'id' : req.params.id
				}
			};

			activeRecord.FindOne(params, function(err, result) {
				if (err || result['0'] === undefined) {
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					var partner = {
						where : {
							'created_by_id' : req.params.id
						},
						table : 'tbl_partner'
					};
					var userInfo = result;
					activeRecord.FindOne(partner, function(err, result) {
						if (err || result['0'] === undefined) {
							var status = helpers.init.functions.errorResponse(
									err, req.originalUrl);
							status['userId'] = req.params.id;
							res.json(status);
						} else {
							var info = {
								user : userInfo,
								partner : result
							};

							var userResult = jsonData.json.userPartner(info);

							var status = helpers.init.functions
									.successResponse(userResult,
											req.originalUrl);
							status['userId'] = req.params.id;
							res.json(status);
						}
					});
				}
			});
		} else {
			var err = "Required parameter id is missing";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.updateInfo = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	try {
		if (req.body) {
			var updatedata = helpers.init.functions
					.setDefaultUpdateTime(req.body);

			var params = {
				load : {
					updated_on : req.body.updated_on
				},
				where : {
					id : req.params.id
				}
			};

			if (req.body.full_name) {
				params.load.full_name = req.body.full_name;
			}
			if (req.body.contact_no) {
				params.load.contact_no = req.body.contact_no;
			}

			var partner = {
				load : {
					updated_on : req.body.updated_on
				},
				where : {
					created_by_id : req.params.id
				},
				table : "tbl_partner"
			};

			if (req.body.business_name) {
				partner.load.business_name = req.body.business_name;
			}
			if (req.body.operating_as) {
				partner.load.operating_as = req.body.operating_as;
			}
			if (req.body.position) {
				partner.load.position = req.body.position;
			}
			if (req.body.website) {
				partner.load.website = req.body.website;
			}
			if (req.body.days_of_service) {
				partner.load.days_of_service = req.body.days_of_service;
			}

			var location = {
				load : {
					updated_on : req.body.updated_on
				},
				where : {
					created_by_id : req.params.id
				},
				table : "tbl_location"
			};

			if (req.body.address) {
				params.load.address = req.body.address;
				location.load.address = req.body.address;
			}
			if (req.body.city) {
				params.load.city = req.body.city;
				location.load.city = req.body.city;
			}
			if (req.body.state) {
				params.load.state = req.body.state;
				location.load.state = req.body.state;
			}
			if (req.body.zipcode) {
				params.load.zipcode = req.body.zipcode;
				location.load.zipcode = req.body.zipcode;
			}
			if (req.body.latitude) {
				params.load.latitude = req.body.latitude;
				location.load.latitude = req.body.latitude;
			}
			if (req.body.longitude) {
				params.load.longitude = req.body.longitude;
				location.load.longitude = req.body.longitude;
			}

			activeRecord.Save(params, function(err, result) {
				if (err || result.affectedRow == 0) {
					console.log(err);
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					status['userId'] = req.params.id;
					res.json(status);
				} else {
					activeRecord.Save(partner, function(err, result) {
						if (err || result.affectedRow == 0) {
							console.log(err);
							var status = helpers.init.functions.errorResponse(
									err, req.originalUrl);
							status['userId'] = req.params.id;
							res.json(status);
						} else {
							activeRecord.Save(location,
									function(err, result) {
										if (err || result.affectedRow == 0) {
											console.log(err);
											var status = helpers.init.functions
													.errorResponse(err,
															req.originalUrl);
											status['userId'] = req.params.id;
											res.json(status);
										} else {
											var status = helpers.init.functions
													.successResponse([],
															req.originalUrl);
											status['userId'] = req.params.id;
											res.json(status);
										}
									});
						}
					});
				}
			});
		} else {
			var err = "Data not post";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.completeSignup = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	try {
		if (req.params.id && req.params.id !== null) {
			var params = {
				load : {
					'step' : constants.CUSTOMER_STEP_COMPLETE,
					'state_id' : constants.STATE_INACTIVE,
				},
				where : {
					'id' : req.params.id
				}
			};

			activeRecord.Save(params, function(err, result) {
				if (err || result.affectedRow == 0) {
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					res.json(status);
				} else {
					var opt = {
						success : "Your account is successfully created."
					};
					var status = helpers.init.functions.successResponse([],
							req.originalUrl, opt);
					res.json(status);
				}
			});
		} else {
			var err = "Required parameter not send.";
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		}
	} catch (err) {
		var err = "Data is missing?";
		var status = helpers.init.functions.errorResponse(err, req.originalUrl);
		res.json(status);
	}
}

exports.partnerSignup = function(req, res, next) {
	var conn = res.locals._admin.db.client;

	helpers.init.functions.setDefaultCreateTime(req.body);
	var params = {
		load : {
			'full_name' : req.body.full_name,
			'password' : passwordHash.generate(req.body.password),
			'email' : req.body.email,
			'contact_no' : req.body.contact_no,
			'city' : req.body.city,
			'state' : req.body.state,
			'zipcode' : req.body.zipcode,
			'address' : req.body.address,
			'step' : constants.PARTNER_STEP_ONE,
			'latitude' : (typeof req.body.latitude != "undefined") ? req.body.latitude
					: null,
			'longitude' : (typeof req.body.longitude != "undefined") ? req.body.longitude
					: null,
			'role_id' : constants.ROLE_PARTNER,
			'state_id' : constants.STATE_INACTIVE,
			'created_on' : req.body.created_on,
			'customer_id' : (typeof req.body.customer_id != "undefined") ? req.body.customer_id
					: null,
			'location' : (typeof req.body.location != "undefined") ? req.body.location
					: null,
		}
	};

	var partnerDetail = {
		load : {
			'business_name' : req.body.business_name,
			'operating_as' : req.body.operating_as,
			'position' : req.body.position,
			'website' : req.body.website,
			'days_of_service' : JSON.stringify(req.body.days_of_service),
			'created_on' : req.body.created_on
		},
		table : 'tbl_partner',
	};
	var noti = {
		load : {
			'message' : 'New Signup by ' + req.body.full_name,
			'created_on' : req.body.created_on
		},
		table : 'tbl_notification'
	}
	var p = {
		recursion : {
			'pUniqueId' : "unique_id"
		}
	};
	var find = {
		where : {
			'email' : req.body.email
		}
	};

	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	activeRecord
			.Recursion(
					p,
					function(err, value, result) {
						var uId = value;
						activeRecord
								.FindOne(
										find,
										function(err, result) {
											if (err) {
												console.log(err);
												var status = helpers.init.functions
														.errorResponse(err,
																req.originalUrl);
												res.json(status);
											} else if (result != []
													&& typeof result['0'] !== 'undefined') {
												if (result['0'].step == constants.PARTNER_STEP_ONE) {
													var error = "Email Already Exists";
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													status['step'] = result['0'].step;
													res.json(status);
												} else {
													var error = "Please Complete you signup details";
													var status = helpers.init.functions
															.errorResponse(
																	error,
																	req.originalUrl);
													status['step'] = result['0'].step;
													status['userId'] = result['0'].id;
													res.json(status);
												}
											} else {
												params.load.unique_id = uId;
												activeRecord
														.Save(
																params,
																function(err,
																		result) {
																	if (err) {
																		console
																				.log(err);
																		var status = helpers.init.functions
																				.errorResponse(
																						err,
																						req.originalUrl);
																		res
																				.json(status);
																	} else {
																		partnerDetail.load.created_by_id = result.insertId;
																		var userId = result.insertId;
																		activeRecord
																				.Save(
																						partnerDetail,
																						function(
																								err,
																								resu) {
																							if (err
																									|| result.insertId == 0) {
																								console
																										.log(err);
																								var status = helpers.init.functions
																										.errorResponse(
																												err,
																												req.originalUrl);
																								res
																										.json(status);
																							} else {
																								var params = {
																									load : {
																										'city' : req.body.city,
																										'type_id' : constants.LOCATION_TYPE_PARTNER,
																										'state_id' : constants.STATE_INACTIVE,
																										'zipcode' : req.body.zipcode,
																										'address' : req.body.address,
																										'latitude' : (typeof req.body.latitude != "undefined") ? req.body.latitude
																												: null,
																										'longitude' : (typeof req.body.longitude != "undefined") ? req.body.longitude
																												: null,
																										'created_on' : req.body.created_on
																									},
																									table : 'tbl_location'
																								};
																								params.load.created_by_id = userId;
																								activeRecord
																										.Save(
																												params,
																												function(
																														err,
																														result) {
																													if (err) {
																														var status = helpers.init.functions
																																.errorResponse(
																																		err,
																																		req.originalUrl);
																														res
																																.json(status);
																													} else {
																														noti.load.created_by_id = result.insertId;
																														noti.load.model_id = result.insertId;
																														activeRecord
																																.Save(
																																		noti,
																																		function(
																																				err,
																																				result) {
																																			if (err) {
																																				var status = helpers.init.functions
																																						.errorResponse(
																																								err,
																																								req.originalUrl);
																																				res
																																						.json(status);
																																			} else {
																																				var status = helpers.init.functions
																																						.successResponse(
																																								result,
																																								req.originalUrl);
																																				status['userId'] = partnerDetail.load.created_by_id;
																																				res
																																						.json(status);
																																			}
																																		});
																													}
																												});
																							}
																						});
																	}
																});
											}
										});
					});
}

exports.partnerStep2 = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	console.log(req.body);
	helpers.init.functions.setDefaultUpdateTime(req.body);
	var activationKey = helpers.init.functions.random(60);
	var step = {
		load : {
			'step' : constants.PARTNER_STEP_TWO,
			'verification_key' : activationKey
		},
		where : {
			'id' : req.params.id
		},
		table : 'tbl_user'
	};
	var message = {
		load : {
			'marketing_message' : req.body.marketing_message
		},
		where : {
			'created_by_id' : req.params.id
		},
		table : 'tbl_partner'
	};
	var params = {
		where : {
			'created_by_id' : req.params.id
		},
		table : 'tbl_partner'
	};
	var email = {
		where : {
			'id' : req.params.id
		},
		table : 'tbl_user'
	};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	activeRecord
			.FindOne(
					params,
					function(err, result) {
						if (err) {
							console.log(err);
							var error = "User Not found.";
							var status = helpers.init.functions.errorResponse(
									error, req.originalUrl);
							res.json(status);
						} else {
							activeRecord
									.Save(
											step,
											function(err, result) {
												if (err || result == []) {
													console.log(err);
													var status = helpers.init.functions
															.errorResponse(
																	err,
																	req.originalUrl);
													res.json(status);
												} else {
													activeRecord
															.Save(
																	message,
																	function(
																			err,
																			result) {
																		if (err) {
																			console
																					.log(err);
																			var status = helpers.init.functions
																					.errorResponse(
																							err,
																							req.originalUrl);
																			res
																					.json(status);
																		} else {
																			activeRecord
																					.FindOne(
																							email,
																							function(
																									err,
																									result) {
																								if (err
																										|| result['0'] === undefined) {
																									console
																											.log(err);
																									var status = helpers.init.functions
																											.errorResponse(
																													err,
																													req.originalUrl);
																									res
																											.json(status);
																								} else {
																									var MailerObj = new Mailer(
																											{
																												res : res
																											});

																									var tp = path
																											.join(
																													__dirname,
																													'/../../templates/verification.html');
																									var email = result['0'].email;
																									var step = result['0'].step;
																									// var

																									var baseUrl = req.protocol
																											+ '://'
																											+ req
																													.get('host');
																									var activationKeyUrl = baseUrl
																											+ "/success/"
																											+ activationKey;

																									var img = baseUrl
																											+ "/img/template.jpg";
																									var userInfo = {
																										email : email,
																										logoFile : img,
																										keyUrl : activationKeyUrl
																									};
																									templates
																											.render(
																													tp,
																													userInfo,
																													function(
																															err,
																															html,
																															text,
																															subject) {
																														if (err) {
																															console
																																	.log(err);
																															var status = helpers.init.functions
																																	.errorResponse(
																																			error,
																																			req.originalUrl);
																															res
																																	.json(err);
																														} else {
																															var mailOptions = {
																																to : email,
																																subject : "Account Verification",
																																html : html
																															};
																															MailerObj
																																	.send(
																																			mailOptions,
																																			function(
																																					err,
																																					response) {
																																				console
																																						.log("SEND MAIL");
																																				if (err) {
																																					var status = helpers.init.functions
																																							.errorResponse(
																																									err,
																																									req.originalUrl);
																																					status['step'] = step;
																																					res
																																							.json(status);
																																				} else {
																																					var status = helpers.init.functions
																																							.successResponse(
																																									[ {
																																										email : email
																																									} ],
																																									req.originalUrl);
																																					status['step'] = step;
																																					res
																																							.json(status);
																																				}
																																			});
																														}
																													});
																								}
																							});
																		}
																	});
												}
											});
						}
					});
}

exports.emailVerify = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	if (req.params.id !== undefined) {
		var params = {
			where : {
				'id' : req.params.id
			}
		}
		var activeRecord = new ActiveRecord({
			conn : conn,
			table : 'tbl_user'
		});

		activeRecord.FindOne(params, function(err, result) {
			if (err || result['0'] == undefined) {
				console.log(err);
				var status = helpers.init.functions.errorResponse(err,
						req.originalUrl);
				res.json(status);
			} else {
				if (result['0'].email_verified == constants.EMAIL_VERIFY) {
					var status = helpers.init.functions.successResponse(result,
							req.originalUrl);

					status['step'] = result['0'].step;
					status['userId'] = result['0'].id;
					status['data'] = result['0'].email;
					res.json(status);
				} else {
					var err = "Please verify your account.";
					var status = helpers.init.functions.errorResponse(err,
							req.originalUrl);
					status['step'] = result['0'].step;
					status['userId'] = result['0'].id;
					status['data'] = result['0'].email;
					res.json(status);
				}
			}
		});
	} else {
		var error = "Missing argument.";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}

exports.terms = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var params = {
		where : {
			type_id : req.params.type
		},
		table : 'tbl_page'
	};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	activeRecord.FindAll(params, function(err, result) {
		if (err) {
			console.log(err);
			var status = helpers.init.functions.errorResponse(err,
					req.originalUrl);
			res.json(status);
		} else {
			var status = helpers.init.functions.successResponse(jsonData.json
					.pageDetails(result), req.originalUrl);
			res.json(status);
		}
	});
}

exports.login = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	helpers.init.functions.setDefaultCreateTime(req.body);
	var auth = helpers.init.functions.random(35);
	if (req.body) {
		if (req.body.email) {
			if (req.body.password) {
				var params = {
					where : {
						'email' : req.body.email
					}
				};
				var auth_sess = {
					load : {
						auth_code : auth,
						device_token : (req.body.device_token !== undefined) ? req.body.device_token
								: null,
						type_id : (req.body.type !== undefined) ? req.body.type
								: null,
						created_on : req.body.created_on
					},
					table : 'tbl_auth_session'
				}
				var activeRecord = new ActiveRecord({
					conn : conn,
					table : 'tbl_user'
				});

				activeRecord
						.FindOne(
								params,
								function(err, result) {
									if (err || result['0'] === undefined) {
										console.log(err);
										var error = "Incorrect Email.";
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										res.json(status);
									} else if (typeof result['0'] != 'undefined'
											&& result[0].step != 0) {
										var error = "Please Complete you signup details.";
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										status['userId'] = result['0'].id;
										status['step'] = result['0'].step;
										res.json(status);
									} else if (typeof result['0'] != 'undefined'
											&& result[0].state_id == constants.STATE_INACTIVE) {
										var error = "Your account is not verify please contact to customer service for more information.";
										var status = helpers.init.functions
												.errorResponse(error,
														req.originalUrl);
										status['userId'] = result['0'].id;
										status['step'] = result['0'].step;
										res.json(status);
									} else {
										if (passwordHash.verify(
												req.body.password,
												result['0'].password)) {
											auth_sess.load.create_user_id = result['0'].id;
											var userInfo = result;
											activeRecord
													.Save(
															auth_sess,
															function(err, value) {
																if (err) {
																	console
																			.log(err);
																	var status = helpers.init.functions
																			.errorResponse(
																					err,
																					req.originalUrl);
																	status['userId'] = userInfo['0'].id;
																	res
																			.json(status);
																} else {

																	var partner = {
																		where : {
																			'created_by_id' : userInfo['0'].id
																		},
																		table : 'tbl_partner'
																	};

																	activeRecord
																			.FindOne(
																					partner,
																					function(
																							err,
																							result) {
																						if (err
																								|| result['0'] === undefined) {
																							var status = helpers.init.functions
																									.errorResponse(
																											err,
																											req.originalUrl);
																							status['userId'] = userInfo['0'].id;
																							res
																									.json(status);
																						} else {
																							var info = {
																								user : userInfo,
																								partner : result
																							};

																							var userResult = jsonData.json
																									.userPartner(info);

																							var status = helpers.init.functions
																									.successResponse(
																											userResult,
																											req.originalUrl);
																							status['userId'] = userInfo['0'].id;
																							status['auth_code'] = auth;
																							res
																									.json(status);
																						}
																					});
																}
															});
										} else {
											var error = "Incorrect Password.";
											var status = helpers.init.functions
													.errorResponse(error,
															req.originalUrl);
											res.json(status);
										}
									}
								});
			} else {
				var error = "Password cannot be blank.";
				var status = helpers.init.functions.errorResponse(error,
						req.originalUrl);
				res.json(status);
			}
		} else {
			var error = "Email cannot be blank.";
			var status = helpers.init.functions.errorResponse(error,
					req.originalUrl);
			res.json(status);
		}
	} else {
		var error = "Email/Password cannot be blank.";
		var status = helpers.init.functions.errorResponse(error,
				req.originalUrl);
		res.json(status);
	}
}
