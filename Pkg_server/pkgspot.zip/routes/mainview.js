let constants = require('../lib/app/const');
exports.get = function(req, res, next) {
	var settings = res.locals._admin.settings, custom = res.locals._admin.custom;
	var connection = res.locals._admin.db.client;
	var tables = [];
	for ( var key in settings) {
		var item = settings[key];
		if (!item.mainview.show || !item.table.pk || item.table.view)
			continue;
		tables.push({
			slug : item.slug,
			name : item.table.verbose
		});
	}

	var views = [];
	for ( var key in settings) {
		var item = settings[key];
		if (!item.mainview.show || !item.table.view)
			continue;
		views.push({
			slug : item.slug,
			name : item.table.verbose
		});
	}

	var customs = [];
	for ( var key in custom) {
		var item = custom[key].app;
		if (!item || !item.mainview || !item.mainview.show)
			continue;
		customs.push({
			slug : item.slug,
			name : item.verbose
		});
	}
	res.locals.tables = !tables.length ? null : {
		items : tables
	};
	res.locals.views = !views.length ? null : {
		items : views
	};
	res.locals.custom = !customs.length ? null : {
		items : customs
	};

	var sql = "SELECT count(*) as total FROM tbl_user WHERE role_id='"
			+ constants.ROLE_CUSTOMER + "'";

	var count = [];
	connection
			.query(
					sql,
					function(err, result) {
						var user = result[0].total;

						var sql = "SELECT count(*) as total FROM tbl_notification";

						connection
								.query(
										sql,
										function(err, result) {
											var notification = result[0].total;
											var sql = "SELECT count(*) as total FROM tbl_user where state_id = 1";

											connection
													.query(
															sql,
															function(err,
																	result) {
																var acitveUser = result[0].total;
																var sql = "SELECT count(*) as total FROM tbl_user where state_id = 0";

																connection
																		.query(
																				sql,
																				function(
																						err,
																						result) {

																					var inacitveUser = result[0].total;
																					
																					var sql = "SELECT count(*) as total FROM tbl_user WHERE role_id='"
																						+ constants.ROLE_PARTNER + "'";
																					
																					connection.query(
																									sql,
																									function(
																											err,
																											result) {
																										var userPartner = result[0].total;
																										var sql = "SELECT count(*) as total FROM tbl_package_history";
																										
																										connection.query(
																														sql,
																														function(
																																err,
																																result) {
																															count = {
																																user : user,
																																partner : userPartner,
																																package : result[0].total,
																																notification : notification,
																																acitveUser : acitveUser,
																																inacitveUser : inacitveUser,
																															};

																															res.locals.total = {
																																count : count,
																															};

																															res.locals.partials = {
																																content : 'mainview'
																															};
																															next();
																														});
																									});
																				});

															});
										});
					});

}
