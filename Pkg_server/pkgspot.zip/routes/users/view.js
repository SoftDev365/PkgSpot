exports.get = function(req, res, next) {
	var result = [];
	if (req.params.id != "undefined") {
		res.locals._admin.db.client.query("Select * from tbl_user where id='"
				+ req.params.id + "'", function(err, result) {
			if (err || result[0] == undefined) {
				res.redirect(res.locals.root + '/404');
			} else {
				var data = result[0];

				res.locals._admin.db.client.query(
						"Select * from tbl_partner where created_by_id='"
								+ req.params.id + "'", function(err, result) {

							res.locals.view = {
								data : data,
								partner : result[0]
							};

							res.locals.breadcrumbs = {
								links : [ {
									url : '/',
									text : res.locals.string.home
								}, {
									url : '/users',
									text : "Users"
								}, {
									active : true,
									text : req.params.id
								} ]
							};

							res.locals.partials = {
								content : 'users/view',
							};
							next();
						});
			}

		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.userDetails = function(req, res, next) {
	var result = [];
	if (req.params.id != "undefined") {
		res.locals._admin.db.client.query("Select * from tbl_user where unique_id='"
				+ req.params.id + "'", function(err, result) {
			if (err || result[0] == undefined) {
				res.redirect(res.locals.root + '/404');
			} else {
				var data = result[0];

				res.locals._admin.db.client.query(
						"Select * from tbl_partner where created_by_id='"
								+ data.id + "'", function(err, result) {

							res.locals.view = {
								data : data,
								partner : result[0]
							};

							res.locals.breadcrumbs = {
								links : [ {
									url : '/',
									text : res.locals.string.home
								}, {
									url : '/users',
									text : "Users"
								}, {
									active : true,
									text : req.params.id
								} ]
							};

							res.locals.partials = {
								content : 'users/view',
							};
							next();
						});
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}
