let constants = require('../../lib/app/const');
var forEach = require('async-foreach').forEach;
var moment = require('moment');
var helper = require('../../lib/app/helper');
var jsonData = require('../../lib/app/jsonData');
var DATABASE = require('../../lib/app/query');
var passwordHash = require('password-hash');
var ActiveRecord = require('../../lib/db/activeRecord');
var fs = require('fs');
var path = require('path');

var status = {};
status['status'] = '1000';
status['error'] = '';
status['data'] = [];

function getArgs(req, res) {
	var args = {
		settings : res.locals._admin.settings,
		db : res.locals._admin.db,
		debug : res.locals._admin.debug,
		log : res.locals._admin.log,
		slug : req.params[0],
		// id : req.params[1] == 'add' ? null : req.params[1].split(','),
		data : req.body,
		upload : req.files,
		upath : res.locals._admin.config.app.upload
	};
	args.name = res.locals._admin.slugs[args.slug];
	return args;
}

var ValidateUser = {
	checkUniqueId : function(db, id, callback) {
		return db.query("select unique_id from tbl_user where role_id='"
				+ constants.ROLE_PARTNER + "'", callback);
	},
	saveUser : function(db, data, callback) {
		console.log("Insert into tbl_user " + data.keys + " VALUES "
				+ data.values + "");
		return db.query("Insert into tbl_user " + data.keys + " VALUES "
				+ data.values + "", callback);
	},
	savePartner : function(db, data, callback) {
		console.log("Insert into tbl_partner " + data.keys + " VALUES "
				+ data.values + "");
		return db.query("Insert into tbl_partner " + data.keys + " VALUES "
				+ data.values + "", callback);
	},
	deleteUser : function(db, id, callback) {
		return db.query("delete from tbl_user where id='" + id
				+ "' AND role_id != 0", callback);
	},
	deleteLocation : function(db, id, callback) {
		return db.query("delete from tbl_location where created_by_id='" + id
				+ "'", callback);
	},
};

var database = {
	keyValues : function(data) {
		var k = '', v = '';
		for ( var key in data) {
			if (typeof key != "undefined") {
				if (key != '' && data[key] != '') {
					k += "`" + key + '`,';

					if (typeof data[key] == 'string') {
						v += '"' + data[key] + '",';
					} else {
						v += data[key] + ',';
					}
				}
			}
		}
		var columns = {
			keys : '(' + k.slice(0, -1) + ')',
			values : '(' + v.slice(0, -1) + ')'
		};
		return columns;
	},
	keys : function(data) {
		var k;
		for ( var key in data) {
			if (typeof key != "undefined") {
				k += key + ',';
			}
		}

		return '(' + k.slice(0, -1) + ')';
	},
	values : function(data) {
		var v;
		for ( var key in data) {
			if (typeof key != "undefined")
				v += data[key] + ',';
		}
		return '(' + v.slice(0, -1) + ')';
	},
};

function gerateUniqueKey(length) {
	return Math.floor(Math.pow(10, length - 1) + Math.random()
			* (Math.pow(10, length) - Math.pow(10, length - 1) - 1));
}

exports.index = function(req, res, next) {
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : res.locals.string.home
		}, {
			url : '/users',
			text : "Users"
		}, {
			active : true,
			text : "Customer"
		} ]
	};

	res.locals.partials = {
		content : 'users',
	};
	next();
}

exports.deleteUserDetail = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	if (req.params && req.params.id != 'undefined') {
		var p = {
			where : {
				'unique_id' : req.params.id
			}
		}
		activeRecord.FindOne(p, function(err, result) {
			if (err || typeof result['0'] == undefined) {
				res.redirect(res.locals.root + '/404');
			} else {
				var params = {
					table : {
						'tbl_user' : {
							where : {
								'id' : result['0'].id
							}
						},
						'tbl_auth_session' : 'tbl_auth_session',
						'tbl_partner' : {
							where : {
								'created_by_id' : result['0'].id
							}
						},
						'tbl_media' : 'tbl_media',
						'tbl_package_history' : {
							where : {
								'created_by_id' : result['0'].id
							}
						},
						'tbl_location' : {
							where : {
								'created_by_id' : result['0'].id
							}
						}
					},
					where : {
						'create_user_id' : result['0'].id
					}
				};

				activeRecord.DeleteRelatedAll(params, function(err, result) {
					if (err) {
						console.log(err);
						res.redirect(res.locals.root + '/404');
					} else {
						res.redirect(res.locals.root + '/users');
					}
				});
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.customerSignup = function(req, res, next) {
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : res.locals.string.home
		}, {
			url : '/users',
			text : "Users"
		}, {
			active : true,
			text : "Customer"
		} ]
	};

	res.locals.partials = {
		content : 'users/customer-form',
	};
	next();
}

exports.adminProfile = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : res.locals.string.home
		}, {
			active : true,
			text : "Admin"
		} ]
	};

	var u = {
		where : {
			role_id : constants.ROLE_ADMIN
		}
	}

	activeRecord.FindOne(u, function(err, result) {
		if (err || result['0'] == undefined) {
			res.redirect(res.locals.root + '/404');
		} else {
			res.locals.view = {
				admin : result['0']
			};

			res.locals.partials = {
				content : 'users/admin-profile',
			};
			next();
		}
	});
}

exports.changePassword = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var response = {};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});

	req.body.password = passwordHash.generate(req.body.password);

	var params = {
		load : {
			password : req.body.password,
		},
		where : {
			id : req.body.uid
		}
	};

	activeRecord.Save(params, function(err, result) {
		if (err) {
			console.log(err);
			response['status'] = constants.API_ERROR;
		} else {
			response['status'] = constants.API_SUCCESS;
			res.json(response);
		}
	});
}

exports.updateAdminInfo = function(req, res, next) {
	var pwd = require('pwd');
	var conn = res.locals._admin.db.client;
	var response = {};
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	var params = {
		load : {
			email : req.body.email,
			zipcode : req.body.zipcode,
			address : req.body.address,
			city : req.body.city,
			contact_no : req.body.contact_no,
			full_name : req.body.full_name
		},
		where : {
			id : req.body.uid
		}
	};

	activeRecord.Save(params, function(err, result) {
		if (err) {
			console.log(err);
			response['status'] = constants.API_ERROR;
		} else {
			var u = {
				where : {
					id : req.body.uid
				}
			};
			activeRecord.FindOne(u, function(err, result) {
				if (err || result.length <= 0) {
					console.log(err);
					response['status'] = constants.API_ERROR;
					res.json(response);
				} else {
					response['status'] = constants.API_SUCCESS;
					response['data'] = result['0'];
					res.json(response);
				}
			});
		}
	});
}

exports.changeState = function(req, res, next) {

	if (req.params.state == constants.STATE_ACTIVE) {
		var state = '0';
	} else {
		var state = '1';
	}

	var data = "state_id = " + state;
	DATABASE.connection.UserTable.updateUser(res.locals._admin.db.client,
			req.params.id, data, function(err, rows) {
				if (err) {
					console.log(err);
					status['status'] = constants.API_ERROR;
					status['error'] = "Data not save";
					status['url'] = 'api/user/change-state';
					status['data'] = [];
					res.json(status);
				} else {
					status['status'] = constants.API_SUCCESS;
					status['error'] = "";
					status['url'] = 'api/user/change-state';
					res.json(status);
				}
			});
}

exports.get = function(req, res, next) {
	res.locals.breadcrumbs = {
		links : [ {
			url : '/',
			text : res.locals.string.home
		}, {
			url : '/users',
			text : "Users"
		}, {
			active : true,
			text : "Partner"
		} ]
	};

	res.locals.partials = {
		content : 'users/partner-form',
	};
	next();
}

exports.deleteuser = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var activeRecord = new ActiveRecord({
		conn : conn,
		table : 'tbl_user'
	});
	if (req.params && req.params.id != 'undefined') {
		var params = {
			table : {
				'tbl_user' : {
					where : {
						'id' : req.params.id
					}
				},
				'tbl_auth_session' : 'tbl_auth_session',
				'tbl_partner' : {
					where : {
						'created_by_id' : req.params.id
					}
				},
				'tbl_media' : 'tbl_media',
				'tbl_package_history' : {
					where : {
						'created_by_id' : req.params.id
					}
				},
				'tbl_location' : {
					where : {
						'created_by_id' : req.params.id
					}
				}
			},
			where : {
				'create_user_id' : req.params.id
			}
		};

		activeRecord.DeleteRelatedAll(params, function(err, result) {
			if (err) {
				console.log(err);
				res.redirect(res.locals.root + '/404');
			} else {
				res.redirect(res.locals.root + '/users');
			}
		});
	} else {
		res.redirect(res.locals.root + '/404');
	}
}

exports.post = function(req, res, next) {
	var conn = res.locals._admin.db.client;
	var args = getArgs(req, res), events = res.locals._admin.events;

	var checkPost = req.body.action;

	if (typeof checkPost.customer != 'undefined') {
		var id = "C" + gerateUniqueKey(6);
	} else {
		var id = "P" + gerateUniqueKey(7);
	}

	var activeRecord = new ActiveRecord({
		conn : conn
	});

	// ValidateUser.checkUniqueId(res.locals._admin.db.client, id, function(err,
	// result) {

	if (typeof req.body.view.tbl_user.records['0'].columns != 'undefined') {

		var col = req.body.view.tbl_user.records['0'].columns;
		col.created_on = moment().format("YYYY-MM-DD HH:mm:ss");
		col.updated_on = moment().format("YYYY-MM-DD HH:mm:ss");
		col.unique_id = id;
		col.step = constants.CUSTOMER_STEP_COMPLETE;
		col['password'] = passwordHash.generate(col.password);

		if (typeof checkPost.customer != 'undefined') {
			col.role_id = constants.ROLE_CUSTOMER;
		} else {
			col.role_id = constants.ROLE_PARTNER;
		}

		col.state_id = constants.STATE_ACTIVE;

		ValidateUser
				.saveUser(
						res.locals._admin.db.client,
						database.keyValues(col),
						function(err, result) {

							if (err) {
								console.log(err);
								if (typeof checkPost.customer != 'undefined') {
									res.locals.breadcrumbs = {
										links : [ {
											url : '/',
											text : res.locals.string.home
										}, {
											url : '/users',
											text : "Customer"
										}, {
											active : true,
											text : "Customer"
										} ]
									};

									res.locals.partials = {
										content : 'users/customer-form',
									};
								} else {
									res.locals.breadcrumbs = {
										links : [ {
											url : '/',
											text : res.locals.string.home
										}, {
											url : '/users',
											text : "Users"
										}, {
											active : true,
											text : "Partner"
										} ]
									};

									res.locals.partials = {
										content : 'users/partner-form',
									};
								}
								next();
							} else {
								if (result) {
									var userId = result.insertId;
									if (typeof checkPost.customer != 'undefined') {
										res.redirect(res.locals.root
												+ '/users/view/'
												+ result.insertId);
									} else {
										var col = req.body.view.tbl_partner.records['0'].columns;
										col.created_on = moment().format(
												"YYYY-MM-DD HH:mm:ss");
										col.updated_on = moment().format(
												"YYYY-MM-DD HH:mm:ss");
										col.state_id = constants.STATE_ACTIVE;
										col.created_by_id = result.insertId;

										ValidateUser
												.savePartner(
														res.locals._admin.db.client,
														database.keyValues(col),
														function(err, result) {

															if (err) {
																ValidateUser
																		.deleteUser(
																				res.locals._admin.db.client,
																				col.created_by_id,
																				function(
																						err,
																						result) {

																					if (err) {
																						res
																								.redirect(res.locals.root
																										+ '/404');
																					} else {
																						res.locals.breadcrumbs = {
																							links : [
																									{
																										url : '/',
																										text : res.locals.string.home
																									},
																									{
																										url : '/users',
																										text : "Users"
																									},
																									{
																										active : true,
																										text : "Partner"
																									} ]
																						};

																						res.locals.partials = {
																							content : 'users/partner-form',
																						};
																						next();
																					}
																				});
															} else {
																var columns = req.body.view.tbl_user.records['0'].columns;
																var params = {
																	load : {
																		address : columns.address,
																		latitude : columns.latitude,
																		longitude : columns.longitude,
																		zipcode : columns.zipcode,
																		country : columns.country,
																		state : columns.state,
																		city : columns.city,
																		created_on : moment()
																				.format(
																						"YYYY-MM-DD HH:mm:ss"),
																		updated_on : moment()
																				.format(
																						"YYYY-MM-DD HH:mm:ss"),
																		state_id : constants.STATE_ACTIVE,
																		type_id : constants.LOCATION_TYPE_PARTNER,
																		created_by_id : userId
																	},
																	table : 'tbl_location'
																};
																activeRecord
																		.Save(
																				params,
																				function(
																						err,
																						result) {
																					console
																							.log(err);
																					res
																							.redirect(res.locals.root
																									+ '/users/view/'
																									+ col.created_by_id);
																				});
															}
														});
									}
								} else {
									res.redirect(res.locals.root + '/404');
								}
							}
						});
	}
	// });
}
