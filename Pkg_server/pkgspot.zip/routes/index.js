exports.auth     = require('./auth' );
exports.login    = require('./login');
exports.success    = require('./success');
exports.notfound = require('./404');
exports.pagination = require('./pagination');

//exports.home = require('./home');
exports.mainview = require('./mainview');
exports.listview = require('./listview');
exports.editview = require('./editview');
exports.deleteview = require('./deleteview');

exports.view = require('./users/view');
exports.users = require('./users/users');

exports.userIndex = require('./users/user-index');

exports.notification = require('./notification/notification');
exports.location = require('./location/location');

exports.packageHistoryAdmin = require('./package-history');

exports.page = require('./page');

exports.setting = require('./setting');

exports.frontend   = require('./frontend');

exports.render   = require('./render');


//Apis
exports.user = require('./api/user');
exports.partner = require('./api/partner');
exports.packageHistory = require('./api/package');
exports.authSession = require('./api/auth');

exports.adminApi = require('./api/admin');