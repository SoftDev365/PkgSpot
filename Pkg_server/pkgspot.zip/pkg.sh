#/bin/bash
myvar=$(ps -A | grep node | wc -l)
echo $myvar
if [ $myvar -gt 0 ]
then
echo "Running"
else
 cd /home/local/TOXSL/asheesh.tehariya/node/pkg-spot/
 forever start -o output_log.log -e error.log -c nodemon app.js
fi
while true
do
 /home/ramesh/pkg.sh
 sleep 5
done

